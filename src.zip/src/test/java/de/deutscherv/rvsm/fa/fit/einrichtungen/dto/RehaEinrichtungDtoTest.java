package de.deutscherv.rvsm.fa.fit.einrichtungen.dto;

import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import de.deutscherv.rvsm.fa.fit.util.StringUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RehaEinrichtungDtoTest {

    private Validator validator;

    @BeforeEach
    public void setUp() {
        final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void testWhenFieldsTooLong() {

        final String strWith51Chars = StringUtils.randomStringGenerator(51);
        final String strWith256Chars = StringUtils.randomStringGenerator(256);
        final String strWith501Chars = StringUtils.randomStringGenerator(501);

        final RehaEinrichtungDto dto = new RehaEinrichtungDto().aresc(strWith256Chars)
                .name(strWith501Chars).email(strWith51Chars).telefonnummer(strWith51Chars);

        final Set<ConstraintViolation<RehaEinrichtungDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(4, violations.size());

    }

    @Test
    void testWhenFieldsValid() {

        final RehaEinrichtungDto dto = new RehaEinrichtungDto().aresc("fbadc5bd").name("Rehamed")
                .email("test@test.de").telefonnummer("70");

        final Set<ConstraintViolation<RehaEinrichtungDto>> violations = validator.validate(dto);

        assertTrue(violations.isEmpty());
    }
}
