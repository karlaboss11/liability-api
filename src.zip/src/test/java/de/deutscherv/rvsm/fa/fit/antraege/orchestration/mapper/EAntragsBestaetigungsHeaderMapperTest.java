package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DefaultProcessorTest;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test eAntrag Bestaetigung Heade-Mapper.
 */
class EAntragsBestaetigungsHeaderMapperTest extends DefaultProcessorTest {

    private final EantragsBestaetigungsHeaderMapper mapper = new EantragsBestaetigungsHeaderMapper();

    /**
     * Test Mapping EantragsBestaetigungDto Header.
     */
    @Test
    @SneakyThrows
    void testBesataetigungMapping() {
        final var message = this.getMessage();
        final var eantragsBestaetigungDTO = new EantragsBestaetigungDTO();
        message.setBody(eantragsBestaetigungDTO);
        message.setHeader(DRVHeader.CORRELATION_ID, "messageId");
        message.setHeader(DRVHeader.ANTRAG_NUTZDATENID, "nutzdatenId");

        final var exchange = getExchange(message);
        mapper.process(exchange);

        final var result = exchange.getMessage().getBody(EantragsBestaetigungDTO.class);

        assertThat(result).isNotNull();
        assertThat(result.getMessageId()).isEqualTo("messageId");
        assertThat(result.getNutzdatenID()).isEqualTo("nutzdatenId");
    }

}
