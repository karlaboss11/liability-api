package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;

import java.util.UUID;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class PDFArchiveProcessorTest extends DefaultProcessorTest {

    @Test
    void createPdfArchivTest() throws Exception {
        final Exchange exchange = getExchange();

        final Antrag antrag = setExchangeMitAntrag(exchange, AntragStatus.STATISTIK_ERFASST);
        final AntragService antragService = Mockito.mock(AntragService.class);
        Mockito.when(antragService.createPdfArchiv(any())).thenReturn(true);
        final PDFArchiveProcessor pDFArchiveProcessor = new PDFArchiveProcessor(antragService);
        pDFArchiveProcessor.process(exchange);
        final Antrag processedAntrag = (Antrag) exchange.getMessage().getBody();

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange, final AntragStatus antragStatus) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(antragStatus).build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }
}
