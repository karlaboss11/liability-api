package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.jms.MessagingException;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.FehlerEintrag;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurVorgangScheduledService;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.testdaten.TestRehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.mockito.InjectSpy;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import lombok.SneakyThrows;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.spi.RouteController;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test Papierantragsrouten.
 */
@QuarkusTest
class PapierantragRoutesTest {

    private static WireMockServer wireMockServer;


    @Inject
    private DrvMandant drvMandant;
    @Inject
    private EntityManager entityManager;
    @InjectSpy
    private AufgabeService aufgabeServiceMock;

    @InjectMock
    private RvPurVorgangScheduledService purVorgangScheduledService;

    @Inject
    private CamelContext camelContext;
    private CountDownLatch latch;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void setUpAll() {
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        WireMockStub.disconnect(wireMockServer);
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setup() {
        wireMockServer.resetAll();
        Mockito.lenient().doCallRealMethod()
                .when(aufgabeServiceMock).schliesseAufgabePapierantragErfasst(Mockito.any(), Mockito.any());

        latch = new CountDownLatch(1);
        RouteController routeController = camelContext.getRouteController();

        Set<String> countdownRoutes = Set.of(
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS,
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS
        );
        for (final String route : countdownRoutes) {
            routeController.stopRoute(route);
            AdviceWith.adviceWith(route, camelContext,
                    new AdviceWithRouteBuilder() {
                        @Override
                        public void configure() {
                            weaveAddLast().process(exchange -> latch.countDown());
                        }
                    });
            routeController.startRoute(route);
        }
    }

    /**
     * Test Papierantrserstellung ohne Fehler.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungOhneFehler() {
        final TestPerson harveyDent = TestPerson.HARVEY_DENT;
        setupWiremockKeineFehler(harveyDent);

        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(harveyDent));
        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_CREATED);
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
    }

    /**
     * Test Papierantrserstellung Validierungsfehler.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungWennFehlerValidierungDannKeinAntragGespeichert() {
        final TestPerson peterPan = TestPerson.PETER_PAN;
        setupWiremockKeineFehler(peterPan);

        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(peterPan));
        // DTO manipulieren, damit Validierungsfehler geworfen wird
        dto.getAntrag().setAntragsdatum(LocalDate.now());
        dto.getAntrag().setEingangsdatum(LocalDate.now().minusDays(1));

        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_BAD_REQUEST);
        assertThat(antrag).isNull();
    }

    /**
     * Test Papierantrserstellung SMP.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungWennSelbstmeldeportalClientFehlerDannAntragNichtGespeichert() {
        final TestPerson harveyDent = TestPerson.HARVEY_DENT;
        setupWiremock(harveyDent, new WiremockConfig(false, true, true, true, true, true));
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(harveyDent));

        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_BAD_GATEWAY);
        assertThat(antrag).isNull();
    }

    /**
     * Test Papierantrserstellung Aufgabe schliessen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungWennAufgabeSchliessenFehlerDannStatusVorgangErzeugtUndFehlerPersistiert() {
        final TestPerson harveyDent = TestPerson.HARVEY_DENT;
        setupWiremockKeineFehler(harveyDent);
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(harveyDent));

        Mockito.doThrow(MessagingException.class).when(aufgabeServiceMock)
                .schliesseAufgabePapierantragErfasst(Mockito.any(), Mockito.anyString());

        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.VORGANG_ERZEUGT);

        final Fehler fehler = findFehler(antrag.getUuid());
        assertThat(fehler).isNotNull();
        Assertions.assertThat(fehler.getStatus()).isEqualTo(AntragStatus.VORGANG_ERZEUGT);
    }

    /**
     * Test Papierantrserstellung mit Statistikfehler.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungWennStatistikFehlerDannStatusVorgangErzeugtUndFehlerPersistiert() {
        final TestPerson bobBaumeister = TestPerson.BOB_BAUMEISTER;
        setupWiremock(bobBaumeister, new WiremockConfig(true, true, true, false, true, true));
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));

        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_ABGEFRAGT);

        final Fehler fehler = findFehler(antrag.getUuid());
        assertThat(fehler).isNotNull();
        Assertions.assertThat(fehler.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
    }

    /**
     * Test Papierantrserstellung mit Kontoinformationsfehler.
     */
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungKontoinformationFehler() {
        final TestPerson bobBaumeister = TestPerson.BOB_BAUMEISTER;
        FehlerEintrag fehlerEintrag = FehlerEintrag.builder()
                .statuscode("AF2001").build();
        final KontoinformationResponse fehler = KontoinformationResponse.builder()
                .rvSystemFehler(List.of(fehlerEintrag)).build();
        final ObjectMapper objectMapper = new ObjectMapper();
        stubFor(post(urlPathTemplate("/rvdialog-wartezeitabfrage"))
                .withHeader("Content-Type", new EqualToPattern("application/json", false))
                .willReturn(aResponse().withBody(objectMapper.writeValueAsString(fehler)).withStatus(500)
                        .withHeader("Content-Type", "application/json")));
        setupWiremock(bobBaumeister, new WiremockConfig(true, true, true, true, true, false));
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));
        final Antrag antrag = erstelleAntrag(dto, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT);
    }

    /**
     * Test Papierantrserstellung Entwurf.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungEntwurf() {
        final TestPerson bobBaumeister = TestPerson.BOB_BAUMEISTER;
        setupWiremockKeineFehler(bobBaumeister);
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));

        final Antrag antrag = erstelleEntwurf(dto, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.ENTWURF);
    }

    /**
     * Test Papierantrserstellung mit Fehler beim Entwurf.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungEntwurfFehler() {
        final TestPerson bobBaumeister = TestPerson.BOB_BAUMEISTER;
        setupWiremockKeineFehler(bobBaumeister);
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));
        dto.getVersicherter().setVsnr("");
        final Antrag antrag = erstelleEntwurf(dto, HttpStatus.SC_BAD_REQUEST);
        assertThat(antrag).isNull();
    }

    /**
     * Test Papierantrserstellung bei vorhendenem Entwurf.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testePapierantragsErstellungBeiVorhandenemEntwurf() {
        final TestPerson bobBaumeister = TestPerson.BOB_BAUMEISTER;
        setupWiremockKeineFehler(bobBaumeister);
        final PapierantragDto entwurfDto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));
        final Antrag antragsEntwurf = erstelleEntwurf(entwurfDto, HttpStatus.SC_CREATED);
        assertThat(antragsEntwurf).isNotNull();
        assertThat(antragsEntwurf.getStatus()).isEqualTo(AntragStatus.ENTWURF);

        final String uuid = antragsEntwurf.getUuid().toString();
        entityManager.detach(antragsEntwurf);

        final PapierantragDto antragDto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(bobBaumeister));
        antragDto.setVorgangsId(entwurfDto.getVorgangsId());
        antragDto.setAufgabenId(entwurfDto.getAufgabenId());
        antragDto.getAntrag().setUuid(uuid);
        final Antrag antrag = erstelleAntrag(antragDto, 201);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getUuid()).isEqualTo(antragsEntwurf.getUuid());
        assertThat(antrag.getStatus())
                .isNotEqualTo(AntragStatus.ENTWURF)
                .isEqualTo(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
    }

    /**
     * Test Papierantrserstellung ohne Fehler.
     * @param pfad zu testende API
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ValueSource(strings = { "/erledigung-auf-andere-art-und-weise", "/ruecknahme", "/weiterbearbeitung-in-rvdialog" })
    @ParameterizedTest
    void testePapierantragsErstellungOhneFehlerFuerErledigungOhneBescheid(final String pfad) {
        final TestPerson ericCartman = TestPerson.ERIC_CARTMANN;
        setupWiremockKeineFehler(ericCartman);
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(ericCartman));

        final Antrag antrag = erstelleAntragErledigungOhneBescheid(dto, pfad, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
    }

    /**
     * Test Papierantragserstellung mit fehlerhafte Eingabe.
     * @param pfad zu testende APIl
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ValueSource(strings = { "/erledigung-auf-andere-art-und-weise", "/ruecknahme", "/weiterbearbeitung-in-rvdialog" })
    @ParameterizedTest
    void testePapierantragsErstellungFehlerhafteEingabeErgibtBadRequestUndAntragNichtGespeichert(final String pfad) {
        final TestPerson ericCartman = TestPerson.ERIC_CARTMANN;
        setupWiremockKeineFehler(ericCartman);
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(ericCartman));
        // invalide Datumsangabe
        dto.getAntrag().setEingangsdatum(dto.getAntrag().getAntragsdatum().minusDays(1));

        final Antrag antrag = erstelleAntragErledigungOhneBescheid(dto, pfad, HttpStatus.SC_BAD_REQUEST);
        assertThat(antrag).isNull();
    }

    /**
     * Test Papierantragerstellung ohne Bescheid.
     * @param pfad zu testende API
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ValueSource(strings = { "/erledigung-auf-andere-art-und-weise", "/ruecknahme", "/weiterbearbeitung-in-rvdialog" })
    @ParameterizedTest
    void testePapierantragsErstellungStatistikFehlerNotFoundUnd(final String pfad) {
        final TestPerson ericCartman = TestPerson.ERIC_CARTMANN;
        setupWiremock(ericCartman, new WiremockConfig(true, true, true, false, true, true));
        final PapierantragDto dto = PapierantragTestDatenHelper.erstellePapierantrag(getPapierantragInput(ericCartman));
        final Antrag antrag = erstelleAntragErledigungOhneBescheid(dto, pfad, HttpStatus.SC_CREATED);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_ABGEFRAGT);

        final Fehler fehler = findFehler(antrag.getUuid());
        assertThat(fehler).isNotNull();
        Assertions.assertThat(fehler.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
    }


    private PapierantragTestDatenHelper.PapierantragInput getPapierantragInput(final TestPerson testPerson) {
        return new PapierantragTestDatenHelper.PapierantragInput(testPerson,
                RandomStringUtils.insecure().nextAlphanumeric(14),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                TestRehaEinrichtung.BEISPIELKLINIK_HAIDHAUSEN,
                TestRehaEinrichtung.BEISPIELKLINIK_HAIDHAUSEN);
    }

    @SneakyThrows
    private Antrag erstelleAntrag(final PapierantragDto papierantrag, final int httpStatusCodeErwartet) {
        given().body(papierantrag).contentType("application/json")
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .post("/papierantraege").then().contentType("application/json")
                .statusCode(httpStatusCodeErwartet);

        latch.await(3, TimeUnit.SECONDS);

        return findAntrag(papierantrag.getVorgangsId());
    }

    private Antrag erstelleEntwurf(final PapierantragDto papierantrag, final int httpStatusCodeErwartet) {
        given().body(papierantrag)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .when()
                .post("/papierantraege/entwurf").then()
                .statusCode(httpStatusCodeErwartet);
        return findAntrag(papierantrag.getVorgangsId());
    }

    @SneakyThrows
    private Antrag erstelleAntragErledigungOhneBescheid(final PapierantragDto papierantrag, final String pfad,
            final int httpStatusCodeErwartet) {
        given().body(papierantrag).contentType("application/json")
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON)
                .post("/papierantraege" + pfad).then()
                .statusCode(httpStatusCodeErwartet);

        latch.await(5, TimeUnit.SECONDS);

        return findAntrag(papierantrag.getVorgangsId());
    }


    /**
     * Sucht anhand der Vorgangskennung nach einem Antrag.
     *
     * @param vorgangsKennung die Vorgangskennung zum Antrag
     * @return die Antrags-UUID
     */
    @SneakyThrows
    private Antrag findAntrag(final String vorgangsKennung) {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final TypedQuery<Antrag> query = entityManager.createQuery(
                    "select an from Antrag an where an.vorgangskennung = :vorgangskennung",
                    Antrag.class);
            query.setParameter("vorgangskennung", vorgangsKennung);
            return query.getResultStream().findFirst().orElse(null);
        }
    }

    @SneakyThrows
    private Fehler findFehler(final UUID antragUuid) {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final TypedQuery<Fehler> query = entityManager.createQuery(
                    "select f from Fehler f where f.antragId = :antragUuid",
                    Fehler.class);
            query.setParameter("antragUuid", antragUuid);
            return query.getResultStream().findFirst().orElse(null);
        }
    }

    private void setupWiremockKeineFehler(final TestPerson testPerson) {
        setupWiremock(testPerson, new WiremockConfig());
    }

    private void setupWiremock(final TestPerson testPerson, final WiremockConfig config) {
        if (config.smp()) {
            WireMockStub.stubForSmp(null, null, null, "2", null);
            WireMockStub.stubForSmp(null, null, null, "3", null);
            WireMockStub.stubForSmp(null, null, null, "4", null);
        }
        if (config.pur()) {
            WireMockStub.stubForRvPur();
        }
        if (config.azk()) {
            WireMockStub.stubForAzk();
        }
        if (config.statistik()) {
            WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
            WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        }
        if (config.kti()) {
            WireMockStub.stubForKontoinformation(testPerson);
        }
        if (config.psd()) {
            WireMockStub.stubForStammdaten(testPerson);
        }
    }

    /**
     * Record zur Konfiguration von Wiremock.
     * @param smp true falls smp genutzt wird
     * @param pur true falls pur genutzt wird
     * @param azk true falls azk genutzt wird
     * @param statistik true falls statistik genutzt wird
     * @param psd true falls psd genutzt wird
     * @param kti true falls kti genutzt wird
     */
    record WiremockConfig(boolean smp, boolean pur, boolean azk, boolean statistik, boolean psd, boolean kti) {
        /**
         * Konstruktor.
         */
        public WiremockConfig() {
            this(true, true, true, true, true, true);
        }
    }
}