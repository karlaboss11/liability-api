package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.SMPEinrichtungsEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.transaction.Transactional;
import java.util.Optional;
import java.util.UUID;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

/**
 *  Integrationstest für den SMPEinrichtungs-Enricher {@link SMPEinrichtungsEnricher}.
 */
@QuarkusTest
class SMPEinrichtungsEnricherTest extends DefaultProcessorTest {
    SMPEinrichtungsEnricher sMPEinrichtungsEnricher;


    @Test
    @Transactional
    void setSmpEinrichtungenTest() throws Exception {
        AntragRepository mock = Mockito.mock(AntragRepository.class);
        final Exchange exchange = getExchange();
        final Antrag antrag = setExchangeMitAntrag(exchange, AntragStatus.STATISTIK_ERFASST);
        antrag.setEinrichtungTrainingObjekt(
                RehaEinrichtung.builder().smpEinrichtungsId(12345L).build());
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        Mockito.when(mock.merge(antrag)).thenReturn(antrag);
        final SelbstmeldeportalService selbstmeldeportalService = Mockito.mock(SelbstmeldeportalService.class);
        Mockito.when(selbstmeldeportalService.setSmpEinrichtungen(any())).thenReturn(antrag);

        sMPEinrichtungsEnricher = new SMPEinrichtungsEnricher(
                selbstmeldeportalService,
                mock,
                Mockito.mock(RvfitLogger.class),
                Mockito.mock(DrvMandant.class),
                Mockito.mock(JsonWebToken.class));
        sMPEinrichtungsEnricher.process(exchange);
        final Antrag processedAntrag = (Antrag) exchange.getMessage().getBody();

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
        Assertions.assertEquals(12345L, processedAntrag.getEinrichtungTrainingObjekt().getSmpEinrichtungsId());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange, final AntragStatus antragStatus) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(antragStatus).build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }
}
