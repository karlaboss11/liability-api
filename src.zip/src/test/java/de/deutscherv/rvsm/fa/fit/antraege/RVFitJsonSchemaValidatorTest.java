package de.deutscherv.rvsm.fa.fit.antraege;

import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto.PersonentypEnum;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonenbeziehungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonenbeziehungDto.PersonenbeziehungstypEnum;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.AtadDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.AntragserfassungDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.KopfDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestFesterTeilDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestVariablerTeilAntragserfassungDto;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * RVFitJasonSchemaValidator.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
public class RVFitJsonSchemaValidatorTest {

    @Inject
    private RVFitJsonSchemaValidator rVFitJsonSchemaValidator;

    /**
     * Test, validiere RestApi RehaEinrichtungUpdateDto.
     */
    @Test
    void validateRestApiRehaEinrichtungUpdateDto() {
        final RehaEinrichtungUpdateDto rehaEinrichtungUpdateDto = new RehaEinrichtungUpdateDto();
        rehaEinrichtungUpdateDto.setAngebotId(11112L);
        rehaEinrichtungUpdateDto.setDurchfuehrungsart("Ambulant (ganztägig)");
        final boolean validRehaEinrichtungUpdateDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, rehaEinrichtungUpdateDto);

        assertTrue(validRehaEinrichtungUpdateDto);
    }

    /**
     * Test, validiere RestApi Liste RehaEinrichtungUpdateDto.
     */
    @Test
    void validateRestApiListRehaEinrichtungUpdateDto() {
        final RehaEinrichtungUpdateDto rehaEinrichtungUpdateDto = new RehaEinrichtungUpdateDto();
        rehaEinrichtungUpdateDto.setAngebotId(11112L);
        rehaEinrichtungUpdateDto.setDurchfuehrungsart("Ambulant (ganztägig)");

        final List<RehaEinrichtungUpdateDto> rehaEinrichtungenUpdateDto =
                List.of(rehaEinrichtungUpdateDto);
        final boolean validRehaEinrichtungenUpdateDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, rehaEinrichtungenUpdateDto);

        assertTrue(validRehaEinrichtungenUpdateDto);
    }

    /**
     * Test, validiere Selbstmeldeportal EinrichtungResponseExtended.
     */
    @Test
    void validateSelbstmeldeportalEinrichtungResponseExtended() {
        final EinrichtungResponseExtended einrichtungResponseExtended =
                new EinrichtungResponseExtended();
        final boolean validEinrichtungResponseExtended = rVFitJsonSchemaValidator
                .isValid(RestServiceClient.SELBSTMELDEPORTAL, einrichtungResponseExtended);

        assertTrue(validEinrichtungResponseExtended);
    }

    /**
     * Test, validiere KontoinformationResponse.
     */
    @Test
    void validateKontoinformationResponse() {
        final KontoinformationResponse kontoinformationResponse =
                KontoinformationResponse.builder().altersteilzeitGrund("altersteilzeitGrund")
                        .altersteilzeitKobs(LocalDate.now()).beamteneigenschaft(true).build();
        final boolean validKontoinformationResponse = rVFitJsonSchemaValidator
                .isValid(RestServiceClient.KONTOINFORMATION, kontoinformationResponse);

        assertTrue(validKontoinformationResponse);
    }

    /**
     * Test, validiere RvPur-VorgangResponseDto.
     */
    @Test
    void validateRvPurVorgangResponseDto() {
        final VorgangResponseDto vorgangResponseDto = new VorgangResponseDto();
        final AtadDto atad = new AtadDto();
        atad.atadErmDrck("DRCK");
        vorgangResponseDto.setAtad(atad);
        vorgangResponseDto.setFehlerFeld(StringUtils.EMPTY);
        final boolean validVorgangResponseDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.RVPUR, vorgangResponseDto);

        assertTrue(validVorgangResponseDto);
    }

    /**
     * Test, validiere Statistik-KopfDto.
     */
    @Test
    void validateStatistikKopfDto() {
        final KopfDto kopfDto = new KopfDto();
        final boolean validKopfDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.STATISTIK, kopfDto);

        assertTrue(validKopfDto);
    }

    /**
     * Test, validiere Statistik-AntragserfassungDto.
     */
    @Test
    void validateStatistikAntragserfassungDto() {
        final AntragserfassungDto antragserfassungDto = new AntragserfassungDto();
        final RequestFesterTeilDto requestFesterTeilDto = new RequestFesterTeilDto();
        requestFesterTeilDto.PNR("PNR").SUSY("SUSY");
        final RequestVariablerTeilAntragserfassungDto requestVariablerTeilAntragserfassungDto =
                new RequestVariablerTeilAntragserfassungDto();
        requestVariablerTeilAntragserfassungDto.BEAT("B").DF("D").DTAQ(LocalDate.now())
                .DTEQ(LocalDate.now());
        antragserfassungDto.REQUEST_FESTER_TEIL(requestFesterTeilDto)
                .REQUEST_VARIABLER_TEIL(requestVariablerTeilAntragserfassungDto);
        final boolean validAntragserfassungDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.STATISTIK, antragserfassungDto);

        assertTrue(validAntragserfassungDto);
    }

    /**
     * Test, validiere PersonenbeziehungDto.
     */
    @Test
    void validatePersonendatenPersonenbeziehungDto() {
        final PersonenbeziehungDto personenbeziehungDto = new PersonenbeziehungDto();
        personenbeziehungDto.ausgehendVon(UUID.randomUUID()).bezugsperson(UUID.randomUUID())
                .personenbeziehungstyp(PersonenbeziehungstypEnum.BERECHTIGTER);
        final boolean validPersonenbeziehungDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.STAMMDATEN, personenbeziehungDto);

        assertTrue(validPersonenbeziehungDto);
    }

    /**
     * Test, validiere PersonendatenKontoDto.
     */
    @Test
    void validatePersonendatenKontoDto() {
        final KontoDto kontoDto = new KontoDto();
        final PersonDto personDto = new PersonDto();
        personDto.name("name").personentyp(PersonentypEnum.BETEILIGTER);
        kontoDto.ktan("70").versicherungsnummer("04030583T112").setPersonen(List.of(personDto));
        final boolean validKontoDto =
                rVFitJsonSchemaValidator.isValid(RestServiceClient.STAMMDATEN, kontoDto);

        assertTrue(validKontoDto);
    }
}
