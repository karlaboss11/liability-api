package de.deutscherv.rvsm.fa.fit.antraege;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.extension.ResponseDefinitionTransformerV2;
import com.github.tomakehurst.wiremock.http.ResponseDefinition;
import com.github.tomakehurst.wiremock.stubbing.ServeEvent;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.ws.rs.core.Response.Status;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * Response-Transformer für Wiremock, der dynamisch die Stammdaten zur VSNR in der Anfrage bestimmt.
 * 
 * @author U38322
 */
@Slf4j
public class StammdatenMockTransformer implements ResponseDefinitionTransformerV2 {

    /**
     * Stammdaten Transformer.
     */
    public static final String NAME = "stammdaten-transformer";
    /**
     * VSNR zum Test einer schutwuerdigen Person (Mitarbeiter).
     */
    public static final String VSNR_SCHUTZWUERDIGE_PERSON_MA = "15150791G180";
    /**
     * VSNR zum Test einer schutwuerdigen Person (Zeuge).
     */
    public static final String VSNR_SCHUTZWUERDIGE_PERSON_ZEUGE = "18010170Y168";
    /**
     * VSNR zum Test Bestandsfehler.
     */
    public static final String VSNR_BESTANDSFEHLER = "04080800T022";

    private static final String FALSCHE_GEBURTSDATEN = """
                [
                 {
                  "ktan": "70",
                  "versicherungsnummer": "04080800T022",
                  "personen": [
                   {
                    "personentyp": "VERSICHERTER",
                    "name": "Knoedel",
                    "vorname": "Henry",
                    "vorsatzwort": "",
                    "namenszusatz": "",
                    "titel": "Dr.",
                    "geburtsname": "Barrie",
                    "geburtsort": "Köln",
                    "staatsangehoerigkeit": "000",
                    "laenderschluesselGeburtsort": "000",
                    "geburtsdatum": "2000-00-00",
                    "telefon": "017610323499",
                    "fax": "0345 213-2022694",
                    "artZustellung": "GRUNDSTELLUNG",
                    "mail": "",
                    "artZugaenglichkeit": "GRUNDSTELLUNG",
                    "geschlecht": "MAENNLICH",
                    "anschrift": {
                     "postleitzahl": "06114",
                     "wohnort": "Halle (Saale)",
                     "strasseHausnummer": "Paracelsusstr. 21",
                     "anschriftenzusatz": "",
                     "laenderschluessel": "000"
                    }
                   }
                  ]
                 },
                 {
                  "ktan": "70",
                  "versicherungsnummer": "04210202S417",
                  "personen": [
                   {
                    "personentyp": "VERSICHERTER",
                    "name": "Knoedel",
                    "vorname": "Henriette",
                    "vorsatzwort": "",
                    "namenszusatz": "",
                    "titel": "",
                    "geburtsname": "",
                    "geburtsort": "München",
                    "staatsangehoerigkeit": "000",
                    "laenderschluesselGeburtsort": "000",
                    "geburtsdatum": "1980-04-00",
                    "telefon": "",
                    "fax": "",
                    "artZustellung": "GRUNDSTELLUNG",
                    "mail": "",
                    "artZugaenglichkeit": "GRUNDSTELLUNG",
                    "geschlecht": "WEIBLICH",
                    "anschrift": {
                     "postleitzahl": "80337",
                     "wohnort": "München",
                     "strasseHausnummer": "Lindwurmstraße 70",
                     "anschriftenzusatz": "",
                     "laenderschluessel": "000"
                    }
                   }
                  ]
                 }
                ]
            """;

    private static final String ERROR_RESPONSE_SCHUTZWUERDIGE_PERSON_MA = """
            {
            "timestamp":null,
            "uuid":null,
            "errorMessage":"Bei der Datenübermittlung ist ein technischer Fehler aufgetreten. Die gewünschten Daten können derzeit nicht zur Verfügung gestellt werden. Bitte nehmen Sie den Antrag ohne Daten aus dem Rentenversicherungskonto auf.",
            "statusCode":null,
            "exceptionType":null,
            "constraintViolations":
            [
            {
            "path":null,
            "violationMessage":"Bei der Datennübermittlung ist ein technischer Fehler aufgetreten. Die gewünschten Daten können derzeit nicht zur Verfügung gestellt werden. Bitte nehmen Sie den Antrag ohne Daten aus dem Rentenversicherungskonto auf.",
            "value":"EA-KTO-025"
            }
            ]
            }
            """;

    private static final String FEHLER_EINTRAG_BESTANDSFEHLER = """
            {
            "statuscode":"AF0005",
            "message":"Die im Datensatz enthaltene Servicenummer ist unbekannt."
            }
            """;

    private final Jsonb json = JsonbBuilder.create();
    private List<KontoDto> stammdaten;

    /**
     * Konstruktor.
     */
    public StammdatenMockTransformer() {
        try {
            final var stammdatenFile = StammdatenMockTransformer.class.getResourceAsStream("/psd.json");
            stammdaten = json.fromJson(stammdatenFile, new ArrayList<KontoDto>() {
            }.getClass().getGenericSuperclass());

            // Die beiden Fälle mit nicht validen Geburtsdaten dranhängen
            stammdaten.addAll(json.fromJson(FALSCHE_GEBURTSDATEN, new ArrayList<KontoDto>() {
            }.getClass().getGenericSuperclass()));
        } catch (Exception e) {
            LOG.atInfo().setCause(e).log("Kann Stammdaten-Mock nicht initialisieren");
        }
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public ResponseDefinition transform(ServeEvent serveEvent) {
        final var pathTemplate = serveEvent.getStubMapping().getRequest().getUrlMatcher().getPathTemplate();
        final var parameters = pathTemplate.parse(serveEvent.getRequest().getUrl());
        final var vsnr = parameters.get("vsnr");

        // Prüfung/Errorhandling Schutzwürdige Personen
        if (vsnr.equals(VSNR_SCHUTZWUERDIGE_PERSON_MA)) {
            return new ResponseDefinitionBuilder().withHeader("Content-Type", "application/json")
                    .withBody(ERROR_RESPONSE_SCHUTZWUERDIGE_PERSON_MA)
                    .withStatus(423).build();
        }
        if (vsnr.equals(VSNR_SCHUTZWUERDIGE_PERSON_ZEUGE)) {
            // Error Value von Mitarbeiterschutz 'EA-KTO-025' auf Zeugenschutz 'EA-KTO-026' ändern
            return new ResponseDefinitionBuilder().withHeader("Content-Type", "application/json")
                    .withBody(ERROR_RESPONSE_SCHUTZWUERDIGE_PERSON_MA.replace("EA-KTO-025", "EA-KTO-026"))
                    .withStatus(423).build();
        }

        // Prüfung/Errorhandling Bestandsfehler
        if (vsnr.equals(VSNR_BESTANDSFEHLER)) {
            return new ResponseDefinitionBuilder().withHeader("Content-Type", "application/json")
                    .withBody(FEHLER_EINTRAG_BESTANDSFEHLER)
                    .withStatus(500).build();
        }

        return stammdaten.stream()
                .filter(person -> person.getVersicherungsnummer().equals(vsnr))
                .findFirst()
                .map(person -> new ResponseDefinitionBuilder()
                        .withHeader("Content-Type", "application/json")
                        .withBody(json.toJson(person))
                        .withStatus(Status.OK.getStatusCode()))
                .orElseGet(() -> new ResponseDefinitionBuilder().withStatus(Status.NOT_FOUND.getStatusCode()))
                .build();
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }

}
