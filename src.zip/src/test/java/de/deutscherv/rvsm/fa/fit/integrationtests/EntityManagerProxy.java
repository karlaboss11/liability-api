package de.deutscherv.rvsm.fa.fit.integrationtests;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * Entity Manger Proxy.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class EntityManagerProxy {

    private static final int MAX_TRIES = 10;

    private final EntityManager entityManager;

    private void refresh(final Antrag antrag) {
        entityManager.refresh(antrag);
    }

    /**
     * Refresh Antrag.
     * @param uuid ID des Antrags.
     * @param statusToWaitFor Status auf den gewartet wird.
     * @return Antrag
     */
    @Transactional
    public Antrag getAntragRefreshed(final UUID uuid, final AntragStatus statusToWaitFor) {
        Antrag antrag = entityManager.find(Antrag.class, uuid);
        int count = 0;
        while (count++ < MAX_TRIES && statusToWaitFor != antrag.getStatus()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            refresh(antrag);
        }
        return antrag;
    }

}
