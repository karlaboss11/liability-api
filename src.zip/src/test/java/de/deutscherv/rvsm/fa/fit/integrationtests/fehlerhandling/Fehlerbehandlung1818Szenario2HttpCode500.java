package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1818">EVORVF2-1818</a>.
 * Szenario 2 (keine Aussteuerung, StatusCode Schutzbedarf AF0075, aber HTTP 500 statt 423)
 */
@Slf4j
@Getter
public class Fehlerbehandlung1818Szenario2HttpCode500 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0075";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;
    private final WireMockServer wireMockServer;
    private final String antragXml;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param latch Latch
     * @param wireMockServer Wiremockserver
     */
    public Fehlerbehandlung1818Szenario2HttpCode500(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final BestandsfehlerRepository bestandsfehlerRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final EntityManager entityManager,
            final CountDownLatch latch,
            final WireMockServer wireMockServer) {
        super(TestPerson.HARVEY_DENT,
                new RegressionsConfig(true, true, false,
                        new StammdatenConfig(null, AF_STATUSCODE, FehlerTyp.UNERWARTET_AF, 500)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManager = entityManager;
        this.latch = latch;
        this.wireMockServer = wireMockServer;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        Mockito.clearInvocations(purAufgabenProducer);

        var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (final AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT);
            entityManager.detach(antrag);
        }

        given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .get("antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_LOCKED);

        try (final AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
            antrag.getAufgaben().forEach(aufgabe -> assertThat(aufgabe.getDatumErledigt()).isNotNull());

            Verarbeitungsstatus verarbeitungsStatus = getVerarbeitungsstatus();
            assertThat(verarbeitungsStatus.getArt()).isEqualTo(Art.WEITERBEARBEITUNG_IN_RVDIALOG);

            List<Fehler> fehlerListe = entityManager.createQuery("select f from Fehler f where antragId =: antragId", Fehler.class)
                    .setParameter("antragId", antrag.getUuid())
                    .getResultList();
            assertThat(fehlerListe).isEmpty();

            entityManager.detach(antrag);
        }

        return true;
    }

    private Verarbeitungsstatus getVerarbeitungsstatus() {
        final TypedQuery<Verarbeitungsstatus> query = entityManager.createQuery(
                """
                        SELECT v FROM Antrag a
                        LEFT JOIN Verarbeitungsstatus v on a.uuid = v.antragId
                        WHERE a.uuid = :antragUuid
                        """,
                Verarbeitungsstatus.class);
        query.setParameter("antragUuid", antragUuid);
        return query.getSingleResult();
    }

}
