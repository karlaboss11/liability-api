package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.diloop.DokumentenErzeugungConfig;
import org.eclipse.microprofile.config.ConfigProvider;

/**
 * DokumentenErzeugungTestConfig.
 */
public class DokumentenErzeugungTestConfig extends DokumentenErzeugungConfig {

    @Override
    public String getDefaultAigr() {
        return "4814";
    }

    @Override
    public String getCallingSystemName() {
        return "rvFit";
    }

    @Override
    public String getCallingSystemVersion() {
        return "0.1.0-SNAPSHOT";
    }

    @Override
    public String getVorlagenIdBescheidAblehnung() {
        return "9329a746-2e78-4b86-afa3-54d53773d15f";
    }

    @Override
    public String getVorlagenIdBescheidBewilligung() {
        return "fd4c2eca-0cb1-452d-a440-363b2fca136b";
    }

    @Override
    public String getVorlagenIdBescheidBewilligungUnterschiedlicheEinrichtungen() {
        return "74105002-856a-4eaa-a928-6dacb97dde3c";
    }

    @Override
    public String getVorlagenIdSachverhaltsaufklaerung() {
        return "be081409-79cc-4611-b604-893929fa92aa";
    }

    @Override
    public String getMailTo() {
        return ConfigProvider.getConfig().getValue("dokumentenerzeugung.default-mail", String.class);
    }
}
