package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.EantragsUnmarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import java.nio.charset.StandardCharsets;
import lombok.SneakyThrows;
import org.apache.camel.Exchange;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class EantragsUnmarshallerTest extends DefaultProcessorTest {

    private final EantragsUnmarshaller unmarshaller = new EantragsUnmarshaller();

    @SneakyThrows
    @Test
    void testUnmarshalling() {

        Exchange exc = getExchange();
        String eantrag = new String(
                EantragsUnmarshallerTest.class.getClassLoader()
                        .getResourceAsStream("eAntragXmls/eAntrag_04021093N590.xml").readAllBytes(),
                StandardCharsets.UTF_8);

        final var defaultMessage = getMessage();
        defaultMessage.setBody(eantrag);
        exc.setMessage(defaultMessage);
        unmarshaller.process(exc);
        final var antragsdaten = exc.getMessage().getBody(Antragsdaten.class);
        Assertions.assertThat(antragsdaten.getSteuerdaten().getVsnr()).isEqualTo("04021093N590");
    }

}