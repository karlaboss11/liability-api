package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import jakarta.enterprise.inject.Instance;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DrvMandantExtractorTest extends DefaultProcessorTest {

    public static final String MANDANT_SCOPE_PROPERTY_KEY =
            "$" + DrvMandantExtractor.class.getSimpleName() + ".scope";

    private final DrvMandantExtractor drvMandantExtractorProcessor = new DrvMandantExtractor(new DrvMandant(Mockito.mock(Instance.class)));

    @Test
    void drvMandantExtractorProcessorTest() throws Exception {
        final Exchange exchange = getExchange();
        final Message message = getMessage();
        message.setHeader(DRVHeader.MANDANT_PROPERTY_KEY, "70");
        exchange.setMessage(message);

        drvMandantExtractorProcessor.process(exchange);

        assertEquals("70", exchange.getProperty(DRVHeader.MANDANT_PROPERTY_KEY));
        assertThat(exchange.getProperty(MANDANT_SCOPE_PROPERTY_KEY).toString())
                .contains("de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant");
    }
}
