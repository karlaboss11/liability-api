package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.testdaten.TestRehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1819">EVORVF2-1819</a>.
 * Szenario 1
 */
@Slf4j
@Getter
public class Fehlerbehandlung1819Szenario1 extends RegressionsTestTemplate {

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final String antragXml;
    private final AntragRepository antragRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final StatistikService statistikService;
    private final WireMockServer wireMockServer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param latch Latch
     * @param statistikService Statistik-Service
     * @param wireMockServer Wiremockserver
     */
    public Fehlerbehandlung1819Szenario1(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final StatistikService statistikService,
            final WireMockServer wireMockServer,
            final EntityManager entityManager,
            final CountDownLatch latch) {
        super(TestPerson.PETER_PAN,
                new RegressionsConfig(true, true, false));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.statistikService = statistikService;
        this.wireMockServer = wireMockServer;
        this.entityManager = entityManager;
        this.latch = latch;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        final PapierantragTestDatenHelper.PapierantragInput papierantragInput = new PapierantragTestDatenHelper.PapierantragInput(
                getTestPerson(),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                TestRehaEinrichtung.BEISPIELKLINIK_HAIDHAUSEN,
                TestRehaEinrichtung.BEISPIELKLINIK_HAIDHAUSEN);

        final PapierantragDto papierantrag = PapierantragTestDatenHelper.erstellePapierantrag(papierantragInput);
        given().body(papierantrag).contentType("application/json")
                .post("/papierantraege").then().contentType("application/json").statusCode(HttpStatus.SC_CREATED);

        boolean asyncRouteCompleted = latch.await(2, TimeUnit.SECONDS);
        assertThat(asyncRouteCompleted).isTrue();

        antragUuid = findUuidByVorgangsKennung(papierantragInput.vorgangsKennung());

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);

            final Aufgabe antragErfassenAufgabe = antrag.getAufgaben().stream()
                    .filter(aufgabe -> aufgabe.getAufgabenArt() == AufgabenArt.ANTRAGSERFASSUNG)
                    .findFirst().orElseThrow();
            assertThat(antragErfassenAufgabe).isNotNull();
            assertThat(antragErfassenAufgabe.getDatumErledigt()).isNotNull();

            final Aufgabe anspruchspruefungAufgabe = antrag.getAufgaben().stream()
                    .filter(aufgabe -> aufgabe.getAufgabenArt() == AufgabenArt.EINRICHTUNGSWAHL)
                    .findFirst().orElseThrow();
            assertThat(anspruchspruefungAufgabe).isNotNull();
            assertThat(anspruchspruefungAufgabe.getDatumErledigt()).isNull();

            assertThat(antrag.getMsnr()).isNotNull();
            assertThat(antrag.getAtad()).isNotNull();

            Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
            Mockito.verify(statistikService, times(1)).createStatistikAntragserfassung(any());
            entityManager.detach(antrag);
        }

        return true;
    }

    @SneakyThrows
    private UUID findUuidByVorgangsKennung(final String vorgangsKennung) {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final TypedQuery<Antrag> query = entityManager.createQuery(
                    "select an from Antrag an where an.vorgangskennung = :vorgangskennung",
                    Antrag.class);
            query.setParameter("vorgangskennung", vorgangsKennung);
            return query.getSingleResult().getUuid();
        }
    }

}
