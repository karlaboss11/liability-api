package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.StammdatenEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;

class StammdatenEnricherTest extends DefaultProcessorTest {

    @Test
    @Transactional
    void getStammdatenByVsnrTest() throws Exception {
        final Exchange exchange = getExchange();
        final Antrag antrag = setExchangeMitAntrag(exchange);
        StammdatenService stammdatenService = Mockito.mock(StammdatenService.class);

        Mockito.when(stammdatenService.getStammdatenByVsnr(any(), anyBoolean()))
                .thenReturn(Stammdaten.builder().vsnr("15280982D041").build());
        final var arMock = Mockito.mock(AntragRepository.class);
        Mockito.when(arMock.merge(any(Antrag.class))) //gib den Antrag einfach wieder zurück
                .then(invocationOnMock -> invocationOnMock.getArguments()[0]);

        final StammdatenEnricher stammdatenEnricher = new StammdatenEnricher(stammdatenService, arMock,
                Mockito.mock(BestandsfehlerRepository.class));

        stammdatenEnricher.process(exchange);
        final Antrag processedAntrag =  exchange.getMessage().getBody(Antrag.class);

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
        assertEquals("15280982D041", processedAntrag.getVersichertenStammdaten().getFirst().getVsnr());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(AntragStatus.STATISTIK_ERFASST).build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }
}
