package de.deutscherv.rvsm.fa.fit.antraege;

import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLFilter;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class NamespaceFilterTest {

    private static XMLReader reader;

    private static final String XML_VALID = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<antragsdaten xmlns=\"http://xmlns.deutscherv.de/eAntrag\">"
            + " <steuerdaten>"
            + "  <vsnr>03010161X513</vsnr>"
            + "  <kennung>ALRV</kennung>"
            + "  <absender>INTERNET</absender>"
            + "  <empfaenger>24</empfaenger>"
            + "  <version>50</version>"
            + "  <zeitpunktErstellung>2023-02-16T12:07:36.193+01:00</zeitpunktErstellung>"
            + "  <userId>eAntrag</userId>"
            + "  </steuerdaten>"
            + "</antragsdaten>";

    private static final String XML_INVALID = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<antragsdaten xmlns=\"http://xmlns.deutscherv.de/eAntrag\">"
            + " <steuerdaten>"
            + "  <vsnr>03010161X513</vsnr>"
            + "  <kennung>ALRV</kennung>"
            + "  <absender>INTERNET</absender>"
            + "  <empfaenger>24</empfaenger>"
            + "  <version>50</version>"
            + "  <zeitpunktErstellung>2023-02-16T12:07:36.193+01:00</zeitpunktErstellung>"
            + "  <userId>eAntrag</userId>"
            + "  </steuerdaten>"
            + "</xxxxxxxxxx>";

    @BeforeAll
    static void startUp() throws ParserConfigurationException, SAXException {

        final SAXParserFactory parserFactory = SAXParserFactory.newInstance();
        final SAXParser parser = parserFactory.newSAXParser();
        reader = parser.getXMLReader();

    }

    @Test
    @SneakyThrows
    void testWithAddedNamespaceURI() {
        final XMLFilter filter = new NamespaceFilter("http://xmlns.deutscherv.de/eAntrag", true);
        filter.setParent(reader);
        final SAXSource source = new SAXSource(filter,
                new InputSource(new ByteArrayInputStream(XML_VALID.getBytes(StandardCharsets.UTF_8))));

        final DOMResult result = new DOMResult();
        assertDoesNotThrow(() -> TransformerFactory.newInstance().newTransformer().transform(source, result));

    }

    @Test
    @SneakyThrows
    void testWithoutAddedNamespaceURI() {
        final XMLFilter filter = new NamespaceFilter(null, false);
        filter.setParent(reader);
        final SAXSource source = new SAXSource(filter,
                new InputSource(new ByteArrayInputStream(XML_VALID.getBytes(StandardCharsets.UTF_8))));

        final DOMResult result = new DOMResult();
        final Transformer transformer = TransformerFactory.newInstance().newTransformer();
        assertDoesNotThrow(() -> transformer.transform(source, result));

    }

    @Test
    @SneakyThrows
    void testWithInvalidXML() {
        final XMLFilter filter = new NamespaceFilter(null, false);
        filter.setParent(reader);
        final SAXSource source = new SAXSource(filter,
                new InputSource(new ByteArrayInputStream(XML_INVALID.getBytes(StandardCharsets.UTF_8))));

        final DOMResult result = new DOMResult();
        final Transformer transformer = TransformerFactory.newInstance().newTransformer();
        assertThrows(TransformerException.class, () -> transformer.transform(source, result));

    }

}
