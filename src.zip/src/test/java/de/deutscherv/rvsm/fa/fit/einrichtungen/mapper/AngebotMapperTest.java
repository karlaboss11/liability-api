package de.deutscherv.rvsm.fa.fit.einrichtungen.mapper;

import org.junit.jupiter.api.Test;

import static de.deutscherv.rvsm.fa.fit.einrichtungen.mapper.AngebotMapper.toFreiePlaetze;
import static de.deutscherv.rvsm.fa.fit.einrichtungen.mapper.AngebotMapper.toFreiePlaetzeWert;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test: Angebot-Mapper.
 */
public class AngebotMapperTest {
    @Test
    void testToFreiePlaetze() {
        assertNull(toFreiePlaetze(null));
        assertEquals("Angebot pausiert", toFreiePlaetze(-2));
        assertEquals("Auf Anfrage", toFreiePlaetze(-1));
        assertEquals("Keine freien Plätze", toFreiePlaetze(0));
        assertEquals("1 - 3 freie Plätze", toFreiePlaetze(1));
        assertEquals("mehr als 3 freie Plätze", toFreiePlaetze(4));
        assertThrows(IllegalArgumentException.class, () -> toFreiePlaetze(7));
    }

    @Test
    void testToFreiePlaetzeWert() {
        assertNull(toFreiePlaetzeWert(null));
        assertEquals(-2, toFreiePlaetzeWert("Angebot pausiert"));
        assertEquals(-1, toFreiePlaetzeWert("Auf Anfrage"));
        assertEquals(0, toFreiePlaetzeWert("Keine freien Plätze"));
        assertEquals(1, toFreiePlaetzeWert("1 - 3 freie Plätze"));
        assertEquals(4, toFreiePlaetzeWert("mehr als 3 freie Plätze"));
        assertThrows(IllegalArgumentException.class, () -> toFreiePlaetzeWert("Hello there"));
    }
}
