package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.testdaten.TestRehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1819">EVORVF2-1819</a>.
 * Szenario 3 mit FE-Fehler
 */
@Slf4j
@Getter
public class Fehlerbehandlung1819Szenario3b extends RegressionsTestTemplate {

    private static final String FE_FEHLERCODE = "070400";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final String antragXml;
    private final AntragRepository antragRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final StatistikService statistikService;
    private final WireMockServer wireMockServer;
    private final EntityManager entityManager;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final String endpunkt;
    private final CountDownLatch latch;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param statistikService Statistikservice
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param endpunkt Endpunkt
     * @param latch Latch
     * @param wireMockServer Wiremockserver
     */
    public Fehlerbehandlung1819Szenario3b(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final StatistikService statistikService,
            final WireMockServer wireMockServer,
            final EntityManager entityManager,
            final BestandsfehlerRepository bestandsfehlerRepository,
            final String endpunkt,
            final CountDownLatch latch) {
        super(TestPerson.PETER_PAN,
                new RegressionsConfig(true, true, false,
                        new StatistikErfassungConfig(FehlerTyp.UNERWARTET_AF, FE_FEHLERCODE, 500)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.statistikService = statistikService;
        this.wireMockServer = wireMockServer;
        this.entityManager = entityManager;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.latch = latch;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
        this.endpunkt = endpunkt;
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        Mockito.clearInvocations(purAufgabenProducer, statistikService);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput = new PapierantragTestDatenHelper.PapierantragInput(
                getTestPerson(),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                TestRehaEinrichtung.FANTASIEKLINIK_ENGLISCHER_GARTEN,
                TestRehaEinrichtung.FANTASIEKLINIK_ENGLISCHER_GARTEN);

        final PapierantragDto papierantrag = PapierantragTestDatenHelper.erstellePapierantrag(papierantragInput);
        given().body(papierantrag).contentType("application/json")
                .post("/papierantraege" + endpunkt).then().contentType("application/json").statusCode(HttpStatus.SC_CREATED);

        latch.await(3, TimeUnit.SECONDS);

        antragUuid = findUuidByVorgangsKennung(papierantragInput.vorgangsKennung());

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT);

            final Aufgabe antragErfassenAufgabe = antrag.getAufgaben().stream()
                    .filter(aufgabe -> aufgabe.getAufgabenArt() == AufgabenArt.ANTRAGSERFASSUNG)
                    .findFirst().orElseThrow();
            assertThat(antragErfassenAufgabe).isNotNull();
            assertThat(antragErfassenAufgabe.getDatumErledigt()).isNotNull();

            final Aufgabe anspruchspruefungAufgabe = antrag.getAufgaben().stream()
                    .filter(aufgabe -> aufgabe.getAufgabenArt() == AufgabenArt.BESTANDSFEHLER)
                    .findFirst().orElseThrow();
            assertThat(anspruchspruefungAufgabe).isNotNull();
            assertThat(anspruchspruefungAufgabe.getDatumErledigt()).isNull();

            assertThat(antrag.getMsnr()).isNull();
            assertThat(antrag.getAtad()).isNull();

            List<Bestandsfehler> bestandsfehlerList = bestandsfehlerRepository.findByAntragUuidNotDeleted(getAntragUuid());
            assertThat(bestandsfehlerList).hasSize(1);
            assertThat(bestandsfehlerList.getFirst().getDeleted()).isNull();
            assertThat(bestandsfehlerList.getFirst().getBestandsfehlercode()).isEqualTo(FE_FEHLERCODE);

            Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
            Mockito.verify(statistikService, times(1)).createStatistikAntragserfassung(any());
            entityManager.detach(antrag);
        }

        BestandsfehlerDto bestandsfehlerDto = given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .get("antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_OK).extract().as(BestandsfehlerDto.class);
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNull();
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).containsOnly("FE" + FE_FEHLERCODE);

        return true;
    }

    @SneakyThrows
    private UUID findUuidByVorgangsKennung(final String vorgangsKennung) {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final TypedQuery<Antrag> query = entityManager.createQuery(
                    "select an from Antrag an where an.vorgangskennung = :vorgangskennung",
                    Antrag.class);
            query.setParameter("vorgangskennung", vorgangsKennung);
            return query.getSingleResult().getUuid();
        }
    }

}
