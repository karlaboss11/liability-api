package de.deutscherv.rvsm.fa.fit.antraege;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.einrichtungen.repository.RehaEinrichtungRepository;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test AntragRepository.
 */
@QuarkusTest
@Slf4j
class AntragRepositoryTest {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final String VSNR = "23 270152 B 506";
    private static final String XML = "xml";
    private static final String ANTRAGSDATUM = "2023-03-20";
    private static final Integer WARTEZEIT6IN24M = 1;
    private static final String EINRICHTUNGSNAME = "Berlin Einrichtung";
    private static final Integer FREIE_PLAETZE = 4;
    private static final String ADRESSE_PLZ = "80336";
    private static final String POSTANSCHRIFT_PLZ = "80337";

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private RehaEinrichtungRepository einrichtungRepository;

    @Inject
    private DrvMandant drvMandant;

    /**
     * Teste Repository.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void antragRepositoryTest() {
        LOG.atInfo().log("Antrag Repository Test");

        drvMandant.setInScope("17");

        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID()).xml(XML)
            .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).build();
        antrag.addVersicherte(Stammdaten.builder().vsnr(VSNR).build());
        antrag.addKontoinformation(
            Kontoinformation.builder().wartezeit6in24m(WARTEZEIT6IN24M).build());
        final RehaEinrichtung einrichtung = RehaEinrichtung.builder().name(EINRICHTUNGSNAME)
            .adresse(EinrichtungAnschrift.builder().plz(ADRESSE_PLZ).build())
            .postanschrift(EinrichtungAnschrift.builder().plz(POSTANSCHRIFT_PLZ).build()).build();
        einrichtung.addAngebot(Angebot.builder().freiePlaetzeWert(FREIE_PLAETZE).build());
        antrag.setEinrichtungStartObjekt(einrichtung);
        antrag.addAntragPruefergebnis(
            AntragPruefergebnis.builder().ergebnis(PruefErgebnis.ERFUELLT).build());

        antragRepository.persist(antrag);

        final Antrag persistedAntrag =
            antragRepository.findByUuid(antrag.getUuid()).orElseThrow(NotFoundException::new);

        assertThat(persistedAntrag.getVsnr()).isEqualTo(VSNR);
        assertThat(persistedAntrag.getXml()).isEqualTo(XML);
        assertThat(persistedAntrag.getAntragsDatum()).isEqualTo(ANTRAGSDATUM);
        assertThat(persistedAntrag.getVersichertenStammdaten().getFirst().getVsnr()).isEqualTo(VSNR);
        assertThat(persistedAntrag.getKontoinformationen().getFirst().getWartezeit6in24m())
            .isEqualTo(WARTEZEIT6IN24M);
        assertThat(persistedAntrag.getEinrichtungStartObjekt().getAdresse().getPlz())
            .isEqualTo(ADRESSE_PLZ);
        assertThat(persistedAntrag.getEinrichtungStartObjekt().getPostanschrift().getPlz())
            .isEqualTo(POSTANSCHRIFT_PLZ);
        assertThat(
            persistedAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert())
            .isEqualTo(FREIE_PLAETZE);
        assertThat(persistedAntrag.getAntragPruefergebnisse().getFirst().getErgebnis())
            .isEqualTo(PruefErgebnis.ERFUELLT);
    }

    /**
     * Testet die findAntragByTransaktionsId Methode.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void findAntragByTransaktionsId() {

        drvMandant.setInScope("17");

        final UUID transaktionsId = UUID.randomUUID();
        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID()).xml(XML)
            .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).build();

        final Aufgabe aufgabe = Aufgabe.builder().transaktionId(transaktionsId)
            .datumErstellung(LocalDateTime.now()).aufgabenArt(AufgabenArt.EINRICHTUNGSWAHL).build();

        antrag.addAufgabe(aufgabe);

        antragRepository.persistAndFlush(antrag);

        final Antrag foundAntrag = antragRepository.findAntragByTransaktionsId(transaktionsId);

        assertThat(foundAntrag).isNotNull();
        assertThat(foundAntrag.getUuid()).isEqualTo(antrag.getUuid());
        assertThat(foundAntrag.getAufgaben()).extracting(Aufgabe::getTransaktionId)
            .anySatisfy(tan -> assertThat(tan).isEqualTo(transaktionsId));
    }

    /**
     * Testet die findByVorgangskennung Methode.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void findByVorgangskennungTest() {

        drvMandant.setInScope("17");

        final String vorgangskennung = "V250000022RVX1";
        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID()).xml(XML)
            .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).vorgangskennung(vorgangskennung).build();

        antragRepository.persistAndFlush(antrag);

        final Antrag foundAntrag = antragRepository.findByVorgangskennung(vorgangskennung);

        assertThat(foundAntrag).isNotNull();
        assertThat(foundAntrag.getUuid()).isEqualTo(antrag.getUuid());
        assertThat(foundAntrag.getVorgangskennung()).isEqualTo(vorgangskennung);
    }

    /**
     * Test find by UUID.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void findByUuidTest() {

        drvMandant.setInScope("17");

        final UUID antragId = UUID.randomUUID();

        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(antragId).xml(XML)
            .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).build();

        antragRepository.persistAndFlush(antrag);

        final Optional<Antrag> foundAntrag = antragRepository.findByUuid(antragId);

        assertThat(foundAntrag).isNotNull();
        assertThat(foundAntrag).isPresent();
        assertThat(foundAntrag.get().getUuid()).isEqualTo(antragId);
    }

    /**
     * Test find Papierantrag Entwurf by VSNR.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void findPapierantragEntwurfByVsnrTest() {

        drvMandant.setInScope("17");

        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID())
            .status(AntragStatus.ENTWURF).antragsart(AntragsArt.PAPIERANTRAG).build();

        antragRepository.persistAndFlush(antrag);

        final Antrag foundAntrag = antragRepository.findPapierantragEntwurfByVsnr(VSNR);

        assertThat(foundAntrag).isNotNull();
        assertThat(foundAntrag.getVsnr()).isEqualTo(VSNR);
    }

    /**
     * Test Last inserted Vorgangskennung.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void getLastInsertedVorgangskennungTest() {

        drvMandant.setInScope("17");

        final String vorgangskennung = "randomKennung";

        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID())
            .vorgangskennung(vorgangskennung).antragsart(AntragsArt.E_ANTRAG).build();

        antragRepository.persistAndFlush(antrag);

        final Optional<String> foundVorganskennung =
            antragRepository.getLastInsertedVorgangskennung();

        assertThat(foundVorganskennung).isPresent();
        assertThat(foundVorganskennung).isNotNull();
        assertThat(foundVorganskennung.get()).isEqualTo(vorgangskennung);
    }

    /**
     * Test Last inserted Vorgangskennung is null.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void getLastInsertedVorgangskennungIsNull() {
        drvMandant.setInScope("17");

        final Optional<String> foundVorganskennung =
            antragRepository.getLastInsertedVorgangskennung();

        assertThat(foundVorganskennung).isEmpty();
    }

    /**
     * Test find Antrag mit offener Vorgangserzeugung.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void findAntraegeMitOffenerVorgangserzeugungTest() {
        drvMandant.setInScope("70");
        final UUID antragId = UUID.randomUUID();
        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(antragId).xml(XML)
            .created(LocalDateTime.now()).status(AntragStatus.VORGANG_WIRD_ERSTELLT)
            .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).build();
        antragRepository.persistAndFlush(antrag);

        final List<Antrag> antraege = antragRepository.findAntraegeimStatus(AntragStatus.VORGANG_WIRD_ERSTELLT, 5)
            .stream().filter(a -> a.getUuid().equals(antragId)).toList();
        assertThat(antraege).isNotNull().hasSize(1);
        assertThat(antraege.getFirst().getUuid()).isEqualTo(antragId);
    }

    /**
     * Test setze Antraege fuer erzeugte Vorgange auf Status IN_BEARBEITUNG.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void setzeAntraegeFuerErzeugteVorgaengeAufStatusInBearbeitungTest() {
        drvMandant.setInScope("70");

        final UUID antragId = UUID.randomUUID();
        erstelleAntrag(antragId);

        final int aktualiserteAntraege = aktualisiereAntrag(antragId);
        assertThat(aktualiserteAntraege).isOne();

        final List<Antrag> antraege = antragRepository.findAntraegeimStatus(AntragStatus.VORGANG_WIRD_ERSTELLT, 5)
            .stream().filter(a -> a.getUuid().equals(antragId)).toList();
        assertThat(antraege).isNotNull().isEmpty();
        final Antrag antragNachUpdate = getAntragNachUpdate(antragId);
        assertThat(antragNachUpdate.getStatus()).isEqualTo(AntragStatus.VORGANG_ERZEUGT);
    }

    /**
     * Aktualisiere Antrag.
     *
     * @param antragId ID des Antrags
     * @return Anzahl der geaendertenSaetze
     */
    @Transactional
    int aktualisiereAntrag(final UUID antragId) {
        final List<String> antragIds = antragRepository.findAntraegeimStatus(AntragStatus.VORGANG_WIRD_ERSTELLT, 5)
            .stream().map(Antrag::getUuid).map(UUID::toString)
            .filter(id -> id.equals(antragId.toString())).toList();
        return antragRepository.setzeStatusVonVorgangWirdErstelltAufVorgangErzeugt(antragIds);
    }

    /**
     * Liest Antrag nach Update.
     *
     * @param antragId ID des Antrags
     * @return geaenderter Antrag
     */
    @Transactional
    public Antrag getAntragNachUpdate(final UUID antragId) {
        return antragRepository.findByUuid(antragId).orElseThrow();
    }

    /**
     * Erstelle Antrag.
     *
     * @param antragId ID des Antrags
     */
    @Transactional
    public void erstelleAntrag(final UUID antragId) {
        final Antrag antrag =
            Antrag.builder().vsnr(VSNR).uuid(antragId).xml(XML).created(LocalDateTime.now())
                .status(AntragStatus.VORGANG_WIRD_ERSTELLT).vorgangskennung("V240009725RV34")
                .antragsDatum(LocalDate.parse(ANTRAGSDATUM, FORMATTER)).build();
        antragRepository.persistAndFlush(antrag);
    }

    /**
     * Test loesche Papierantragsentwurf.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void loeschePapierantragEntwurfByVsnrTest() {

        drvMandant.setInScope("17");

        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID())
            .status(AntragStatus.ENTWURF).antragsart(AntragsArt.PAPIERANTRAG).build();

        antragRepository.persistAndFlush(antrag);

        Antrag foundAntrag = antragRepository.findPapierantragEntwurfByVsnr(VSNR);

        assertThat(foundAntrag).isNotNull();
        assertThat(foundAntrag.getVsnr()).isEqualTo(VSNR);

        antragRepository.deletePapierantragEntwurfByVsnr(VSNR);
        foundAntrag = antragRepository.findPapierantragEntwurfByVsnr(VSNR);
        antragRepository.persistAndFlush(antrag);

        assertThat(foundAntrag).isNull();

    }

    /**
     * Test Ist die VorgangsID belegt wird False geliefert falls es ein Enwurf ist.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void testIstVorgangsIdBelegtGibtFalseZurueckFallsEntwurf() {
        drvMandant.setInScope("70");
        final String vorgangsKennung = RandomStringUtils.insecure().nextAlphanumeric(14);
        final Antrag antrag = Antrag.builder().vsnr(VSNR).uuid(UUID.randomUUID()).vorgangskennung(vorgangsKennung)
            .status(AntragStatus.ENTWURF).antragsart(AntragsArt.PAPIERANTRAG).build();
        antragRepository.persistAndFlush(antrag);

        assertThat(antragRepository.istVorgangsIdBelegt(vorgangsKennung)).isFalse();
    }

}
