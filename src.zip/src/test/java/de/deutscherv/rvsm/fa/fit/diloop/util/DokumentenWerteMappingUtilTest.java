package de.deutscherv.rvsm.fa.fit.diloop.util;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.UnvollstaendigeStammdatenException;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.util.LandIsoCodes;
import de.drv.rvevo.shared.api.doe.model.NatuerlichePersonDTO;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static de.deutscherv.rvsm.fa.fit.diloop.util.DokumentenWerteMappingUtil.mapArtDerZugaenglichkeitZuEZustellung;
import static de.deutscherv.rvsm.fa.fit.diloop.util.DokumentenWerteMappingUtil.mapArtDerZustellungZuEPostfach;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test DokumenteWerteMappingUtil.
 */
class DokumentenWerteMappingUtilTest {

    /**
     * Test wenn LaenderCode Null ist.
     */
    @Test
    void getLanSsollteExceptionWerfenWennLaenderCodeNull() {
        assertThrows(StammdatenException.class,
            () -> DokumentenWerteMappingUtil.getLand(null));
    }

    /**
     * Test wenn Laendercode ungueltiger Wert ist.
     */
    @Test
    void getLandSollteExceptionWerfenWennLaenderCodeUngueltigerWert() {
        assertThrows(StammdatenException.class,
            () -> DokumentenWerteMappingUtil.getLand("1000"));
    }

    /**
     * Test bei leerer Eingabe wird Deutschland geliefert.
     */
    @Test
    void getLandSollteDeutschlandLiefernFuerLeereEingabe() {
        assertThat(DokumentenWerteMappingUtil.getLand("").getWert())
            .isEqualTo(LandIsoCodes.DEUTSCHLAND.getIso31661Alpha3());
    }

    /**
     * Test getLand sollte Null liefern wenn das Land ubekannt ist.
     *
     * @param landIsoCodeString Laendercode
     */
    @ParameterizedTest
    @ValueSource(strings = {
        "UNBEKANNTES_AUSLAND",
        "STAATENLOS",
        "UNGEKLAERT",
        "OHNE_ANGABE"
    })
    void getLandSollteNullZurueckgebenWennUnbekanntesLand(final String landIsoCodeString) {
        final LandIsoCodes land = LandIsoCodes.valueOf(landIsoCodeString);
        assertThat(DokumentenWerteMappingUtil.getLand(land.getNtsc())).isNull();
    }

    /**
     * Test Person zu Andrede, sollte Anrede fuer ENUM-Wert zurueckgeben.
     *
     * @param enumValue zu testender Wert
     * @param anrede    erwarteter Wert
     */
    @ParameterizedTest
    @CsvSource(quoteCharacter = '"', textBlock = """
            HERR,Herr
            FRAU,Frau
            FRAEULEIN,Frau
            DAMEN_UND_HERREN,""
            DAMEN,""
            HERREN,""
            NEUTRALE_ANREDE,neutral
        """)
    void mapPersonZuAnredeSollteAnredeFuerEnumWertZurueckgeben(final String enumValue, final String anrede) {
        final PersonDto personDto = new PersonDto();
        personDto.setAnrede(PersonDto.AnredeEnum.valueOf(enumValue));
        assertThat(DokumentenWerteMappingUtil.mapPersonZuAnrede(personDto))
            .isEqualTo(anrede);
    }

    /**
     * Test Art der Zugaenglichkeit, sollte String fuer Zustellung zurueckgeben.
     *
     * @param enumValue zu testender Wert
     * @param expected  erwarteter Wert
     */
    @ParameterizedTest
    @CsvSource(quoteCharacter = '"', textBlock = """
            GROSSDRUCK, 01
            BRAILLE_KURZSCHRIFT, 02
            BRAILLE_VOLLSCHRIFT, 03
            CD_ROM, 13
            HOERMEDIUM, 22
            GRUNDSTELLUNG, ""
        """)
    void mapArtDerZugaenglichkeitSollteStringFuerEZustellungZurueckgeben(final String enumValue, final String expected) {
        //GIVEN
        final PersonDto personDto = new PersonDto();
        personDto.setArtZugaenglichkeit(PersonDto.ArtZugaenglichkeitEnum.valueOf(enumValue));
        //WHEN
        final String result = mapArtDerZugaenglichkeitZuEZustellung(personDto);
        //THEN
        assertThat(result).isEqualTo(expected);
    }

    /**
     * Test Art der Zustellung.
     *
     * @param enumValue zu testender Wert
     * @param expected  erwarteter Wert
     */
    @ParameterizedTest
    @CsvSource(quoteCharacter = '"', textBlock = """
            E_POSTFACH, 1
            GRUNDSTELLUNG, ""
        """)
    void mapArtZustellungSollteStringFuerEPostfach(final String enumValue, final String expected) {
        //GIVEN
        final PersonDto personDto = new PersonDto();
        personDto.setArtZustellung(PersonDto.ArtZustellungEnum.valueOf(enumValue));
        //WHEN
        final String result = mapArtDerZustellungZuEPostfach(personDto);
        //THEN
        assertThat(result).isEqualTo(expected);
    }

    /**
     * Test Person zu Anrede, sollte "neutral" liefern.
     */
    @Test
    void mapPersonZuAnredeSollteNeutralFuerPersonOhneGesetzteAnredeZurueckgeben() {
        assertThat(DokumentenWerteMappingUtil.mapPersonZuAnrede(new PersonDto()))
            .isEqualTo("neutral");
    }

    /**
     * Erstelle Adresse String.
     */
    @Test
    void erstelleAdressenString() {
        final EinrichtungAnschrift anschrift = EinrichtungAnschrift.builder().uuid(UUID.randomUUID())
            .strasse("Kavalierstr.").hausnummer("37").plz("06844").ort("Dessau-Roßlau")

            .build();
        final RehaEinrichtung rehaEinrichtung = RehaEinrichtung.builder().uuid(UUID.randomUUID()).resc("E23128")
            .name("Med Reha Dessau GmbH").adresse(anschrift).postanschrift(anschrift).build();
        final String adressenString =
            DokumentenWerteMappingUtil.erstelleAdressenString(rehaEinrichtung);
        assertThat(adressenString).isEqualTo("""
            Med Reha Dessau GmbH
            Kavalierstr. 37
            06844 Dessau-Roßlau""");
    }

    /**
     * Extrahiere natuerliche Person aus dem Antrag.
     */
    @Test
    void extrahiereNatuerlichePersonAusAntrag() {
        final List<NatuerlichePersonDTO> natuerlichePersonen =
            DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto(getKonto());
        assertThat(natuerlichePersonen).hasSize(1);
        assertThat(natuerlichePersonen.getFirst().getAdresse().getAdressat()).isEqualTo("Jane Doe");
        assertThat(natuerlichePersonen.getFirst().getAdresse().getStrasseHausnummer())
            .isEqualTo("Teststr. 1A");
        assertThat(natuerlichePersonen.getFirst().getAdresse().getPlz()).isEqualTo("12345");
        assertThat(natuerlichePersonen.getFirst().getAdresse().getOrt()).isEqualTo("Teststadt");

        assertThat(natuerlichePersonen.getFirst().getAnrede()).isEqualTo("Frau");
        assertThat(natuerlichePersonen.getFirst().getVorname()).isEqualTo("Jane");
        assertThat(natuerlichePersonen.getFirst().getNachname()).isEqualTo("Doe");
        assertThat(natuerlichePersonen.getFirst().getTitel()).isEqualTo("Dr.");
        assertThat(natuerlichePersonen.getFirst().getNamenszusatz()).isEqualTo("OBE");
        assertThat(natuerlichePersonen.getFirst().getVorsatzwort()).isEqualTo("Freifrau");
        assertThat(natuerlichePersonen.getFirst().getGeburtsdatum()).isEqualTo("1972-08-19");
        assertThat(natuerlichePersonen.getFirst().getRollen()).containsOnly("Versicherter");
    }

    /**
     * Wirf unvollstaendige Stammdatenexception falls keine Person gesetzt ist.
     */
    @Test
    void wirftUnvollstaendigeStammdatenExceptionFallsKeinePersonGesetzt() {
        assertThrows(UnvollstaendigeStammdatenException.class,
            () -> DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto(new KontoDto()));
    }

    /**
     * Wirf unvollstaendige Stammdatenexception falls keine Anschrift gesetzt ist.
     */
    @Test
    void wirftUnvollstaendigeStammdatenExceptionFallsKeineAnschriftGesetzt() {
        final KontoDto konto = new KontoDto();
        konto.getPersonen().add(new PersonDto());
        assertThrows(UnvollstaendigeStammdatenException.class,
            () -> DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto(konto));
    }

    /**
     * Wirf unvollstaendige Stammdatenexception falls kein Laenderschlussel der Anschrift gesetzt ist.
     */
    @Test
    void wirftUnvollstaendigeStammdatenExceptionFallsKeinLaenderschluesselInAnschriftGesetzt() {
        final KontoDto konto = new KontoDto();
        final PersonDto person = new PersonDto();
        final PersonAnschriftDto anschrift = new PersonAnschriftDto();
        person.setAnschrift(anschrift);
        konto.getPersonen().add(person);
        assertThrows(StammdatenException.class,
            () -> DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto(konto));
    }

    /**
     * Wirf keine Exception falls keine Anrede gesetzt ist.
     */
    @Test
    void wirftKeinenFehlerFallsAnredeNichtGesetzt() {
        final KontoDto konto = new KontoDto();
        final PersonDto person = new PersonDto();
        person.setGeschlecht(PersonDto.GeschlechtEnum.WEIBLICH);
        final PersonAnschriftDto anschrift = new PersonAnschriftDto();
        anschrift.setLaenderschluessel(LandIsoCodes.DEUTSCHLAND.getNtsc());
        person.setAnschrift(anschrift);
        konto.getPersonen().add(person);

        final NatuerlichePersonDTO natuerlichePersonDto = Assertions.assertDoesNotThrow(
            () -> DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto(konto)).getFirst();
        assertThat(natuerlichePersonDto.getAnrede()).isEqualTo("neutral");
    }

    private KontoDto getKonto() {
        final PersonAnschriftDto anschrift = new PersonAnschriftDto();
        anschrift.setStrasseHausnummer("Teststr. 1A");
        anschrift.setWohnort("Teststadt");
        anschrift.setPostleitzahl("12345");
        anschrift.setLaenderschluessel("000");

        final PersonDto person = getPersonDto(anschrift);

        final List<PersonDto> personDtoList = new ArrayList<>();
        personDtoList.add(person);

        final KontoDto konto = new KontoDto();
        konto.setPersonen(personDtoList);
        konto.setKtan("70");

        return konto;
    }

    private static PersonDto getPersonDto(PersonAnschriftDto anschrift) {
        final PersonDto person = new PersonDto();
        person.setVorname("Jane");
        person.setName("Doe");
        person.setGeschlecht(PersonDto.GeschlechtEnum.WEIBLICH);
        person.setAnschrift(anschrift);
        person.setLaenderschluesselGeburtsort("000");
        person.setGeburtsdatum(LocalDate.of(1972, 8, 19).toString());
        person.setGeburtsort("Los Angeles");
        person.setTelefon("+49123456789");
        person.setTitel("Dr.");
        person.setVorsatzwort("Freifrau");
        person.setNamenszusatz("OBE");
        person.setStaatsangehoerigkeit("Deutsch");
        person.setAnrede(PersonDto.AnredeEnum.FRAU);
        return person;
    }

}
