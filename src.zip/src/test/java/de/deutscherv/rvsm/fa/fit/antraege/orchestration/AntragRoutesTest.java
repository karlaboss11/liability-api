package de.deutscherv.rvsm.fa.fit.antraege.orchestration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.kontoinformation.KontoinformationService;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalClient;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import io.quarkus.artemis.test.ArtemisTestResource;
import io.quarkus.test.InjectMock;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test AntragRoutes.
 */
@QuarkusTest
@Slf4j
@QuarkusTestResource(ArtemisTestResource.class)
class AntragRoutesTest extends CamelQuarkusTestSupport {
    private static KontoDto konto;
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static List<EinrichtungResponseExtended> einrichtungenResponseExtended70469;
    @Inject
    private AntragRepository repository;
    @Inject
    private DrvMandant mandant;
    @InjectMock
    @RestClient
    private SelbstmeldeportalClient selbstmeldeportalClient;
    @InjectMock
    private StammdatenService stammdatenService;
    @InjectMock
    private StatistikService statistikService;
    @InjectMock
    private KontoinformationService kontoinformationService;
    @InjectMock
    private RvPurService rvPurService;

    /**
     * Globale Testvorbereitungen.
     *
     * @throws JsonProcessingException Json fehlerhaft
     */
    @BeforeAll
    static void set() throws JsonProcessingException {
        final List<EinrichtungResponseExtended> einrichtungenResponseExtendedAll = OBJECT_MAPPER.readValue(jsonToString("einrichtung"
                + "/einrichtungen_all_extended.json"),
            new TypeReference<>() {
            });
        einrichtungenResponseExtended70469 = einrichtungenResponseExtendedAll.stream().filter(
                e -> e.getAngebote().stream().anyMatch(a -> a.getAdresse().getPlz().equals("70469")))
            .toList();

        konto = new KontoDto();
        konto.setVersicherungsnummer("04021093N590");
    }

    /**
     * Test, saveEantrag.
     */
    @SneakyThrows
    @Test
    @Transactional
    void testSaveEantrag() {
        Mockito.when(kontoinformationService.getKontoinformationEntity(any(), any())).thenReturn(new Kontoinformation());
        Mockito.when(stammdatenService.getStammdatenByVsnr(any()))
            .thenReturn(Stammdaten.builder().vsnr("04021093N590").build());
        Mockito.when(stammdatenService.getKontoDto(any())).thenReturn(konto);
        Mockito.when(selbstmeldeportalClient.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response.ok(einrichtungenResponseExtended70469).build());
        Mockito.when(statistikService.createStatistikAntragserfassung(any())).thenReturn(true);

        final var producerTemplate = context.createProducerTemplate();
        final String eantrag = new String(
            AntragRoutesTest.class.getClassLoader()
                .getResourceAsStream("eAntragXmls/eAntrag_04021093N590.xml").readAllBytes(),
            StandardCharsets.UTF_8);
        final var uuid = UUID.randomUUID();
        producerTemplate.sendBodyAndHeader(DIRECT_INIT_EANTRAG, eantrag, RVFitCamelHeader.ANTRAG_UUID, uuid);

        mandant.setInScope("70");
        final var antrag = repository.findByUuid(uuid);

        assertThat(antrag).isPresent();
        assertThat(antrag.get().getVsnr()).isEqualTo("04021093N590");
        assertThat(antrag.get().getStatus()).isEqualTo(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT);
        assertThat(antrag.get().getXml()).isEqualTo(eantrag);
    }

    /**
     * Test, save eAntrag Doppelvergabe.
     */
    @SneakyThrows
    @Test
    @Transactional
    void testSaveEantragDoppelvergabe() {
        Mockito.when(selbstmeldeportalClient.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response.ok(einrichtungenResponseExtended70469).build());
        Mockito.when(statistikService.createStatistikAntragserfassung(any())).thenReturn(true);

        final String eantrag = new String(
            AntragRoutesTest.class.getClassLoader()
                .getResourceAsStream("eAntragXmls/eAntrag_04121282D010.xml").readAllBytes(),
            StandardCharsets.UTF_8);

        final var producerTemplate = context.createProducerTemplate();
        final var uuid = UUID.randomUUID();
        producerTemplate.sendBodyAndHeader(DIRECT_INIT_EANTRAG, eantrag, RVFitCamelHeader.ANTRAG_UUID, uuid);

        mandant.setInScope("70");
        final var antrag = repository.findByUuid(uuid);

        assertThat(antrag).isPresent();
        assertThat(antrag.get().getVsnr()).isEqualTo("04121282D010");
        assertThat(antrag.get().getStatus()).isEqualTo(AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT);
        assertThat(antrag.get().getXml()).isEqualTo(eantrag);
    }
}
