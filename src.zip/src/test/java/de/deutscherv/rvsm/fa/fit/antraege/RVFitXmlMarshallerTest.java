package de.deutscherv.rvsm.fa.fit.antraege;

import com.fasterxml.jackson.core.JsonProcessingException;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test RvFitXmlMarshaller.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
public class RVFitXmlMarshallerTest {

    @Inject
    RVFitXmlMarshaller rVFitXmlMarshaller;

    private Map<String, String> xmlAntraege = null;

    @BeforeAll
    void set() {
        xmlAntraege =
                Xml.getXmlAntraege(Arrays.asList("eAntrag_04030583T112", "eAntrag_10241061D968"));
    }

    @Test
    void unmarshallXmlTest() throws JsonProcessingException {
        final String xml = xmlAntraege.get("eAntrag_04030583T112");
        final Antragsdaten antragsdaten = rVFitXmlMarshaller.unmarshall(Antragsdaten.class, xml);

        assertEquals("04030583T112", antragsdaten.getSteuerdaten().getVsnr());
        assertEquals("70", antragsdaten.getSteuerdaten().getEmpfaenger());
        assertEquals("52", antragsdaten.getSteuerdaten().getVersion());
        assertTrue(antragsdaten.getDaten().getAntrag().getFirst().isIsHauptantrag());
        assertEquals("g0180", antragsdaten.getDaten().getAntrag().getFirst().getName());
    }

    @Test
    void unmarshallXmlOhneEinrichtungenTest() throws JsonProcessingException {
        final String xml = xmlAntraege.get("eAntrag_10241061D968");
        final Antragsdaten antragsdaten = rVFitXmlMarshaller.unmarshall(Antragsdaten.class, xml);

        assertTrue(Objects.isNull(antragsdaten.getDaten().getAntrag().getFirst().getFrage().getFirst()
                .getZeile().getFirst().getFragefeld().get(0).getValue()));
        assertTrue(Objects.isNull(antragsdaten.getDaten().getAntrag().getFirst().getFrage().getFirst()
                .getZeile().getFirst().getFragefeld().get(1).getValue()));
        assertNull(antragsdaten.getDaten().getAntrag().getFirst().getFrage().getFirst().getZeile()
                .getFirst().getFragefeld().get(0).getValue());
        assertNull(antragsdaten.getDaten().getAntrag().getFirst().getFrage().getFirst().getZeile()
                .getFirst().getFragefeld().get(1).getValue());
    }
}
