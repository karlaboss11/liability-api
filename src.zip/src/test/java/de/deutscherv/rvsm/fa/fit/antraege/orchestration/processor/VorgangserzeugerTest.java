package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;

import java.util.UUID;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class VorgangserzeugerTest extends DefaultProcessorTest {


    @Test
    void sendeRvPurVorgangTest() throws Exception {
        final Exchange exchange = getExchange();
        final Antrag antrag = setExchangeMitAntrag(exchange, AntragStatus.ENTWURF);
        final var antragRepository = Mockito.mock(AntragRepository.class);
        RvPurService rvPurService = Mockito.mock(RvPurService.class);
        Mockito.when(antragRepository.merge(any()))
                .thenAnswer(invocation -> invocation.getArgument(0));
        Mockito.doNothing().when(rvPurService).sendeRvPurVorgang(any(Antrag.class));
        final Vorgangserzeuger vorgangserzeuger = new Vorgangserzeuger(rvPurService, true, antragRepository);
        vorgangserzeuger.process(exchange);
        final Antrag processedAntrag = (Antrag) exchange.getMessage().getBody();

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
        assertEquals(AntragStatus.VORGANG_WIRD_ERSTELLT, processedAntrag.getStatus());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange, final AntragStatus antragStatus) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(antragStatus).build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }
}
