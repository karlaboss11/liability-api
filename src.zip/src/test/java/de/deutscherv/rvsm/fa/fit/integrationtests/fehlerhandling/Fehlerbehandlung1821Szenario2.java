package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.integrationtests.EntityManagerProxy;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCreateDTO;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * siehe <a href="https://jira.service.zd.drv/browse/EVORVF2-1821">...</a>.
 */
public class Fehlerbehandlung1821Szenario2 extends RegressionsTestTemplate {
    private static final String AF_FEHLER = "AF4711";
    private static final RegressionsConfig INITIAL_CONFIG = new RegressionsConfig(true, true, false,
        new StammdatenConfig(null, AF_FEHLER, FehlerTyp.UNERWARTET_AF, HttpStatus.SC_INTERNAL_SERVER_ERROR));
    private static final RegressionsConfig NO_ERROR_CONFIG = new RegressionsConfig(true, true, false);

    private final String antragXml;
    private final FluentProducerTemplate producerTemplate;
    private final DrvMandant drvMandant;
    private final AntragRepository antragRepository;
    private final FehlerRepository fehlerRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final EntityManager entityManager;
    private final WireMockServer wireMockServer;
    private final PurAufgabenProducer purAufgabenProducer;

    private final EntityManagerProxy entityManagerProxy;
    private final CountDownLatch latch;

    /**
     * Konstruktor.
     *
     * @param drvMandant               DRV-Mandant
     * @param producerTemplate         Producertemplate
     * @param antragRepository         Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer      rvPuRAufgaben-Producer
     * @param entityManager            Entity-Manager
     * @param latch                    Latch
     * @param wireMockServer           Wiremockserver
     * @param testPerson               Testperson
     * @param fehlerRepository         Fehlerrepository
     * @param entityManagerProxy       EntityMangerProxy
     */
    public Fehlerbehandlung1821Szenario2(final TestPerson testPerson,
        final FluentProducerTemplate producerTemplate,
        final DrvMandant drvMandant,
        final AntragRepository antragRepository,
        final FehlerRepository fehlerRepository,
        final BestandsfehlerRepository bestandsfehlerRepository,
        final EntityManager entityManager,
        final WireMockServer wireMockServer,
        final PurAufgabenProducer purAufgabenProducer,
        final EntityManagerProxy entityManagerProxy,
        final CountDownLatch latch) {

        super(testPerson, INITIAL_CONFIG);
        this.producerTemplate = producerTemplate;
        this.drvMandant = drvMandant;
        this.antragRepository = antragRepository;
        this.fehlerRepository = fehlerRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.entityManager = entityManager;
        this.wireMockServer = wireMockServer;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManagerProxy = entityManagerProxy;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
        this.latch = latch;

    }

    @Override
    @SneakyThrows
    public boolean fuehreAus() {
        //lade einen Antrag hoch (AF-Fehler beim Abholen der Stammdaten)
        final var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        this.antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            // hole den Antrag frisch aus der DB
            final Antrag antrag = antragRepository.findByUuid(getAntragUuid()).orElseThrow();
            assertThat(antrag).isNotNull();
            // Status ist auf Stammdaten Fehler
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT);
            // Kein Fehler sollte zum Retry gespeichert wein
            final List<Fehler> fehler = fehlerRepository.findByAntrag(antrag);
            assertThat(fehler).isEmpty();
            entityManager.detach(antrag);
            fehler.forEach(entityManager::detach);
            // suche nach Bestandfehlern
            final List<Bestandsfehler> byAntragUuidNotDeleted = bestandsfehlerRepository.findByAntragUuidNotDeleted(antrag.getUuid());
            assertThat(byAntragUuidNotDeleted).hasSize(1);
            byAntragUuidNotDeleted.forEach(entityManager::detach);
            // überprüfe ob eine Aufgabe erzeugt wurde
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any(AufgabeCreateDTO.class));
        }
        // Rufe Bestanstandsfehler ab
        final BestandsfehlerDto bestandsfehlerDto
            = given()
            .contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
            .get("/antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_OK).extract()
            .as(BestandsfehlerDto.class);
        assertThat(bestandsfehlerDto.getUnerwartererFehler().getFehlercode()).isEqualTo(AF_FEHLER);
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).isNullOrEmpty();
        // reset der Fehler
        Mockito.clearInvocations(purAufgabenProducer);
        updateWireMockConfig(wireMockServer, NO_ERROR_CONFIG);

        // versuche erneut zu verarbeiten
        given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
            .post("antraege/{uuid}/erneuter-versuch").then().statusCode(HttpStatus.SC_OK);

        final boolean await = latch.await(3, TimeUnit.SECONDS);
        assertThat(await).isTrue();

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            // Antrag sollte voll verarbeitbar sein
            final Antrag antrag = entityManagerProxy.getAntragRefreshed(antragUuid, AntragStatus.STATISTIK_ABGESCHLOSSEN);
            final List<Bestandsfehler> bestandsFehler = bestandsfehlerRepository.findByAntragUuidNotDeleted(antrag.getUuid());
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
            assertThat(bestandsFehler).isEmpty();
            // Aufgabe wurde geschlossen
            Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());
        }
        // Ich habe fertig
        return true;
    }

}
