package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.jms.MessagingException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.NotAllowedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.NotSupportedException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.core.Response;
import java.util.NoSuchElementException;
import java.util.stream.Stream;
import org.jboss.resteasy.reactive.ClientWebApplicationException;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.testcontainers.shaded.org.apache.commons.lang3.NotImplementedException;

import static org.assertj.core.api.Assertions.assertThat;

class GenericExceptionMapperTest {

    private final GenericExceptionMapper mapper = new GenericExceptionMapper();

    private static Stream<Arguments> provideParameters() {
        return Stream.of(Arguments.of(new IllegalArgumentException(), Response.Status.BAD_REQUEST.getStatusCode()),
            Arguments.of(new ClientWebApplicationException(), Response.Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new ArrayIndexOutOfBoundsException(), Response.Status.SERVICE_UNAVAILABLE.getStatusCode()),
            Arguments.of(new NotAllowedException(""), Response.Status.METHOD_NOT_ALLOWED.getStatusCode()),
            Arguments.of(new NullPointerException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NotSupportedException(), Response.Status.UNSUPPORTED_MEDIA_TYPE.getStatusCode()),
            Arguments.of(new IllegalStateException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new ServiceUnavailableException(), Response.Status.SERVICE_UNAVAILABLE.getStatusCode()),
            Arguments.of(new Exception(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new IllegalStateException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new InternalServerErrorException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NoSuchElementException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NoSuchFieldException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NotFoundException(), Response.Status.NOT_FOUND.getStatusCode()),
            Arguments.of(new NotImplementedException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NullPointerException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new RuntimeException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new SecurityException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new UnsupportedOperationException(), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new MessagingException(new Exception()), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode())
        );
    }

    @ParameterizedTest
    @MethodSource("provideParameters")
    public void testGenericException(Throwable exception, int statusCode) {
        try (Response response = mapper.toResponse(exception)) {
            assertThat(response.getStatus())
                .as(exception.getClass().getSimpleName())
                .isEqualTo(statusCode);
        }
    }
}