package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1818">EVORVF2-1818</a>.
 * Szenario 1 (Bestandsfehler erneut verarbeiten)
 */
@Slf4j
@Getter
public class Fehlerbehandlung1818Szenario1BestandsfehlerErneuterVersuch extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0075";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;
    private final WireMockServer wireMockServer;
    private final String antragXml;
    private final int httpCode;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param latch Latch
     * @param wireMockServer Wiremockserver
     * @param httpCode httpCode
     */
    public Fehlerbehandlung1818Szenario1BestandsfehlerErneuterVersuch(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final BestandsfehlerRepository bestandsfehlerRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final EntityManager entityManager,
            final CountDownLatch latch,
            final WireMockServer wireMockServer, int httpCode) {
        super(TestPerson.ERIC_CARTMANN,
                new RegressionsConfig(true, true, false,
                        new KontoinformationConfig(FehlerTyp.UNERWARTET_AF, "AF0005", 500)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManager = entityManager;
        this.latch = latch;
        this.wireMockServer = wireMockServer;
        this.httpCode = httpCode;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        Mockito.clearInvocations(purAufgabenProducer);

        var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (final AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT);
            entityManager.detach(antrag);
        }

        final BestandsfehlerDto bestandsfehlerDto = given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .get("/antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_OK).extract().as(BestandsfehlerDto.class);
        assertThat(bestandsfehlerDto.getVorname()).isEqualTo("Eric");
        assertThat(bestandsfehlerDto.getName()).isEqualTo("Cartman");
        assertThat(bestandsfehlerDto.getVsnr()).isEqualTo(getTestPerson().VSNR);

        updateWireMockConfig(wireMockServer, new RegressionsConfig(true, true, false,
                new StammdatenConfig(null, AF_STATUSCODE, FehlerTyp.UNERWARTET_AF, httpCode)));

        given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .post("antraege/{uuid}/erneuter-versuch").then().statusCode(HttpStatus.SC_LOCKED);

        Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());

        try (final AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
            antrag.getAufgaben().forEach(aufgabe -> assertThat(aufgabe.getDatumErledigt()).isNotNull());

            List<Bestandsfehler> bestandsfehlerList = bestandsfehlerRepository.findByAntragUuidNotDeleted(antragUuid);
            assertThat(bestandsfehlerList).isEmpty();
        }

        return true;
    }

}
