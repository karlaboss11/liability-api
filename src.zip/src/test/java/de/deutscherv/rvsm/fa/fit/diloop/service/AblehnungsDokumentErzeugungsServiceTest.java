package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import jakarta.validation.ValidationException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static de.deutscherv.rvsm.fa.fit.testdaten.TestPerson.LYSANDER_THALBERG;
import static de.deutscherv.rvsm.fa.fit.testdaten.TestPerson.MENSCH_MEIER;
import static de.deutscherv.rvsm.fa.fit.testdaten.TestPerson.PETER_PAN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test AblehnungsDokumentERzeugungsService.
 */
class AblehnungsDokumentErzeugungsServiceTest extends DokumentenErzeugungsServiceTestParent {

    private static AblehnungsDokumentErzeugungsService ablehnungsDoeService;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void setup() {
        ablehnungsDoeService =
            new AblehnungsDokumentErzeugungsService(new DokumentenErzeugungTestConfig());
    }

    /**
     * Vorbereitung vor jedem Test.
     */
    @BeforeEach
    void reset() {
        this.dto = null;
    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @SneakyThrows
    @AfterEach
    void afterEach() {
        printResult();
    }

    /**
     * Test, Dokumentenerzeugung fpr Staatsangehörigkeit Regel nicht erfüllt.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungFuerStaatsangehoerigkeitRegelNichtErfuellt() {
        final DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(PETER_PAN);

        this.dto = ablehnungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(PETER_PAN.VSNR);
        assertThat(dto.getAigr()).isEqualTo(String.format("%04d", daten.antrag().getAtad()));
        final Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen).isNotNull().isNotEmpty();
        assertThat(variablen.get("rvEvolution")).isEqualTo("1");
        assertThat(variablen).containsEntry("sv_op_G9581_00_Ablehnungsgrund", "0")
            .containsEntry("USEQ_RBH_22_op_Inland_Ausland_EU", "1")
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()));
    }

    /**
     * Test, Dokumentenerzeugung für Massnahme Regel nicht erfüllt.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungFuerMassnahmeRegelNichtErfuellt() {
        final DokumentenErstellungsDaten daten =
            erstelleDokumentenErstellungsTestDaten(LYSANDER_THALBERG);

        this.dto = ablehnungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(LYSANDER_THALBERG.VSNR);
        assertThat(dto.getAigr()).isEqualTo(String.format("%04d", daten.antrag().getAtad()));
        final Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen)
            .isNotNull()
            .isNotEmpty()
            .containsEntry("sv_op_G9581_00_Ablehnungsgrund", "1")
            .containsEntry("USEQ_RBH_22_op_Inland_Ausland_EU", "2")
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()));
        assertDoesNotThrow(
            () -> LocalDate.parse(variablen.get("sv_d_G9581_00_vorhergehende_Leistung_End")));
    }

    /**
     * Test, Dokumentenerzeugung NotFountException falls kein Ablehnungsgrund vorhanden.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungNotFoundExceptionFallsKeinAblehnungsGrundVorhanden() {
        final DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(PETER_PAN);
        for (AntragPruefergebnis antragPruefergebnis : daten.antrag().getAntragPruefergebnisse()) {
            antragPruefergebnis.setErgebnis(PruefErgebnis.ERFUELLT);
        }
        assertThrows(ValidationException.class,
            () -> ablehnungsDoeService.erzeugeAuftragsDto(daten));
    }

    /**
     * TEst Dokumentenerzeugung für Regel nicht erfüllt.
     *
     * @param regelName       Name der Regel
     * @param ablehnungsGrund Ablehnungsgrund
     */
    @SneakyThrows
    @CsvSource(textBlock = """
        REGEL_STAATSANGEHOERIGKEIT,0
        REGEL_MASSNAHME,1
        REGEL_AKTIVEBESCHAEFTIGUNG,2
        REGEL_ALTERSTEILZEIT,2
        REGEL_WARTEZEITPRUEFUNG,3
        REGEL_AUFENTHALT,4
        REGEL_ANTRAGALTERSRENTE,5
        REGEL_BEZUGALTERSRENTE,5
        REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT,6
        REGEL_BEAMTENEIGENSCHAFT_BEZUEGE,7
        """)
    @ParameterizedTest
    void testeDokumentenErzeugungFuerRegelNichtErfuellt(final String regelName,
        final String ablehnungsGrund) {
        final DokumentenErstellungsDaten daten =
            erstelleDokumentenErstellungsTestDaten(LYSANDER_THALBERG);

        final AntragPruefergebnis pruefergebnisZurRegel = daten.antrag().getAntragPruefergebnisse()
            .stream().filter(a -> a.getRegelName() == RegelName.valueOf(regelName)).findFirst()
            .orElseThrow();
        pruefergebnisZurRegel.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        this.dto = ablehnungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getAigr()).isEqualTo(String.format("%04d", daten.antrag().getAtad()));
        final Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen)
            .isNotNull()
            .isNotEmpty()
            .containsEntry("sv_op_G9581_00_Ablehnungsgrund", ablehnungsGrund)
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()));
    }

    /**
     * Test, manuelles Eingreifen.
     */
    @Test
    @SneakyThrows
    void testeManuellesEingreifen() {
        final DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(MENSCH_MEIER);

        final List<AntragPruefergebnis> pruefergebnisse = daten.antrag().getAntragPruefergebnisse();

        final AntragPruefergebnis korrigiertesErgebnis = new AntragPruefergebnis();
        korrigiertesErgebnis.setErgebnis(PruefErgebnis.ERFUELLT);
        korrigiertesErgebnis.setPrioritaet(14L);
        korrigiertesErgebnis.setRegelId(26L);
        korrigiertesErgebnis.setKtan("70");
        korrigiertesErgebnis.setBegruendung("manuell eingegriffen");
        korrigiertesErgebnis.setRegelName(RegelName.REGEL_MASSNAHME);
        korrigiertesErgebnis.setLastModified(LocalDateTime.now());

        pruefergebnisse.add(korrigiertesErgebnis);

        daten.antrag().setAntragPruefergebnisse(pruefergebnisse);

        this.dto = ablehnungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(MENSCH_MEIER.VSNR);
        assertThat(dto.getAigr()).isEqualTo(String.format("%04d", daten.antrag().getAtad()));
        final Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen)
            .isNotNull()
            .isNotEmpty()
            .containsEntry("sv_op_G9581_00_Ablehnungsgrund", "4")
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()));
    }

}
