package de.deutscherv.rvsm.fa.fit.integrationtests;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.RetryRoutes;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import java.util.Map;
import java.util.UUID;
import lombok.SneakyThrows;
import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes.DIRECT_ERROR;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test Fehlerbehandlungen.
 */
@QuarkusTest
public class FehlerbehandlungsTest extends CamelQuarkusTestSupport {
    static WireMockServer wireMockServer;
    @Inject
    private FluentProducerTemplate producerTemplate;
    @Inject
    private FehlerRepository fr;
    @Inject
    private AntragRepository ar;
    @Inject
    private DrvMandant mandant;
    @Inject
    private EntityManager em;

    @Override
    public boolean isUseAdviceWith() {
        return true;
    }

    /**
     * Globale Vorbereitungen.
     */
    @BeforeAll
    static void init() {
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);
        wireMockServer.start();
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void shutDown() {
        WireMockStub.disconnect(wireMockServer);
    }

    /**
     * Test FehlerCounter.
     */
    @SneakyThrows
    @Test
    void fehlerCounterTest() {
        AdviceWith.adviceWith(context, DIRECT_ERROR, a ->
                a.weaveAddLast().to("mock:error")
        );
        final var mockEndpoint = getMockEndpoint("mock:error");
        mockEndpoint.expectedMessageCount(1);
        context.start();
        final var uuid = UUID.randomUUID();
        final var exchange = producerTemplate.withBody(
                Xml.getXmlAntrag("eAntragXmls/eAntrag_" + TestPerson.PETER_PAN.VSNR + ".xml"))
                .withHeaders(Map.of(RVFitCamelHeader.ANTRAG_UUID, uuid, DRVHeader.MANDANT_PROPERTY_KEY, "70"))
                .to(EingangEAntragRoutes.DIRECT_INIT_EANTRAG)
                .send();//)
        final var exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        assertThat(exception).isNotNull();
        mandant.setInScope("70");
        var antrag = ar.findByUuid(uuid).orElseThrow();
        var fehlerList = fr.findByAntrag(antrag);
        assertThat(fehlerList.size()).isEqualTo(1);
        assertThat(fehlerList.getFirst().getRetries()).isEqualTo(0);
        em.detach(antrag);
        producerTemplate.to(RetryRoutes.DIRECT_RETRY).send();

        mandant.setInScope("70");
        fehlerList.forEach(em::detach);
        fr.flush();

        fehlerList = fr.findByAntrag(antrag);
        assertThat(fehlerList).hasSize(1);
        assertThat(fehlerList.getFirst().getRetries()).isEqualTo(1);

        stubAll();
        producerTemplate.to(RetryRoutes.DIRECT_RETRY).send();
        mandant.setInScope("70");
        fehlerList.forEach(em::detach);
        em.detach(antrag);
        antrag = ar.findByUuid(uuid).orElseThrow();
        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.VORGANG_ERZEUGT);
        fehlerList = fr.findByAntrag(antrag);
        assertThat(fehlerList).isEmpty();
    }

    private void stubAll() {

        WireMockStub.stubForRvPur();
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForStammdaten(TestPerson.PETER_PAN);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);

    }

}
