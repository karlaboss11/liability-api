package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import io.quarkus.test.junit.QuarkusTest;
import java.util.UUID;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integrationstest für den Doppelvergabe-Prozessor {@link DoppelvergabeProcessor}.
 */
@QuarkusTest
class DoppelvergabeProcessorTest extends DefaultProcessorTest {

    DoppelvergabeProcessor doppelvergabeProcessor;

    AufgabeService aufgabeService;

    AntragRepository antragRepository;


    @BeforeEach
    void init() {
        aufgabeService = Mockito.mock(AufgabeService.class);
        antragRepository = Mockito.mock(AntragRepository.class);
        final RvfitLogger rvfitLogger = Mockito.mock(RvfitLogger.class);
        final DrvMandant drvMandant = Mockito.mock(DrvMandant.class);
        final JsonWebToken jwt = Mockito.mock(JsonWebToken.class);

        doppelvergabeProcessor = new DoppelvergabeProcessor(aufgabeService, antragRepository, rvfitLogger, drvMandant, jwt);
    }

    @Test
    void testDoppelvergabe() throws Exception {
        var antrag = Antrag.builder()
                .uuid(UUID.randomUUID())
                .status(AntragStatus.STATISTIK_ERFASST)
                .doppelvergabe(DoppelvergabeStatus.PRUEFEN)
                .build();

        var exchange = getExchange();
        var message = getMessage();
        exchange.setMessage(message);
        message.setBody(antrag);

        doppelvergabeProcessor.process(exchange);

        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT);
        assertThat(exchange.isRouteStop()).isTrue();
        Mockito.verify(aufgabeService).erstellePurAufgabe(Mockito.same(antrag), Mockito.same(AufgabenArt.DOPPELVERGABE));
    }

    @Test
    void testKeineDoppelvergabe() throws Exception {
        var antrag = Antrag.builder()
                .uuid(UUID.randomUUID())
                .status(AntragStatus.STATISTIK_ERFASST)
                .doppelvergabe(DoppelvergabeStatus.KEINE_DOPPELVERGABE)
                .build();

        var exchange = getExchange();
        var message = getMessage();
        exchange.setMessage(message);
        message.setBody(antrag);

        doppelvergabeProcessor.process(exchange);

        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);
        assertThat(exchange.isRouteStop()).isFalse();
        Mockito.verifyNoInteractions(aufgabeService);
    }

}
