package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.persistence.EntityManager;
import java.util.UUID;
import org.apache.camel.Exchange;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * Test des PersonendatenabgleichProcessor.
 **/
@QuarkusTest
class PersonendatenableichProcessorTest extends DefaultProcessorTest {

    private PersonendatenableichProcessor personendatenableichProcessor;

    /**
     * Stammdaten sollen geaendert werden.
     *
     * @throws Exception kommt hoffentlich nicht vor.
     */
    @Test
    void shouldUpdateStammdatenTest() throws Exception {
        final EntityManager entityManager = Mockito.mock(EntityManager.class);

        final UUID uuid = UUID.randomUUID();
        final Antrag antrag =
            Antrag.builder().uuid(uuid).ktan("70").vsnr(TestPerson.HARVEY_DENT.VSNR).build();
        antrag.addVersicherte(Stammdaten.builder().vsnr(TestPerson.HARVEY_DENT.VSNR).build());
        final AntragService antragService = Mockito.mock(AntragService.class);
        when(antragService.getAntragByUuid(any(UUID.class))).thenReturn(antrag);

        final StammdatenService stammdatenService = Mockito.mock(StammdatenService.class);
        when(stammdatenService.getStammdatenByVsnr(any()))
            .thenReturn(Stammdaten.builder().vsnr(TestPerson.PETER_PAN.VSNR).build());

        final ExceptionHandler exceptionHandler = Mockito.mock(ExceptionHandler.class);
        doNothing().when(exceptionHandler).process(any());
        doNothing().when(exceptionHandler).handleExceptionForRetry(any(), any(), any());

        personendatenableichProcessor = new PersonendatenableichProcessor(entityManager,
            antragService, stammdatenService, exceptionHandler);

        final Exchange exchange = getExchange();
        exchange.getMessage().setHeader(RVFitCamelHeader.ANTRAG_UUID, uuid);

        personendatenableichProcessor.process(exchange);

        assertEquals(true, exchange.getMessage().getHeader("stammdatenUpdated"));
        Assertions.assertEquals(TestPerson.PETER_PAN.VSNR,
            exchange.getMessage().getBody(Antrag.class).getVersichertenStammdaten().getFirst()
                .getVsnr());
    }

    /**
     * Stammdaten sollten nicht geaendert werden.
     *
     * @throws Exception kommt hoffentlich nicht vor.
     */
    @Test
    void shoulNotdUpdateStammdatenTest() throws Exception {
        final EntityManager entityManager = Mockito.mock(EntityManager.class);

        final UUID uuid = UUID.randomUUID();
        final Antrag antrag =
            Antrag.builder().uuid(uuid).ktan("70").vsnr(TestPerson.HARVEY_DENT.VSNR).build();
        antrag.addVersicherte(Stammdaten.builder().vsnr(TestPerson.HARVEY_DENT.VSNR).build());
        final AntragService antragService = Mockito.mock(AntragService.class);
        when(antragService.getAntragByUuid(any(UUID.class))).thenReturn(antrag);

        final StammdatenService stammdatenService = Mockito.mock(StammdatenService.class);
        when(stammdatenService.getStammdatenByVsnr(any()))
            .thenReturn(Stammdaten.builder().vsnr(TestPerson.HARVEY_DENT.VSNR).build());

        final ExceptionHandler exceptionHandler = Mockito.mock(ExceptionHandler.class);
        doNothing().when(exceptionHandler).process(any());
        doNothing().when(exceptionHandler).handleExceptionForRetry(any(), any(), any());

        personendatenableichProcessor = new PersonendatenableichProcessor(entityManager,
            antragService, stammdatenService, exceptionHandler);

        final Exchange exchange = getExchange();
        exchange.getIn().setHeader(RVFitCamelHeader.ANTRAG_UUID, uuid);

        personendatenableichProcessor.process(exchange);

        assertEquals(false, exchange.getMessage().getHeader("stammdatenUpdated"));
        Assertions.assertEquals(TestPerson.HARVEY_DENT.VSNR,
            exchange.getMessage().getBody(Antrag.class).getVersichertenStammdaten().getFirst()
                .getVsnr());
    }
}
