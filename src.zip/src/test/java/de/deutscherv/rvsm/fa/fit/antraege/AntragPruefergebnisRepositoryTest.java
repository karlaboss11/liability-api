package de.deutscherv.rvsm.fa.fit.antraege;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Test AntragPruefergebnisRepository.
 */
@QuarkusTest
class AntragPruefergebnisRepositoryTest {

    private static final String DETAIL_1 = "Ich bin Ergebnis 1";

    @Inject
    EntityManager em;
    private final Function<UUID, AntragPruefergebnis> find =
        id -> em.find(AntragPruefergebnis.class, id);

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private PruefergebnisService pruefergebnisService;

    @Inject
    private DrvMandant drvMandant;

    @InjectMock
    private AntragService antragService;

    /**
     * Teste Speichern von Prüfergebnis.
     */
    @Test
    @Transactional
    void speicherPruefergebnisSuccess() {
        drvMandant.setInScope("17");
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setBegruendung("");
        antragPruefergebnis.setErgebnis(PruefErgebnis.AUSSTEUERN);
        antragPruefergebnis.setParentUuid(null);
        final Antrag antrag = getAntragTest(LocalDate.now().toString(), "65170839J088",
            "Hans Dampf Weg", null, antragPruefergebnis);
        antragRepository.persist(antrag);
        final UUID id = antrag.getAntragPruefergebnisse().getFirst().getUuid();

        assertNotNull(id);
        assertNotNull(find.apply(id));
    }

    /**
     * Teste Speichern von Prüfergebnis mit Regel und Ergebnis.
     */
    @Test
    @Transactional
    void speicherPruefergebnisMitRegelundErgebnisSuccess() {
        drvMandant.setInScope("70");

        WireMockServer wireMockServer = WireMockStub.connect(WireMockStub.PORT);
        WireMockStub.stubForKontoinformation(TestPerson.HARVEY_DENT);
        WireMockStub.stubForSmp(null, null, null, null, null);

        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setBegruendung("lol");
        antragPruefergebnis.setErgebnis(PruefErgebnis.AUSSTEUERN);
        antragPruefergebnis.setParentUuid(null);

        final RegelErgebnis r1 = new RegelErgebnis();
        r1.setDetail(DETAIL_1);
        r1.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r1.setRegelName(RegelName.REGEL_MASSNAHME);

        Antrag antrag = getAntragTest(LocalDate.now().toString(), TestPerson.HARVEY_DENT.VSNR,
            "Hans Dampf Weg", "17", antragPruefergebnis);
        pruefergebnisService.speicherePruefergebnis(antrag, r1);
        antrag = antragRepository.findByUuid(antrag.getUuid()).get();

        antrag = pruefergebnisService.checkAnspruchspruefung(antrag);
        final UUID id1 = antrag.getAntragPruefergebnisse().get(0).getUuid();
        final UUID id2 = antrag.getAntragPruefergebnisse().get(1).getUuid();

        assertNotNull(id1);
        assertNotNull(id2);

        final AntragPruefergebnis a1 = find.apply(id1);
        final AntragPruefergebnis a2 = find.apply(id2);

        assertNotNull(a1);
        assertEquals(PruefErgebnis.AUSSTEUERN, a1.getErgebnis());
        assertEquals("lol", a1.getBegruendung());
        assertNotNull(a2);
        assertEquals(DETAIL_1, a2.getBegruendung());
        assertEquals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, a2.getErgebnis());
        wireMockServer.shutdown();
    }

    /**
     * Teste Speichern von Prüfergebnis mit Regel.
     */
    @Test
    @Transactional
    void speicherPruefergebnisMitRegelSuccess() {
        drvMandant.setInScope("17");
        final RegelErgebnis r1 = new RegelErgebnis();
        r1.setDetail(DETAIL_1);
        r1.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r1.setRegelName(RegelName.REGEL_MASSNAHME);

        Antrag antrag =
            getAntragTest(LocalDate.now().toString(), "65170839J088", "Hans Dampf Weg", "17", null);
        pruefergebnisService.speicherePruefergebnis(antrag, r1);

        antrag = antragRepository.findByUuid(antrag.getUuid()).get();

        final UUID id = antrag.getAntragPruefergebnisse().getFirst().getUuid();

        assertNotNull(id);
        final AntragPruefergebnis a1 = find.apply(id);
        assertNotNull(a1);
        assertEquals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, a1.getErgebnis());
        assertEquals(DETAIL_1, a1.getBegruendung());
    }

    /**
     * Teste Speichern von verschachteltem Prüfergebnis.
     */
    @Test
    @Transactional
    void speicherPruefergebnisMitRegelVerschachteltSuccess() {
        drvMandant.setInScope("17");
        final RegelErgebnis r5 = new RegelErgebnis();
        r5.setDetail("Ich bin Ergebnis 5");
        r5.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r5.setRegelName(RegelName.REGEL_MASSNAHME);

        final RegelErgebnis r4 = new RegelErgebnis();
        r4.setDetail("Ich bin Ergebnis 4");
        r4.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r4.setRegelName(RegelName.REGEL_MASSNAHME);

        final RegelErgebnis r3 = new RegelErgebnis();
        r3.setDetail("Ich bin Ergebnis 3");
        r3.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r3.setRegelName(RegelName.REGEL_MASSNAHME);

        final RegelErgebnis r2 = new RegelErgebnis();
        r2.setDetail("Ich bin Ergebnis 2");
        r2.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r2.setRegelName(RegelName.REGEL_MASSNAHME);

        final RegelErgebnis r1 = new RegelErgebnis();
        r1.setDetail("Ich bin Ergebnis 1");
        r1.setPruefErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        r1.setRegelName(null);
        r1.setDetailErgebnisse(new ArrayList<>(List.of(r2, r3, r4, r5)));

        Antrag antrag =
            getAntragTest(LocalDate.now().toString(), "65170839J088", "Hans Dampf Weg", "17", null);
        pruefergebnisService.speicherePruefergebnis(antrag, r1);
        pruefergebnisService.speicherePruefergebnis(antrag, r2);
        pruefergebnisService.speicherePruefergebnis(antrag, r3);
        pruefergebnisService.speicherePruefergebnis(antrag, r4);
        pruefergebnisService.speicherePruefergebnis(antrag, r5);

        antrag = antragRepository.findByUuid(antrag.getUuid()).get();

        final UUID id1 = antrag.getAntragPruefergebnisse().get(0).getUuid();
        final UUID id2 = antrag.getAntragPruefergebnisse().get(1).getUuid();
        final UUID id3 = antrag.getAntragPruefergebnisse().get(2).getUuid();
        final UUID id4 = antrag.getAntragPruefergebnisse().get(3).getUuid();
        final UUID id5 = antrag.getAntragPruefergebnisse().get(4).getUuid();

        final AntragPruefergebnis a1 = find.apply(id1);
        final AntragPruefergebnis a2 = find.apply(id2);
        final AntragPruefergebnis a3 = find.apply(id3);
        final AntragPruefergebnis a4 = find.apply(id4);
        final AntragPruefergebnis a5 = find.apply(id5);
        assertNotNull(a1);
        assertNotNull(a2);
        assertNotNull(a3);
        assertNotNull(a4);
        assertNotNull(a5);

        assertEquals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, a1.getErgebnis());
        assertEquals(DETAIL_1, a1.getBegruendung());
        assertNull(a1.getParentUuid());
        assertNull(a1.getPrioritaet());
        assertNull(a1.getRegelId());

        assertEquals(RegelName.REGEL_MASSNAHME.getId(), a2.getRegelId());
        assertEquals(14L, a2.getPrioritaet());

        assertEquals(RegelName.REGEL_MASSNAHME.getId(), a3.getRegelId());
        assertEquals(14L, a3.getPrioritaet());

        assertEquals(RegelName.REGEL_MASSNAHME.getId(), a4.getRegelId());
        assertEquals(14L, a4.getPrioritaet());

        assertEquals(RegelName.REGEL_MASSNAHME.getId(), a5.getRegelId());
        assertEquals(14L, a5.getPrioritaet());
    }

    /**
     * Testantrag.
     *
     * @param datum               datum
     * @param vsnr                vsnr
     * @param strasse             straße
     * @param antragPruefergebnis prüfergebnis
     * @param ktan                DRV-Mandaten
     * @return Antrag
     */
    private Antrag getAntragTest(final String datum, final String vsnr, final String strasse,
        final String ktan, final AntragPruefergebnis antragPruefergebnis) {
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        final Antrag antrag = new Antrag();
        antrag.addVersicherte(getVersicherterTest(vsnr, strasse));
        antrag.addAntragPruefergebnis(antragPruefergebnis);
        antrag.setVsnr(vsnr);
        antrag.setKtan(ktan);
        antrag.setGeburtsdatum(LocalDate.of(1970, 5, 1));
        antrag.setGeburtsdatumStatus(GeburtsdatumStatus.OK);
        final LocalDate antragsdatum = LocalDate.parse(datum, formatter);
        antrag.setAntragsDatum(antragsdatum);
        return antrag;
    }

    /**
     * Teststammdaten.
     *
     * @param vsnr    vsnr
     * @param strasse straße
     * @return Stammdaten
     */
    private Stammdaten getVersicherterTest(final String vsnr, final String strasse) {
        final Stammdaten versicherter = new Stammdaten();
        versicherter.setVsnr(vsnr);
        versicherter.setVorname("");
        versicherter.setNachname("");
        versicherter.setStrasse(strasse);
        versicherter.setHausnummer("");
        versicherter.setPlz("");
        versicherter.setWohnort("");
        return versicherter;
    }
}
