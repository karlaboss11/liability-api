package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DefaultProcessorTest;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.util.DauerMetricUtil;
import de.deutscherv.rvsm.fa.fit.util.FehlerMetricUtil;
import java.util.List;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;

/**
 * Test von  StatusBasierterDynamischerRouter.
 */
class StatusBasierterDynamischerRouterTest extends DefaultProcessorTest {

    private static final FehlerMetricUtil FMU = Mockito.mock(FehlerMetricUtil.class);
    private static final DauerMetricUtil DMU = Mockito.mock(DauerMetricUtil.class);
    private static final FehlerRepository FR = Mockito.mock(FehlerRepository.class);
    private static StatusBasierterDynamischerRouter sbr;
    private static Fehler fehler;
    private static Antrag antrag;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void init() {
        final var uuid = UUID.randomUUID();
        antrag = Antrag.builder().uuid(uuid).build();
        fehler = Fehler.builder()
            .antragId(antrag.getUuid())
            .status(AntragStatus.VORGANG_ERZEUGT)
            .retries(0)
            .build();
        Mockito.when(FR.findByAntrag(any())).thenReturn(List.of(fehler));
        sbr = new StatusBasierterDynamischerRouter(FMU, FR, DMU);
    }

    /**
     * siehe <a href="https://jira.service.zd.drv/browse/EVORVF1-1876"></a>.
     */
    @Test
    void fehlerLoeschung() {

        final var exc = getExchange();

        //Noch kein Fehler
        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, null, exc)).isEqualTo("direct:initEantrag");
        antrag.setStatus(AntragStatus.ENTWURF);

        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, null, exc)).isEqualTo("direct:erstelleVorgang");
        antrag.setStatus(AntragStatus.VORGANG_WIRD_ERSTELLT);
        antrag.setStatus(AntragStatus.VORGANG_ERZEUGT);

        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, null, exc)).isEqualTo("direct:getMetadata");
        Mockito.verify(FR, Mockito.never()).delete(any());
        Mockito.verify(FR, Mockito.never()).deleteAll(any());

        // Fehler tritt auf, verarbeitung wird erneut angestoßen
        exc.getMessage().setHeader(RVFitCamelHeader.RVFIT_FEHLER, fehler);
        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, fehler, exc)).isEqualTo("direct:getMetadata");
        Mockito.verify(FR, Mockito.never()).delete(any());
        Mockito.verify(FR, Mockito.never()).deleteAll(any());

        //Antrag konnte weiter verarbeitet werden und wird erneut geroutet
        antrag.setStatus(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, fehler, exc)).isEqualTo("direct:erfasseStatistik");

        Mockito.verify(FR, Mockito.atLeastOnce()).delete(any());
        Mockito.verify(FR, Mockito.never()).deleteAll(any());

        // Am Ende werden alle gelöscht
        Mockito.when(FR.findByAntrag(any())).thenReturn(List.of(fehler));
        antrag.setStatus(AntragStatus.STATISTIK_ERFASST);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.setStatus(AntragStatus.AUFGABE_ABGESCHLOSSEN);
        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, fehler, exc)).isEqualTo("direct:schliesseStatistikAb");
        antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        Assertions.assertThat(sbr.statusBasiertesRouting(antrag, fehler, exc)).isNull();
        Mockito.verify(FR, Mockito.atLeastOnce()).delete(any(Fehler.class));
        Mockito.verify(FR, Mockito.atLeastOnce()).deleteAll(anyList());

    }
}
