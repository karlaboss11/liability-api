package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DefaultProcessorTest;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapperImpl;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AntragsdatenToAntragMapperTest extends DefaultProcessorTest {
    private final AntragsdatenToAntragMapper mapper = new AntragsdatenToAntragMapper(new AntragMapperImpl());
    private final RVFitXmlMarshaller antragsmarMarshaller = new RVFitXmlMarshaller();

    @SneakyThrows
    @Test
    void testAntragsdatenMapping() {

        final var message = this.getMessage();
        Antragsdaten antragsdaten = antragsmarMarshaller.unmarshall(Antragsdaten.class,
                Xml.getXmlAntrag("eAntragXmls/eAntrag_15280982D041.xml"));

        message.setBody(antragsdaten);
        final var exchange = getExchange(message);
        mapper.process(exchange);
        final var antrag = exchange.getMessage().getBody(Antrag.class);
        assertThat(antrag).isNotNull();
        assertThat(antrag.getVsnr()).isEqualTo("15280982D041");
    }

}