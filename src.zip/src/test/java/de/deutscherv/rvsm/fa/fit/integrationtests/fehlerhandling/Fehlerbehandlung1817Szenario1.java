package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import jakarta.persistence.EntityManager;
import java.util.concurrent.CountDownLatch;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1817">EVORVF2-1817</a>.
 * Szenario 1
 */
@Slf4j
@Getter
public class Fehlerbehandlung1817Szenario1 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF2001";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param latch Latch
     */
    public Fehlerbehandlung1817Szenario1(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final BestandsfehlerRepository bestandsfehlerRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final EntityManager entityManager,
            final CountDownLatch latch) {
        super(TestPerson.HARVEY_DENT,
                new RegressionsConfig(true, true, false,
                        new StammdatenConfig(null, AF_STATUSCODE, FehlerTyp.UNERWARTET_AF, 500)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManager = entityManager;
        this.latch = latch;
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        final AntwortDto antwortDto = given().pathParam("versicherungsnummer", getTestPerson().VSNR)
                                        .get("/stammdaten/{versicherungsnummer}").then()
                                        .contentType("application/json").statusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                                        .extract().as(AntwortDto.class);
        final BestandsfehlerDto bestandsfehler = antwortDto.getBestandsfehler();
        assertThat(bestandsfehler.getUnerwartererFehler().getFehlercode()).isEqualTo(AF_STATUSCODE);
        assertThat(bestandsfehler.getVsnr()).isEqualTo(getTestPerson().VSNR);
        assertThat(bestandsfehler.getName()).isEqualTo("");
        assertThat(bestandsfehler.getVorname()).isEqualTo("");

        return true;
    }

}
