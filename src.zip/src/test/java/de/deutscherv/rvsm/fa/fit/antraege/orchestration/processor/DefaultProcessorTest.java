package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.support.DefaultExchange;
import org.apache.camel.support.DefaultMessage;

/**
 * Test DefaultProcessor.
 */
public abstract class DefaultProcessorTest {
    final CamelContext defaultCamelContext = new DefaultCamelContext();

    protected Exchange getExchange() {
        return new DefaultExchange(defaultCamelContext);
    }

    protected Exchange getExchange(Message message) {
        var exchange = new DefaultExchange(defaultCamelContext);
        exchange.setMessage(message);
        return exchange;
    }

    protected Message getMessage() {
        return new DefaultMessage(defaultCamelContext);
    }
}
