package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.azk.AzkException;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalClientException;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.verarbeitung.VerarbeitungsstatusUpdateException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import static org.assertj.core.api.Assertions.assertThat;

class RvfitExceptionMapperTest {

    private final RvfitExceptionMapper mapper = new RvfitExceptionMapper();

    private static final int HTTP_STATUS_LOCK = 423;

    private static Stream<Arguments> provideParameters() {
        return Stream.of(
            Arguments.of(new DokumentenErzeugungsException("", new NullPointerException()),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new NichtAutorisiertException("", "", ""),
                Status.UNAUTHORIZED.getStatusCode()),
            Arguments.of(new KontoinformationException("", new NullPointerException()),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new EingabevalidierungException("", "", ""),
                Status.BAD_REQUEST.getStatusCode()),
            Arguments.of(new KtanException(""),
                Status.UNAUTHORIZED.getStatusCode()),
            Arguments.of(new MapperException(""),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new RvPurClientException("", new NullPointerException()),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new SelbstmeldeportalClientException("", new NullPointerException()),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new StammdatenException(""),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new AntragLockException(UUID.randomUUID(), new InterruptedException()),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new KontoGesperrtException("", "", new WebApplicationException()),
                HTTP_STATUS_LOCK),
            Arguments.of(new AzkException(""),
                Status.FORBIDDEN.getStatusCode()),
            Arguments.of(new StatistikException(""),
                Status.BAD_GATEWAY.getStatusCode()),
            Arguments.of(new UnvollstaendigeStammdatenException(""),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new DoeNoAcceptedResponseException(""),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new KontoinformationBestandsFehlerException("Fehler", createAntrag(), createFehlerEintragDto()),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new KeinAntragInBearbeitungException("uuID"),
                Status.NOT_FOUND.getStatusCode()),
            Arguments.of(new PapierantragValidierungException("Fehler"),
                Status.BAD_REQUEST.getStatusCode()),
            Arguments.of(new StammdatenBestandsFehlerException("", createAntrag(), createFehlerEintragDto()),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new StatistikBestandsFehlerException(createAntrag(), "Fehler"),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new VerarbeitungsstatusUpdateException(new Exception()),
                Status.INTERNAL_SERVER_ERROR.getStatusCode()),
            Arguments.of(new RvfitException("normale  Execption") {
            }, Status.INTERNAL_SERVER_ERROR.getStatusCode())
        );
    }

    private static Antrag createAntrag() {
        final Antrag antrag = new Antrag();
        antrag.setVsnr("57180767K004");
        antrag.setVorname("vorname");
        antrag.setNachname("nachname");
        return antrag;
    }

    private static FehlerEintragDto createFehlerEintragDto() {

        final FehlerEintragDto fehlerEintragDto = new FehlerEintragDto();
        fehlerEintragDto.setStatuscode("123456");

        return fehlerEintragDto;

    }

    /**
     * Testes die gemappten Status Codes des {@link RvfitExceptionMapper}.
     *
     * @param exception  zu testende Exception
     * @param statusCode erwarteter Statuscode
     */
    @ParameterizedTest
    @MethodSource("provideParameters")
    public void testRvfitException(RvfitException exception, int statusCode) {
        try (Response response = mapper.toResponse(exception)) {
            assertThat(response.getStatus()).as(exception.getClass().getSimpleName()).isEqualTo(statusCode);
        }
    }

    /**
     * Testes die gemappten Status Codes des {@link RvfitExceptionMapper}. Open: tested den Status Quo, Eine inhaltliche Prüfung hat nicht
     * stattgefunden.
     */
    @Test
    void testStatus() {
        assertThat(mapper.toResponse(new NichtAutorisiertException("/hello", "1234", "darfst Du nicht")))
            .as("NichtAutorisiertException")
            .returns(Status.UNAUTHORIZED.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new EingabevalidierungException("/hello", "1234", "was redest du?")))
            .as("EingabevalidierungException")
            .returns(Status.BAD_REQUEST.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new KontoinformationException("No Kontoinformation for you", new RuntimeException())))
            .as("KontoinformationException")
            .returns(Status.BAD_GATEWAY.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new SelbstmeldeportalClientException("/hello", "1234", "No connection no fun")))
            .as("SelbstmeldeportalClientException")
            .returns(Status.BAD_GATEWAY.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new RvPurClientException("No Pur for you", new RuntimeException())))
            .as("RvPurClientException")
            .returns(Status.BAD_GATEWAY.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new KtanException("Hey dude, where is my KaTANa?")))
            .as("KtanException")
            .returns(Status.UNAUTHORIZED.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new MapperException("Map the Mapper")))
            .as("MapperException")
            .returns(Status.BAD_GATEWAY.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new StammdatenException("Die Daten des Stamms erzeugen Fehler")))
            .as("StammdatenException")
            .returns(Status.BAD_GATEWAY.getStatusCode(), Response::getStatus);
        assertThat(mapper.toResponse(new KontoGesperrtException("1234", "70", new WebApplicationException())))
            .as("KontoGesperrtException")
            .returns(HTTP_STATUS_LOCK, Response::getStatus);
        assertThat(mapper.toResponse(new StatistikException("")))
            .as("StatistikException")
            .returns(502, Response::getStatus);
        assertThat(mapper.toResponse(new RvfitException("Voll normale RvFitException") {
        })).returns(Status.INTERNAL_SERVER_ERROR.getStatusCode(), Response::getStatus);

    }

}
