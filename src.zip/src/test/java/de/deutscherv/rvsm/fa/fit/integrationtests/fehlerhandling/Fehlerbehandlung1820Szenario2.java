package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import java.util.UUID;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1820">EVORVF2-1820</a>.
 * Szenario 2
 */
@Slf4j
@Getter
public class Fehlerbehandlung1820Szenario2 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0047";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final String antragXml;
    private final AntragRepository antragRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final WireMockServer wireMockServer;
    private final EntityManager entityManager;

    /**
     * Konstruktor.
     *
     * @param drvMandant          DRV-Mandant
     * @param producerTemplate    Producertemplate
     * @param antragRepository    Antragsrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager       Entity-Manager
     * @param wireMockServer      Wiremockserver
     */
    public Fehlerbehandlung1820Szenario2(
        final DrvMandant drvMandant,
        final FluentProducerTemplate producerTemplate,
        final AntragRepository antragRepository,
        final PurAufgabenProducer purAufgabenProducer,
        final WireMockServer wireMockServer,
        final EntityManager entityManager) {
        super(TestPerson.MELANIE_BEMERKUNG,
            new RegressionsConfig(true, true, false));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.wireMockServer = wireMockServer;
        this.entityManager = entityManager;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        final var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT);
            assertThat(antrag.getAufgaben().getFirst().getAufgabenArt()).isEqualTo(AufgabenArt.PERSONENDATENABGLEICH);
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
            entityManager.detach(antrag);
        }

        Mockito.clearInvocations(purAufgabenProducer);
        updateWireMockConfig(wireMockServer,
            new RegressionsConfig(true, true, false,
                new StammdatenConfig(null, AF_STATUSCODE, null, 500)));

        final BestandsfehlerDto bestandsfehlerDto = given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
            .post("antraege/{uuid}/antragsdaten-aktualisieren").then()
            .statusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR).extract().as(BestandsfehlerDto.class);
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).as("Unerwarterter Fehler").isNotNull();
        assertThat(bestandsfehlerDto.getUnerwartererFehler().getFehlercode()).as("UnerwarteterFehler Fehlercode")
            .isEqualTo(AF_STATUSCODE);

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
            assertThat(antrag.getAufgaben()).hasSize(2);
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
            Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());
        }

        return true;
    }

}
