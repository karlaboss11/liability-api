package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.EantragsBestaetigungMapperImpl;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DefaultProcessorTest;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test eAntrag Bestaetigung Mapper.
 */
class EAntragsBestaetigungsMapperTest extends DefaultProcessorTest {
    
    private final EAntragsBestaetigungErrorMapper mapper = new EAntragsBestaetigungErrorMapper(new EantragsBestaetigungMapperImpl());
    private final RVFitXmlMarshaller antragsmarMarshaller = new RVFitXmlMarshaller();

    /**
     * Test Mapping EantragsBestaetigungDto.
     */
    @Test
    @SneakyThrows
    void testBesataetigungMapping() {
        final var message = this.getMessage();
        Antragsdaten antragsdaten = antragsmarMarshaller.unmarshall(Antragsdaten.class,
                Xml.getXmlAntrag("eAntragXmls/eAntrag_15280982D041.xml"));
        
        message.setHeader(RVFitCamelHeader.ANTRAGSDATEN, antragsdaten);
        
        final var exchange = getExchange(message);
        mapper.process(exchange);
        
        final var eantragsBestaetigungDTO = exchange.getMessage().getBody(EantragsBestaetigungDTO.class);
        
        assertThat(eantragsBestaetigungDTO).isNotNull();
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getVsnr()).isEqualTo("15280982D041");
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getFehlerNummer()).isNotNull();
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getFehlerText()).isNotNull();
    }
    
}
