package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.kontoinformation.KontoinformationService;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalClient;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.util.JSONTestUtils;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.transaction.UserTransaction;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.assertj.core.api.Assertions;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;

/**
 * Test der RetryRoutes.
 */
@Slf4j
@QuarkusTest
class RetryRoutesTest extends CamelQuarkusTestSupport {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static List<EinrichtungResponseExtended> einrichtungenResponseExtended70469;
    @Inject
    private DrvMandant mandantHolder;
    @InjectMock
    @RestClient
    private SelbstmeldeportalClient selbstmeldeportalClient;
    @InjectMock
    private StammdatenService stammdatenService;
    @Inject
    private UserTransaction transaction;
    @InjectMock
    private KontoinformationService kontoinformationService;
    @InjectMock
    private StatistikService statistikService;
    @Inject
    private FehlerRepository fehlerRepository;
    @Inject
    private AntragRepository antragRepository;
    @Inject
    private DrvMandant mandant;
    @InjectMock
    private RvPurService rvPurService;
    @Inject
    private FluentProducerTemplate pt;

    /**
     * Globale Testvorbereitung.
     *
     * @throws JsonProcessingException JSON-Fehler
     */
    @BeforeAll
    static void set() throws JsonProcessingException {
        final List<EinrichtungResponseExtended> einrichtungenResponseExtendedAll =
            OBJECT_MAPPER.readValue(JSONTestUtils.jsonToString("einrichtung/einrichtungen_all_extended.json"),
                new TypeReference<>() {
                });

        einrichtungenResponseExtended70469 = einrichtungenResponseExtendedAll.stream().filter(
                e -> e.getAngebote().stream().anyMatch(a -> a.getAdresse().getPlz().equals("70469")))
            .toList();

    }

    /**
     * Test der Fehlerbearbeitung.
     */
    @SneakyThrows
    @Test
    void testeFehlerbearbeitung() {
        final KontoDto konto = new KontoDto();
        konto.setVersicherungsnummer("04021093N590");
        context.getRegistry().bind("statistikservice", statistikService);
        Mockito.when(stammdatenService.getKontoDto(any())).thenReturn(konto);
        Mockito.when(kontoinformationService.getKontoinformationEntity(any(), any())).thenReturn(new Kontoinformation());
        Mockito.when(selbstmeldeportalClient.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response.ok(einrichtungenResponseExtended70469).build());
        final var uuid = saveEantragMitFehlern();

        mandant.setInScope("70");
        @SuppressWarnings("unchecked")
        final var resultingFehler = (List<Fehler>) pt
            .to(FehlerRoutes.GET_FEHLER).request(List.class);

        Assertions.assertThat(resultingFehler).isNotNull();
        Assertions.assertThat(
                //notwendig, da Fehler im Repo sein können
                resultingFehler.stream().filter(x -> uuid.equals(x.getAntragId())).count())
            .isEqualTo(2);

    }

    /**
     * Speichern eines eAntrags mit Fehlern.
     *
     * @return UUID des erstellten Antrags
     * @throws IOException Fehler beim Lesen der XML
     */
    @SneakyThrows
    @Transactional
    UUID saveEantragMitFehlern() throws IOException {
        final String eantrag = new String(
            RetryRoutesTest.class.getClassLoader()
                .getResourceAsStream("eAntragXmls/eAntrag_04021093N590.xml").readAllBytes(),
            StandardCharsets.UTF_8);

        final UUID uuid = UUID.randomUUID();

        final Antrag antrag = Antrag.builder().xml(eantrag)
            .ktan("70").vsnr("04021093N590").uuid(uuid).status(AntragStatus.ENTWURF).build();
        mandant.setInScope("70");
        antragRepository.persist(antrag);
        antragRepository.flush();
        final Fehler fehler1 = Fehler.builder().status(antrag.getStatus()).antragId(uuid).retries(0).build();
        final Fehler fehler2 = Fehler.builder().status(antrag.getStatus()).antragId(uuid).retries(0).build();
        fehlerRepository.persist(fehler1);
        fehlerRepository.persist(fehler2);
        fehlerRepository.flush();
        antragRepository.flush();

        return uuid;
    }

    @SneakyThrows
    @Test
    void testeFehlerfall() {
        final String eantrag = new String(
            RetryRoutesTest.class.getClassLoader()
                .getResourceAsStream("eAntragXmls/eAntrag_48210470M496.xml").readAllBytes(),
            StandardCharsets.UTF_8);

        var exchange = pt.withBody(eantrag).to(MappingRoutes.DIRECT_UNMARSHAL_EANTRAG).send();
        exchange = pt.withExchange(exchange).to(MappingRoutes.DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG).send();

        exchange.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, "70");
        exchange.setProperty(RetryRoutesTest.class.getSimpleName() + ".scope", mandantHolder.setInScope("70"));
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_SAVE_EANTRAG).send();

        final var uuid = exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID,
            String.class);
        Assertions.assertThat(uuid).isNotNull();

        final var antrag = exchange.getMessage().getBody(Antrag.class);

        Assertions.assertThat(antrag).isNotNull();
        Assertions.assertThat(antrag.getUuid()).isNotNull();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG).send();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_ERSTELLE_VORGANG).send();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_SETSMP_EINRICHTUNGEN).send();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_ERFASSE_STATISTIK).send();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_FETCH_STAMMDATEN).send();
        exchange = pt.withExchange(exchange).to(RouteNames.DIRECT_PRUEFE_REGELN).send(); //WIP

    }

}
