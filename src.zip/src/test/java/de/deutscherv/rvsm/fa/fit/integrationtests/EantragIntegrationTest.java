package de.deutscherv.rvsm.fa.fit.integrationtests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EXTraNachrichtDTO;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import io.quarkus.artemis.test.ArtemisTestResource;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.control.RequestContextController;
import jakarta.inject.Inject;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSConsumer;
import jakarta.jms.JMSContext;
import jakarta.jms.TextMessage;
import jakarta.transaction.Transactional;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test eAntrag-Integration.
 */
@QuarkusTest
@Slf4j
@QuarkusTestResource(ArtemisTestResource.class)
class EantragIntegrationTest extends CamelQuarkusTestSupport {

    private static WireMockServer wireMockServer;
    @Inject
    private AntragRepository antragRepository;
    @Inject
    private FehlerRepository fehlerRepository;
    @Inject
    private ConnectionFactory connectionFactory;
    @Inject
    private RequestContextController requestContext;
    private final ObjectMapper mapper = new ObjectMapper();
    @Inject
    private DrvMandant drvMandant;

    @ConfigProperty(name = "spoc-adapter.transfer-eantrag")
    private String transferEantragQueueName;
    @ConfigProperty(name = "spoc-adapter.bestaetige-eantrag")
    private String bestaetigeEantrag;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void init() {
        System.setProperty("quarkus.scheduler.enabled", "false");
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);
        WireMockStub.stubForRvPur();
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @SneakyThrows
    @AfterEach
    void cleanup() {
        try (JMSContext context = connectionFactory.createContext();
            JMSConsumer consumer =
                context.createConsumer(context.createQueue(transferEantragQueueName))) {
            boolean empty = false;
            while (!empty) {
                empty = consumer.receive(200) == null;
            }
        }

        wireMockServer.resetAll();
        WireMockStub.stubForRvPur();
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            fehlerRepository.deleteAll(fehlerRepository.findAll());
        }
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void beforeEach() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            fehlerRepository.deleteAll(fehlerRepository.findAll());
        }
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void shutDown() {
        WireMockStub.disconnect(wireMockServer);
    }

    @Override
    public boolean isUseAdviceWith() {
        return true;
    }

    /**
     * Test Dunkelverarbeitung - Positiv.
     */
    @SneakyThrows
    @Test
    @RequestScoped
    void dunkelverarbeitungPositiv() {
        WireMockStub.stubForStammdaten(null);
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        try (var context = connectionFactory.createContext()) {
            final var transferEantragQueue = context.createQueue(this.transferEantragQueueName);
            final var bestaetigungsConsumer = context.createConsumer(context.createQueue(bestaetigeEantrag));
            final var producer = context.createProducer();

            final String eantrag = new String(
                EantragIntegrationTest.class.getClassLoader()
                    .getResourceAsStream("eAntragXmls/eAntrag_03080800B018.xml").readAllBytes(),
                StandardCharsets.UTF_8);

            final EXTraNachrichtDTO dto = new EXTraNachrichtDTO();
            dto.xml(eantrag);

            UUID uuid = UUID.randomUUID();

            final String json = mapper.writeValueAsString(dto);
            final TextMessage textMessage = context.createTextMessage(json);
            textMessage.setStringProperty(DRVHeader.CORRELATION_ID, uuid.toString());
            textMessage.setStringProperty(DRVHeader.MANDANT_PROPERTY_KEY, "70");
            textMessage.setStringProperty(DRVHeader.UUID_PROPERTY_KEY, uuid.toString());
            producer.send(transferEantragQueue, textMessage);
            LOG.atInfo().addArgument(uuid).setMessage("UUID:[{}]").log();

            final var message = bestaetigungsConsumer.receive(20000);
            assertThat(message).isNotNull();
            drvMandant.setInScope("70");
            assertThat(fehlerRepository.findAll()).isEmpty();
        }
    }

    /**
     * Regressionstest.
     */
    @SneakyThrows
    @Test
    @RequestScoped
    @Transactional
    void regressionstestBeiFehlerInDerJMSRoute() {
        wireMockServer.resetAll();

        try (var context = connectionFactory.createContext()) {
            final var transferEantragQueue = context.createQueue(this.transferEantragQueueName);
            final var bestaetigungsConsumer = context.createConsumer(context.createQueue(bestaetigeEantrag));
            final var producer = context.createProducer();

            String eantrag = new String(
                EantragIntegrationTest.class.getClassLoader()
                    .getResourceAsStream("eAntragXmls/eAntrag_03080800B018.xml").readAllBytes(),
                StandardCharsets.UTF_8);

            final EXTraNachrichtDTO dto = new EXTraNachrichtDTO();
            dto.xml(eantrag);

            UUID uuid = UUID.randomUUID();

            final String json = mapper.writeValueAsString(dto);
            final TextMessage textMessage = context.createTextMessage(json);
            textMessage.setStringProperty(DRVHeader.MANDANT_PROPERTY_KEY, "70");
            textMessage.setStringProperty(DRVHeader.UUID_PROPERTY_KEY, uuid.toString());
            textMessage.setStringProperty(DRVHeader.CORRELATION_ID, uuid.toString());
            producer.send(transferEantragQueue, textMessage);
            LOG.atWarn().addArgument(uuid).setMessage("UUUD:[{}]").log();

            final var message = bestaetigungsConsumer.receive(20000);
            assertThat(message).isNotNull();
            requestContext.activate();
            drvMandant.setInScope("70");
            antragRepository.flush();
            final var antrag = antragRepository.findByUuid(uuid).orElse(null);
            assertThat(antrag).as("der verarbeitete eAntrag").isNotNull();
        }
    }

    /**
     * Test für Keine Rückmeldung wenn keine MessageId vorhanden ist.
     */
    @SneakyThrows
    @Test
    @RequestScoped
    void testKeineRueckmeldungOhneMessageId() {
        WireMockStub.stubForStammdaten(null);
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        try (var context = connectionFactory.createContext()) {
            final var transferEantragQueue = context.createQueue(this.transferEantragQueueName);
            final var bestaetigungsConsumer = context.createConsumer(context.createQueue(bestaetigeEantrag));
            final var producer = context.createProducer();

            final String eantrag = new String(
                EantragIntegrationTest.class.getClassLoader()
                    .getResourceAsStream("eAntragXmls/eAntrag_03080800B018.xml").readAllBytes(),
                StandardCharsets.UTF_8);

            final EXTraNachrichtDTO dto = new EXTraNachrichtDTO();
            dto.xml(eantrag);

            final UUID uuid = UUID.randomUUID();

            final String json = mapper.writeValueAsString(dto);
            TextMessage textMessage = context.createTextMessage(json);
            textMessage.setStringProperty(DRVHeader.MANDANT_PROPERTY_KEY, "70");
            textMessage.setStringProperty(DRVHeader.UUID_PROPERTY_KEY, uuid.toString());
            producer.send(transferEantragQueue, textMessage);
            LOG.atInfo().addArgument(uuid).setMessage("UUID:[{}]").log();

            final var message = bestaetigungsConsumer.receive(20000);
            assertThat(message).isNull();
        }
    }
}
