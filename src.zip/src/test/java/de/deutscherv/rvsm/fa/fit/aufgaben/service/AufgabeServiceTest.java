package de.deutscherv.rvsm.fa.fit.aufgaben.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.repository.AufgabeRepository;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCompleteDTO;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCreateDTO;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSConsumer;
import jakarta.jms.JMSContext;
import jakarta.jms.TextMessage;
import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrowsExactly;

@QuarkusTest
class AufgabeServiceTest {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    static {
        objectMapper.registerModule(new JavaTimeModule());
    }

    @Inject
    AntragRepository antragRepository;

    @Inject
    AufgabeRepository aufgabeRepository;

    @Inject
    AufgabeService aufgabeService;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private VerarbeitungsstatusService verarbeitungsstatusService;

    @Inject
    ConnectionFactory connectionFactory;

    @ConfigProperty(name = "vom.queue.outgoing.request.create.aufgabe")
    private String createAufgabeQueue;

    @ConfigProperty(name = "vom.queue.outgoing.aufgabe.completed")
    private String completeAufgabeQueue;

    @ParameterizedTest
    @EnumSource(AufgabenArt.class)
    @Transactional
    void testErstelleVerschiedeneAufgaben(final AufgabenArt aufgabenArt) {
        flushQueue(createAufgabeQueue);

        drvMandant.setInScope("17");
        final var antrag = getAntrag();
        antragRepository.persistAndFlush(antrag);
        aufgabeService.erstellePurAufgabe(antrag, aufgabenArt);

        final var eAntrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();
        assertThat(eAntrag.getAufgaben()).hasSize(1);
        final Aufgabe erstellteAufgabe = eAntrag.getAufgaben().getFirst();

        assertThat(erstellteAufgabe.getAufgabenArt()).isEqualTo(aufgabenArt);

        final var createEvent =
                assertDoesNotThrow(() -> receiveFromQueue(createAufgabeQueue, AufgabeCreateDTO.class));

        flushQueue(createAufgabeQueue);

        assertThat(createEvent.getAufruferReferenzId())
                .isEqualTo(erstellteAufgabe.getTransaktionId().toString());
    }

    @Test
    @Transactional
    void testSchliesseAufgabe() {
        flushQueue(completeAufgabeQueue);
        final var antrag = getAntrag();
        // given
        drvMandant.setInScope("17");
        final var transaktionId = UUID.randomUUID();
        final var aufgabe = Aufgabe.builder().aufgabenArt(AufgabenArt.EINRICHTUNGSWAHL)
                .transaktionId(transaktionId).build();

        aufgabeRepository.persist(aufgabe);
        antrag.getAufgaben().add(aufgabe);
        assertThat(aufgabeRepository.find(aufgabe.getUuid()).getDatumErledigt()).isNull();

        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        // when
        aufgabeService.purAufgabeSchliessen(antrag);

        // then

        // datenbankobjekt aktualisiert
        final Aufgabe updatedAufgabe = aufgabeRepository.find(aufgabe.getUuid());
        assertThat(updatedAufgabe.getDatumErledigt().toLocalDate()).isEqualTo(LocalDate.now());
        assertThat(updatedAufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.EINRICHTUNGSWAHL);
        assertThat(updatedAufgabe.getTransaktionId()).isEqualTo(transaktionId);

        // message liegt in queue
        final var completedEvent = assertDoesNotThrow(
                () -> receiveFromQueue(completeAufgabeQueue, AufgabeCompleteDTO.class));
        assertThat(completedEvent.getAufruferReferenzId())
                .isEqualTo(aufgabe.getTransaktionId().toString());
        assertThat(completedEvent.getAbschlussgrund()).isEmpty();
        assertThat(completedEvent.getErledigungsdatum())
                .isEqualTo(updatedAufgabe.getDatumErledigt().toLocalDate());
    }

    @Test
    @Transactional
    void testSchliesseAufgabePapierantragErfasst() {
        flushQueue(completeAufgabeQueue);

        // given
        drvMandant.setInScope("17");

        final PapierantragDto papierantrag = new PapierantragDto();
        papierantrag.setAufgabenId("aufgabenId");

        final var transaktionId = UUID.randomUUID();
        final var aufgabe = Aufgabe.builder().aufgabenArt(AufgabenArt.EINRICHTUNGSWAHL)
                .transaktionId(transaktionId).vomAufgabenId(papierantrag.getAufgabenId()).build();
        final String grund = "Papierantrag erfasst";
        aufgabeRepository.persist(aufgabe);
        assertThat(aufgabeRepository.find(aufgabe.getUuid()).getDatumErledigt()).isNull();

        // when
        aufgabeService.schliesseAufgabePapierantragErfasst(aufgabe, papierantrag.getAufgabenId());

        // then

        // datenbankobjekt aktualisiert
        final Aufgabe updatedAufgabe = aufgabeRepository.find(aufgabe.getUuid());
        assertThat(updatedAufgabe.getDatumErledigt().toLocalDate()).isEqualTo(LocalDate.now());
        assertThat(updatedAufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.EINRICHTUNGSWAHL);
        assertThat(updatedAufgabe.getTransaktionId()).isEqualTo(transaktionId);

        // message liegt in queue
        final var completedEvent = assertDoesNotThrow(
                () -> receiveFromQueue(completeAufgabeQueue, AufgabeCompleteDTO.class));
        assertThat(completedEvent.getAufruferReferenzId()).isEqualTo(papierantrag.getAufgabenId());
        assertThat(completedEvent.getAbschlussgrund()).isEqualTo(grund);
        assertThat(completedEvent.getErledigungsdatum())
                .isEqualTo(updatedAufgabe.getDatumErledigt().toLocalDate());
    }

    @ParameterizedTest
    @EnumSource(Art.class)
    @Transactional
    void testrvPurAufgabeSchliessen(final Art art) {
        drvMandant.setInScope("70");
        final Antrag antrag = getAntrag();
        antragRepository.persist(antrag);
        final VersandErgebnisDto versandErgebnisDto = new VersandErgebnisDto(VersandErgebnisDto.StatusEnum.VERSAND);
        verarbeitungsstatusService.saveVerarbeitungsstatus(antrag.getUuid(), versandErgebnisDto,
                art);
        if (Set.of(Art.SACHVERHALTSAUFKLAERUNG, Art.GESPERRT).contains(art)) {
            assertThrowsExactly(IllegalStateException.class, () -> aufgabeService.purAufgabeSchliessen(antrag));
        } else if (Set.of(Art.BEWILLIGUNG,
                Art.ABLEHNUNG,
                Art.STORNO,
                Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE,
                Art.RUECKNAHME,
                Art.WEITERBEARBEITUNG_IN_RVDIALOG).contains(art)) {
            antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
            Assertions.assertDoesNotThrow(() -> aufgabeService.purAufgabeSchliessen(antrag));
        }

    }

    /**
     * Wartet auf eine Nachricht in einer Queue und gibt diese zurück.
     *
     * @param <T>       der Typ der Nachricht
     * @param queueName der Name der Queue
     * @param typ       der Typ der Nachricht
     * @return die erste Nachricht, die in die Queue geschrieben wird.
     * @throws Exception wenn ein Fehler auftritt
     */
    private <T> T receiveFromQueue(final String queueName, final Class<T> typ) throws Exception {
        try (JMSContext context = connectionFactory.createContext();
                JMSConsumer consumer = context.createConsumer(context.createQueue(queueName))) {
            final TextMessage message = (TextMessage) consumer.receive(1000);

            final String body = message.getText();
            return objectMapper.readValue(body, typ);
        }
    }

    private void flushQueue(final String queueName) {
        try (JMSContext context = connectionFactory.createContext();
                JMSConsumer consumer = context.createConsumer(context.createQueue(queueName))) {
            boolean empty = false;
            while (!empty) {
                empty = consumer.receive(200) == null;
            }
        }
    }

    /**
     * Erstellt einen minimalen Antrag zum Testen.
     *
     * @return ein minimaler Antrag nur mit VSNR
     */
    private Antrag getAntrag() {
        final Antrag antrag = new Antrag();
        antrag.setStatus(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
        antrag.setVsnr("23270152B506");
        antrag.setUuid(UUID.randomUUID());

        return antrag;
    }
}
