package de.deutscherv.rvsm.fa.fit.einrichtungen.dto;

import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseDto;
import de.deutscherv.rvsm.fa.fit.util.StringUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PhaseDtoTest {

    private Validator validator;

    @BeforeEach
    public void setUp() {
        final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void testWhenFieldsTooLong() {

        final String strWith256Chars = StringUtils.randomStringGenerator(256);
        final String strWith501Chars = StringUtils.randomStringGenerator(501);

        final PhaseDto dto = new PhaseDto().name(strWith256Chars).text(strWith256Chars)
                .freiePlaetze(strWith256Chars).durchfuehrungsart(strWith501Chars);

        final Set<ConstraintViolation<PhaseDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(4, violations.size());

    }

    @Test
    void testWhenFieldsValid() {

        final PhaseDto dto = new PhaseDto().name("name").text("text").freiePlaetze("freiePlaetze")
                .durchfuehrungsart("durchfuehrungsart");

        final Set<ConstraintViolation<PhaseDto>> violations = validator.validate(dto);

        assertTrue(violations.isEmpty());
    }
}
