package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@QuarkusTest
class AntragStatusServiceTest {

    @Inject
    private DrvMandant drvMandant;

    @Inject
    AntragRepository antragRepository;

    @Inject
    AntragStatusService antragStatusService;

    @BeforeEach
    void setUp() {
        drvMandant.setInScope("70");
    }

    @Test
    @Transactional
    void shouldPersistAntragMitStatusTest() {
        final UUID uuid = UUID.randomUUID();
        final Antrag antrag = Antrag.builder().uuid(uuid).vsnr("vsnr")
                .status(AntragStatus.AUFGABE_ABGESCHLOSSEN).build();
        antragStatusService.setAntragStatus(antrag, AntragStatus.STATISTIK_ABGESCHLOSSEN);

        final Optional<Antrag> persistedAntrag = antragRepository.findByUuid(uuid);

        assertNotNull(persistedAntrag);
        assertEquals(AntragStatus.STATISTIK_ABGESCHLOSSEN, persistedAntrag.get().getStatus());
    }

    @Test
    @Transactional
    void shouldThrowUnsupportedOperationExceptionTest() {
        final UUID uuid = UUID.randomUUID();
        final Antrag antrag =
                Antrag.builder().uuid(uuid).vsnr("vsnr").status(AntragStatus.ENTWURF).build();

        assertThrows(UnsupportedOperationException.class, () -> antragStatusService
                .setAntragStatus(antrag, AntragStatus.STATISTIK_ABGESCHLOSSEN));
    }

}
