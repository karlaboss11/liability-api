package de.deutscherv.rvsm.fa.fit.antraege.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.StammdatenMockTransformer;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.AtadDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenClient;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.ErfassungResponseDto;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.KontoTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_UNMARSHAL_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_CHECK_DOPPELVERGABE;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERFASSE_STATISTIK;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_VORGANG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_STAMMDATEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PRUEFE_REGELN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SAVE_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SETSMP_EINRICHTUNGEN;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Test EinrichtungenUpdateService.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
class EinrichtungenUpdateServiceTest extends CamelQuarkusTestSupport {
    static final String DIRECT_JUST_SAVEANDCHECKEANTRAG = "direct:justSaveAndCheck";
    private static WireMockServer wireMockServer;
    @Inject
    ObjectMapper objectMapper;
    @Inject
    private EinrichtungenUpdateService einrichtungenUpdateService;
    @Inject
    private AntragRepository antragRepository;
    @Inject
    private DrvMandant drvMandant;
    @InjectMock
    @RestClient
    private StammdatenClient stammdatenClient;
    private Map<String, String> xmlAntraege = null;
    @Inject
    private FluentProducerTemplate producerTemplate;

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        wireMockServer.stop();
    }

    @Override
    protected RoutesBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from(DIRECT_JUST_SAVEANDCHECKEANTRAG)
                    .routeId(DIRECT_JUST_SAVEANDCHECKEANTRAG)
                    .to(DIRECT_UNMARSHAL_EANTRAG)
                    .to(DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
                    .to(DIRECT_EXTRACT_MANDANT)
                    .to(DIRECT_SAVE_EANTRAG)
                    .to(DIRECT_GENERATE_VORGANGSKENNUNG)
                    .to(DIRECT_ERSTELLE_VORGANG)
                    .to(DIRECT_FETCH_KONTOINFORMATIONEN)
                    .to(DIRECT_SETSMP_EINRICHTUNGEN)
                    .to(DIRECT_ERFASSE_STATISTIK)
                    .to(DIRECT_CHECK_DOPPELVERGABE)
                    .to(DIRECT_FETCH_STAMMDATEN)
                    .to(DIRECT_PRUEFE_REGELN)
                ;
            }
        };
    }

    /**
     * Globale Testvorbereitungen.
     *
     * @throws JsonProcessingException Fehler
     */
    @BeforeAll
    void set() throws JsonProcessingException {
        xmlAntraege =
            Xml.getXmlAntraege(Arrays.asList("eAntrag_15010191A388", "eAntrag_02220697M981"));
        final List<EinrichtungResponseExtended> einrichtungenResponseExtendedAll =
            objectMapper.readValue(jsonToString("einrichtung/einrichtungen_all_extended.json"),
                new TypeReference<>() {
                });
        final String einrichtungenResponseExtendedPhase2 =
            objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream()
                .filter(
                    e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Startphase")))
                .toList());
        final String einrichtungenResponseExtendedPhase3 = objectMapper.writeValueAsString(
            einrichtungenResponseExtendedAll.stream().filter(e -> e.getAngebote().stream()
                .anyMatch(a -> a.getPhase().equals("Auffrischungsphase"))).toList());
        final String einrichtungenResponseExtendedPhase4 =
            objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream().filter(
                    e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Trainingsphase")))
                .toList());
        final String einrichtungenResponseExtendedPhase2Durchfuerung5 =
            objectMapper
                .writeValueAsString(
                    einrichtungenResponseExtendedAll.stream()
                        .filter(e -> e.getAngebote().stream()
                            .anyMatch(a -> a.getPhase().equals("Startphase")
                                && a.getDurchfuehrungsart().equals("Ambulant (ganztägig)")))
                        .toList());
        final String einrichtungenResponseExtendedPhase3Durchfuerung5 =
            objectMapper
                .writeValueAsString(
                    einrichtungenResponseExtendedAll.stream()
                        .filter(e -> e.getAngebote().stream()
                            .anyMatch(a -> a.getPhase().equals("Auffrischungsphase")
                                && a.getDurchfuehrungsart().equals("Ambulant (ganztägig)")))
                        .toList());
        final String einrichtungenResponseExtendedPhase4Durchfuerung4 =
            objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream().filter(
                    e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Trainingsphase")
                        && a.getDurchfuehrungsart().equals("Ambulant")))
                .toList());

        final VorgangResponseDto vorgangResponseDto = new VorgangResponseDto();
        final AtadDto atadDto = new AtadDto();
        atadDto.setAtadErm("0000");
        atadDto.atadErmDrck("0000");
        atadDto.atadErmMmad("0000");
        atadDto.setAtadErmZus("00000000000000000000");
        atadDto.setAtadHsi("000000000000");
        atadDto.setAtadEakte("0000");
        vorgangResponseDto.setAtad(atadDto);
        vorgangResponseDto.setFehlerFeld(StringUtils.EMPTY);
        final Jsonb jsonb = JsonbBuilder.create();
        final String vorgangResponseDtoJson = jsonb.toJson(vorgangResponseDto);

        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig()
            .port(WireMockStub.PORT).extensions(StammdatenMockTransformer.class));
        wireMockServer.start();
        WireMock.configureFor("localhost", wireMockServer.port());

        stubFor(post(urlPathMatching("/sendungsservice/([a-zA-Z0-9/-]*)/uebernehmeSendung2127"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(aResponse().withHeader("Content-Type", "application/json")
                .withBody(vorgangResponseDtoJson).withStatus(Response.Status.OK.getStatusCode())));

        stubFor(get(urlEqualTo("/nachderreha-api/rvfit/v2/einrichtungen")).willReturn(
            aResponse().withStatus(200).withBody(jsonToString("einrichtung/einrichtungen_all.json"))
                .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=2)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase2)
                    .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=3)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase3)
                    .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=4)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase4)
                    .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(&phase=2)(&durchfuehrungsart=5)"))
            .willReturn(aResponse().withStatus(200)
                .withBody(einrichtungenResponseExtendedPhase2Durchfuerung5)
                .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(&phase=3)(&durchfuehrungsart=5)"))
            .willReturn(aResponse().withStatus(200)
                .withBody(einrichtungenResponseExtendedPhase3Durchfuerung5)
                .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(&phase=4)(&durchfuehrungsart=4)"))
            .willReturn(aResponse().withStatus(200)
                .withBody(einrichtungenResponseExtendedPhase4Durchfuerung4)
                .withHeader("Content-Type", "application/json")));

        final ErfassungResponseDto entity = new ErfassungResponseDto();
        entity.setATAD("0000");
        entity.setMSNR("00");
        stubFor(post(urlEqualTo("/statistik/antragserfassung"))
            .willReturn(aResponse().withHeader("Content-Type", "application/json")
                .withBody(objectMapper.writeValueAsString(entity))
                .withStatus(Response.Status.CREATED.getStatusCode())));

        WireMockStub.stubForAzk();

        when(stammdatenClient.getKonto(anyString(), anyString()))
            .thenReturn(Response.ok(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN)).build());

    }

    /**
     * Test Update Einrichtugnen.
     *
     * @param eAntragXml XML eines eAntrags
     * @param name       der Trainingseinrichtung
     * @param resc       der Trainingseinrichtung
     */
    @ParameterizedTest
    @CsvSource({ "eAntrag_15010191A388, Testklinik Milbertshofen am Hart, T00003" })
    @Transactional
    void updateEinrichtungenTest(final String eAntragXml, final String name, final String resc) {
        when(stammdatenClient.getKonto(anyString(), anyString()))
            .thenReturn(Response.ok(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN)).build());
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);

        Antrag eAntrag = saveEantrag(xmlAntraege.get(eAntragXml));
        drvMandant.setInScope(eAntrag.getKtan());

        assertEquals(eAntrag.getEinrichtungTrainingObjekt().getName(), name);
        assertEquals(eAntrag.getEinrichtungTrainingObjekt().getResc(), resc);

        final RehaEinrichtungUpdateDto gleicheEinrichtungStart = new RehaEinrichtungUpdateDto();
        gleicheEinrichtungStart.setAngebotId(17503L);
        gleicheEinrichtungStart.setDurchfuehrungsart("Ambulant (ganztägig)");
        einrichtungenUpdateService.updateEinrichtungByPhase(eAntrag.getUuid(), "Startphase",
            gleicheEinrichtungStart);
        eAntrag = antragRepository.findByUuid(eAntrag.getUuid()).orElseThrow();
        assertEquals(17503L, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(3, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDauer());
        assertEquals("Ambulant (ganztägig)",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());
        assertEquals(17507L, eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(1, eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getDauer());
        assertEquals("Ambulant (ganztägig)", eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Test eAntrag XML Resc Speichern und eindeutiges Angebot suchen.
     *
     * @param eAntragXml XML des eAntrags
     * @param name       der Trainingseinrichtung
     * @param resc       der Trainingseinrichtung
     */
    @ParameterizedTest
    @CsvSource({ "eAntrag_15010191A388, Testklinik Milbertshofen am Hart, T00003" })
    @Transactional
    void eAntragXmlRescSpeichernUndEindeutigesAngebotSuchenTest(final String eAntragXml,
        final String name, final String resc) {

        when(stammdatenClient.getKonto(anyString(), anyString()))
            .thenReturn(Response.ok(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN)).build());
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);

        Antrag eAntrag = saveEantrag(xmlAntraege.get(eAntragXml));
        drvMandant.setInScope(eAntrag.getKtan());

        assertEquals(eAntrag.getEinrichtungTrainingObjekt().getName(), name);
        assertEquals(eAntrag.getEinrichtungTrainingObjekt().getResc(), resc);

        final RehaEinrichtungUpdateDto gleicheEinrichtungStart = new RehaEinrichtungUpdateDto();
        gleicheEinrichtungStart.setAngebotId(17549L);
        gleicheEinrichtungStart.setDurchfuehrungsart("Ambulant (ganztägig)");
        einrichtungenUpdateService.updateEinrichtungByPhase(eAntrag.getUuid(), "Startphase",
            gleicheEinrichtungStart);
        eAntrag = antragRepository.findByUuid(eAntrag.getUuid()).orElseThrow();
        assertEquals(17549L, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(4, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant (ganztägig)", eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());

        final RehaEinrichtungUpdateDto neueEinrichtungStart = new RehaEinrichtungUpdateDto();
        neueEinrichtungStart.setAngebotId(17575L);
        neueEinrichtungStart.setDurchfuehrungsart("Ambulant (ganztägig)");
        einrichtungenUpdateService.updateEinrichtungByPhase(eAntrag.getUuid(), "Startphase",
            neueEinrichtungStart);

        eAntrag = antragRepository.findByUuid(eAntrag.getUuid()).orElseThrow();
        assertEquals(17575L, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(4, eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant (ganztägig)", eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());

        final RehaEinrichtungUpdateDto neueEinrichtungTraining = new RehaEinrichtungUpdateDto();
        neueEinrichtungTraining.setAngebotId(17576L);
        neueEinrichtungTraining.setDurchfuehrungsart("Ambulant");
        einrichtungenUpdateService.updateEinrichtungByPhase(eAntrag.getUuid(), "Trainingsphase",
            neueEinrichtungTraining);

        eAntrag = antragRepository.findByUuid(eAntrag.getUuid()).orElseThrow();
        assertEquals(17576L, eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(4, eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant", eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Test Update Einrichtung der Phase, Invalide Starteinrichtung.
     */
    @Test
    @Transactional
    void updateEinrichtunByPhaseInvalideStartEinrichtungTest() {
        when(stammdatenClient.getKonto(anyString(), anyString()))
            .thenReturn(Response.ok(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN)).build());
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);

        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_02220697M981"));
        drvMandant.setInScope(eAntrag.getKtan());

        final RehaEinrichtungUpdateDto einrichtung = new RehaEinrichtungUpdateDto();
        einrichtung.setAngebotId(0L);
        einrichtung.setDurchfuehrungsart("Ambulant (ganztägig)");

        final UUID uuid = eAntrag.getUuid();
        assertThatThrownBy(() -> einrichtungenUpdateService
            .updateEinrichtungByPhase(uuid, "STARTPHASE", einrichtung))
            .isInstanceOf(EingabevalidierungException.class);

    }

    /**
     * Test Update Einrichtung der Phase, Invalide Trainingseinrichtung.
     */
    @Test
    @Transactional
    void updateEinrichtungByPhaseNichtEindeutigeTrainingsEinrichtungTest() {
        when(stammdatenClient.getKonto(anyString(), anyString()))
            .thenReturn(Response.ok(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN)).build());
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);

        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_02220697M981"));
        drvMandant.setInScope(eAntrag.getKtan());

        final RehaEinrichtungUpdateDto einrichtung = new RehaEinrichtungUpdateDto();
        einrichtung.setAngebotId(0L);
        einrichtung.setDurchfuehrungsart("Ambulant (ganztägig)");

        final UUID uuid = eAntrag.getUuid();
        assertThatThrownBy(() -> einrichtungenUpdateService
            .updateEinrichtungByPhase(uuid, "TRAININGSPHASE", einrichtung))
            .isInstanceOf(EingabevalidierungException.class);

    }

    /**
     * Test Update Einrichtung der Phase, Invalide Phase.
     */
    @Test
    @Transactional
    void updateEinrichtunByPhaseInvalidePhaseTest() {
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_02220697M981"));
        drvMandant.setInScope(eAntrag.getKtan());

        final RehaEinrichtungUpdateDto einrichtung = new RehaEinrichtungUpdateDto();
        einrichtung.setAngebotId(0L);
        einrichtung.setDurchfuehrungsart("Ambulant (ganztägig)");

        final UUID uuid = eAntrag.getUuid();
        assertThatThrownBy(() -> einrichtungenUpdateService
            .updateEinrichtungByPhase(uuid, "FALSCH", einrichtung))
            .isInstanceOf(EingabevalidierungException.class);

    }

    private Antrag saveEantrag(final String xml) {
        return producerTemplate.withBody(xml).withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(DIRECT_JUST_SAVEANDCHECKEANTRAG).request(Antrag.class);
    }
}
