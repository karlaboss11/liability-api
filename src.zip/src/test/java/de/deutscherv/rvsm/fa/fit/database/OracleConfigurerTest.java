package de.deutscherv.rvsm.fa.fit.database;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import oracle.jdbc.OracleConnection;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * TEst OracleConfigurer.
 */
class OracleConfigurerTest {

    /**
     * TEst Call.
     */
    @Test
    void testCall() {
        final OracleConfigurer configurer = new OracleConfigurer();
        final Map<String, String> config = new HashMap<>();
        final BiConsumer<String, String> consumer = config::put;
        configurer.setJdbcProperties(consumer);
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT), "10");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_DEFAULT_CONNECTION_VALIDATION), "SERVER");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ALLOW_WEAK_CRYPTO), "FALSE");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_LEVEL), "REQUIRED");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_TYPES), "(AES256)");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CHECKSUM_LEVEL), "REQUIRED");
        assertEquals(config.get(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CHECKSUM_TYPES), "(SHA256, SHA512)");
    }
}
