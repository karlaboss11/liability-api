package de.deutscherv.rvsm.fa.fit.antraege.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Organisationsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.SimTypKennung;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Steuerdaten;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EAntragDatenDTO;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

class EantragsBestaetigungMapperTest {

    @Inject
    private final RVFitXmlMarshaller marshaller = new RVFitXmlMarshaller();

    private final EantragsBestaetigungMapper eantragsBestaetigungMapper = new EantragsBestaetigungMapperImpl();

    @Test
    void antragsdatenToEantragsBestaetigungDTOTest() {

        final String xml = Xml.getXmlAntrag("eAntragXmls/eAntrag_04030583T112.xml");
        try {
            final Antragsdaten antragsdaten = marshaller.unmarshall(Antragsdaten.class, xml);
            final EantragsBestaetigungDTO antragsbestaetigung = eantragsBestaetigungMapper.antragsdatenToEantragsBestaetigung(antragsdaten);

            checkEqual(antragsdaten, antragsbestaetigung);
            checkEqualKennung(antragsdaten, antragsbestaetigung);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void antragsdatenWithToEantragsBestaetigungDTOTest() throws DatatypeConfigurationException {

        LocalDate localDate = LocalDate.now();

        XMLGregorianCalendar xmlGregorianCalendar =
                DatatypeFactory.newInstance().newXMLGregorianCalendar(localDate.toString());

        final Antragsdaten antragsdaten = new Antragsdaten();

        final Steuerdaten steuerdaten = new Steuerdaten();
        steuerdaten.setAbsender("absender");
        steuerdaten.setEmpfaenger("empfaenger");
        steuerdaten.setKennung(SimTypKennung.ALRV);
        steuerdaten.setVersion("version");
        steuerdaten.setUserId("userId");
        steuerdaten.setVsnr("vsnr");
        steuerdaten.setZeitpunktErstellung(xmlGregorianCalendar);

        antragsdaten.setSteuerdaten(steuerdaten);
        antragsdaten.setOrganisationsdaten(null);

        final EantragsBestaetigungDTO antragsbestaetigung = eantragsBestaetigungMapper.antragsdatenToEantragsBestaetigung(antragsdaten);

        checkEqual(antragsdaten, antragsbestaetigung);
        checkEqualKennung(antragsdaten, antragsbestaetigung);
        assertThat(antragsbestaetigung.geteAntragDaten().getDokumentID()).isEmpty();
        assertThat(antragsbestaetigung.geteAntragDaten().getAtad()).isNull();
    }

    @Test
    void antragsdatenWitToEantragsBestaetigungDTOTest() throws DatatypeConfigurationException {

        final String xml = Xml.getXmlAntrag("eAntragXmls/eAntrag_04030583T112.xml");
        try {
            final Antragsdaten antragsdaten = marshaller.unmarshall(Antragsdaten.class, xml);
            final Organisationsdaten organisationsdaten = new Organisationsdaten();
            organisationsdaten.setAtad("atad");
            antragsdaten.setOrganisationsdaten(organisationsdaten);

            antragsdaten.setDaten(null);

            final EantragsBestaetigungDTO antragsbestaetigung = eantragsBestaetigungMapper.antragsdatenToEantragsBestaetigung(antragsdaten);

            checkEqual(antragsdaten, antragsbestaetigung);
            checkEqualKennung(antragsdaten, antragsbestaetigung);
            assertThat(antragsbestaetigung.geteAntragDaten().getDokumentID()).isEmpty();
            assertThat(antragsbestaetigung.geteAntragDaten().getAtad()).isEqualTo(antragsdaten.getOrganisationsdaten().getAtad());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void antragsdatenWithSimTypKennungNullToEantragsBestaetigungDTOTest() throws DatatypeConfigurationException {

        final String xml = Xml.getXmlAntrag("eAntragXmls/eAntrag_04030583T112.xml");
        try {
            final Antragsdaten antragsdaten = marshaller.unmarshall(Antragsdaten.class, xml);
            antragsdaten.getSteuerdaten().setKennung(null);
            final EantragsBestaetigungDTO antragsbestaetigung = eantragsBestaetigungMapper.antragsdatenToEantragsBestaetigung(antragsdaten);

            checkEqual(antragsdaten, antragsbestaetigung);
            assertThat(antragsbestaetigung.geteAntragDaten().getKennung()).isNull();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkEqual(final Antragsdaten antragsdaten, final EantragsBestaetigungDTO eantragsBestaetigungDTO) {
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getAbsender()).isEqualTo(antragsdaten.getSteuerdaten().getAbsender());
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getEmpfaenger()).isEqualTo(antragsdaten.getSteuerdaten().getEmpfaenger());
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getVersion()).isEqualTo(antragsdaten.getSteuerdaten().getVersion());
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getVsnr()).isEqualTo(antragsdaten.getSteuerdaten().getVsnr());
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getUserId()).isEqualTo(antragsdaten.getSteuerdaten().getUserId());
    }

    private void checkEqualKennung(final Antragsdaten antragsdaten, final EantragsBestaetigungDTO eantragsBestaetigungDTO) {
        assertThat(eantragsBestaetigungDTO.geteAntragDaten().getKennung()).isEqualTo(
                EAntragDatenDTO.KennungEnum.valueOf(antragsdaten.getSteuerdaten().getKennung().value()));
    }
}
