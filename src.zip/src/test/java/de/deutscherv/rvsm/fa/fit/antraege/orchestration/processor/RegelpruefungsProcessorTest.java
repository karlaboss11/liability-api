package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.UUID;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class RegelpruefungsProcessorTest extends DefaultProcessorTest {

    static RegelpruefungsProcessor regelpruefungsProcessor;

    @BeforeAll
    static void init() {
        DrvMandant drvMandant = Mockito.mock(DrvMandant.class);
        PruefergebnisService pruefergebnisService = Mockito.mock(PruefergebnisService.class);
        Mockito.when(pruefergebnisService.berechnePruefergebnis(any()))
                .thenReturn(getGesamtErgebnis(RegelName.REGEL_BEZUGALTERSRENTE));
        final var antragRepository = Mockito.mock(AntragRepository.class);
        regelpruefungsProcessor = new RegelpruefungsProcessor(pruefergebnisService, antragRepository);
        Mockito.when(antragRepository.merge(any()))
                .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    @Transactional
    void pruefeRegelnTest() throws Exception {
        final Exchange exchange = getExchange();
        final Antrag antrag = setExchangeMitAntrag(exchange, AntragStatus.STATISTIK_ERFASST);
        antrag.addAntragPruefergebnis(
                AntragPruefergebnis.builder().ergebnis(PruefErgebnis.ERFUELLT).build());

        regelpruefungsProcessor.process(exchange);
        final Antrag processedAntrag = (Antrag) exchange.getMessage().getBody();

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
        Assertions.assertEquals(antrag.getAntragPruefergebnisse().getFirst(),
                processedAntrag.getAntragPruefergebnisse().getFirst());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange, final AntragStatus antragStatus) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(antragStatus).ktan("70").build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }

    private static RegelErgebnis getGesamtErgebnis(final RegelName regelName) {
        final var teilErgebnis = new RegelErgebnis();
        teilErgebnis.setPruefErgebnis(PruefErgebnis.ERFUELLT);
        teilErgebnis.setRegelName(regelName);
        teilErgebnis.setDetail("teilergebnis");
        final var gesamtErgebnis = new RegelErgebnis();
        gesamtErgebnis.setPruefErgebnis(PruefErgebnis.ERFUELLT);
        gesamtErgebnis.setRegelName(null);
        gesamtErgebnis.setDetail("gesamtergebnis");
        gesamtErgebnis.setDetailErgebnisse(List.of(teilErgebnis));
        return gesamtErgebnis;
    }
}
