package de.deutscherv.rvsm.fa.fit.antraege;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragCreator;
import de.deutscherv.rvsm.fa.fit.testdaten.StammdatenTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.AuftragsStatusDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PruefergebnisUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VerarbeitungsartDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import io.quarkus.artemis.test.ArtemisTestResource;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import wiremock.org.eclipse.jetty.http.HttpStatus;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.util.Json.objectToJson;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test AntraaegeApiImpl.
 */
@Slf4j
@QuarkusTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@QuarkusTestResource(ArtemisTestResource.class)
class AntraegeApiImplTest {

    private static final UUID DOE_STUB_ID = UUID.randomUUID();
    private static WireMockServer wireMockServer;
    private static Map<String, String> xmlAntraege;
    private static StubMapping stubStammdatenBadGateway;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;
    @Inject
    private AntragRepository antragRepository;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private AntraegeApiImpl antraegeApi;

    @Inject
    private EntityManager entityManager;

    @Inject
    private CamelContext camelContext;
    @Inject
    private FluentProducerTemplate producerTemplate;

    private CountDownLatch latch;

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        wireMockServer.stop();
    }

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    void set() {
        xmlAntraege =
                Xml.getXmlAntraege(Arrays.asList("eAntrag_15010191A388", "eAntrag_02220697M981"));

        wireMockServer = WireMockStub.connect(WireMockStub.PORT);
        wireMockServer.resetMappings();
        WireMockStub.stubForDoE(DOE_STUB_ID);
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForAzk();
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStammdaten(TestPerson.BOB_BAUMEISTER);
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setUp() {
        MappingBuilder mappingBuilder = post(urlPathTemplate("/auftraege"))
                .withId(DOE_STUB_ID)
                .withHeader("Content-Type", new EqualToPattern("application/json", false))
                .willReturn(aResponse().withStatus(202).withBody(getDokumentenErzeugungAuftragAntwort()));
        wireMockServer.editStub(mappingBuilder);
        latch = new CountDownLatch(1);
        camelContext.getRouteController().stopRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
        AdviceWith.adviceWith(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS, camelContext,
                new AdviceWithRouteBuilder() {
                    @Override
                    public void configure() {
                        weaveAddLast().process(exchange -> latch.countDown());
                    }
                });
        camelContext.getRouteController().startRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
    }

    /**
     * Test GetbyUUId.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testGetByUuid() {
        WireMockStub.stubForStammdaten(TestPerson.BOB_BAUMEISTER);
        final UUID antragUuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        final Response response = antraegeApi.getByUuid(UUID.fromString(antragUuid.toString()));
        assertThat(response.getStatus()).isEqualTo(200);
    }

    /**
     * Test Post Dokumentendaten.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    @Test
    void postDokumentendaten() {
        final UUID antragUuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        final DokumentenklasseDto dokumentenklasseDto = new DokumentenklasseDto();
        dokumentenklasseDto.setVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG);
        dokumentenklasseDto.setFreitextVersicherter("Der Freittext");
        given().body(objectToJson(dokumentenklasseDto)).contentType(ContentType.JSON)
                .pathParam("uuid", antragUuid.toString()).when()
                .post("antraege/{uuid}/dokumentendaten").then().statusCode(200);
    }

    /**
     * Test Post Dokumentendaten mit Invalidem DTO.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    @Test
    void testPostDokumentendatenInvalidDto() {
        final DokumentenklasseDto dokumentenklasseDto = new DokumentenklasseDto();
        dokumentenklasseDto.setFreitextVersicherter("Der Freittext");
        dokumentenklasseDto.setVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG);
        final String json = objectToJson(dokumentenklasseDto).replace("SACHVERHALTSAUFKLAERUNG", "Nix gut");
        given().body(json).contentType(ContentType.JSON)
                .pathParam("uuid", "2b684ca0-c002-49d7-aab0-cb3c411be0de").when()
                .post("antraege/{uuid}/dokumentendaten").then().statusCode(500);
    }

    /**
     * Test Verarbeitung Ablehnung mit Invalidem DTO.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    @Test
    void testVerarbeiteAblehnungInvalidDto() {
        final VersandErgebnisDto versandErgebnisDto = new VersandErgebnisDto();
        versandErgebnisDto.setAuftragId(UUID.randomUUID());
        versandErgebnisDto.setMeldung("Meldung");
        versandErgebnisDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);
        final String json = objectToJson(versandErgebnisDto).replace("VERSAND", "Nix gut");
        given().body(json).contentType(ContentType.JSON)
                .pathParam("uuid", "2b684ca0-c002-49d7-aab0-cb3c411be0de").when()
                .post("antraege/{uuid}/ablehnung").then().statusCode(500);
    }

    /**
     * Test Get Dokumentendaten.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    @Test
    void getDokumentendaten() {
        WireMockStub.stubForStammdaten(TestPerson.BOB_BAUMEISTER);
        final UUID antragUuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        final DokumentenklasseDto dokumentenklasseDto = new DokumentenklasseDto();
        dokumentenklasseDto.setVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG);
        dokumentenklasseDto.setFreitextVersicherter("Der Freittext");
        given().body(objectToJson(dokumentenklasseDto)).contentType(ContentType.JSON)
                .pathParam("uuid", antragUuid.toString()).when()
                .post("antraege/{uuid}/dokumentendaten").then().statusCode(200);

        given().contentType(ContentType.JSON)
                .pathParam("uuid", antragUuid).when()
                .get("antraege/{uuid}/dokumentendaten").then().statusCode(200);
    }

    /**
     * Test Update Einrichtung by Phase.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void updateEinrichtungByPhaseTest() {
        WireMockStub.stubForStammdaten(TestPerson.BOB_BAUMEISTER);
        final UUID antragUuid = createAntrag(TestPerson.BOB_BAUMEISTER);

        final RehaEinrichtungUpdateDto einrichtungStart = new RehaEinrichtungUpdateDto();
        einrichtungStart.setAngebotId(17562L);
        einrichtungStart.setDurchfuehrungsart("Ambulant (ganztägig)");

        given().contentType(ContentType.JSON).body(objectToJson(einrichtungStart))
                .pathParam("uuid", antragUuid).when()
                .pathParam("phase", "STARTPHASE").post("/antraege/{uuid}/einrichtung/phasen/{phase}")
                .then().statusCode(200);
    }

    /**
     * Test Get by UUID Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testGetByUuidRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .get("/antraege/{uuid}").then().statusCode(403);
    }

    /**
     * Test Post Dokumentendaten Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testPostDokumentendatenRolleErfasserDarfNichtZugreifen() {
        final DokumentenklasseDto dto = new DokumentenklasseDto();
        dto.setVorlage(DokumentenklasseDto.VorlageEnum.BEWILLIGUNG);
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).body(dto).when()
                .post("/antraege/{uuid}/dokumentendaten").then().statusCode(403);
    }

    /**
     * Test Get Dokumentendaten Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testGetDokumentendatenRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .get("/antraege/{uuid}/dokumentendaten").then().statusCode(403);
    }

    /**
     * Test Dokumentenerzeugung Bewilligung Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testPostDokumentenerzeugungBewilligungRolleErfasserDarfNichtZugreifen() {
        final BewilligungsdatenDto dto = new BewilligungsdatenDto();
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).body(dto).when()
                .post("/antraege/{uuid}/dokumentenerzeugung/bewilligung").then().statusCode(403);
    }

    /**
     * Test Reset Regelergebnis Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testResetRegelErgebnisRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).body("RegelName")
                .when().put("/antraege/{uuid}/pruefergebnis/reset").then().statusCode(403);
    }

    /**
     * Test Update Einrichtung by Phase Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testUpdateEinrichtungByPhaseTestRolleErfasserDarfNichtZugreifen() {
        final RehaEinrichtungUpdateDto einrichtungStart = new RehaEinrichtungUpdateDto();
        einrichtungStart.setAngebotId(17562L);
        einrichtungStart.setDurchfuehrungsart("Ambulant (ganztägig)");

        given().contentType(ContentType.JSON).body(objectToJson(einrichtungStart))
                .pathParam("uuid", UUID.randomUUID()).when().pathParam("phase", "STARTPHASE")
                .post("/antraege/{uuid}/einrichtung/phasen/{phase}").then().statusCode(403);
    }

    /**
     * Test Update Regelergebnis Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testUpdateRegelErgebnisRolleErfasserDarfNichtZugreifen() {
        final PruefergebnisUpdateDto dto = new PruefergebnisUpdateDto();
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when().body(dto)
                .put("/antraege/{uuid}/pruefergebnis").then().statusCode(403);
    }

    /**
     * Test Verarbeite Erlediung auf andere Art und Weise Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testVerarbeiteErledigungAufAndereArtUndWeiseRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .post("/antraege/{uuid}/erledigung-auf-andere-art-und-weise").then().statusCode(403);
    }

    /**
     * Test Verarbeite Rücknahme Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testVerarbeiteRuecknahmeRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .post("/antraege/{uuid}/ruecknahme").then().statusCode(403);
    }

    /**
     * Test Verarbeite Sachverhaltsaufklaerung Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testVerarbeiteSachverhaltsaufklaerungRolleErfasserDarfNichtZugreifen() {
        final VersandErgebnisDto dto = new VersandErgebnisDto();
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when().body(dto)
                .post("/antraege/{uuid}/sachverhaltsaufklaerung").then().statusCode(403);
    }

    /**
     * Test Verarbeite Stornierung Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testVerarbeiteStornierungRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .post("/antraege/{uuid}/storno").then().statusCode(403);
    }

    /**
     * Test Verarbeite Weiterleitung Rolle Eerfasser -> Darf nicht zugreifen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testVerarbeiteWeiterleitungRolleErfasserDarfNichtZugreifen() {
        given().contentType(ContentType.JSON).pathParam("uuid", UUID.randomUUID()).when()
                .post("/antraege/{uuid}/weiterbearbeitung-in-rvdialog").then().statusCode(403);
    }

    /**
     * Test Ermittle Verarbeitungsart Valide.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testErmittleVerarbeitungsartValid() {
        drvMandant.setInScope("70");
        final UUID antragUuid = UUID.randomUUID();
        legeVerarbeitungsstatusAn(antragUuid);

        final VerarbeitungsartDto verarbeitungsart = given().contentType(ContentType.JSON)
                .pathParam("uuid", antragUuid).when().get("/antraege/{uuid}/verarbeitungsart").then()
                .assertThat().statusCode(200).extract().as(VerarbeitungsartDto.class);

        assertThat(verarbeitungsart.getArt()).isEqualTo(VerarbeitungsartDto.ArtEnum.ABLEHNUNG);
    }

    /**
     * Test Ermittle Verarbeitungsart Inalide.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testErmittleVerarbeitungsartInvalid() {
        drvMandant.setInScope("70");

        final String verarbeitungsart = given().contentType(ContentType.JSON)
                .pathParam("uuid", UUID.randomUUID()).when().get("/antraege/{uuid}/verarbeitungsart")
                .then().statusCode(200).extract().asString();

        assertThat(verarbeitungsart).isEmpty();
    }

    /**
     * Test setze eAntrag.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testSetEantrag() {
        given().contentType(ContentType.XML).body(xmlAntraege.get("eAntrag_15010191A388")).when()
                .post("/antraege/eantrag").then().statusCode(500);
    }


    /**
     * Falls das Bestandssystem nicht erreichbar ist muss der Return Code 502 BAD GATEAWAY gemeldet werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testErneuterVersuchBestandssystemFehler() {
        drvMandant.setInScope("70");
        UUID uuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        stubStammdatenBadGateway = stubFor(get(urlPathTemplate("/konten/{versicherungsnr}"))
                .willReturn(aResponse().withStatus(HttpStatus.BAD_GATEWAY_502)
                        .withHeader("Content-Type", "application/json")));
        assertThrows(StammdatenException.class, () -> antraegeApi.erneuterVersuch(uuid));
        given().contentType(ContentType.JSON).pathParam("uuid", uuid)
                .post("antraege/{uuid}/erneuter-versuch").then().statusCode(502);
        wireMockServer.removeStub(stubStammdatenBadGateway);
    }

    /**
     * Falls das Bestandssystem erreichbar ist darf der Return Code nicht 502 BAD GATEAWAY sein.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testPersonendatenabgleichBestandssystemOk() {
        drvMandant.setInScope("70");
        UUID uuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        assertThat(antraegeApi.getPersonendatenabgleich(uuid).getStatus()).isNotEqualTo(HttpStatus.BAD_GATEWAY_502);
    }

    /**
     * Falls das Bestandssystem nicht erreichbar ist muss der Return Code 502 BAD GATEAWAY gemeldet werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testPersonendatenabgleichBestandssystemFehler() {
        drvMandant.setInScope("70");
        UUID uuid = createAntrag(TestPerson.BOB_BAUMEISTER);
        stubStammdatenBadGateway = stubFor(get(urlPathTemplate("/konten/{versicherungsnr}"))
                .willReturn(aResponse().withStatus(HttpStatus.BAD_GATEWAY_502)
                        .withHeader("Content-Type", "application/json")));
        assertThat(antraegeApi.getPersonendatenabgleich(uuid).getStatus()).isEqualTo(HttpStatus.BAD_GATEWAY_502);
        wireMockServer.removeStub(stubStammdatenBadGateway);
    }

    private static String getDokumentenErzeugungAuftragAntwort() {
        final AuftragsStatusDto auftragsStatusDto = new AuftragsStatusDto();
        auftragsStatusDto.setAuftragId(UUID.randomUUID());
        auftragsStatusDto.setStatus(AuftragsStatusDto.StatusEnum.UI_INTERAKTION_NOETIG);
        final AntwortDto antwortDto = new AntwortDto();
        antwortDto.setCode(0);
        antwortDto.setNachricht("string");
        auftragsStatusDto.setErrors(List.of(antwortDto));
        return objectToJson(auftragsStatusDto);
    }

    @Transactional
    public void legeVerarbeitungsstatusAn(final UUID antragUuid) {
        final Antrag antrag = new Antrag();
        antrag.setUuid(antragUuid);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.setVsnr(StammdatenTestDaten.getStammdaten(TestPerson.PETER_PAN).getVsnr());
        antragRepository.persist(antrag);

        final Verarbeitungsstatus verarbeitungsstatus = new Verarbeitungsstatus();
        verarbeitungsstatus.setCreated(LocalDateTime.now());
        verarbeitungsstatus.setLastmodified(LocalDateTime.now());
        verarbeitungsstatus.setAntragId(antragUuid);
        verarbeitungsstatus.setAuftragId(UUID.randomUUID());
        verarbeitungsstatus.setStatus(VerarbeitungStatus.FEHLER);
        verarbeitungsstatus.setArt(Art.ABLEHNUNG);
        verarbeitungsstatusRepository.persistAndFlush(verarbeitungsstatus);

    }

    @SneakyThrows
    private UUID createAntrag(final TestPerson testPerson) {
        PapierantragCreator papierantragCreator = new PapierantragCreator(wireMockServer, entityManager, drvMandant, latch);
        return papierantragCreator.createAntrag(testPerson).getUuid();
    }

}
