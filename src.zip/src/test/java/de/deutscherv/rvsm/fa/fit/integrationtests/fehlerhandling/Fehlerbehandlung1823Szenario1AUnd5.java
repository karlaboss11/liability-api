package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.restassured.http.ContentType;
import java.util.List;
import java.util.UUID;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1823">EVORVF2-1823</a>.
 * Szenario 1 (AF-Fehler) und 5
 */
@Slf4j
@Getter
public class Fehlerbehandlung1823Szenario1AUnd5 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0202";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final String antragXml;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     */
    public Fehlerbehandlung1823Szenario1AUnd5(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final BestandsfehlerRepository bestandsfehlerRepository, PurAufgabenProducer purAufgabenProducer) {
        super(TestPerson.HARVEY_DENT,
                new RegressionsConfig(true, true, false,
                        new StatistikBescheidConfig(FehlerTyp.UNERWARTET_AF, AF_STATUSCODE, 500)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(
                    antragUuid).orElseThrow();
            List<Bestandsfehler> bestandsFehler = bestandsfehlerRepository.findByAntragUuidNotDeleted(antrag.getUuid());

            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT);
            assertThat(bestandsFehler).isNotEmpty().hasSize(1);
            assertThat(bestandsFehler.getFirst().getBestandsfehlercode()).isEqualTo(AF_STATUSCODE);
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
        }

        BestandsfehlerDto bestandsfehlerDto = given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .get("antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_OK).extract().as(BestandsfehlerDto.class);
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNotNull();
        assertThat(bestandsfehlerDto.getUnerwartererFehler().getFehlercode()).isEqualTo(AF_STATUSCODE);

        return true;
    }

}
