package de.deutscherv.rvsm.fa.fit.diloop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.DoeNoAcceptedResponseException;
import de.deutscherv.rvsm.fa.fit.exceptions.DokumentenErzeugungsException;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ErrorResponseConstraintViolationsInnerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ErrorResponseDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.AntragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.KontoTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragCreator;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragDTO;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test DokumentendatenService.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
class DokumentendatenServiceTest {

    private static final String KONTO_RESPONSE_BODY = """
        {
          "ktan": "70",
          "versicherungsnummer": "02220697M981",
          "personen": [
           {
            "personentyp": "VERSICHERTER",
            "anrede": "HERR",
            "name": "Mouse",
            "vorname": "Mickey",
            "vorsatzwort": "",
            "namenszusatz": "",
            "titel": "",
            "geburtsname": "Disney",
            "geburtsort": "Bernburg (Saale)",
            "staatsangehoerigkeit": "163",
            "laenderschluesselGeburtsort": "000",
            "geburtsdatum": "1997-06-22",
            "telefon": "017610323499",
            "fax": "",
            "artZustellung": "GRUNDSTELLUNG",
            "mail": "",
            "artZugaenglichkeit": "GRUNDSTELLUNG",
            "geschlecht": "UNBESTIMMT",
            "anschrift": {
             "postleitzahl": "17033",
             "wohnort": "Neubrandenburg",
             "strasseHausnummer": "Platanenstr.  43",
             "anschriftenzusatz": "",
             "laenderschluessel": "000"
            }
           }
          ]
         }
         """;

    private static final MappingBuilder MAPPING_BUILDER_STATUS_ACCEPTED =
        WireMock.post(WireMock.urlEqualTo("/auftraege")).willReturn(
            WireMock.aResponse().withHeader("Content-Type", "application/json").withBody("""
                    {
                      "auftragId": "9272b231-8ea5-4b37-919c-43e32bf48792",
                      "status": "UI_INTERAKTION_NOETIG",
                      "errors": [
                        {
                          "message": "string",
                          "code": 0
                        }
                      ],
                      "debug": {
                        "diloopResponse": "string",
                        "jwt": {
                          "keycloak": {
                            "base64": "string",
                            "json": "string"
                          },
                          "diloop": {
                            "base64": "string",
                            "json": "string"
                          }
                        },
                        "mappingResult": "string"
                      }
                    }
                """).withStatus(Status.ACCEPTED.getStatusCode()));
    private static final MappingBuilder MAPPING_BUILDER_STATUS_OK =
        WireMock.post(WireMock.urlEqualTo("/auftraege"))
            .willReturn(WireMock.aResponse().withStatus(Status.OK.getStatusCode()));
    private static final MappingBuilder MAPPING_BUILDER_KONTO_DATEN =
        WireMock.post(WireMock.urlPathTemplate("/konten/{versicherungsnummer}"))
            .withPathParam("versicherungsnummer", equalTo("02220697M981")).willReturn(WireMock
                .aResponse().withBody(KONTO_RESPONSE_BODY).withStatus(Status.OK.getStatusCode()));
    private static final MappingBuilder MAPPING_BUILDER_ERROR =
        WireMock.post(WireMock.urlEqualTo("/auftraege")).willReturn(
            WireMock.aResponse().withStatus(Status.INTERNAL_SERVER_ERROR.getStatusCode()));

    private static WireMockServer wireMockServer;
    private static StubMapping stubKontoZeugenschutz;

    private static ObjectMapper objectMapper;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private DokumentendatenService dokumentendatenService;

    @Inject
    private EntityManager entityManager;

    @InjectMock
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private CamelContext camelContext;
    private CountDownLatch latch;

    private Verarbeitungsstatus verarbeitungsstatus;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    @SneakyThrows
    void set() {
        objectMapper = new ObjectMapper();

        wireMockServer = new WireMockServer(WireMockStub.PORT);

        wireMockServer.start();
        WireMock.configureFor("localhost", wireMockServer.port());
        stubKontoZeugenschutz = stubFor(get(urlPathTemplate("/konten/{vsnr}"))
            .willReturn(aResponse().withBody(createErrorResponseDto())
                .withHeader("Content-Type", "application/json")
                .withStatus(423)));
    }

    private static String createErrorResponseDto() throws JsonProcessingException {
        final ErrorResponseDto errorResponseDto = new ErrorResponseDto();
        errorResponseDto.setErrorMessage("Hier ist der Fehler");
        final ErrorResponseConstraintViolationsInnerDto errorResponseConstraintViolationsInnerDto =
            new ErrorResponseConstraintViolationsInnerDto();
        errorResponseConstraintViolationsInnerDto.setValue(StammdatenService.ZEUGENSCHUTZ);
        errorResponseDto.addConstraintViolationsItem(errorResponseConstraintViolationsInnerDto);

        return objectMapper.writeValueAsString(errorResponseDto);
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        // WireMocke beenden
        wireMockServer.stop();
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setup() {
        latch = new CountDownLatch(1);
        camelContext.getRouteController().stopRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
        AdviceWith.adviceWith(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS, camelContext,
            new AdviceWithRouteBuilder() {
                @Override
                public void configure() {
                    weaveAddLast().process(exchange -> latch.countDown());
                }
            });
        camelContext.getRouteController().startRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);

        stubFor(get(urlPathTemplate("/konten/{versicherungsnummer}"))
            .withPathParam("versicherungsnummer", equalTo("02220697M981"))
            .willReturn(aResponse().withStatus(200).withBody(KONTO_RESPONSE_BODY)
                .withHeader("Content-Type", "application/json")));

        final var peterPanKontoDaten = new ObjectMapper()
            .writeValueAsString(KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN));
        stubFor(get(urlPathTemplate("/konten/{versicherungsnummer}"))
            .withPathParam("versicherungsnummer", equalTo(TestPerson.PETER_PAN.VSNR))
            .willReturn(aResponse().withStatus(200).withBody(peterPanKontoDaten)
                .withHeader("Content-Type", "application/json")));

        WireMockStub.stubForAzk();
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForSmp(null, null, null, "4", "4");

    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @AfterEach
    void afterEach() {
        WireMock.removeAllMappings();
    }

    /**
     * Test Dokumentendaten - Sachverhaltsaufklärung Accepted.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerSachverhaltsaufklaerungStatusAcceptedTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);

        final AuftragsStatusDTO auftragsStatusDto = dokumentendatenService.getDokumentendaten(antrag,
            getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG),
            false);
        assertThat(auftragsStatusDto.getAuftragId())
            .isEqualTo(UUID.fromString("9272b231-8ea5-4b37-919c-43e32bf48792"));

    }

    /**
     * Test Dokumentendaten - Bewilligung Accepted.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerBewilligungStatusAcceptedTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMockStub.stubForStammdaten(TestPerson.PETER_PAN);

        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);
        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        drvMandant.setInScope("70");

        final List<AntragPruefergebnis> antragPruefergebnisse = antrag.getAntragPruefergebnisse();
        antragPruefergebnisse.forEach(pruefergebnis -> {
            pruefergebnis.setErgebnis(PruefErgebnis.ERFUELLT);
            pruefergebnis.setLastModified(LocalDateTime.now());
        });

        final AuftragsStatusDTO auftragsStatusDto = dokumentendatenService.getDokumentendatenBewilligung(antrag,
            new BewilligungsdatenDto(), false);
        assertThat(auftragsStatusDto.getAuftragId())
            .isEqualTo(UUID.fromString("9272b231-8ea5-4b37-919c-43e32bf48792"));
    }

    /**
     * Test Dokumentendaten - Bewilligung Not Found.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerBewilligungAntragNichtInBearbeitungNotFoundExceptionTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);

        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);

        final BewilligungsdatenDto bewilligungsdatenDto = new BewilligungsdatenDto();
        assertThrows(EingabevalidierungException.class,
            () -> dokumentendatenService.getDokumentendatenBewilligung(antrag, bewilligungsdatenDto, false));
    }

    /**
     * Test Dokumentendaten - Bewilligung Eingabevalidierung.
     * @param auf   Auffrischungsphasenobjekt
     * @param startObjekt Startphasenobjekt
     * @param training Trainingsphasenobjekt
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ParameterizedTest
    @CsvSource(nullValues = { "null" }, value = { "null,x,x", "x,null,x", "x,x,null" })
    void getDokumentendatenFuerBewilligungEingabeValidierungExceptionTest(final String auf,
        final String startObjekt, final String training) {
        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);

        antrag.setEinrichtungAufObjekt(
            Optional.ofNullable(auf).map(s -> new RehaEinrichtung()).orElse(null));
        antrag.setEinrichtungStartObjekt(
            Optional.ofNullable(startObjekt).map(s -> new RehaEinrichtung()).orElse(null));
        antrag.setEinrichtungTrainingObjekt(
            Optional.ofNullable(training).map(s -> new RehaEinrichtung()).orElse(null));

        final BewilligungsdatenDto bewilligungsdatenDto = new BewilligungsdatenDto();
        assertThrows(EingabevalidierungException.class,
            () -> dokumentendatenService.getDokumentendatenBewilligung(antrag, bewilligungsdatenDto, false));
    }

    /**
     * Test für die Dokumentenerzeugung BEWILLIGUNG Betrifft separierte Schnittstelle 'antraege/{uuid}/dokumentenerzeugung/bewilligung.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenBewilligungStatusAcceptedTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);

        drvMandant.setInScope("70");

        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);

        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        final List<AntragPruefergebnis> antragPruefergebnisse = antrag.getAntragPruefergebnisse();
        antragPruefergebnisse.forEach(pruefergebnis -> {
            pruefergebnis.setErgebnis(PruefErgebnis.ERFUELLT);
            pruefergebnis.setLastModified(LocalDateTime.now());
        });

        final BewilligungsdatenDto bewilligungsdatenDto = new BewilligungsdatenDto();
        bewilligungsdatenDto.setFreitextVersicherter("Text an Versicherter");
        bewilligungsdatenDto.setFreitextEinrichtung("Text an Einrichtung");
        final AuftragsStatusDTO auftragsStatusDto = dokumentendatenService
            .getDokumentendatenBewilligung(antrag, bewilligungsdatenDto, false);
        assertThat(auftragsStatusDto.getAuftragId())
            .isEqualTo(UUID.fromString("9272b231-8ea5-4b37-919c-43e32bf48792"));
    }

    /**
     * Test Dokumentendaten - Ablehnung.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerAblehnungStatusAcceptedTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMockStub.stubForStammdaten(TestPerson.HOMER_SIMPSON);

        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.HOMER_SIMPSON);

        WireMockStub.stubForStammdaten(TestPerson.HOMER_SIMPSON);
        final AuftragsStatusDTO auftragsStatusDto = dokumentendatenService.getDokumentendaten(antrag,
            getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.ABLEHNUNG), false);
        assertThat(auftragsStatusDto.getAuftragId())
            .isEqualTo(UUID.fromString("9272b231-8ea5-4b37-919c-43e32bf48792"));
    }

    /**
     * Test Dokumentendaten - Ablehnung Bad Request.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerAblehnungStatusBadRequestTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_OK);
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);

        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);
        final DokumentenklasseDto dokumentenklasseDto = getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG);
        assertThrows(DoeNoAcceptedResponseException.class, () -> dokumentendatenService.getDokumentendaten(antrag,
            dokumentenklasseDto,
            false));
    }

    /**
     * Test Dokumentendaten - Sachverhaltsaufklaerung Server Error.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerSachverhaltsaufklaerungStatusInternalServerErrorTest() {
        WireMock.stubFor(MAPPING_BUILDER_ERROR);
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);

        final DokumentenklasseDto dokumentenklasseDto = getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.SACHVERHALTSAUFKLAERUNG);
        assertThrows(DokumentenErzeugungsException.class,
            () -> dokumentendatenService.getDokumentendaten(antrag,
                dokumentenklasseDto,
                false));
    }

    /**
     * Test Dokumentendaten - Ablehnung Variablen Test.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerAblehnungVariablenTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMock.stubFor(MAPPING_BUILDER_KONTO_DATEN);

        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);

        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);

        antrag.getAntragPruefergebnisse().forEach(pruefergebnis -> {
            pruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
            pruefergebnis.setBegruendung("Begründung");
            pruefergebnis.setLastModified(LocalDateTime.now());
        });

        final String freierAblehnungstext = "...wurde abgelehnt...";
        final DokumentgenerierungsAuftragDTO dto = dokumentendatenService
            .getDokumentgenerierungsAuftragDTO(getDokumentendatenVorlageMitFreitext(
            ), false, antrag);

        assertThat(dto.getInputs().getVariablen().get("d_G9581_00_Antragsdatum")).isNotNull();
        assertThat(dto.getInputs().getVariablen().get("sv_op_G9581_00_Ablehnungsgrund"))
            .isNotNull();
        assertThat(dto.getInputs().getVariablen()).containsEntry("sv_tm_G9581_00_Freier_Text_Eingabe", freierAblehnungstext);

    }

    /**
     * Test Dokumentendaten - Bewilling kein Angebot.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerBewilligungNoAngebotTest() {
        final var test = WireMock.get(WireMock.urlPathTemplate("/konten/{versicherungsnummer}"))
            .withPathParam("versicherungsnummer", equalTo("04210202S484"))
            .willReturn(WireMock.aResponse().withBody("""
                    {
                      "ktan": "70",
                      "versicherungsnummer": "04210202S484",
                      "personen": [
                       {
                        "personentyp": "VERSICHERTER",
                        "anrede": "HERR",
                        "name": "Mouse",
                        "vorname": "Mickey",
                        "vorsatzwort": "",
                        "namenszusatz": "",
                        "titel": "",
                        "geburtsname": "Disney",
                        "geburtsort": "Bernburg (Saale)",
                        "staatsangehoerigkeit": "163",
                        "laenderschluesselGeburtsort": "000",
                        "geburtsdatum": "1997-06-22",
                        "telefon": "017610323499",
                        "fax": "",
                        "artZustellung": "GRUNDSTELLUNG",
                        "mail": "",
                        "artZugaenglichkeit": "GRUNDSTELLUNG",
                        "geschlecht": "UNBESTIMMT",
                        "anschrift": {
                         "postleitzahl": "17033",
                         "wohnort": "Neubrandenburg",
                         "strasseHausnummer": "Platanenstr.  43",
                         "anschriftenzusatz": "",
                         "laenderschluessel": "000"
                        }
                       }
                      ]
                     }
                     """).withHeader("Content-Type", "application/json;charset=UTF-8")
                .withStatus(Status.OK.getStatusCode()));
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMock.stubFor(test);

        drvMandant.setInScope("70");
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        final Antrag antrag = createAntrag(TestPerson.PETER_PAN);

        assertThrows(EingabevalidierungException.class,
            () -> dokumentendatenService
                .getDokumentgenerierungsdatenBewilligung(
                    antrag, "", "", false));
    }

    /**
     * Test Dokumentendaten - Ablehnung Praenvention letzte 12 Monate.
     */
    @SneakyThrows
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getDokumentendatenFuerAblehnungAbgeschlossenePraeventionsleistungLetzte12MonateTest() {
        WireMock.stubFor(MAPPING_BUILDER_STATUS_ACCEPTED);
        WireMock.stubFor(MAPPING_BUILDER_KONTO_DATEN);
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);

        drvMandant.setInScope("70");
        final Antrag antrag = createAntrag(TestPerson.MICKEY_MOUSE);
        final Kontoinformation kontoInformation = new Kontoinformation();
        kontoInformation.setMassnahmeRehaKobs(antrag.getAntragsDatum().minusMonths(2));
        antrag.getKontoinformationen().add(kontoInformation);

        final AntragPruefergebnis ergebnisRegelMassnahme = new AntragPruefergebnis();
        ergebnisRegelMassnahme.setRegelName(RegelName.REGEL_MASSNAHME);
        ergebnisRegelMassnahme.setLastModified(LocalDateTime.now());
        ergebnisRegelMassnahme.setBegruendung("Begründung");
        ergebnisRegelMassnahme.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        ergebnisRegelMassnahme.setPrioritaet(1L);
        antrag.getAntragPruefergebnisse().clear();
        antrag.getAntragPruefergebnisse().add(ergebnisRegelMassnahme);

        final DokumentgenerierungsAuftragDTO dto =
            dokumentendatenService.getDokumentgenerierungsAuftragDTO(
                getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.ABLEHNUNG), false,
                antrag);

        assertThat(dto.getInputs().getVariablen().get("d_G9581_00_Antragsdatum")).isNotNull();
        assertThat(dto.getInputs().getVariablen().get("sv_op_G9581_00_Ablehnungsgrund"))
            .isNotNull();
    }

    /**
     * Test Auftragsstatus.
     */
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getAuftragsStatusTest() {
        drvMandant.setInScope("70");
        final UUID uuid = UUID.randomUUID();
        setVerarbeitungsstatusTest(uuid);

        Mockito.when(verarbeitungsstatusRepository.findByAntragId(uuid))
            .thenReturn(Optional.of(verarbeitungsstatus));

        final AuftragsStatusDTO auftragStatus = dokumentendatenService.getAuftragStatus(uuid);
        assertEquals(verarbeitungsstatus.getAuftragId(), auftragStatus.getAuftragId());
    }

    /**
     * Test Auftragsstatus - Status empty.
     */
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getAuftragsStatusIsEmptyTest() {
        drvMandant.setInScope("70");

        final UUID uuid = UUID.randomUUID();
        setVerarbeitungsstatusTest(uuid);

        Mockito.when(verarbeitungsstatusRepository.findByAntragId(uuid))
            .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> dokumentendatenService.getAuftragStatus(uuid));
    }

    /**
     * Test Auftragsstatus - Antrag Locked.
     */
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void getAuftragsStatusAntragIsLockedTest() {
        drvMandant.setInScope("70");
        wireMockServer.addStubMapping(stubKontoZeugenschutz);

        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);
        AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        final UUID uuid = UUID.randomUUID();
        assertThrows(KontoGesperrtException.class, () -> dokumentendatenService.getAuftragStatus(uuid));
        wireMockServer.removeStub(stubKontoZeugenschutz);

    }

    private DokumentenklasseDto getDokumentendatenVorlage(
        final DokumentenklasseDto.VorlageEnum vorlageEnum) {
        final DokumentenklasseDto dokumentenklasseDto = new DokumentenklasseDto();
        dokumentenklasseDto.setVorlage(vorlageEnum);
        return dokumentenklasseDto;
    }

    private DokumentenklasseDto getDokumentendatenVorlageMitFreitext() {
        final DokumentenklasseDto dokumentenklasseDto = getDokumentendatenVorlage(DokumentenklasseDto.VorlageEnum.ABLEHNUNG);
        dokumentenklasseDto.setFreitextVersicherter("...wurde abgelehnt...");
        return dokumentenklasseDto;
    }

    private void setVerarbeitungsstatusTest(final UUID uuid) {
        verarbeitungsstatus = new Verarbeitungsstatus();
        verarbeitungsstatus.setUuid(UUID.randomUUID());
        verarbeitungsstatus.setAntragId(uuid);
        verarbeitungsstatus.setCreated(LocalDateTime.now());
        verarbeitungsstatus.setAuftragId(UUID.randomUUID());
        verarbeitungsstatus.setArt(Art.ABLEHNUNG);
        verarbeitungsstatus.setMeldung("Test");
        verarbeitungsstatus.setStatus(VerarbeitungStatus.ERSTELLT);
    }

    @SneakyThrows
    private Antrag createAntrag(final TestPerson testPerson) {
        PapierantragCreator papierantragCreator = new PapierantragCreator(wireMockServer, entityManager, drvMandant, latch);

        UUID uuid = papierantragCreator.createAntrag(testPerson).getUuid();
        boolean antragAsyncVerarbeitet = latch.await(2, TimeUnit.SECONDS);
        Assertions.assertThat(antragAsyncVerarbeitet).isTrue();
        return entityManager.find(Antrag.class, uuid);
    }
}
