package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.EantragsBestaetigungMapperImpl;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class VerarbeiteEAntragExceptionHandlerProcessTest extends DefaultProcessorTest {


    @Test
    void verarbeiteEAntragExceptionHandlerProcessorTest() throws Exception {
        final VerarbeiteEAntragExceptionHandlerProcess verarbeiteEAntragExceptionHandlerProcess =
                new VerarbeiteEAntragExceptionHandlerProcess(new EantragsBestaetigungMapperImpl());
        final Exchange exchange = getExchange();
        final Message message = getMessage();
        message.setBody(Xml.getXmlAntrag("eAntragXmls/eAntrag_15280982D041.xml"));
        exchange.setMessage(message);
        exchange.setProperty(Exchange.EXCEPTION_CAUGHT, new Exception(""));

        verarbeiteEAntragExceptionHandlerProcess.process(exchange);
        final EantragsBestaetigungDTO antragsbestaetigung =
                (EantragsBestaetigungDTO) exchange.getMessage().getBody();

        assertEquals("70", antragsbestaetigung.geteAntragDaten().getEmpfaenger());
        assertEquals("class java.lang.Exception",
                antragsbestaetigung.geteAntragDaten().getFehlerNummer());
    }
}
