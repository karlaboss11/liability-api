package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import java.util.UUID;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.mockito.Mockito;
import wiremock.org.eclipse.jetty.http.HttpStatus;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1820">EVORVF2-1820</a>.
 * Szenario 1
 */
@Slf4j
@Getter
public class Fehlerbehandlung1820Szenario1 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0047";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final String antragXml;
    private final AntragRepository antragRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final WireMockServer wireMockServer;
    private final EntityManager entityManager;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param wireMockServer Wiremockserver
     */
    public Fehlerbehandlung1820Szenario1(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final WireMockServer wireMockServer,
            final EntityManager entityManager) {
        super(TestPerson.HARVEY_DENT,
                new RegressionsConfig(true, true, false,
                        new StammdatenConfig("Biele", null,null,200)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.wireMockServer = wireMockServer;
        this.entityManager = entityManager;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        Mockito.clearInvocations(purAufgabenProducer);

        var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT);
            assertThat(antrag.getAufgaben().getFirst().getAufgabenArt()).isEqualTo(AufgabenArt.PERSONENDATENABGLEICH);
            Mockito.verify(purAufgabenProducer, times(1)).createAufgabe(any());
            entityManager.detach(antrag);
        }

        Mockito.clearInvocations(purAufgabenProducer);
        updateWireMockConfig(wireMockServer,
                new RegressionsConfig(true, true, false,
                        new StammdatenConfig(null, AF_STATUSCODE, null, HttpStatus.INTERNAL_SERVER_ERROR_500)));
        AntwortDto antwortDto = given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
                .post("antraege/{uuid}/personendatenabgleich").then().statusCode(HttpStatus.INTERNAL_SERVER_ERROR_500)
                .extract().as(AntwortDto.class);
        BestandsfehlerDto bestandsfehler = antwortDto.getBestandsfehler();
        assertThat(bestandsfehler.getUnerwartererFehler().getFehlercode()).isEqualTo(AF_STATUSCODE);
        assertThat(bestandsfehler.getVsnr()).isEqualTo(getTestPerson().VSNR);
        assertThat(bestandsfehler.getName()).isEqualTo("Dent");
        assertThat(bestandsfehler.getVorname()).isEqualTo("Harvey");

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT);
            assertThat(antrag.getAufgaben().getFirst().getAufgabenArt()).isEqualTo(AufgabenArt.PERSONENDATENABGLEICH);
            assertThat(antrag.getAufgaben().getFirst().getDatumErledigt()).isNull();
            Mockito.verify(purAufgabenProducer, times(0)).createAufgabe(any());
            Mockito.verify(purAufgabenProducer, times(0)).completeAufgabe(any());
        }

        return true;
    }

}
