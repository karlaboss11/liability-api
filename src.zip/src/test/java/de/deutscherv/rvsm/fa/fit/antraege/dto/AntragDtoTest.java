package de.deutscherv.rvsm.fa.fit.antraege.dto;

import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.util.StringUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AntragDtoTest {

    private Validator validator;

    @BeforeEach
    public void setUp() {
        final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void testWhenFieldsTooShort() {

        final AntragDto dto = new AntragDto().uuid("tO6vn3Rlgs").vsnr("13240855M5").geschlecht("").ktan("7");

        final Set<ConstraintViolation<AntragDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(4, violations.size());
    }

    @Test
    void testWhenFieldsTooLong() {

        final String strWith256Chars = StringUtils.randomStringGenerator(256);

        final AntragDto dto = new AntragDto().uuid(StringUtils.randomStringGenerator(37))
                .vsnr("13240855M5568").strasse(strWith256Chars).hausnummer("XGxQSSLkgnU").plz("12345678910")
                .wohnort(strWith256Chars).land(strWith256Chars).vorname(strWith256Chars)
                .nachname(strWith256Chars).fruehererName(strWith256Chars).vorsatzwort(strWith256Chars)
                .namenszusatz(strWith256Chars).titel(strWith256Chars).geburtsname(strWith256Chars)
                .geburtsort(strWith256Chars).geburtsland(strWith256Chars).geschlecht("MF")
                .staatsangehoerigkeit(strWith256Chars).telefon("0839930271632685868115811845663")
                .fax("0839930271632685868115811845663").ktan("707");

        final Set<ConstraintViolation<AntragDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(21, violations.size());

    }

    @Test
    void testWhenFieldsValid() {

        final AntragDto dto = new AntragDto().uuid("fbadc5bd-a6f5-42f2-bea6-c665a81c49ba")
                .vsnr("13240855M556").plz("71686").geschlecht("M").ktan("70");

        final Set<ConstraintViolation<AntragDto>> violations = validator.validate(dto);

        assertTrue(violations.isEmpty());
    }
}
