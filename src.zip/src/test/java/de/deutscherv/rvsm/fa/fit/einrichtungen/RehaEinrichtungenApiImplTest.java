package de.deutscherv.rvsm.fa.fit.einrichtungen;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.StammdatenMockTransformer;
import de.deutscherv.rvsm.fa.fit.openapi.model.EinrichtungAnschriftAutovervollstaendigungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungAutovervollstaendigungDto;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test, RehaEinrichtungenApiImpl.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
class RehaEinrichtungenApiImplTest {
    private static WireMockServer wireMockServer;

    @Inject
    private RehaEinrichtungenApiImpl rehaEinrichtungenApi;

    @Inject
    private DrvMandant drvMandant;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    @SuppressWarnings("unchecked")
    static void set() {
        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(WireMockStub.PORT)
            .extensions(StammdatenMockTransformer.class));
        wireMockServer.start();
        WireMock.configureFor("localhost", wireMockServer.port());
        stubFor(get(urlEqualTo("/nachderreha-api/rvfit/v2/einrichtungen/all")).willReturn(
            aResponse().withStatus(200)
                .withBody(jsonToString("einrichtung/einrichtungen_all.json"))
                .withHeader("Content-Type", "application/json")));

        stubFor(get(urlEqualTo("/nachderreha-api/rvfit/v2/einrichtungen?plz=66292&umkreis=40000&phase=2&durchfuehrungsart=4"))
            .willReturn(
                aResponse().withStatus(200)
                    .withBody(jsonToString("einrichtung/einrichtungen_all.json"))
                    .withHeader("Content-Type", "application/json")));

        stubFor(get(urlEqualTo("/rehaeinrichtungen")).willReturn(
            aResponse().withStatus(200)
                .withBody(jsonToString("einrichtung/einrichtungen_all.json"))
                .withHeader("Content-Type", "application/json")));
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    @SneakyThrows
    static void tearDownAfterClass() {
        wireMockServer.stop();
    }

    /**
     * Test, Lies alle  Rehaeinrichtugen, Pruefe PLZ-Laengen.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testGetAllRehaeinrichtungenPruefePlzLaengen() {
        final List<RehaEinrichtungAutovervollstaendigungDto> rehaEinrichtungDtos = Arrays.asList(
            given().get("/rehaeinrichtungen/autovervollstaendigungen").then()
                .contentType(ContentType.JSON).statusCode(200).extract()
                .as(RehaEinrichtungAutovervollstaendigungDto[].class));

        final List<String> adressePlzList = rehaEinrichtungDtos.stream()
            .map(RehaEinrichtungAutovervollstaendigungDto::getAdresse)
            .map(EinrichtungAnschriftAutovervollstaendigungDto::getPlz).toList();

        assertThat(adressePlzList).isNotEmpty().allMatch(plz -> plz.matches("\\d{4,5}"));
    }

    /**
     * Test, lies alle Reha-Einrichtungen.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void getAlleRehaeinrichtungenTest() {
        final List<RehaEinrichtungAutovervollstaendigungDto>
            rehaEinrichtungAutovervollstaendigungDtos = Arrays.asList(
            given().get("/rehaeinrichtungen/autovervollstaendigungen").then()
                .contentType(ContentType.JSON).statusCode(200).extract()
                .as(RehaEinrichtungAutovervollstaendigungDto[].class));

        assertEquals("10000", rehaEinrichtungAutovervollstaendigungDtos.get(0).getId());
        assertEquals("10001", rehaEinrichtungAutovervollstaendigungDtos.get(1).getId());
        assertEquals("10002", rehaEinrichtungAutovervollstaendigungDtos.get(2).getId());
    }

    /**
     * Test, lies alle Reha-Einrichtungen, Test Rolle Erfasser.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void getAlleRehaeinrichtungenTestRolleErfasser() {
        final List<RehaEinrichtungAutovervollstaendigungDto>
            rehaEinrichtungAutovervollstaendigungDtos = Arrays.asList(
            given().get("/rehaeinrichtungen/autovervollstaendigungen").then()
                .contentType(ContentType.JSON).statusCode(200).extract()
                .as(RehaEinrichtungAutovervollstaendigungDto[].class));

        assertEquals("10000", rehaEinrichtungAutovervollstaendigungDtos.get(0).getId());
        assertEquals("10001", rehaEinrichtungAutovervollstaendigungDtos.get(1).getId());
        assertEquals("10002", rehaEinrichtungAutovervollstaendigungDtos.get(2).getId());
    }

    /**
     * Test Suche Reha-Einrichtungen, Rolle Erfasser nicht zulaessig.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void getSucheRehaeinrichtungenRolleErfasserNichtZulaessig() {
        given().queryParams(Map.of("q", "66292",
                "umkreis", 40000,
                "phase", "Startphase",
                "durchfuehrungsart", "Ambulant"))
            .get("/rehaeinrichtungen")
            .then()
            .contentType(ContentType.JSON)
            .statusCode(403);
    }

    /**
     * Test suche.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void sucheTest() {
        drvMandant.setInScope("70");
        Response response = rehaEinrichtungenApi.suche("66292", 40000, "Startphase", "Ambulant");
        assertThat(response.getStatus()).isEqualTo(200);

    }
}
