package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.RetryRoutes;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1819">EVORVF2-1821</a>
 * Szenario 1.
 */
public class Fehlerbehandlung1821Szenario1 extends RegressionsTestTemplate {

    // Beim abholen der Stamdaten tritt ein unerwarteter Fehler auf (nicht AF, nur 500)
    private static final RegressionsConfig INITIAL_CONFIG = new RegressionsConfig(true, true, false,
        new StammdatenConfig(null, null, FehlerTyp.UNERWARTET, HttpStatus.SC_INTERNAL_SERVER_ERROR));
    private static final RegressionsConfig REGRESSIONS_CONFIG = new RegressionsConfig(true, true, false);
    private final String antragXml;
    private final FluentProducerTemplate producerTemplate;
    private final DrvMandant drvMandant;
    private final AntragRepository antragRepository;
    private final FehlerRepository fehlerRepository;
    private final EntityManager entityManager;
    private final WireMockServer wireMockServer;

    /**
     * Konstruktor.
     *
     * @param drvMandant       DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param entityManager    Entity-Manager
     * @param wireMockServer   Wiremockserver
     * @param fehlerRepository Fehler-Repository
     * @param testPerson       Testperson
     */
    public Fehlerbehandlung1821Szenario1(final TestPerson testPerson,
        final FluentProducerTemplate producerTemplate,
        final DrvMandant drvMandant,
        final AntragRepository antragRepository,
        final FehlerRepository fehlerRepository,
        final EntityManager entityManager,
        final WireMockServer wireMockServer) {
        super(testPerson, INITIAL_CONFIG);
        this.producerTemplate = producerTemplate;
        this.drvMandant = drvMandant;
        this.antragRepository = antragRepository;
        this.fehlerRepository = fehlerRepository;
        this.entityManager = entityManager;
        this.wireMockServer = wireMockServer;
        this.antragXml = Xml.getXmlAntrag("eAntragXmls/eAntrag_" + getTestPerson().VSNR + ".xml");
    }

    @Override
    @SneakyThrows
    public boolean fuehreAus() {
        // Lade einen Antrag hoch
        final var exchange = producerTemplate.to(DIRECT_INIT_EANTRAG).withBody(antragXml).send();
        this.antragUuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(getAntragUuid()).orElseThrow();
            assertThat(antrag).isNotNull();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.VORGANG_ERZEUGT);
            final List<Fehler> fehler = fehlerRepository.findByAntrag(antrag);
            assertThat(fehler).isNotEmpty().hasSize(1);
            fehler.forEach(entityManager::detach);
            entityManager.detach(antrag);
        }
        updateWireMockConfig(wireMockServer, REGRESSIONS_CONFIG);

        producerTemplate.to(RetryRoutes.DIRECT_RETRY).send();

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(getAntragUuid()).orElseThrow();
            assertThat(antrag).isNotNull();
            assertThat(antrag.getStatus()).isNotEqualTo(AntragStatus.ENTWURF);
            final List<Fehler> fehler = fehlerRepository.findByAntrag(antrag);
            assertThat(fehler).isEmpty();
            entityManager.detach(antrag);
        }
        return true;
    }

}
