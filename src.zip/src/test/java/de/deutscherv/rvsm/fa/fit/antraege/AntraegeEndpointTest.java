package de.deutscherv.rvsm.fa.fit.antraege;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.antraege.service.EinrichtungenUpdateService;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentendatenService;
import de.deutscherv.rvsm.fa.fit.exceptions.ValidationExceptionMapper;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragPruefergebnisDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PruefergebnisUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RegelNameDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragCreator;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDebugDTO;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import lombok.SneakyThrows;
import org.apache.camel.CamelContext;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_UNMARSHAL_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_CHECK_DOPPELVERGABE;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERFASSE_STATISTIK;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_VORGANG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_STAMMDATEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SAVE_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SETSMP_EINRICHTUNGEN;
import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

/**
 * Test AntraegeEndpoint.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
@ActivateRequestContext
class AntraegeEndpointTest extends CamelQuarkusTestSupport {

    private static final String NOT_FOUND_NACHRICHT =
        "Die angeforderte Resource wurde nicht gefunden";
    private static final String DIRECT_JUST_SAVEEANTRAG = "direct:justsaveEantrag";

    private static Map<String, String> xmlAntraege = null;

    private static WireMockServer wireMockServer;

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private AntragService antragService;

    @Inject
    private EinrichtungenUpdateService einrichtungenUpdateService;

    @Inject
    private AntraegeApiImpl antraegeApiImpl;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private EntityManager entityManager;

    @Inject
    private FluentProducerTemplate producerTemplate;

    @Inject
    private CamelContext camelContext;
    private CountDownLatch latch = new CountDownLatch(1);
    private Antrag antragKtan70;

    @Override
    protected RoutesBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                from(DIRECT_JUST_SAVEEANTRAG)
                    .routeId(DIRECT_JUST_SAVEEANTRAG)
                    .to(DIRECT_UNMARSHAL_EANTRAG)
                    .to(DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
                    .to(DIRECT_EXTRACT_MANDANT)
                    .to(DIRECT_SAVE_EANTRAG)
                    .to(DIRECT_GENERATE_VORGANGSKENNUNG)
                    .to(DIRECT_ERSTELLE_VORGANG)
                    .to(DIRECT_FETCH_KONTOINFORMATIONEN)
                    .to(DIRECT_SETSMP_EINRICHTUNGEN)
                    .to(DIRECT_ERFASSE_STATISTIK)
                    .to(DIRECT_CHECK_DOPPELVERGABE)
                    .to(DIRECT_FETCH_STAMMDATEN);
            }
        };
    }

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    @Transactional
    void setUpAll() {
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);

        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForSmp(null, null, null, "4", "4");
        WireMockStub.stubForRvPur();
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStammdaten(null);
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);
        WireMockStub.stubForAzk();
        xmlAntraege = Xml.getXmlAntraege(
            Arrays.asList("eAntrag_04030583T112", "eAntrag_04100179M632", "eAntrag_04140500S561",
                "eAntrag_04191094J688", "eAntrag_04220283C878", "eAntrag_02220697M981",
                "eAntrag_04270194L037", "eAntrag_04150370A444", "eAntrag_04200100L719",
                "eAntrag_04140300W554", "eAntrag_15150791G180", "eAntrag_15010191A388"));
        antragKtan70 = getBasicAntrag(TestPerson.PETER_PAN.VSNR);
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        WireMockStub.disconnect(wireMockServer);
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setup() {
        latch = new CountDownLatch(1);
        camelContext.getRouteController().stopRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
        AdviceWith.adviceWith(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS, camelContext,
            new AdviceWithRouteBuilder() {
                @Override
                public void configure() {
                    weaveAddLast().process(exchange -> latch.countDown());
                }
            });
        camelContext.getRouteController().startRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
    }

    /**
     * Get Antrag soll NotFoundException werfen. NotFoundExceptionMapper soll aufgerufen werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void getByUuidNotAllowedExceptionTest() {
        final AntragRepository mockAntragRepository = Mockito.mock(AntragRepository.class);
        when(mockAntragRepository.findByUuid(any(UUID.class)))
            .thenThrow(new IllegalArgumentException());

        final AntwortDto antwortDto =
            given().get("antraege/" + UUID.randomUUID()).then().contentType("application/json")
                .statusCode(HttpStatus.SC_NOT_FOUND).extract().response().as(AntwortDto.class);

        assertEquals(Status.NOT_FOUND.getStatusCode(), antwortDto.getCode());
    }

    /**
     * Get Antrag soll FORBIDDEN werfen da nicht mit der Rolle PR_Fit_BST zugegriffen wird.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_FE")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void getByUuidForbiddenExceptionTest() {
        drvMandant.setInScope("70");
        final Antrag antrag = producerTemplate.withBody(xmlAntraege.get("eAntrag_04140300W554"))
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(DIRECT_JUST_SAVEEANTRAG).request(Antrag.class);
        drvMandant.setInScope("70");

        given().get("antraege/" + antrag.getUuid()).then()
            .statusCode(HttpStatus.SC_FORBIDDEN);

    }

    /**
     * Get Antrag soll NotFoundException werfen. NotFoundExceptionMapper soll aufgerufen werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void getByUuidNotFoundExceptionTest() {
        final AntwortDto antwortDto = given().get("antraege/" + antragKtan70.getUuid()).then()
            .statusCode(HttpStatus.SC_NOT_FOUND).extract().response().as(AntwortDto.class);

        assertEquals(NOT_FOUND_NACHRICHT, antwortDto.getNachricht());
        assertEquals(Status.NOT_FOUND.getStatusCode(), antwortDto.getCode());
    }

    /**
     * Get Antrag soll NotFoundException werfen, wenn Antrag Abgeschlossen.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    @Transactional
    void testGetByUuidAntragStatusAbgeschlossen() {
        final Antrag antrag = getBasicAntrag(TestPerson.PETER_PAN.VSNR);

        // Abschluss Status setzen und speichern
        antrag.setStatus(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antragRepository.merge(antrag);

        final Response response = antraegeApiImpl.getByUuid(antrag.getUuid());

        assertEquals(response.getStatus(), Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Get Antrag soll NotFoundException werfen. NotFoundExceptionMapper soll aufgerufen werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void getAntragByIdShouldReturn404WhenAntragDoesntExist() {
        final AntwortDto antwortDto = given().get("antraege/" + UUID.randomUUID()).then()
            .statusCode(HttpStatus.SC_NOT_FOUND).extract().response().as(AntwortDto.class);

        assertEquals(NOT_FOUND_NACHRICHT, antwortDto.getNachricht());
        assertEquals(Status.NOT_FOUND.getStatusCode(), antwortDto.getCode());
    }

    /**
     * Teste Update Einrichtungen by Phase.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70"),
        @Claim(key = "drvid", value = "DRV241222222222") })
    @Transactional
    void updateEinrichtungByPhaseTest() {
        Antrag eAntrag = getBasicAntrag("15010191A388");

        final RehaEinrichtungUpdateDto einrichtungTraining = new RehaEinrichtungUpdateDto();
        einrichtungTraining.setAngebotId(17550L);
        einrichtungTraining.setDurchfuehrungsart("Ambulant");

        einrichtungenUpdateService.updateEinrichtungByPhase(eAntrag.getUuid(), "Trainingsphase",
            einrichtungTraining);
        eAntrag = antragRepository.findByUuid(eAntrag.getUuid()).orElseThrow();
        assertEquals("T00003", eAntrag.getEinrichtungTrainingObjekt().getResc());
        assertEquals("Testklinik Milbertshofen am Hart", eAntrag.getEinrichtungTrainingObjekt().getName());
        assertEquals(17550L, eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals(4, eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant", eAntrag.getEinrichtungTrainingObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Update Antrag EinrichtungenByPhase soll ValidationException werfen. ValidationExceptionMapper soll aufgerufen werden.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void testupdateEinrichtungByPhaseWithInvalidDto() {

        var antrag = getBasicAntrag("04030583T112");
        final var einrichtungen = "";

        final AntwortDto antwortDto = given().contentType(ContentType.JSON).body(einrichtungen)
            .post("antraege/" + antrag.getUuid() + "/einrichtung/phasen/STARTPHASE").then()
            .extract().response().as(AntwortDto.class);

        assertEquals(Status.BAD_REQUEST.getStatusCode(), antwortDto.getCode());
        assertEquals(ValidationExceptionMapper.VALIDATION_FEHLGESCHLAGEN_NACHRICHT,
            antwortDto.getNachricht());
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();
        antragRepository.delete(antrag);
    }

    /**
     * Teste Update Status by Antrag Guuid.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void updateRegelErgebnisTest() {
        final Antrag antragMitErgebnis = getBasicAntragMitErgebnis("04150370A444");

        @Valid
        @NotNull
        final PruefergebnisUpdateDto pruefergebnisUpdateDto = new PruefergebnisUpdateDto();
        pruefergebnisUpdateDto.setAntragPruefergebnis(AntragPruefergebnisDto.AUSSTEUERN);
        pruefergebnisUpdateDto.setBegruendung("");
        pruefergebnisUpdateDto.setRegelName(RegelNameDto.REGEL_WIDERSPRUCHSVERFAHREN);
        final Response response = antraegeApiImpl.updateRegelErgebnis(antragMitErgebnis.getUuid(),
            pruefergebnisUpdateDto);

        assertEquals(Status.OK.getStatusCode(), response.getStatusInfo().getStatusCode());
        antragRepository
            .delete(antragRepository.findByUuid(antragMitErgebnis.getUuid()).orElseThrow());
    }

    /**
     * Teste Update Status by Antrag Guuid.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void resetRegelErgebnisTest() {
        final Antrag antragMitErgebnis = getBasicAntragMitErgebnis("04200100L719");
        final Response response = antraegeApiImpl.resetRegelErgebnis(antragMitErgebnis.getUuid(),
            "REGEL_BEAMTENEIGENSCHAFT_BEZUEGE");

        assertEquals(Status.OK.getStatusCode(), response.getStatusInfo().getStatusCode());

        antragRepository
            .delete(antragRepository.findByUuid(antragMitErgebnis.getUuid()).orElseThrow());
    }

    /**
     * Teste updateVerarbeitungsstatus by Antrag UUID.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void updateVerarbeiteAblehnungTest() {
        final DokumentendatenService mock =
            Mockito.mock(DokumentendatenService.class, Mockito.CALLS_REAL_METHODS);

        Mockito.doReturn(createMockAuftragStatusDTO()).when(mock).getDokumentendaten(any(), any(),
            anyBoolean());
        QuarkusMock.installMockForType(mock, DokumentendatenService.class);

        drvMandant.setInScope("70");
        final UUID antragUUID = createAntrag();

        final VersandErgebnisDto versandErgebnis = new VersandErgebnisDto();
        versandErgebnis.setAuftragId(UUID.randomUUID());
        versandErgebnis.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID).body(versandErgebnis)
            .post("antraege/{uuid}/ablehnung").then().statusCode(HttpStatus.SC_OK);

        resetAntragsStatusUndLoescheVerarbeitungsStatus(antragUUID
        );
    }

    /**
     * Test Update Verarbeite Bewilligung.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void updateVerarbeiteBewilligungTest() {
        final DokumentendatenService mock =
            Mockito.mock(DokumentendatenService.class, Mockito.CALLS_REAL_METHODS);
        Mockito.doReturn(createMockAuftragStatusDTO()).when(mock).getDokumentendaten(any(), any(),
            anyBoolean());
        QuarkusMock.installMockForType(mock, DokumentendatenService.class);

        drvMandant.setInScope("70");
        final UUID antragUUID = createAntrag();

        final VersandErgebnisDto versandErgebnis = new VersandErgebnisDto();
        versandErgebnis.setAuftragId(UUID.randomUUID());
        versandErgebnis.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID).body(versandErgebnis)
            .post("antraege/{uuid}/bewilligung").then().statusCode(HttpStatus.SC_OK);

        resetAntragsStatusUndLoescheVerarbeitungsStatus(antragUUID
        );
    }

    /**
     * Test Update verarbeite Sachverhaltsaufklaerung.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void updateVerarbeiteSachverhaltsaufklaerungTest() {
        drvMandant.setInScope("70");
        final UUID antragUUID = UUID.fromString("5e8ea10a-e4f3-4957-8553-4e51d5513fe0");

        final VersandErgebnisDto versandErgebnis = new VersandErgebnisDto();
        versandErgebnis.setAuftragId(UUID.randomUUID());
        versandErgebnis.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID).body(versandErgebnis)
            .post("antraege/{uuid}/sachverhaltsaufklaerung").then()
            .statusCode(HttpStatus.SC_NOT_IMPLEMENTED);
    }

    /**
     * Test Update APIs.
     * <ul>
     *     <li>Erledigung auf andere Art und Weise</li>
     *     <li>Storno</li>
     *     <li>Rücknahme</li>
     * </ul>
     *
     * @param url zu testende URL
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ParameterizedTest
    @ValueSource(strings = { "antraege/{uuid}/erledigung-auf-andere-art-und-weise",
        "antraege/{uuid}/storno",
        "/antraege/{uuid}/ruecknahme" })
    @Transactional
    void updateApiTest(final String url) {
        drvMandant.setInScope("70");
        final UUID antragUUID = createAntrag();

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID)
            .post(url).then()
            .statusCode(HttpStatus.SC_OK);

        resetAntragsStatusUndLoescheVerarbeitungsStatus(antragUUID
        );
    }

    /**
     * Test Update verarbeite Weiterleitung.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void updateVerarbeiteWeiterleitungTest() {
        drvMandant.setInScope("70");
        final UUID antragUUID = createAntrag();

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID)
            .post("/antraege/{uuid}/weiterbearbeitung-in-rvdialog").then().statusCode(200);

        resetAntragsStatusUndLoescheVerarbeitungsStatus(antragUUID
        );
    }

    /**
     * Test Update verarbeite Weiterleidung aus fehlenden Stammdaten.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void updateVerarbeiteWeiterleitungAusFehlendeStammdatenTest() {
        drvMandant.setInScope("70");
        final Antrag antrag = createAntragInStatus(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT, AufgabenArt.BESTANDSFEHLER);
        given().contentType(ContentType.JSON).pathParam("uuid", antrag.getUuid())
            .post("/antraege/{uuid}/weiterbearbeitung-in-rvdialog").then().statusCode(200);
        Antrag fertig = antragService.getAntragByUuid(antrag.getUuid());
        assertEquals(AntragStatus.STATISTIK_ABGESCHLOSSEN, fertig.getStatus());
    }

    /**
     * Erstelle Antrat in einem Status.
     *
     * @param status      der gesetzt wird.
     * @param aufgabenArt die benutzt wird
     * @return erstellter Antrag
     */
    @Transactional
    public Antrag createAntragInStatus(AntragStatus status, AufgabenArt aufgabenArt) {
        Antrag antrag = Antrag.builder().ktan("70").vsnr("02220697M981").status(status).build();
        final Aufgabe aufgabe = Aufgabe.builder().aufgabenArt(aufgabenArt).vomAufgabenId("123").transaktionId(UUID.randomUUID()).build();
        final ArrayList<Aufgabe> aufgabeListe = new ArrayList<>();
        aufgabeListe.add(aufgabe);
        antrag.setAufgaben(aufgabeListe);
        antrag = antragRepository.merge(antrag);
        antragRepository.persist(antrag);
        antragRepository.flush();
        return antrag;
    }

    /**
     * Teste dokumentenerzeugungBewilligungTest.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @Test
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void dokumentenerzeugungBewilligungTest() {
        final DokumentendatenService mock =
            Mockito.mock(DokumentendatenService.class, Mockito.CALLS_REAL_METHODS);
        Mockito.doReturn(createMockAuftragStatusDTO()).when(mock)
            .getDokumentendatenBewilligung(any(), any(), anyBoolean());
        QuarkusMock.installMockForType(mock, DokumentendatenService.class);

        drvMandant.setInScope("70");
        final UUID antragUUID = createAntrag();

        final BewilligungsdatenDto bewilligungsdatenDto = new BewilligungsdatenDto();
        bewilligungsdatenDto.setFreitextEinrichtung("Text Einrichtung");
        bewilligungsdatenDto.setFreitextVersicherter("Text Versicherter");

        given().contentType(ContentType.JSON).pathParam("uuid", antragUUID)
            .body(bewilligungsdatenDto).post("antraege/{uuid}/dokumentenerzeugung/bewilligung")
            .then().statusCode(HttpStatus.SC_OK);

    }

    private void resetAntragsStatusUndLoescheVerarbeitungsStatus(final UUID antragUUID) {
        final Antrag antrag =
            entityManager.createQuery("select a from Antrag a where uuid = :guuid", Antrag.class)
                .setParameter("guuid", antragUUID).getSingleResult();
        entityManager.merge(antrag);
        if (!antrag.getStatus().equals(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT)) {
            entityManager
                .createQuery(
                    "update Antrag antrag set antrag.status = :status where antrag.uuid = :uuid")
                .setParameter("status", AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT).setParameter("uuid", antragUUID)
                .executeUpdate();
            entityManager.merge(antrag);
        }
        entityManager.createQuery("delete from Verarbeitungsstatus");
        entityManager.merge(antrag);
    }

    private Antrag getBasicAntragMitErgebnis(final String vsnr) {
        Antrag antrag = getBasicAntrag(vsnr);
        antrag = producerTemplate.withBody(antrag).to(RouteNames.DIRECT_PRUEFE_REGELN)
            .request(Antrag.class);
        drvMandant.setInScope("70");
        return antrag;
    }

    private Antrag getBasicAntrag(final String vsnr) {
        drvMandant.setInScope("70");
        Antrag antrag =
            Antrag.builder().uuid(UUID.randomUUID()).status(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK)
                .ktan("70").vsnr(vsnr).xml(xmlAntraege.get("eAntrag_" + vsnr))
                .antragsDatum(LocalDate.now()).geburtsdatum(LocalDate.of(1977, 1, 8))
                .geburtsdatumStatus(GeburtsdatumStatus.OK).build();
        antragRepository.persistAndFlush(antrag);
        antrag = producerTemplate.withBody(antrag)
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(RouteNames.DIRECT_FETCH_STAMMDATEN).request(Antrag.class);
        antragRepository.merge(antrag);
        antragRepository.flush();
        return antrag;
    }

    private AuftragsStatusDTO createMockAuftragStatusDTO() {
        final AuftragsStatusDTO auftragsStatusDTO = new AuftragsStatusDTO();
        final AuftragsStatusDebugDTO debug = new AuftragsStatusDebugDTO();
        debug.setDiloopResponse("string");
        auftragsStatusDTO.setDebug(debug);
        auftragsStatusDTO.setStatus(AuftragsStatusDTO.StatusEnum.IN_BEARBETUNG);
        auftragsStatusDTO.setAuftragId(UUID.randomUUID());
        return auftragsStatusDTO;
    }

    @SneakyThrows
    private UUID createAntrag() {
        final PapierantragCreator papierantragCreator = new PapierantragCreator(wireMockServer, entityManager, drvMandant, latch);
        return papierantragCreator.createAntrag(TestPerson.PIPI_LANGSTRUMPF).getUuid();
    }
}
