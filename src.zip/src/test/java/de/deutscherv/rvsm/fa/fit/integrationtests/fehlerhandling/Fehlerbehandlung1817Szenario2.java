package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.testdaten.TestRehaEinrichtung;
import jakarta.persistence.EntityManager;
import java.util.concurrent.CountDownLatch;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static io.restassured.RestAssured.given;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1817">EVORVF2-1817</a>.
 * Szenario 1
 */
@Slf4j
@Getter
public class Fehlerbehandlung1817Szenario2 extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF2001";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;

    /**
     * Konstruktor.
     * @param drvMandant DRV-Mandant
     * @param producerTemplate Producertemplate
     * @param antragRepository Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer rvPuRAufgaben-Producer
     * @param entityManager Entity-Manager
     * @param latch Latch
     */
    public Fehlerbehandlung1817Szenario2(
            final DrvMandant drvMandant,
            final FluentProducerTemplate producerTemplate,
            final AntragRepository antragRepository,
            final BestandsfehlerRepository bestandsfehlerRepository,
            final PurAufgabenProducer purAufgabenProducer,
            final EntityManager entityManager,
            final CountDownLatch latch) {
        super(TestPerson.HARVEY_DENT,
                new RegressionsConfig(true, true, false));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManager = entityManager;
        this.latch = latch;
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        final PapierantragTestDatenHelper.PapierantragInput papierantragInput = new PapierantragTestDatenHelper.PapierantragInput(
                getTestPerson(),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                RandomStringUtils.insecure().nextAlphanumeric(14),
                TestRehaEinrichtung.FANTASIEKLINIK_ENGLISCHER_GARTEN,
                TestRehaEinrichtung.FANTASIEKLINIK_ENGLISCHER_GARTEN);

        final PapierantragDto papierantrag = PapierantragTestDatenHelper.erstellePapierantrag(papierantragInput);

        stubFor(get(urlPathTemplate("/konten/{versicherungsnummer}"))
                .withPathParam("versicherungsnummer", equalTo(getTestPerson().VSNR))
                .willReturn(aResponse().withStatus(500).withHeader("Content-Type", "application/json")));

        given().body(papierantrag).contentType("application/json")
                .post("/papierantraege").then().contentType("application/json")
                .statusCode(HttpStatus.SC_CREATED);

        return true;
    }

}
