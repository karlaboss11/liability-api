package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.anzeigetool.utils.MarshallerUtils;
import de.deutscherv.anzeigetool.xmldr.XmlDr;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.util.ValidationUtil;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Steuerdaten;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragArchivPdfDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import java.time.LocalDate;
import java.util.Base64;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Test PruefErgebnisServiceMock.
 */
@ExtendWith(MockitoExtension.class)
@Slf4j
class PruefergebnisServiceMockTest {

    private static final byte[] SAMPLE_PDF = "Sample PDF Data".getBytes();
    private static final LocalDate SAMPLE_DATE = LocalDate.of(2025, 2, 2);

    @Mock
    private Antragsdaten antragsdaten;

    @Mock
    private Steuerdaten steuerdaten;

    @Mock
    private XmlDr xmlDr;

    @Mock
    private MarshallerUtils marshallerUtils;

    @Mock
    private AntragPruefergebnis currentRegelPruefergebnis;

    private Antrag antrag;

    @InjectMocks
    private PruefergebnisService pruefergebnisService;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        final UUID testUuid = UUID.randomUUID();
        antrag = mock(Antrag.class);
        Mockito.lenient().when(antrag.getUuid()).thenReturn(testUuid);
        Mockito.lenient().when(antragsdaten.getSteuerdaten()).thenReturn(steuerdaten);
        Mockito.lenient().when(currentRegelPruefergebnis.getErgebnis()).thenReturn(PruefErgebnis.ERFUELLT);

        Mockito.lenient().when(antrag.getVsnr()).thenReturn("123456789");
        Mockito.lenient().when(antrag.getAntragsDatum()).thenReturn(SAMPLE_DATE);

    }

    /**
     * Test, Pruefe Antragsversion wenn das Anzeigetool Exception wirft.
     */
    @Test
    void testPruefeAntragsVersionWhenAnzeigetoolExceptionThrown() {
        // Call the method and verify it does not throw an exception
        assertDoesNotThrow(() -> ValidationUtil.pruefeAntragsVersion(antragsdaten));
    }

    /**
     * Test, achivePdf erfolgreich.
     */
    @Test
    void testArchivePdfSuccess() {
        final boolean result = AntragService.archivePdf(antrag, SAMPLE_PDF);

        // Verify expected Base64 encoding
        final String expectedBase64 = Base64.getEncoder().encodeToString(SAMPLE_PDF);
        final AntragArchivPdfDto expectedDto = new AntragArchivPdfDto();
        expectedDto.setVsnr("123456789");
        expectedDto.setAntragsdatum(SAMPLE_DATE);
        expectedDto.setPdf(expectedBase64);

        assertEquals(expectedBase64, expectedDto.getPdf());
        assertEquals("123456789", expectedDto.getVsnr());
        assertEquals(SAMPLE_DATE, expectedDto.getAntragsdatum());
        assertTrue(result);
    }

    /**
     * Test, archivePdf mit Null-Antrag, sollte Exception werfen.
     */
    @Test
    void testArchivePdfWithNullAntrag_ShouldThrowException() {
        final Exception exception = assertThrows(NullPointerException.class, () -> AntragService.archivePdf(null, SAMPLE_PDF));
        assertNotNull(exception.getMessage());
    }

    /**
     * Test, archivePdf mit Null-PdfSTream, sollte Exception werfen.
     */
    @Test
    void testArchivePdfWithNullPdfStream_ShouldThrowException() {
        final Exception exception = assertThrows(NullPointerException.class, () -> AntragService.archivePdf(antrag, null));
        assertNotNull(exception.getMessage());
    }

}
