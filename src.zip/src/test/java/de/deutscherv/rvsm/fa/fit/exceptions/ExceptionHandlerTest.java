package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.argThat;
import static org.mockito.Mockito.verify;

/**
 * Test Exceptionhandler.
 */
class ExceptionHandlerTest {

    @Mock
    private FehlerRepository fehlerRepository;

    @InjectMocks
    private ExceptionHandler exceptionHandler;

    /**
     * Vorbereitung vor jedem Test.
     */
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Test Exception - Retry.
     */
    @Test
    void testHandleExceptionForRetry() {
        final Exception exception = new Exception("Test exception message");
        final UUID uuid = UUID.randomUUID();
        final String message = "Test error message";

        exceptionHandler.handleExceptionForRetry(exception, Antrag.builder().uuid(uuid).build(), message);

        // Verify the repository persist method is called with the expected Fehler object
        verify(fehlerRepository).persist(
                argThat(fehler -> fehler.getAntragId().equals(uuid)));
    }

    /**
     * Test Exception - Nachricht Max Size.
     */
    @Test
    void testHandleExceptionNachrichtMaxSize(){
        final Exception exception = new Exception("Test exception message");
        UUID uuid = UUID.randomUUID();
        final Antrag antrag = Antrag.builder().uuid(uuid).build();
        final String message = "Error! ".repeat(1100);

        exceptionHandler.handleExceptionForRetry(exception, antrag, message);

        // Verify the repository persist method is called and the message length is not larger than 1000
        verify(fehlerRepository).persist(
                argThat(fehler -> fehler.getAntragId().equals(uuid)));
    }
}
