package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.List;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

@QuarkusTest
class PruefergebnisServiceQuarkusTest {

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private PruefergebnisService pruefergebnisService;

    @Inject
    private DrvMandant drvMandant;

    /**
     * Testet, ob der PruefergebnisService die Regelpriorität richtig setzt.
     *
     * @param regelName           der Name der Regel
     * @param erwartetePrioritaet die erwartete Priorität
     */
    @ParameterizedTest
    @Transactional
    @CsvSource({ "REGEL_BEZUGALTERSRENTE, 1", "REGEL_ANTRAGALTERSRENTE, 4",
        "REGEL_BEAMTENEIGENSCHAFT_BEZUEGE, 5", "REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT, 6",
        "REGEL_WARTEZEITPRUEFUNG, 7", "REGEL_AKTIVEBESCHAEFTIGUNG, 8", "REGEL_BEZUGEMRENTE, 9",
        "REGEL_ANTRAGEMRENTE, 10", "REGEL_LAUFENDERREHAANTRAG, 12",
        "REGEL_WIDERSPRUCHSVERFAHREN, 13", "REGEL_MASSNAHME, 14" })
    void speicherePruefergebnisSetzePrioritaet(final RegelName regelName,
        final long erwartetePrioritaet) {
        drvMandant.setInScope("17");
        final var antrag = getAntrag();
        pruefergebnisService.speicherePruefergebnis(antrag, getGesamtErgebnis(regelName));
        final var pruefergebnisse = antrag.getAntragPruefergebnisse();

        assertThat(pruefergebnisse).hasSize(2);
        assertThat(pruefergebnisse.get(1).getPrioritaet()).isEqualTo(erwartetePrioritaet);
    }

    /**
     * Testet, ob der PruefergebnisService die RegelId richtig setzt.
     *
     * @param regelName der Name der Regel
     */
    @ParameterizedTest
    @Transactional
    @ValueSource(strings = { "REGEL_BEZUGALTERSRENTE", "REGEL_ANTRAGALTERSRENTE",
        "REGEL_BEAMTENEIGENSCHAFT_BEZUEGE", "REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT",
        "REGEL_WARTEZEITPRUEFUNG", "REGEL_BEZUGEMRENTE", "REGEL_ANTRAGEMRENTE",
        "REGEL_LAUFENDERREHAANTRAG", "REGEL_WIDERSPRUCHSVERFAHREN", "REGEL_MASSNAHME" })
    void speicherePruefergebnisSetzeRegelId(final RegelName regelName) {
        drvMandant.setInScope("17");
        final var antrag = getAntrag();
        pruefergebnisService.speicherePruefergebnis(antrag, getGesamtErgebnis(regelName));
        final var pruefergebnisse = antrag.getAntragPruefergebnisse();

        assertThat(pruefergebnisse).hasSize(2);
        assertThat(pruefergebnisse.get(1).getRegelId()).isEqualTo(regelName.getId());
    }

    private RegelErgebnis getGesamtErgebnis(final RegelName regelName) {
        final var teilErgebnis = new RegelErgebnis();
        teilErgebnis.setPruefErgebnis(PruefErgebnis.ERFUELLT);
        teilErgebnis.setRegelName(regelName);
        teilErgebnis.setDetail("teilergebnis");
        final var gesamtErgebnis = new RegelErgebnis();
        gesamtErgebnis.setPruefErgebnis(PruefErgebnis.ERFUELLT);
        gesamtErgebnis.setRegelName(null);
        gesamtErgebnis.setDetail("gesamtergebnis");
        gesamtErgebnis.setDetailErgebnisse(List.of(teilErgebnis));
        return gesamtErgebnis;
    }

    /**
     * Testantrag.
     *
     * @return Antrag
     */
    private Antrag getAntrag() {
        final Antrag antrag = new Antrag();
        antrag.setVsnr("04030583T112");
        antrag.setKtan("24");
        antragRepository.persistAndFlush(antrag);
        return antrag;
    }
}
