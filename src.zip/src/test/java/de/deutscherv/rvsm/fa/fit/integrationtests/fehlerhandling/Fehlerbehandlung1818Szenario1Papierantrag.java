package de.deutscherv.rvsm.fa.fit.integrationtests.fehlerhandling;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.PurAufgabenProducer;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.RegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import io.restassured.http.ContentType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.mockito.Mockito;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Regressionstest für das Ticket zur Fehlerbehandlung
 * <a href="https://jira.service.zd.drv/browse/EVORVF2-1818">EVORVF2-1818</a>.
 * Szenario 1 (Papierantrag)
 */
@Slf4j
@Getter
public class Fehlerbehandlung1818Szenario1Papierantrag extends RegressionsTestTemplate {

    private static final String AF_STATUSCODE = "AF0075";

    private final DrvMandant drvMandant;
    private final FluentProducerTemplate producerTemplate;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final PurAufgabenProducer purAufgabenProducer;
    private final EntityManager entityManager;
    private final CountDownLatch latch;
    private final int httpCode;

    /**
     * Konstruktor.
     *
     * @param drvMandant               DRV-Mandant
     * @param producerTemplate         Producertemplate
     * @param antragRepository         Antragsrepository
     * @param bestandsfehlerRepository Bestandsfehlerrepository
     * @param purAufgabenProducer      rvPuRAufgaben-Producer
     * @param entityManager            Entity-Manager
     * @param latch                    Latch
     * @param httpCode                 HTTP-Cocde
     */
    public Fehlerbehandlung1818Szenario1Papierantrag(
        final DrvMandant drvMandant,
        final FluentProducerTemplate producerTemplate,
        final AntragRepository antragRepository,
        final BestandsfehlerRepository bestandsfehlerRepository,
        final PurAufgabenProducer purAufgabenProducer,
        final EntityManager entityManager,
        final CountDownLatch latch,
        final int httpCode) {
        super(TestPerson.HARVEY_DENT,
            new RegressionsConfig(true, true, false,
                new StatistikErfassungConfig(FehlerTyp.UNERWARTET_AF, AF_STATUSCODE, 500),
                new StatistikBescheidConfig(FehlerTyp.UNERWARTET_AF, AF_STATUSCODE, 500),
                new StammdatenConfig(null, AF_STATUSCODE, FehlerTyp.UNERWARTET_AF, httpCode),
                new KontoinformationConfig(FehlerTyp.UNERWARTET_AF, AF_STATUSCODE, 500),
                new DokumentenerzeugungConfig(true)));
        this.drvMandant = drvMandant;
        this.producerTemplate = producerTemplate;
        this.antragRepository = antragRepository;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.purAufgabenProducer = purAufgabenProducer;
        this.entityManager = entityManager;
        this.latch = latch;
        this.httpCode = httpCode;
    }

    @SneakyThrows
    @Override
    public boolean fuehreAus() {
        Mockito.clearInvocations(purAufgabenProducer);

        final AntwortDto antwortDto = given().pathParam("versicherungsnummer", getTestPerson().VSNR)
            .get("/stammdaten/{versicherungsnummer}").then()
            .contentType("application/json").statusCode(HttpStatus.SC_LOCKED)
            .extract().as(AntwortDto.class);
        assertThat(antwortDto.getCode()).isEqualTo(423);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput = new PapierantragTestDatenHelper.PapierantragInput(
            getTestPerson(),
            RandomStringUtils.insecure().nextAlphanumeric(14),
            RandomStringUtils.insecure().nextAlphanumeric(14),
            null,
            null);

        final PapierantragDto papierantrag = PapierantragTestDatenHelper.erstellePapierantrag(papierantragInput);
        papierantrag.getAntrag().setStrasse("X");
        papierantrag.getAntrag().setPlz("00000");
        papierantrag.getAntrag().setWohnort("X");
        papierantrag.getAntrag().setVorname("X");
        papierantrag.getAntrag().setNachname("X");
        papierantrag.getAntrag().setGeburtsdatum("1900-01-01");
        papierantrag.getAntrag().setVersichertenStammdaten(null);
        papierantrag.setVersicherter(new StammdatenDto(getTestPerson().VSNR));

        given().body(papierantrag).contentType("application/json")
            .post("/papierantraege/weiterbearbeitung-in-rvdialog").then()
            .statusCode(HttpStatus.SC_CREATED);

        latch.await(3, TimeUnit.SECONDS);

        Mockito.verify(purAufgabenProducer, times(1)).completeAufgabe(any());

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = entityManager.createQuery("select a from Antrag a where vorgangskennung = :vorgangsId", Antrag.class)
                .setParameter("vorgangsId", papierantrag.getVorgangsId()).getSingleResult();
            antragUuid = antrag.getUuid();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT);
            entityManager.detach(antrag);

            List<Aufgabe> aufgaben = entityManager.createQuery("select a from Aufgabe a where vomAufgabenId = :aufgabenId", Aufgabe.class)
                .setParameter("aufgabenId", papierantrag.getAufgabenId()).getResultStream().toList();
            assertThat(aufgaben).hasSize(1);
            final Aufgabe aufgabe = aufgaben.getFirst();
            assertThat(aufgabe.getDatumErledigt()).isNotNull();
            assertThat(aufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.ANTRAGSERFASSUNG);
        }

        given().contentType(ContentType.JSON).pathParam("uuid", getAntragUuid())
            .get("antraege/{uuid}/bestandsfehler").then().statusCode(HttpStatus.SC_LOCKED);

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final List<Aufgabe> aufgaben = entityManager.createQuery("select a from Aufgabe a where vomAufgabenId = :aufgabenId",
                    Aufgabe.class)
                .setParameter("aufgabenId", papierantrag.getAufgabenId()).getResultStream().toList();
            assertThat(aufgaben).hasSize(1);
            final Aufgabe aufgabe = aufgaben.getFirst();
            assertThat(aufgabe.getDatumErledigt()).isNotNull();
            assertThat(aufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.ANTRAGSERFASSUNG);
        }

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Antrag antrag = antragRepository.findByUuid(antragUuid).orElseThrow();
            assertThat(antrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);

            antrag.getAufgaben().forEach(aufgabe -> assertThat(aufgabe.getDatumErledigt()).isNotNull());

            final Verarbeitungsstatus verarbeitungsStatus = getVerarbeitungsstatus();
            assertThat(verarbeitungsStatus.getArt()).isEqualTo(Art.WEITERBEARBEITUNG_IN_RVDIALOG);

            final List<Fehler> fehlerListe = entityManager.createQuery("select f from Fehler f where antragId =: antragId", Fehler.class)
                .setParameter("antragId", antrag.getUuid())
                .getResultList();
            assertThat(fehlerListe).isEmpty();

            entityManager.detach(antrag);
        }

        return true;
    }

    private Verarbeitungsstatus getVerarbeitungsstatus() {
        final TypedQuery<Verarbeitungsstatus> query = entityManager.createQuery(
            """
                SELECT v FROM Antrag a
                LEFT JOIN Verarbeitungsstatus v on a.uuid = v.antragId
                WHERE a.uuid = :antragUuid
                """,
            Verarbeitungsstatus.class);
        query.setParameter("antragUuid", antragUuid);
        return query.getSingleResult();
    }
}
