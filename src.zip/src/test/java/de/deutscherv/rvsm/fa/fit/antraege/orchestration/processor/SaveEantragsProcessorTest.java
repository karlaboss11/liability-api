package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.hibernate.query.NativeQuery;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * Integrationstest für den SaveEantrags-Prozessor {@link SaveEantragsProccessor}.
 */
@QuarkusTest
class SaveEantragsProcessorTest extends DefaultProcessorTest {

    @Inject
    SaveEantragsProccessor saveEantragsProccesssor;

    @Test
    @Transactional
    void saveEantragTest() throws Exception {
        final NativeQuery mockQuery = Mockito.mock(NativeQuery.class);
        Number sequence = 22;
        Mockito.when(mockQuery.getSingleResult()).thenReturn(sequence);
        final Exchange exchange = getExchange();
        final Antrag antrag = setExchangeMitAntrag(exchange, null);

        saveEantragsProccesssor = new SaveEantragsProccessor(
                Mockito.mock(AntragRepository.class));
        saveEantragsProccesssor.process(exchange);
        Antrag processedAntrag = (Antrag) exchange.getMessage().getBody();

        assertEquals(antrag.getUuid(), processedAntrag.getUuid());
        assertEquals(antrag.getUuid().toString(),
                exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID));

        antrag.setUuid(null);
        saveEantragsProccesssor.process(exchange);
        processedAntrag = (Antrag) exchange.getMessage().getBody();
        assertNotNull(processedAntrag.getUuid());
    }

    private Antrag setExchangeMitAntrag(final Exchange exchange, final AntragStatus antragStatus) {
        final Antrag antrag = Antrag.builder().uuid(UUID.randomUUID()).status(antragStatus).build();
        final Message message = getMessage();
        message.setBody(antrag);
        exchange.setMessage(message);
        return antrag;
    }
}
