package de.deutscherv.rvsm.fa.fit.antraege.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypAntrag;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypFrage;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypFragefeld;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypZeile;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Steuerdaten;
import de.deutscherv.rvsm.fa.fit.einrichtungen.mapper.EinrichtungMapper;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ArtZugaenglichkeitDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.EinrichtungAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.util.XmlDoc;
import java.time.LocalDate;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test AntragMapper.
 */
@ExtendWith(MockitoExtension.class)
class AntragMapperTest {

    @Mock
    private EinrichtungMapper einrichtungMapper;

    @InjectMocks
    private AntragMapperImpl mapper;
    private final AntragMapper antragMapper = new AntragMapperImpl();

    private final RVFitXmlMarshaller marshaller = new RVFitXmlMarshaller();

    /**
     * Test Antragsdaten zu leerem Freitext.
     */
    @Test
    void antragsdatenToFreitextEmptyTest() {

        final Antragsdaten antragsdaten = new Antragsdaten();
        final Antragsdaten.Daten daten = new Antragsdaten.Daten();

        antragsdaten.setDaten(daten);

        assertThat(AntragMapper.antragsdatenToFreitext(antragsdaten)).isEmpty();
    }

    /**
     * Test Antragsdaten mit vorhandenem Freitext.
     */
    @Test
    void antragdatenToFreitextFilledTest() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var bemerkung = new KomTypFrage();
        bemerkung.setName("bemerkungenZumAntragLang");
        bemerkung.setBemerkung("bemerkung");

        final var r990 = new KomTypAntrag();
        r990.setName("r0990");
        r990.getFrage().add(bemerkung);
        daten.getAntrag().add(r990);

        assertThat(AntragMapper.antragsdatenToFreitext(antragsdaten)).isEqualTo("bemerkung");
    }

    /**
     * Test ob Bemerkung hinterlegt wird.
     */
    @Test
    void antragsdatenToFreitextBemerkungLang() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var bemerkungFeld = new KomTypFragefeld();
        bemerkungFeld.setName("bemerkungenLang");
        bemerkungFeld.setValue("bemerkung");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(bemerkungFeld);

        final var bemerkung = new KomTypFrage();
        bemerkung.setName("bemerkungenZumAntragLang");
        bemerkung.getZeile().add(zeile);

        final var r990 = new KomTypAntrag();
        r990.setName("r0990");
        r990.getFrage().add(bemerkung);
        daten.getAntrag().add(r990);

        assertThat(AntragMapper.antragsdatenToFreitext(antragsdaten)).isEqualTo("bemerkung");
    }

    /**
     * Test ob Freitextbemerkung hinterlegt wird.
     */
    @Test
    void antragsdatenToFreitextBemerkungAnFrage() {
        final Antragsdaten antragsdaten = new Antragsdaten();
        final Antragsdaten.Daten daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var frage = new KomTypFrage();
        frage.setName("test frage");
        frage.setBemerkung("bemerkung");

        final var g0180 = new KomTypAntrag();
        g0180.setIsHauptantrag(true);
        g0180.setName("g0180");
        g0180.getFrage().add(frage);
        daten.getAntrag().add(g0180);

        assertThat(AntragMapper.antragsdatenToFreitext(antragsdaten)).isEqualTo(AntragMapper.BEMERKUNG_SET_MESSAGE);
    }

    /**
     * Test ob Bemerkung für Frage EingereichteUnterlagen2 hinterlegt wird.
     */
    @Test
    void antragsdatenToFreitextangabenEingereichteUnterlagen2() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var bemerkungFeld = new KomTypFragefeld();
        bemerkungFeld.setName("anlage");
        bemerkungFeld.setValue("Test");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(bemerkungFeld);

        final var bemerkung = new KomTypFrage();
        bemerkung.setName("angabenEingereichteUnterlagen2");
        bemerkung.setBemerkung("Eine weitere Bemerkung");
        bemerkung.getZeile().add(zeile);

        final var r990 = new KomTypAntrag();
        r990.setName("r0990");
        r990.getFrage().add(bemerkung);
        daten.getAntrag().add(r990);

        final String freitext = AntragMapper.antragsdatenToFreitext(antragsdaten);
        assertThat(freitext).isEqualTo("Eine weitere Bemerkung");
    }

    /**
     * Test ob Bemerkung für Frage BemerkungenZumAntragLang und EingereichteUnterlagen2 zusammen hinterlegt wird.
     */
    @Test
    void antragsdatenToFreitextangabenEingereichteUnterlagen2UndBemerkungenZumAntragLang() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var bemerkungEingereichteUnterlagen2 = new KomTypFrage();
        bemerkungEingereichteUnterlagen2.setName("angabenEingereichteUnterlagen2");
        bemerkungEingereichteUnterlagen2.setBemerkung("Hier steht Bemerkung 2");

        final var bemerkungZumAntragLang = new KomTypFrage();
        bemerkungZumAntragLang.setName("bemerkungenZumAntragLang");
        bemerkungZumAntragLang.setBemerkung("Hier steht Bemerkung 1");

        final var r990 = new KomTypAntrag();
        r990.setName("r0990");
        r990.getFrage().add(bemerkungEingereichteUnterlagen2);
        r990.getFrage().add(bemerkungZumAntragLang);
        daten.getAntrag().add(r990);

        final String erwarteterFreitext = "Hier steht Bemerkung 1"
            + System.lineSeparator()
            + System.lineSeparator()
            + "Hier steht Bemerkung 2";

        assertThat(AntragMapper.antragsdatenToFreitext(antragsdaten)).isEqualTo(erwarteterFreitext);
    }

    /**
     * Test der Startphase.
     */
    @Test
    void setStartphaseTest() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var id = new KomTypFragefeld();
        id.setName("angebotsId");
        id.setValue("10");

        final var name = new KomTypFragefeld();
        name.setName("bezeichnung60Anbieter");
        name.setValue("anbieter name");

        final var ort = new KomTypFragefeld();
        ort.setName("ort");
        ort.setValue("anbieter ort");

        final var plz = new KomTypFragefeld();
        plz.setName("plz");
        plz.setValue("anbieter plz");

        final var strasse = new KomTypFragefeld();
        strasse.setName("strasse");
        strasse.setValue("anbieter strasse");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(id);
        zeile.getFragefeld().add(name);
        zeile.getFragefeld().add(ort);
        zeile.getFragefeld().add(plz);
        zeile.getFragefeld().add(strasse);

        final var startphase = new KomTypFrage();
        startphase.setName("vorgeseheneRehabilitationseinrichtungStartphase");
        startphase.getZeile().add(zeile);

        final var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(startphase);
        daten.getAntrag().add(g180);

        final var builder = Antrag.builder();
        AntragMapper.setAngebotStart(antragsdaten, builder);

        final var antrag = builder.build();

        assertThat(antrag.getAngebotStartSmpId()).isEqualTo(10);
        assertThat(antrag.getAngebotStartName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotStartOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotStartPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotStartStrasse()).isEqualTo("anbieter strasse");
    }

    /**
     * Test Trainingsphase.
     */
    @Test
    void setTainingsphaseTest() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var id = new KomTypFragefeld();
        id.setName("angebotsId");
        id.setValue("10");

        final var name = new KomTypFragefeld();
        name.setName("bezeichnung60Anbieter");
        name.setValue("anbieter name");

        final var ort = new KomTypFragefeld();
        ort.setName("ort");
        ort.setValue("anbieter ort");

        final var plz = new KomTypFragefeld();
        plz.setName("plz");
        plz.setValue("anbieter plz");

        final var strasse = new KomTypFragefeld();
        strasse.setName("strasse");
        strasse.setValue("anbieter strasse");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(id);
        zeile.getFragefeld().add(name);
        zeile.getFragefeld().add(ort);
        zeile.getFragefeld().add(plz);
        zeile.getFragefeld().add(strasse);

        final var startphase = new KomTypFrage();
        startphase.setName("vorgeseheneRehabilitationseinrichtungTrainingsphase");
        startphase.getZeile().add(zeile);

        final var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(startphase);
        daten.getAntrag().add(g180);

        final var builder = Antrag.builder();
        AntragMapper.setAngebotTraining(antragsdaten, builder);

        final var antrag = builder.build();

        assertThat(antrag.getAngebotTrainingSmpId()).isEqualTo(10);
        assertThat(antrag.getAngebotTrainingName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotTrainingOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotTrainingPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotTrainingStrasse()).isEqualTo("anbieter strasse");
    }

    /**
     * Test Auffrischungsphase.
     */
    @Test
    void setAuffrischungsphaseTest() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var id = new KomTypFragefeld();
        id.setName("angebotsId");
        id.setValue("10");

        final var name = new KomTypFragefeld();
        name.setName("bezeichnung60Anbieter");
        name.setValue("anbieter name");

        final var ort = new KomTypFragefeld();
        ort.setName("ort");
        ort.setValue("anbieter ort");

        final var plz = new KomTypFragefeld();
        plz.setName("plz");
        plz.setValue("anbieter plz");

        final var strasse = new KomTypFragefeld();
        strasse.setName("strasse");
        strasse.setValue("anbieter strasse");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(id);
        zeile.getFragefeld().add(name);
        zeile.getFragefeld().add(ort);
        zeile.getFragefeld().add(plz);
        zeile.getFragefeld().add(strasse);

        final var startphase = new KomTypFrage();
        startphase.setName("vorgeseheneRehabilitationseinrichtungAuffrischungsphase");
        startphase.getZeile().add(zeile);

        final var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(startphase);
        daten.getAntrag().add(g180);

        final var builder = Antrag.builder();
        AntragMapper.setAngebotAuffrischung(antragsdaten, builder);

        final var antrag = builder.build();

        assertThat(antrag.getAngebotAufSmpId()).isEqualTo(10);
        assertThat(antrag.getAngebotAufName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotAufOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotAufPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotAufStrasse()).isEqualTo("anbieter strasse");
    }

    /**
     * Testet, ob die Einrichtungsdaten zur Start-/Auffrischungsphase aus dem Antrag in das AntragDto übernommen werden (siehe
     * EVORVF1-1855).
     *
     * @param name           der Einrichtung
     * @param strasse        der Einrichtung
     * @param plz            der Einrichtung
     * @param ort            der Einrichtung
     * @param expectedOutput Erwartetes Ergebnis
     */
    @ParameterizedTest
    @CsvSource({
        "'Einrichtung ABC', 'Musterstr. 1', '12345', 'Ort', 'Einrichtung ABC, Musterstr. 1, 12345 Ort'",
        "'', 'Musterstr. 1', '12345', 'Ort', 'Musterstr. 1, 12345 Ort'",
        "'Einrichtung ABC', '', '12345', 'Ort', 'Einrichtung ABC, 12345 Ort'",
        "'', '', '12345', 'Ort', '12345 Ort'",
        "'Einrichtung ABC', 'Musterstr. 1', '', '', 'Einrichtung ABC, Musterstr. 1'",
        "'', '', '', '', ''" })
    void toDtoStartphaseTextTest(final String name, final String strasse, final String plz, final String ort, final String expectedOutput) {
        final var antrag = Antrag.builder()
            .geburtsdatum(LocalDate.now())
            .geburtsdatumStatus(GeburtsdatumStatus.OK)
            .angebotStartName(name)
            .angebotStartOrt(ort)
            .angebotStartPlz(plz)
            .angebotStartStrasse(strasse)
            .build();

        final var dto = mapper.toDto(antrag);

        assertThat(dto.getEinrichtungStartAuf()).isEqualTo(expectedOutput);
    }

    /**
     * Testet, ob die Einrichtungsdaten zur Trainingsphase aus dem Antrag in das AntragDto übernommen werden (siehe EVORVF1-1855).
     *
     * @param name           der Einrichtung
     * @param strasse        der Einrichtung
     * @param plz            der Einrichtung
     * @param ort            der Einrichtung
     * @param expectedOutput Erwartetes Ergebnis
     */
    @ParameterizedTest
    @CsvSource({
        "'Einrichtung ABC', 'Musterstr. 1', '12345', 'Ort', 'Einrichtung ABC, Musterstr. 1, 12345 Ort'",
        "'', 'Musterstr. 1', '12345', 'Ort', 'Musterstr. 1, 12345 Ort'",
        "'Einrichtung ABC', '', '12345', 'Ort', 'Einrichtung ABC, 12345 Ort'",
        "'', '', '12345', 'Ort', '12345 Ort'",
        "'Einrichtung ABC', 'Musterstr. 1', '', '', 'Einrichtung ABC, Musterstr. 1'",
        "'', '', '', '', ''" })
    void toDtoTrainingsphaseTextTest(final String name, final String strasse, final String plz, final String ort,
        final String expectedOutput) {
        final var antrag = Antrag.builder()
            .geburtsdatum(LocalDate.now())
            .geburtsdatumStatus(GeburtsdatumStatus.OK)
            .angebotTrainingName(name)
            .angebotTrainingOrt(ort)
            .angebotTrainingPlz(plz)
            .angebotTrainingStrasse(strasse)
            .build();

        final var dto = mapper.toDto(antrag);

        assertThat(dto.getEinrichtungTraining()).isEqualTo(expectedOutput);
    }

    /**
     * Testet, ob beim Mapping des Papierantrags die Einrichtungsdaten für die Angebote der Strart-, Trainings- und Auffrischungsphase
     * {@code null} sind, wenn keine Einrichtungen angegeben wurden.
     */
    @Test
    void papierantragKeineEinrichtungTest() {
        final var papierantrag = new PapierantragDto();
        final var antragDto = new AntragDto();
        antragDto.setGeburtsdatum("1970-05-02");
        papierantrag.setAntrag(antragDto);

        final var antrag = mapper.toEntity(papierantrag);

        assertThat(antrag.getAngebotStartSmpId()).isNull();
        assertThat(antrag.getAngebotStartName()).isNull();
        assertThat(antrag.getAngebotStartPlz()).isNull();
        assertThat(antrag.getAngebotStartOrt()).isNull();
        assertThat(antrag.getAngebotStartStrasse()).isNull();

        assertThat(antrag.getAngebotTrainingSmpId()).isNull();
        assertThat(antrag.getAngebotTrainingName()).isNull();
        assertThat(antrag.getAngebotTrainingPlz()).isNull();
        assertThat(antrag.getAngebotTrainingOrt()).isNull();
        assertThat(antrag.getAngebotTrainingStrasse()).isNull();

        assertThat(antrag.getAngebotAufSmpId()).isNull();
        assertThat(antrag.getAngebotAufName()).isNull();
        assertThat(antrag.getAngebotAufPlz()).isNull();
        assertThat(antrag.getAngebotAufOrt()).isNull();
        assertThat(antrag.getAngebotAufStrasse()).isNull();
    }

    /**
     * Testet, ob beim Mapping des Papierantrags die Einrichtungsdaten für das Angebot der Startphase übernommen werden.
     */
    @Test
    void papierantragStartphaseTest() {
        final var startphase = new RehaEinrichtungDto();
        final var adresse = new EinrichtungAnschriftDto();
        startphase.setSelbstmeldeportalId(1L);
        startphase.setName("anbieter name");
        adresse.setOrt("anbieter ort");
        adresse.setPlz("anbieter plz");
        adresse.setStrasse("anbieter strasse");
        adresse.setHausnummer("anbieter nr");
        startphase.setAdresse(adresse);

        final var papierantrag = new PapierantragDto();
        final var antragDto = new AntragDto();
        antragDto.setGeburtsdatum("1970-05-02");
        papierantrag.setAntrag(antragDto);
        papierantrag.setEinrichtung1(startphase);

        final var antrag = mapper.toEntity(papierantrag);

        assertThat(antrag.getAngebotStartName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotStartOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotStartPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotStartStrasse()).isEqualTo("anbieter strasse anbieter nr");
    }

    /**
     * Testet, ob beim Mapping des Papierantrags die Einrichtungsdaten für das Angebot der Trainingspahse übernommen werden.
     */
    @Test
    void papierantragTrainingsphaseTest() {
        final var trainingsphase = new RehaEinrichtungDto();
        final var adresse = new EinrichtungAnschriftDto();
        trainingsphase.setSelbstmeldeportalId(1L);
        trainingsphase.setName("anbieter name");
        adresse.setOrt("anbieter ort");
        adresse.setPlz("anbieter plz");
        adresse.setStrasse("anbieter strasse");
        adresse.setHausnummer("anbieter nr");
        trainingsphase.setAdresse(adresse);

        final var papierantrag = new PapierantragDto();
        final var antragDto = new AntragDto();
        antragDto.setGeburtsdatum("1970-05-02");
        papierantrag.setAntrag(antragDto);
        papierantrag.setEinrichtung2(trainingsphase);

        final var antrag = mapper.toEntity(papierantrag);

        assertThat(antrag.getAngebotTrainingName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotTrainingOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotTrainingPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotTrainingStrasse()).isEqualTo("anbieter strasse anbieter nr");
    }

    /**
     * Testet, ob beim Mapping des Papierantrags die Einrichtungsdaten für das Angebot der Auffrischungsphase übernommen werden.
     */
    @Test
    void papierantragAuffrischungsphaseTest() {
        final var auffrischungsphase = new RehaEinrichtungDto();
        final var adresse = new EinrichtungAnschriftDto();
        auffrischungsphase.setSelbstmeldeportalId(1L);
        auffrischungsphase.setName("anbieter name");
        adresse.setOrt("anbieter ort");
        adresse.setPlz("anbieter plz");
        adresse.setStrasse("anbieter strasse");
        adresse.setHausnummer("anbieter nr");
        auffrischungsphase.setAdresse(adresse);

        final var stammdatenDto = new StammdatenDto();
        stammdatenDto.setGeburtsdatum("1970-05-02");

        final var papierantrag = new PapierantragDto();
        final var antragDto = new AntragDto();
        antragDto.setGeburtsdatum("1970-05-02");
        papierantrag.setAntrag(antragDto);
        papierantrag.setEinrichtung1(auffrischungsphase);
        papierantrag.setVersicherter(stammdatenDto);

        final var antrag = mapper.toEntity(papierantrag);

        assertThat(antrag.getAngebotAufName()).isEqualTo("anbieter name");
        assertThat(antrag.getAngebotAufOrt()).isEqualTo("anbieter ort");
        assertThat(antrag.getAngebotAufPlz()).isEqualTo("anbieter plz");
        assertThat(antrag.getAngebotAufStrasse()).isEqualTo("anbieter strasse anbieter nr");
    }

    /**
     * Test Doppelvergabe Null.
     */
    @Test
    void doppelvergabeNullTest() {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var geburtsdatum = new KomTypFragefeld();
        geburtsdatum.setName("datumSpezial");
        geburtsdatum.setValue("01.01.1970");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(geburtsdatum);

        final var geburtsdaten = new KomTypFrage();
        geburtsdaten.setName("vGeburtsangaben");
        geburtsdaten.getZeile().add(zeile);

        final var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(geburtsdaten);

        daten.getAntrag().add(g180);

        final var steuerdaten = new Steuerdaten();
        steuerdaten.setDoppelvergabe(null);
        antragsdaten.setSteuerdaten(steuerdaten);

        final var antrag = mapper.antragsdatenToEntity(antragsdaten);

        assertThat(antrag.getDoppelvergabe()).isEqualTo(DoppelvergabeStatus.KEINE_DOPPELVERGABE);
    }

    /**
     * Test mit gesetztem Doppelvergabe-Kennzeichen und ohne Kennzeichen.
     *
     * @param doppelvergabeKennzeichen Kennzeichen
     * @param doppelvergabeStatus      erwarteter Status
     */
    @ParameterizedTest
    @CsvSource({
        "'D', 'PRUEFEN'",
        "'', 'KEINE_DOPPELVERGABE'"
    })
    void doppelvergabeEmptyTest(final String doppelvergabeKennzeichen, final String doppelvergabeStatus) {
        final var antragsdaten = new Antragsdaten();
        final var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        final var geburtsdatum = new KomTypFragefeld();
        geburtsdatum.setName("datumSpezial");
        geburtsdatum.setValue("01.01.1970");

        final var zeile = new KomTypZeile();
        zeile.getFragefeld().add(geburtsdatum);

        final var geburtsdaten = new KomTypFrage();
        geburtsdaten.setName("vGeburtsangaben");
        geburtsdaten.getZeile().add(zeile);

        final var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(geburtsdaten);

        daten.getAntrag().add(g180);

        final var steuerdaten = new Steuerdaten();
        steuerdaten.setDoppelvergabe(doppelvergabeKennzeichen);
        antragsdaten.setSteuerdaten(steuerdaten);

        final var antrag = mapper.antragsdatenToEntity(antragsdaten);

        assertThat(antrag.getDoppelvergabe()).isEqualTo(DoppelvergabeStatus.valueOf(doppelvergabeStatus));
    }

    /**
     * Die verschiedenen Varianten eines Geburtsdatums in Richtung Entity werden getestet.
     */
    @Test
    void geburtsdatumToEntityTest() {
        final AntragDto dto = new AntragDto();

        dto.setGeburtsdatum("1970-05-02");
        Antrag antrag = mapper.toEntity(dto);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 5, 2));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.OK);

        dto.setGeburtsdatum("1970-05-00");
        antrag = mapper.toEntity(dto);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 5, 1));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.TAG_NULL);

        dto.setGeburtsdatum("1970-00-00");
        antrag = mapper.toEntity(dto);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 1, 1));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.MONAT_TAG_NULL);
    }

    /**
     * Die verschiedenen Varianten eines Geburtsdatums in Richtung DTO werden getestet.
     */
    @Test
    void geburtsdatumToDtoTest() {
        final Antrag antrag = new Antrag();

        antrag.setGeburtsdatumStatus(GeburtsdatumStatus.OK);
        antrag.setGeburtsdatum(LocalDate.of(1970, 5, 2));
        AntragDto antragDto = mapper.toDto(antrag);
        assertThat(antragDto.getGeburtsdatum()).isEqualTo("1970-05-02");

        antrag.setGeburtsdatumStatus(GeburtsdatumStatus.TAG_NULL);
        antrag.setGeburtsdatum(LocalDate.of(1970, 5, 1));
        antragDto = mapper.toDto(antrag);
        assertThat(antragDto.getGeburtsdatum()).isEqualTo("1970-05-00");

        antrag.setGeburtsdatumStatus(GeburtsdatumStatus.MONAT_TAG_NULL);
        antrag.setGeburtsdatum(LocalDate.of(1970, 1, 1));
        antragDto = mapper.toDto(antrag);
        assertThat(antragDto.getGeburtsdatum()).isEqualTo("1970-00-00");

    }

    /**
     * Die verschiedenen Varianten eines Geburtsdatums eine eAntrags in Richtung Entity werden getestet.
     */
    @Test
    void antragsdatenToEntityTest() throws Exception {
        final String xml = Xml.getXmlAntrag("eAntragXmls/eAntrag_04030583T112.xml");
        final XmlDoc xmlDoc = new XmlDoc(xml);
        xmlDoc.changeNode(
            "/antragsdaten/daten/antrag/frage[@name='vGeburtsangaben']"
                + "/zeile/fragefeld[@name='datumSpezial']",
            "02.05.1970");

        Antragsdaten antragsdaten = marshaller.unmarshall(Antragsdaten.class, xmlDoc.toXmlString());
        Antrag antrag = antragMapper.antragsdatenToEntity(antragsdaten);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 5, 2));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.OK);

        xmlDoc.changeNode(
            "/antragsdaten/daten/antrag/frage[@name='vGeburtsangaben']"
                + "/zeile/fragefeld[@name='datumSpezial']",
            "00.05.1970");
        antragsdaten = marshaller.unmarshall(Antragsdaten.class, xmlDoc.toXmlString());
        antrag = antragMapper.antragsdatenToEntity(antragsdaten);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 5, 1));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.TAG_NULL);

        xmlDoc.changeNode(
            "/antragsdaten/daten/antrag/frage[@name='vGeburtsangaben']"
                + "/zeile/fragefeld[@name='datumSpezial']",
            "00.00.1970");
        antragsdaten = marshaller.unmarshall(Antragsdaten.class, xmlDoc.toXmlString());
        antrag = antragMapper.antragsdatenToEntity(antragsdaten);
        assertThat(antrag.getGeburtsdatum()).isEqualTo(LocalDate.of(1970, 1, 1));
        assertThat(antrag.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.MONAT_TAG_NULL);

    }

    /**
     * Test, eAntrag Zugaenglichkeit.
     *
     * @param id       des Fragefeldes
     * @param expected erwarteter Wert.
     */
    @ParameterizedTest
    @MethodSource("getEAntragZugaenglichkeitArgs")
    void eAntragZugaenglichkeitTest(final String id, final ArtZugaenglichkeitDto expected) {
        var antragsdaten = new Antragsdaten();
        var daten = new Antragsdaten.Daten();
        antragsdaten.setDaten(daten);

        var zugaenglichkeitFeld = new KomTypFragefeld();
        zugaenglichkeitFeld.setName("dokumentenzugang");
        zugaenglichkeitFeld.setValue(id);

        var zeile = new KomTypZeile();
        zeile.getFragefeld().add(zugaenglichkeitFeld);

        var zugaenglichkeitFrage = new KomTypFrage();
        zugaenglichkeitFrage.setName("dokumentenzugangFuerSehbehinderte");
        zugaenglichkeitFrage.getZeile().add(zeile);

        var g180 = new KomTypAntrag();
        g180.setName("g0180");
        g180.setIsHauptantrag(true);
        g180.getFrage().add(zugaenglichkeitFrage);

        daten.getAntrag().add(g180);

        var actual = AntragMapper.antragsdatenToZugaenglichkeit(antragsdaten);

        assertThat(actual).isEqualTo(expected);
    }

    private static Stream<Arguments> getEAntragZugaenglichkeitArgs() {
        return Stream.of(
            Arguments.of(null, null),
            Arguments.of("01", ArtZugaenglichkeitDto.GROSSDRUCK),
            Arguments.of("02", ArtZugaenglichkeitDto.BRAILLE_KURZSCHRIFT),
            Arguments.of("03", ArtZugaenglichkeitDto.BRAILLE_VOLLSCHRIFT),
            Arguments.of("04", ArtZugaenglichkeitDto.CD_ROM),
            Arguments.of("06", ArtZugaenglichkeitDto.HOERMEDIUM));
    }
}
