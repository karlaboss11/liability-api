package de.deutscherv.rvsm.fa.fit.antraege.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.deutscherv.rvsm.fa.fit.antraege.StammdatenMockTransformer;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.Regel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungAngebotEindeutig;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungFreiePlaetze;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungVorhandenUndIdentisch;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response.Status;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.quarkus.test.CamelQuarkusTestSupport;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.MappingRoutes.DIRECT_UNMARSHAL_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_CHECK_DOPPELVERGABE;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERFASSE_STATISTIK;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_VORGANG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_STAMMDATEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PRUEFE_REGELN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SAVE_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SETSMP_EINRICHTUNGEN;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test RegelpruefungEinrichtungen.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
class RegelpruefungEinrichtungenTest extends CamelQuarkusTestSupport {
    private static final String DIRECT_JUST_SAVEANDCHECKEANTRAG = "direct:justSaveAndCheck";
    private static WireMockServer wireMockServer;

    @Inject
    private RegelEngine regelEngine;

    @Inject
    private SelbstmeldeportalService selbstmeldeportalService;

    @Inject
    private ObjectMapper objectMapper;

    @InjectMock
    private RvPurService rvPurService;

    private Map<String, String> xmlAntraege = null;
    @Inject
    private FluentProducerTemplate producerTemplate;

    /**
     * Erstellt eine RoutesBuilder.
     *
     * @return erstellter RoutesBuilder
     */
    @Override
    protected RoutesBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                from(DIRECT_JUST_SAVEANDCHECKEANTRAG)
                    .routeId(DIRECT_JUST_SAVEANDCHECKEANTRAG)
                    .to(DIRECT_UNMARSHAL_EANTRAG)
                    .to(DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
                    .to(DIRECT_EXTRACT_MANDANT)
                    .to(DIRECT_SAVE_EANTRAG)
                    .to(DIRECT_GENERATE_VORGANGSKENNUNG)
                    .to(DIRECT_ERSTELLE_VORGANG)
                    .to(DIRECT_SETSMP_EINRICHTUNGEN)
                    .to(DIRECT_FETCH_KONTOINFORMATIONEN)
                    .to(DIRECT_ERFASSE_STATISTIK)
                    .to(DIRECT_CHECK_DOPPELVERGABE)
                    .to(DIRECT_FETCH_STAMMDATEN)
                    .to(DIRECT_PRUEFE_REGELN)
                ;
            }
        };
    }

    /**
     * Globale Testvorbereitungen.
     *
     * @throws JsonProcessingException JSON-Fehler
     */
    @BeforeAll
    @SuppressWarnings("unchecked")
    void set() throws JsonProcessingException {
        xmlAntraege =
            Xml.getXmlAntraege(Arrays.asList("eAntrag_04150370A444", "eAntrag_04220283C878",
                "eAntrag_04191094J688", "eAntrag_04211181L720", "eAntrag_04010782D919",
                "eAntrag_04200100L719", "eAntrag_04021093N590", "eAntrag_04140300W554",
                "eAntrag_04030583T112", "eAntrag_16030781H110", "eAntrag_16150480M537"));
        final List<EinrichtungResponseExtended> einrichtungenResponseExtendedAll =
            objectMapper.readValue(jsonToString("einrichtung/einrichtungen_all_extended.json"),
                new TypeReference<>() {
                });
        final String einrichtungenResponseExtendedPhase2 =
            objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream()
                .filter(
                    e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Startphase")))
                .toList());
        final String einrichtungenResponseExtendedPhase3 = objectMapper.writeValueAsString(
            einrichtungenResponseExtendedAll.stream().filter(e -> e.getAngebote().stream()
                .anyMatch(a -> a.getPhase().equals("Auffrischungsphase"))).toList());
        final String einrichtungenResponseExtendedPhase4 =
            objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream().filter(
                    e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Trainingsphase")))
                .toList());

        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(WireMockStub.PORT)
            .extensions(StammdatenMockTransformer.class));
        wireMockServer.start();
        WireMock.configureFor("localhost", wireMockServer.port());

        WireMock.stubFor(WireMock.get(WireMock.urlEqualTo("/nachderreha-api/rvfit/v2"))
            .willReturn(WireMock.aResponse().withBody("[]").withStatus(Status.OK.getStatusCode())));
        WireMock.stubFor(WireMock.get(urlPathMatching(
                "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=2)?"))
            .willReturn(WireMock.aResponse().withBody(einrichtungenResponseExtendedPhase2)
                .withHeader("Content-Type", "application/json")
                .withStatus(Status.OK.getStatusCode())));
        WireMock.stubFor(WireMock.get(urlPathMatching(
                "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=3)?"))
            .willReturn(WireMock.aResponse().withBody(einrichtungenResponseExtendedPhase3)
                .withHeader("Content-Type", "application/json")
                .withStatus(Status.OK.getStatusCode())));
        WireMock.stubFor(WireMock.get(urlPathMatching(
                "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=4)?"))
            .willReturn(WireMock.aResponse().withBody(einrichtungenResponseExtendedPhase4)
                .withHeader("Content-Type", "application/json")
                .withStatus(Status.OK.getStatusCode())));
        WireMock.stubFor(WireMock.get(urlPathMatching("/nachderreha-api/rvfit/v2/einrichtungen"))
            .willReturn(WireMock.aResponse()
                .withBody(jsonToString("einrichtung/einrichtungen_all_extended.json"))
                .withHeader("Content-Type", "application/json")
                .withStatus(Status.OK.getStatusCode())));

        WireMock.stubFor(WireMock.get(WireMock.urlPathTemplate("/konten/{vsnr}"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(WireMock.aResponse().withTransformers(StammdatenMockTransformer.NAME)));
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        Mockito.when(rvPurService.rufeRvPurSendungServiceAb(any()))
            .thenReturn(Mockito.mock(VorgangResponseDto.class));
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);

    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    @SneakyThrows
    static void tearDownAfterClass() {
        wireMockServer.stop();
    }

    private static Stream<Arguments> getEinrichtungAngebotEindeutigRegelArgs() {
        return Stream.of(
            getArgs("eAntrag_04150370A444", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN"),
            getArgs("eAntrag_04220283C878", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN"),
            getArgs("eAntrag_04191094J688", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04211181L720", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04010782D919", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN"),
            getArgs("eAntrag_04200100L719", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN"),
            getArgs("eAntrag_04021093N590", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04140300W554", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_16030781H110", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN, ""),
            getArgs("eAntrag_16150480M537", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                ""));
    }

    private static Stream<Arguments> getEinrichtungFreiePlaetzeRegelArgs() {
        return Stream.of(
            getArgs("eAntrag_04150370A444", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_KEINE_FREIE_PLAETZE"),
            getArgs("eAntrag_04220283C878", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04191094J688", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_KEINE_FREIE_PLAETZE"),
            getArgs("eAntrag_04211181L720", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04010782D919", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04021093N590", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04140300W554", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_16030781H110", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_16150480M537", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"));
    }

    /**
     * Test, Einrichtungen mit eindeutigen Regenln.
     *
     * @param eAntragXml          eAnttrag
     * @param gesamtPruefErgebnis Pruefergebnis Gesamt
     * @param regelPruefErgebnis  Pruefergebnis Regel
     * @param regelErgebnisDetail Pruefergebnis Regel Datail
     */
    @ParameterizedTest
    @MethodSource("getEinrichtungAngebotEindeutigRegelArgs")
    @Transactional
    void einrichtungAngebotEindeutigRegelTest(final String eAntragXml,
        final PruefErgebnis gesamtPruefErgebnis, final PruefErgebnis regelPruefErgebnis,
        final String regelErgebnisDetail) {
        final EinrichtungAngebotEindeutig regel = new EinrichtungAngebotEindeutig();
        doEantragXmlPruefergebnisRegelTest(eAntragXml, regel, gesamtPruefErgebnis,
            regelPruefErgebnis,
            regel.getRegelDetail(regelErgebnisDetail).orElse(regelErgebnisDetail));
    }

    private static Stream<Arguments> getEinrichtungVorhandenUndIdentischRegelParams() {
        return Stream.of(
            getArgs("eAntrag_04150370A444", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04220283C878", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04191094J688", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04211181L720", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04010782D919", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04200100L719", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04021093N590", PruefErgebnis.ERFUELLT, PruefErgebnis.ERFUELLT,
                "ERFUELLT"),
            getArgs("eAntrag_04140300W554", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_KEINE_DATEN"),
            getArgs("eAntrag_04030583T112", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_NICHT_IDENTISCH"),
            getArgs("eAntrag_16030781H110", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_KEIN_ANGEBOT"),
            getArgs("eAntrag_16150480M537", PruefErgebnis.AUSSTEUERN, PruefErgebnis.AUSSTEUERN,
                "AUSSTEUERN_KEIN_ANGEBOT"));
    }

    /**
     * Test, Einrichtung freie Plaetze Regel.
     *
     * @param eAntragXml          eAnttrag
     * @param gesamtPruefErgebnis Pruefergebnis Gesamt
     * @param regelPruefErgebnis  Pruefergebnis Regel
     * @param regelErgebnisDetail Pruefergebnis Regel Datail
     */
    @ParameterizedTest
    @MethodSource("getEinrichtungFreiePlaetzeRegelArgs")
    @Transactional
    void einrichtungFreiePlaetzeRegelTest(final String eAntragXml,
        final PruefErgebnis gesamtPruefErgebnis, final PruefErgebnis regelPruefErgebnis,
        final String regelErgebnisDetail) {
        final EinrichtungFreiePlaetze regel = new EinrichtungFreiePlaetze();
        doEantragXmlPruefergebnisRegelTest(eAntragXml, regel, gesamtPruefErgebnis,
            regelPruefErgebnis,
            regel.getRegelDetail(regelErgebnisDetail).orElse(regelErgebnisDetail));
    }

    /**
     * Test, Einrichtung vorhanden, identische Regel.
     *
     * @param eAntragXml          eAnttrag
     * @param gesamtPruefErgebnis Pruefergebnis Gesamt
     * @param regelPruefErgebnis  Pruefergebnis Regel
     * @param regelErgebnisDetail Pruefergebnis Regel Datail
     */
    @ParameterizedTest
    @MethodSource("getEinrichtungVorhandenUndIdentischRegelParams")
    @Transactional
    void einrichtungVorhandenUndIdentischRegelTest(final String eAntragXml,
        final PruefErgebnis gesamtPruefErgebnis, final PruefErgebnis regelPruefErgebnis,
        final String regelErgebnisDetail) {
        final EinrichtungVorhandenUndIdentisch regel = new EinrichtungVorhandenUndIdentisch();
        doEantragXmlPruefergebnisRegelTest(eAntragXml, regel, gesamtPruefErgebnis,
            regelPruefErgebnis,
            regel.getRegelDetail(regelErgebnisDetail).orElse(regelErgebnisDetail));
    }

    /**
     * Gets the args.
     *
     * @param eAntrag              the e antrag
     * @param gesamtPruefErgebnis  the gesamt pruef ergebnis
     * @param regelPruefErgebnis   the regel pruef ergebnis
     * @param regelErgebnisDetails the regel ergebnis detail
     * @return the args
     */
    private static Arguments getArgs(final String eAntrag, final PruefErgebnis gesamtPruefErgebnis,
        final PruefErgebnis regelPruefErgebnis, final String regelErgebnisDetails) {
        return Arguments.of(eAntrag, gesamtPruefErgebnis, regelPruefErgebnis, regelErgebnisDetails);
    }

    /**
     * Bestimmt die Einrichtung zu einer AngebotsId aus dem Selbstmeldeportal. In der Einrichtung ist nur das Angebot enthalten, das der
     * übergebenen Id entspricht.
     *
     * @param plzVersicherter PLZ der versicherten Person
     * @param angebotId       die Angebots-Id
     * @return die Einrichtung
     */
    private List<RehaEinrichtung> einrichtungenBySmpAngebotId(final String plzVersicherter, final Long angebotId) {
        final var einrichtung = selbstmeldeportalService.getEinrichtungByAngebotId(plzVersicherter, angebotId);
        einrichtung.ifPresent(e -> e.getAngebote()
            .removeIf(angebot -> !Objects.equals(angebot.getSmpAngebotId(), angebotId)));
        return einrichtung.stream().toList();
    }

    /**
     * Prüft das Gesamtergebnis und die Regel Ergebnisse eines Antrags.
     *
     * @param eAntragXml          der Antrag Xml Datei zu speichern
     * @param regel               die regel für den gespeicherte Antrag zu prüfen
     * @param gesamtPruefErgebnis das Gesamtpruefergebnis des Antrags zu prüfen
     * @param regelPruefErgebnis  das Regelpruefergebnis der eingegeben Regel zu prüfen
     * @param regelErgebnisDetail das Regelpruefergebnis Detail der eingegeben Regel zu prüfen
     */
    private void doEantragXmlPruefergebnisRegelTest(final String eAntragXml, final Regel regel,
        final PruefErgebnis gesamtPruefErgebnis, final PruefErgebnis regelPruefErgebnis,
        final String regelErgebnisDetail) {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get(eAntragXml));

        final List<RehaEinrichtung> startEinrichtungen;
        final List<RehaEinrichtung> auffrischungEinrichtungen;
        final List<RehaEinrichtung> trainingEinrichtungen;

        if (eAntrag.getAngebotStartSmpId() != null) {
            startEinrichtungen = einrichtungenBySmpAngebotId(eAntrag.getPlz(), eAntrag.getAngebotStartSmpId());
        } else {
            startEinrichtungen = EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.STARTPHASE, eAntrag),
                selbstmeldeportalService.getEinrichtungen(null, null, null, null, 2, null));
        }

        if (eAntrag.getAngebotAufSmpId() != null) {
            auffrischungEinrichtungen = einrichtungenBySmpAngebotId(eAntrag.getPlz(), eAntrag.getAngebotAufSmpId());
        } else {
            auffrischungEinrichtungen = EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.AUFFRISCHUNG, eAntrag),
                selbstmeldeportalService.getEinrichtungen(null, null, null, null, 3, null));
        }

        if (eAntrag.getAngebotTrainingSmpId() != null) {
            trainingEinrichtungen = einrichtungenBySmpAngebotId(eAntrag.getPlz(), eAntrag.getAngebotTrainingSmpId());
        } else {
            trainingEinrichtungen = EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.TRAININGSPHASE, eAntrag),
                selbstmeldeportalService.getEinrichtungen(null, null, null, null, 4, null));
        }

        final RegelKontext regelKontext = new RegelKontext(eAntrag, null, startEinrichtungen,
            auffrischungEinrichtungen, trainingEinrichtungen);
        final RegelErgebnis regelErgebnis =
            regelEngine.check(List.of(regel.getRegelName()), regelKontext);

        assertThat(regelErgebnis.getPruefErgebnis()).as(eAntrag.getXml())
            .isEqualTo(gesamtPruefErgebnis);
        assertThat(regelErgebnis.getDetail())
            .isEqualTo(RegelErgebnis.getGesamtDetail(regelPruefErgebnis));
        if (!regelErgebnisDetail.isEmpty()) {
            assertThat(regelErgebnis.getDetailErgebnisse()).extracting(RegelErgebnis::getDetail)
                .contains(regelErgebnisDetail);
        }
    }

    private Antrag saveEantrag(String xml) {
        return producerTemplate.withBody(xml).withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(DIRECT_JUST_SAVEANDCHECKEANTRAG).request(Antrag.class);
    }
}
