package de.deutscherv.rvsm.fa.fit.antraege.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.StammdatenMockTransformer;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ErrorResponseConstraintViolationsInnerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ErrorResponseDto;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierantragsPruefung;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.AntragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.PKOGenerator;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response.Status;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import org.apache.camel.FluentProducerTemplate;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Test Antragservice.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
@ActivateRequestContext
class AntragServiceTest {

    private static WireMockServer wireMockServer;
    private static StubMapping stubKontoZeugenschutz;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private AntragService antragService;
    @Inject
    private SelbstmeldeportalService selbstmeldeportalService;

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private PapierantragsPruefung papierantragsPruefung;

    @Inject
    private EntityManager entityManager;

    @Inject
    private ObjectMapper objectMapper;

    @InjectMock
    private RvPurService rvPurService;

    @InjectMock
    private RvfitLogger rvfitLogger;

    private Map<String, String> xmlAntraege = null;
    private Map<String, String> xmlAntraegeModifiziert = null;
    @Inject
    private FluentProducerTemplate producerTemplate;

    /**
     * Testvorbereitng vor jedem Test.
     */
    @BeforeEach
    void setUp() {
        entityManager = mock(EntityManager.class);
        drvMandant.setInScope("70");
    }

    /**
     * Test Lesen des Antrags mit UUID.
     */
    @Test
    @Transactional
    void getByUuid() {
        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);
        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        assertNotNull(antragService.getAntragByUuid(antrag.getUuid()));
    }

    /**
     * Test Lesen des Antrags, Konto gesperrt.
     */
    @Test
    @Transactional
    void getByUuidAntragIsLocked() {
        wireMockServer.addStubMapping(stubKontoZeugenschutz);
        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);
        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        assertThrows(KontoGesperrtException.class, () -> antragService.mapToAntragDto(antrag));
        wireMockServer.removeStub(stubKontoZeugenschutz);
    }

    /**
     * Test Lesen des Antrags mit Vorgangskennung.
     */
    @Test
    @Transactional
    void getAntragByVorgangskennung() {
        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN, "V241000134RVX1");
        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByVorgangskennung(any())).thenReturn(antrag);
        QuarkusMock.installMockForType(mock, AntragRepository.class);

        assertNotNull(antragService.getAntragByVorgangskennung("V241000134RVX1"));
    }

    /**
     * Test lesen der Vorgangskennung.
     */
    @Test
    @Transactional
    void getVorgangskennung() {
        // Mock query
        final Query mockedQuery = mock(Query.class);
        when(entityManager.createQuery(Mockito.anyString())).thenReturn(mockedQuery);
        when(mockedQuery.setMaxResults(1)).thenReturn(mockedQuery);

        // Mock result
        final String vorgangsKennung = PKOGenerator.generateVorgangskennung(PKOGenerator.Type.V,
            1, 25);
        final List<Object> mockedResult = List.of(vorgangsKennung);
        when(mockedQuery.getResultList()).thenReturn(mockedResult);

        // Call method
        final Optional<String> result = Optional.of(PKOGenerator.generateVorgangskennung(PKOGenerator.Type.V,
            1, 25));

        // Assertions
        assertEquals(Optional.of(vorgangsKennung), result);
    }

    /**
     * Globale Testvorberitung.
     *
     * @throws IOException Fehler beim Dateilesen.
     */
    @SuppressWarnings("unchecked")
    @BeforeAll
    void set() throws IOException {
        xmlAntraege = Xml.getXmlAntraege(Arrays.asList("eAntrag_24010101T236", "eAntrag_04030583T112",
            "eAntrag_24100184J787", "eAntrag_04021093N590", "eAntrag_24240370Z898",
            "eAntrag_04121282D054", "eAntrag_04220283C878", "eAntrag_04030485B213"));
        xmlAntraegeModifiziert = Xml.getXmlAntraegeModifiziert(Arrays.asList("eAntrag_04030583T112_auf17577",
            "eAntrag_04030583T112_start17575_auf17578",
            "eAntrag_04030583T112_start17575_auf17581", "eAntrag_04030583T112_start17575",
            "eAntrag_einAngebotOhneDF", "eAntrag_keinAufAngebot",
            "eAntrag_keinFreitextKeinAngebotId", "eAntrag_mehrereAngeboteMitDF",
            "eAntrag_mehrereAngebotOhneDF"));
        drvMandant.setInScope("70");
        final List<EinrichtungResponseExtended> einrichtungenResponseExtendedAll = objectMapper
            .readValue(jsonToString("einrichtung/einrichtungen_all_extended.json"),
                new TypeReference<>() {
                });
        final String einrichtungenResponseExtendedPhase2 = objectMapper.writeValueAsString(einrichtungenResponseExtendedAll.stream()
            .filter(
                e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Startphase")))
            .toList());
        final String einrichtungenResponseExtendedPhase3 = objectMapper.writeValueAsString(
            einrichtungenResponseExtendedAll.stream().filter(e -> e.getAngebote().stream()
                .anyMatch(a -> a.getPhase().equals("Auffrischungsphase"))).toList());
        final String einrichtungenResponseExtendedPhase4 = objectMapper
            .writeValueAsString(einrichtungenResponseExtendedAll.stream().filter(
                e -> e.getAngebote().stream().anyMatch(a -> a.getPhase().equals("Trainingsphase"))
            ).toList());

        // WireMock aufsetzen
        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(WireMockStub.PORT)
            .extensions(StammdatenMockTransformer.class));

        wireMockServer.start();
        configureFor("localhost", wireMockServer.port());
        stubFor(WireMock.post(WireMock.urlEqualTo("/antragsdaten/antragserfassung"))
            .willReturn(WireMock.aResponse().withStatus(Status.CREATED.getStatusCode())));
        stubFor(WireMock.get(WireMock.urlPathTemplate("/konten/{vsnr}"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(WireMock.aResponse().withTransformers(StammdatenMockTransformer.NAME)));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=2)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase2)
                    .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=3)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase3)
                    .withHeader("Content-Type", "application/json")));
        stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?(\\&phase=4)?"))
            .willReturn(
                aResponse().withStatus(200).withBody(einrichtungenResponseExtendedPhase4)
                    .withHeader("Content-Type", "application/json")));
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        stubFor(post(urlPathTemplate("/rvdialog-wartezeitabfrage"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(aResponse().withBody("""
                {
                  "vsnr": "23270152B506",
                  "wartezeit6in24m": 7,
                  "wartezeit180m": 181,
                  "wartezeitfehler": false,
                  "antragRehaMsat": "6",
                  "antragRehaArt": "21",
                  "massnahmeRehaElat": "",
                  "massnahmeRehaKobs": null,
                  "antragRenteLeat": "45",
                  "bezugRenteLeat": "45",
                  "antragRenteTlrt": "0",
                  "bezugRenteTlrt": "0",
                  "bezugRenteProzent": "",
                  "beamteneigenschaft": false,
                  "rechtsbehelfRente": false,
                  "rechtsbehelfReha": false,
                  "beschaeftigungGruppe": "110",
                  "beschaeftigungGrund": "10",
                  "beschaeftigungKobs": "2024-02-13",
                  "altersteilzeitGruppe": "113",
                  "altersteilzeitGrund": "52",
                  "altersteilzeitKobs": "2024-02-13",
                  "selbstaendigkeit": true,
                  "rvSystemFehler": [
                    {
                      "statuscode": "",
                      "message": ""
                    }
                  ],
                  "unerwarteterFehler": ""
                }
                """).withStatus(200).withHeader("Content-Type", "application/json")));
        Mockito.when(rvPurService.rufeRvPurSendungServiceAb(any()))
            .thenReturn(Mockito.mock(VorgangResponseDto.class));

        WireMockStub.stubForAzk();

        stubKontoZeugenschutz = stubFor(get(urlPathTemplate("/konten/{vsnr}"))
            .willReturn(aResponse().withBody(createErrorResponseDto(StammdatenService.ZEUGENSCHUTZ))
                .withHeader("Content-Type", "application/json")
                .withStatus(423)));
        wireMockServer.removeStub(stubKontoZeugenschutz);
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        // WireMock beenden
        wireMockServer.stop();
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrischung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragMehrereAngeboteMitDF() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_mehrereAngeboteMitDF"));
        isAntragMehrereAngeboteMitDF(eAntrag);
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungAufObjekt()));
        isEinrichtungStartAuf10022(eAntrag);
    }

    private void isAntragMehrereAngeboteMitDF(final Antrag eAntrag) {
        assertEquals("55050364D278", eAntrag.getVsnr());
        assertEquals("Testklinik Startauf mehrere Angebote mit DF", eAntrag.getAngebotStartName());
        assertEquals("Stuttgart", eAntrag.getAngebotStartOrt());
        assertEquals("70182", eAntrag.getAngebotStartPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotStartStrasse());

        assertEquals("Testklinik Startauf mehrere Angebote mit DF", eAntrag.getAngebotAufName());
        assertEquals("Stuttgart", eAntrag.getAngebotAufOrt());
        assertEquals("70182", eAntrag.getAngebotAufPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotAufStrasse());

        assertNull(eAntrag.getAngebotTrainingName());
        assertNull(eAntrag.getAngebotTrainingOrt());
        assertNull(eAntrag.getAngebotTrainingPlz());
        assertNull(eAntrag.getAngebotTrainingStrasse());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrischung nicht vorhanden.
     */
    @Test
    @Transactional
    void saveEantragKeinFreitextKeinAngebotId() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_keinFreitextKeinAngebotId"));

        isAntragKeinFreitextKeinAngebotId(eAntrag);
        assertTrue(Objects.isNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.isNull(eAntrag.getEinrichtungAufObjekt()));
    }

    private void isAntragKeinFreitextKeinAngebotId(final Antrag eAntrag) {
        assertEquals("55050364D278", eAntrag.getVsnr());

        assertNull(eAntrag.getAngebotStartName());
        assertNull(eAntrag.getAngebotStartOrt());
        assertNull(eAntrag.getAngebotStartPlz());
        assertNull(eAntrag.getAngebotStartStrasse());

        assertNull(eAntrag.getAngebotAufName());
        assertNull(eAntrag.getAngebotAufOrt());
        assertNull(eAntrag.getAngebotAufPlz());
        assertNull(eAntrag.getAngebotAufStrasse());

        assertNull(eAntrag.getAngebotTrainingName());
        assertNull(eAntrag.getAngebotTrainingOrt());
        assertNull(eAntrag.getAngebotTrainingPlz());
        assertNull(eAntrag.getAngebotTrainingStrasse());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrischung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragEinrichtungStartAuf10023() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_einAngebotOhneDF"));

        isAntragEinAngebotOhneDF(eAntrag);
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungAufObjekt()));
        isEinrichtungStartAuf10023(eAntrag);
    }

    private void isAntragEinAngebotOhneDF(final Antrag eAntrag) {
        assertEquals("04030583T112", eAntrag.getVsnr());

        assertEquals("Testklinik Startauf genau ein Angebot ohne DF",
            eAntrag.getAngebotStartName());
        assertEquals("Stuttgart", eAntrag.getAngebotStartOrt());
        assertEquals("70182", eAntrag.getAngebotStartPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotStartStrasse());

        assertEquals("Testklinik Startauf genau ein Angebot ohne DF", eAntrag.getAngebotAufName());
        assertEquals("Stuttgart", eAntrag.getAngebotAufOrt());
        assertEquals("70182", eAntrag.getAngebotAufPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotAufStrasse());

        assertEquals("Testklinik Milbertshofen am Hart", eAntrag.getAngebotTrainingName());
        assertEquals("München", eAntrag.getAngebotTrainingOrt());
        assertEquals("80937", eAntrag.getAngebotTrainingPlz());
        assertEquals("Neuherbergstraße 114", eAntrag.getAngebotTrainingStrasse());
    }

    private void isEinrichtungStartAuf10023(final Antrag eAntrag) {
        // Einrichtung Startphase
        assertEquals(10023, eAntrag.getEinrichtungStartObjekt().getSmpEinrichtungsId());
        assertEquals("A30137", eAntrag.getEinrichtungStartObjekt().getResc());
        assertEquals("Testklinik Startauf genau ein Angebot ohne DF",
            eAntrag.getEinrichtungStartObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungStartObjekt().getAngebote().size());
        assertEquals(17579L,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Startphase",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant (ganztägig)",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());

        // Einrichtung Auffrischungsphase
        assertEquals(10023, eAntrag.getEinrichtungAufObjekt().getSmpEinrichtungsId());
        assertEquals("A30137", eAntrag.getEinrichtungAufObjekt().getResc());
        assertEquals("Testklinik Startauf genau ein Angebot ohne DF",
            eAntrag.getEinrichtungAufObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungAufObjekt().getAngebote().size());
        assertEquals(17581L,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Auffrischungsphase",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("online",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Training nicht vorhanden.
     */
    @Test
    @Transactional
    void saveEantragKeinAufAngebot() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_keinAufAngebot"));
        isAntragKeinAufAngebot(eAntrag);
        assertTrue(Objects.isNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.isNull(eAntrag.getEinrichtungAufObjekt()));
    }

    private void isAntragKeinAufAngebot(final Antrag eAntrag) {
        assertEquals("55050364D278", eAntrag.getVsnr());

        assertEquals("Testklinik Startauf kein Angebot", eAntrag.getAngebotStartName());
        assertEquals("Stuttgart", eAntrag.getAngebotStartOrt());
        assertEquals("70182", eAntrag.getAngebotStartPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotStartStrasse());

        assertEquals("Testklinik Startauf kein Angebot", eAntrag.getAngebotAufName());
        assertEquals("Stuttgart", eAntrag.getAngebotAufOrt());
        assertEquals("70182", eAntrag.getAngebotAufPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotAufStrasse());

        assertNull(eAntrag.getAngebotTrainingName());
        assertNull(eAntrag.getAngebotTrainingOrt());
        assertNull(eAntrag.getAngebotTrainingPlz());
        assertNull(eAntrag.getAngebotTrainingStrasse());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrichung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragEinrichtungStartAuf10025() {
        final Antrag eAntrag = producerTemplate.withBody(xmlAntraegeModifiziert.get("eAntrag_mehrereAngebotOhneDF"))
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(DIRECT_INIT_EANTRAG).request(Antrag.class);

        isAntragMehrereAngebotOhneDF(eAntrag);
        assertTrue(Objects.isNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.isNull(eAntrag.getEinrichtungAufObjekt()));
    }

    private void isAntragMehrereAngebotOhneDF(final Antrag eAntrag) {
        assertEquals("04030583T112", eAntrag.getVsnr());

        assertEquals("Testklinik Startauf mehrere Angebote ohne DF", eAntrag.getAngebotStartName());
        assertEquals("Stuttgart", eAntrag.getAngebotStartOrt());
        assertEquals("70182", eAntrag.getAngebotStartPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotStartStrasse());

        assertEquals("Testklinik Startauf mehrere Angebote ohne DF", eAntrag.getAngebotAufName());
        assertEquals("Stuttgart", eAntrag.getAngebotAufOrt());
        assertEquals("70182", eAntrag.getAngebotAufPlz());
        assertEquals("Wilhelmsplatz 11", eAntrag.getAngebotAufStrasse());

        assertEquals("Testklinik Milbertshofen am Hart", eAntrag.getAngebotTrainingName());
        assertEquals("München", eAntrag.getAngebotTrainingOrt());
        assertEquals("80937", eAntrag.getAngebotTrainingPlz());
        assertEquals("Neuherbergstraße 114", eAntrag.getAngebotTrainingStrasse());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Training vorhanden.
     */
    @Test
    @Transactional
    void saveEantragEinrichtungStartAuf10010() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04030583T112"));

        isAntrag04030583T112(eAntrag);
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungAufObjekt()));
        isEinrichtungStartAuf10010(eAntrag);
    }

    private void isAntrag04030583T112(final Antrag eAntrag) {
        assertEquals("04030583T112", eAntrag.getVsnr());

        assertEquals("Reha am Kreuz", eAntrag.getAngebotStartName());
        assertEquals("Erfurt", eAntrag.getAngebotStartOrt());
        assertEquals("99099", eAntrag.getAngebotStartPlz());
        assertEquals("Konrad-Zuse-Straße 23", eAntrag.getAngebotStartStrasse());

        assertEquals("Reha am Kreuz", eAntrag.getAngebotAufName());
        assertEquals("Erfurt", eAntrag.getAngebotAufOrt());
        assertEquals("99099", eAntrag.getAngebotAufPlz());
        assertEquals("Konrad-Zuse-Straße 23", eAntrag.getAngebotAufStrasse());

        assertEquals("Testklinik Milbertshofen am Hart", eAntrag.getAngebotTrainingName());
        assertEquals("München", eAntrag.getAngebotTrainingOrt());
        assertEquals("80937", eAntrag.getAngebotTrainingPlz());
        assertEquals("Neuherbergstraße 114", eAntrag.getAngebotTrainingStrasse());
    }

    private void isEinrichtungStartAuf10010(final Antrag eAntrag) {
        // Einrichtung Startphase
        assertEquals(10010, eAntrag.getEinrichtungStartObjekt().getSmpEinrichtungsId());
        assertEquals("E23632", eAntrag.getEinrichtungStartObjekt().getResc());
        assertEquals("Reha am Kreuz", eAntrag.getEinrichtungStartObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungStartObjekt().getAngebote().size());
        assertEquals(17533L,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Startphase",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("stationär",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());

        // Einrichtung Auffrischungsphase
        assertEquals(10010, eAntrag.getEinrichtungAufObjekt().getSmpEinrichtungsId());
        assertEquals("E23632", eAntrag.getEinrichtungAufObjekt().getResc());
        assertEquals("Reha am Kreuz", eAntrag.getEinrichtungAufObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungAufObjekt().getAngebote().size());
        assertEquals(17535L,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Auffrischungsphase",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("stationär",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrischung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragAngebotStartSmpIdNotNull() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_04030583T112_start17575"));

        isAntrag04030583T112(eAntrag);
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungAufObjekt()));
        isEinrichtungStartAuf10022(eAntrag);
    }

    private void isEinrichtungStartAuf10022(final Antrag eAntrag) {
        // Einrichtung Startphase
        assertEquals(10022, eAntrag.getEinrichtungStartObjekt().getSmpEinrichtungsId());
        assertEquals("A30136", eAntrag.getEinrichtungStartObjekt().getResc());
        assertEquals("Testklinik Startauf mehrere Angebote mit DF",
            eAntrag.getEinrichtungStartObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungStartObjekt().getAngebote().size());
        assertEquals(17575L,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Startphase",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant (ganztägig)",
            eAntrag.getEinrichtungStartObjekt().getAngebote().getFirst().getDurchfuehrungsart());

        // Einrichtung Auffrischungsphase
        assertEquals(10022, eAntrag.getEinrichtungAufObjekt().getSmpEinrichtungsId());
        assertEquals("A30136", eAntrag.getEinrichtungAufObjekt().getResc());
        assertEquals("Testklinik Startauf mehrere Angebote mit DF",
            eAntrag.getEinrichtungAufObjekt().getName());
        assertEquals(1, eAntrag.getEinrichtungAufObjekt().getAngebote().size());
        assertEquals(17577L,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getSmpAngebotId());
        assertEquals("Auffrischungsphase",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getPhase());
        assertEquals(4,
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getFreiePlaetzeWert());
        assertEquals("Ambulant (ganztägig)",
            eAntrag.getEinrichtungAufObjekt().getAngebote().getFirst().getDurchfuehrungsart());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Auffrischung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragAngebotAufSmpIdNotNull() {

        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_04030583T112_auf17577"));

        isAntrag04030583T112(eAntrag);
        assertNull(eAntrag.getEinrichtungStartObjekt());
        assertNull(eAntrag.getEinrichtungAufObjekt());
    }

    /**
     * Test sichere eAntrag - Einrichtungen Start und Training vorhanden.
     */
    @Test
    @Transactional
    void saveEantragAngebotSucheSmpFunktioniert() {

        final Antrag eAntrag =
            saveEantrag(xmlAntraege.get("eAntrag_04220283C878"));

        assertNull(eAntrag.getEinrichtungStartObjekt());
        assertNotNull(eAntrag.getEinrichtungTrainingObjekt());
    }

    /**
     * Test sichere eAntrag - Start und Auffrischung verschiedene Einrichtungen.
     */
    @Test
    @Transactional
    void saveEantragAngebotStartAufSmpIdNotNullVerschiedeneEinrichtungen() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_04030583T112_start17575_auf17581"));

        isAntrag04030583T112(eAntrag);
        assertNull(eAntrag.getEinrichtungStartObjekt());
        assertNull(eAntrag.getEinrichtungAufObjekt());
    }

    /**
     * Test sichere eAntrag - Einrichtung vorhanden.
     */
    @Test
    @Transactional
    void saveEantragAngebotStartAufSmpIdNotNullGleichEinrichtung() {
        final Antrag eAntrag = saveEantrag(xmlAntraegeModifiziert.get("eAntrag_04030583T112_start17575_auf17578"));

        isAntrag04030583T112(eAntrag);
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungStartObjekt()));
        assertTrue(Objects.nonNull(eAntrag.getEinrichtungAufObjekt()));
        isEinrichtungStartAuf10022(eAntrag);
    }

    /**
     * Test gueltiges Angebot.
     *
     * @param smpAngebotId     ID SMP-Angebot
     * @param antragAngebotId  ID Antragsabgebot
     * @param freiePlaetzeWert Werte freie Plaetze
     * @param expected         erwartetes Ergebnis
     */
    @Transactional
    @ParameterizedTest
    @CsvSource({ "100, 100, 5, true", // Same SmpAngebotId, freiePlaetzeWert > 0 → true
        "100, 100, 0, false", // Same SmpAngebotId, freiePlaetzeWert == 0 → false
        "101, 100, 0, false", // Different ID, but freiePlaetzeWert == 0 → false
        "101, 100, 3, false", // Different ID, freiePlaetzeWert > 0 → false
    })
    void testAngebotGueltig(final Long smpAngebotId, final Long antragAngebotId,
        final Integer freiePlaetzeWert, final boolean expected) {
        final Angebot angebot = new Angebot();
        angebot.setSmpAngebotId(smpAngebotId);
        angebot.setFreiePlaetzeWert(freiePlaetzeWert);
        final boolean result = selbstmeldeportalService.angebotGueltig(angebot, antragAngebotId);
        assertEquals(expected, result);
    }

    /**
     * Test Doppelvergabe.
     */
    @Transactional
    @Test
    void testDoppelvergabe() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04121282D054"));

        assertThat(eAntrag.getStatus()).isEqualTo(AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT);
        assertThat(eAntrag.getAufgaben()).hasSize(1)
            .allMatch(aufgabe -> aufgabe.getAufgabenArt().equals(AufgabenArt.DOPPELVERGABE));
    }

    /**
     * Test Doppelvergabe Weiterverarbeitung.
     */
    @Test
    @Transactional
    void testDoppelvergabeWeiterverarbeitung() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04121282D054"));
        antragService.verarbeiteDoppelvergabe(eAntrag.getUuid());

        assertThat(eAntrag.getDoppelvergabe()).isEqualTo(DoppelvergabeStatus.WEITERVERARBEITEN);
        assertThat(eAntrag.getStatus()).isEqualTo(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);
        assertThat(eAntrag.getAufgaben())
            .hasSize(1)
            .anySatisfy(aufgabe -> {
                assertThat(aufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.DOPPELVERGABE);
                assertThat(aufgabe.getDatumErledigt()).isNotNull();
            });
    }

    /**
     * Test Doppelvergabe stornieren.
     */
    @Test
    @Transactional
    void testDoppelvergabeStornieren() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04121282D054"));

        producerTemplate
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, eAntrag.getUuid())
            .withExchangeProperty(PROPERTY_ERLEDIGUNGSART, Art.STORNO)
            .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID)
            .request();

        assertThat(eAntrag.getDoppelvergabe()).isEqualTo(DoppelvergabeStatus.STORNIEREN);
        assertThat(eAntrag.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        assertThat(eAntrag.getAufgaben()).hasSize(1)
            .allSatisfy(aufgabe -> {
                assertThat(aufgabe.getAufgabenArt()).isEqualTo(AufgabenArt.DOPPELVERGABE);
                assertThat(aufgabe.getDatumErledigt()).isNotNull();
            });
    }

    /**
     * Test Bemerkung vorhanden.
     */
    @Transactional
    @Test
    void testBemerkungVorhanden() {

        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04030485B213"));

        assertThat(eAntrag.getStatus()).isEqualTo(AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT);
        assertThat(eAntrag.getAufgaben()).hasSize(1)
            .allMatch(aufgabe -> aufgabe.getAufgabenArt().equals(AufgabenArt.BEMERKUNG_ODER_ANHANG_VORHANDEN));
    }

    /**
     * Test Fachprotokoll Storno.
     */
    @Test
    @Transactional
    void testFachprotokollEreignisStorno() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04121282D054"));

        producerTemplate
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, eAntrag.getUuid())
            .withExchangeProperty(PROPERTY_ERLEDIGUNGSART, Art.STORNO)
            .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID)
            .request();

        final ArgumentCaptor<Fachereignis> captor = ArgumentCaptor.forClass(Fachereignis.class);
        verify(rvfitLogger, atLeastOnce()).sendeFachprotokollEreignis(captor.capture());

        final List<Fachereignis> fachereignisse = captor.getAllValues();

        final Fachereignis fachereignisStorno = fachereignisse.stream()
            .filter(fachereignis -> Objects.equals(fachereignis.ereignis(), "Bearbeitung abgeschlossen"))
            .findFirst()
            .orElse(null);

        assertThat(fachereignisStorno.freitext()).isNotNull();
        assertThat(fachereignisStorno.freitext())
            .isEqualTo("Die Bearbeitung des Antrags wurde ohne Entscheidung abgeschlossen. " +
                "Grund: STORNO.");
    }

    /**
     * Test BestandsfehlerDto mit leerer Fehlerliste.
     */
    @Test
    void testeErstelleBestandsfehlerDtoLeereFehlerliste() {
        final Antrag antrag = Antrag.builder().vsnr(TestPerson.JAY_DENT.VSNR).nachname("Dent").vorname("Jay").build();
        final BestandsfehlerDto bestandsfehlerDto = antragService.erstelleBestandsfehlerDto(antrag, List.of());
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).isNull();
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNull();
        assertThat(bestandsfehlerDto.getVorname()).isEqualTo("Jay");
        assertThat(bestandsfehlerDto.getName()).isEqualTo("Dent");
        assertThat(bestandsfehlerDto.getVsnr()).isEqualTo(TestPerson.JAY_DENT.VSNR);
    }

    /**
     * Test BestandsfehlerDto AF_Fehler.
     */
    @Test
    void testeErstelleBestandsfehlerDtoAFFehler() {
        final Antrag antrag = Antrag.builder().vsnr(TestPerson.JAY_DENT.VSNR).nachname("Dent").vorname("Jay").build();
        final Bestandsfehler bestandsfehler = new Bestandsfehler();
        bestandsfehler.setBestandsfehlercode("AF0202");
        final BestandsfehlerDto bestandsfehlerDto = antragService.erstelleBestandsfehlerDto(antrag, List.of(bestandsfehler));
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).isNull();
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNotNull();
        assertThat(bestandsfehlerDto.getUnerwartererFehler().getFehlercode()).isEqualTo("AF0202");
        assertThat(bestandsfehlerDto.getVorname()).isEqualTo("Jay");
        assertThat(bestandsfehlerDto.getName()).isEqualTo("Dent");
        assertThat(bestandsfehlerDto.getVsnr()).isEqualTo(TestPerson.JAY_DENT.VSNR);
    }

    /**
     * Test ErstelleBestandsfelerDto mit FE_Fehler.
     */
    @Test
    void testeErstelleBestandsfehlerDtoFEFehler() {
        final Antrag antrag = Antrag.builder().vsnr(TestPerson.JAY_DENT.VSNR).nachname("Dent").vorname("Jay").build();

        final Bestandsfehler bestandsfehler = new Bestandsfehler();
        bestandsfehler.setBestandsfehlercode("123456");
        final BestandsfehlerDto bestandsfehlerDto = antragService.erstelleBestandsfehlerDto(antrag, List.of(bestandsfehler));
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).hasSize(1);
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes().getFirst()).isEqualTo("FE123456");
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNull();
        assertThat(bestandsfehlerDto.getVorname()).isEqualTo("Jay");
        assertThat(bestandsfehlerDto.getName()).isEqualTo("Dent");
        assertThat(bestandsfehlerDto.getVsnr()).isEqualTo(TestPerson.JAY_DENT.VSNR);
    }

    /**
     * Test Erstelle BestandsfehlerDto mit mehreren FE_Fehlern.
     */
    @Test
    void testeErstelleBestandsfehlerDtoMehrereFEFehler() {
        final Bestandsfehler ersterFehler = new Bestandsfehler();
        ersterFehler.setBestandsfehlercode("123456");

        final Bestandsfehler zweiterFehler = new Bestandsfehler();
        zweiterFehler.setBestandsfehlercode("078912");
        final Antrag antrag = Antrag.builder().vsnr(TestPerson.JAY_DENT.VSNR).nachname("Dent").vorname("Jay").build();

        final BestandsfehlerDto bestandsfehlerDto = antragService.erstelleBestandsfehlerDto(antrag,
            List.of(ersterFehler, zweiterFehler));
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).hasSize(2);
        assertThat(bestandsfehlerDto.getRvSystemFehlerCodes()).containsAll(List.of("FE123456", "FE078912"));
        assertThat(bestandsfehlerDto.getUnerwartererFehler()).isNull();
        assertThat(bestandsfehlerDto.getVorname()).isEqualTo("Jay");
        assertThat(bestandsfehlerDto.getName()).isEqualTo("Dent");
        assertThat(bestandsfehlerDto.getVsnr()).isEqualTo(TestPerson.JAY_DENT.VSNR);
    }

    /**
     * Test Erledigung auf andere Art und Weise.
     */
    @Test
    void testErledigungAufAndereArtUndWeise() {
        final Antrag eAntrag = saveEantrag(xmlAntraege.get("eAntrag_04220283C878"));
        final AntragDto antragDto = antragService.verarbeiteErledigungOhneBescheid(eAntrag.getUuid(), Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE);

        assertThat(antragDto.getStatus()).isEqualTo(AntragDto.StatusEnum.STATISTIK_ABGESCHLOSSEN);

        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusRepository.findByAntragId(eAntrag.getUuid());
        assertThat(verarbeitungsstatus).isPresent();
        assertThat(verarbeitungsstatus.get().getStatus()).isEqualTo(VerarbeitungStatus.OHNE_VERSAND_ERLEDIGT);
        assertThat(verarbeitungsstatus.get().getArt()).isEqualTo(Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE);
    }

    private static String createErrorResponseDto(final String fehler) throws JsonProcessingException {

        final ObjectMapper objectMapper = new ObjectMapper();

        final ErrorResponseDto errorResponseDto = new ErrorResponseDto();
        errorResponseDto.setErrorMessage("Hier ist der Fehler");
        final ErrorResponseConstraintViolationsInnerDto errorResponseConstraintViolationsInnerDto =
            new ErrorResponseConstraintViolationsInnerDto();
        errorResponseConstraintViolationsInnerDto.setValue(fehler);
        errorResponseDto.addConstraintViolationsItem(errorResponseConstraintViolationsInnerDto);

        return objectMapper.writeValueAsString(errorResponseDto);
    }

    private Antrag saveEantrag(String xml) {
        final var antr = producerTemplate.withBody(xml).withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID())
            .to(DIRECT_INIT_EANTRAG).request(Antrag.class);
        drvMandant.setInScope("70");
        return antragRepository.findByUuid(antr.getUuid()).orElseThrow();
    }
}
