package de.deutscherv.rvsm.fa.fit.integrationtests;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.diloop.DoeTechUserApiClient;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.util.Xml;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import java.util.UUID;
import lombok.SneakyThrows;
import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.apache.http.HttpStatus;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test eAntrag-Integration Route Init eAntrag.
 */
@QuarkusTest
class EantragIntegrationRouteInitEantragTest {

    private static WireMockServer wireMockServer;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private FluentProducerTemplate producerTemplate;

    @InjectMock
    @RestClient
    private DoeTechUserApiClient doeApiClient;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void setUpAll() {
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);
    }

    /**
     * Vorbereitung vor jedem Test.
     */
    @BeforeEach
    void setUpEach() {
        wireMockServer.resetAll();
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        WireMockStub.disconnect(wireMockServer);
    }

    /**
     * Test Anspruchspruefung - Aufabe erstellt.
     */
    @SneakyThrows
    @Test
    void anspruechspruefungAufgabeErstelltTest() {
        mockAll(TestPerson.PETER_PAN);
        final Antrag antrag =
                producerTemplate.withBody(Xml.getXmlAntrag("eAntragXmls/eAntrag_03080800B018.xml"))
                        .withHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.randomUUID()).to(DIRECT_INIT_EANTRAG)
                        .request(Antrag.class);

        assertThat(antrag.getStatus()).isEqualTo(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
    }

    /**
     * Test Anspruchspruefung - Aufabe abgeschlossen.
     */
    @SneakyThrows
    @Test
    void aufgabeAbgeschlossenTest() {
        mockAll(TestPerson.HARVEY_DENT);
        UUID uuid = UUID.randomUUID();
        AuftragsStatusDTO auftragsStatusDTO = new AuftragsStatusDTO();
        auftragsStatusDTO.setAuftragId(uuid);

        Mockito.when(doeApiClient.sendeAuftrag(Mockito.any(), Mockito.anyString()))
                .thenReturn(Response.status(HttpStatus.SC_ACCEPTED).entity(auftragsStatusDTO).build());
        final Exchange exchange =
                producerTemplate.withBody(Xml.getXmlAntrag("eAntragXmls/eAntrag_15280982D041.xml"))
                        .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid).to(DIRECT_INIT_EANTRAG)
                        .send();
        assertThat(exchange.isFailed()).isFalse();
        drvMandant.setInScope("70");
        final var antragAusDb = antragRepository.findByUuid(uuid).orElse(null);
        assertThat(antragAusDb).isNotNull();

        assertThat(antragAusDb.getStatus()).isEqualTo(antragAusDb.getStatus());
        assertThat(antragAusDb.getUuid()).isEqualTo(uuid);
        assertThat(antragAusDb.getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);

    }

    private static void mockAll(final TestPerson testPerson) {
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForRvPur();
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        WireMockStub.stubForStammdaten(testPerson);
        WireMockStub.stubForKontoinformation(testPerson);
        WireMockStub.stubForAzk();
    }
}
