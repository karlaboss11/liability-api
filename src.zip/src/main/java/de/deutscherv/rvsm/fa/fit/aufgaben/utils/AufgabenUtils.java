package de.deutscherv.rvsm.fa.fit.aufgaben.utils;

import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;

/**
 *  Hilfsmethoden für Aufgaben.
 */
public class AufgabenUtils {
    private AufgabenUtils() {
    }

    /**
     * Ermittle offene Aufgaben aus dem Antrag.
     *
     * @param antrag Antrag
     * @return Offene Aufgabe aus Antrag oder null
     */
    public static Aufgabe getOffeneAufgabeFromAntrag(Antrag antrag) {
        return antrag.getAufgaben().stream()
                .filter(aufgabe -> aufgabe.getDatumErledigt() == null)
                .findFirst()
                .orElse(null);
    }

    /**
     * Ermittle Aufagabe mit Aufgabenart aus dem Antrag.
     * @param antrag        Antrag
     * @param aufgabenArt   Aufgabenart
     * @return Aufgabe mit Aufgabenart aus Antrag oder null
     */
    public static Aufgabe getAufgabeMitAufgabenArtFromAntrag(Antrag antrag, AufgabenArt aufgabenArt) {
        return antrag.getAufgaben().stream()
                .filter(aufgabe -> aufgabe.getAufgabenArt() == aufgabenArt)
                .findFirst()
                .orElse(null);
    }
}
