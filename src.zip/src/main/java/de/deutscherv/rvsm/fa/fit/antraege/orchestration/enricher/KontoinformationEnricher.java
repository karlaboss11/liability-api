package de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationException;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.kontoinformation.KontoinformationService;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * KontoinformationEnricher.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class KontoinformationEnricher implements Processor {

    private final  KontoinformationService kontoinformationService;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final FehlerRepository fehlerRepository;
    private final RvfitLogger rvfitLogger;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        try {
            bestandsfehlerRepository.schliesseAlleBestandsfehlerZuAntrag(antrag.getUuid());

            final var kontoinformation = kontoinformationService.getKontoinformationEntity(antrag, LocalDate.now());
            if (Objects.nonNull(kontoinformation)) {
                kontoinformation.setKtan(antrag.getKtan());
            }
            if (antrag.getStatus() == AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT) {
                antrag.setStatus(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN);
            } else {
                antrag.setStatus(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
            }
            antrag.addKontoinformation(kontoinformation);
            antrag = antragRepository.merge(antrag);
            antragRepository.flush();
            exchange.getMessage().setBody(antrag);

            rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                    EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                    Ereignistext.KONTOINFORMATION_GESPEICHERT,
                    EreignisFreitext.KONTOINFORMATIONEN_GESPEICHERT,
                    null,
                    antrag,
                    null,
                    jwt,
                    drvMandant
            ));
        } catch (final KontoinformationBestandsFehlerException bestandsFehlerException) {
            FehlerEintragDto fehlerEintragDto = bestandsFehlerException.getFehlerEintragDto();
            Bestandsfehler bestandsfehler = new Bestandsfehler();
            bestandsfehler.setBestandsfehlercode(fehlerEintragDto.getStatuscode());
            bestandsfehler.setAntragId(antrag.getUuid());
            bestandsfehlerRepository.persist(bestandsfehler);

            if (antrag.getStatus() != AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT) {
                antrag.setStatus(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN);
            }

            antrag = antragRepository.merge(antrag);
            antragRepository.flush();
            exchange.getMessage().setBody(antrag);
            exchange.getMessage().setHeader(RVFitCamelHeader.KONTOINFORMATION_BESTANDSFEHELR, bestandsFehlerException);
        } catch (final KontoinformationException kontoinformationException) {
            LOG.atInfo().addArgument(kontoinformationException.getMessage()).addArgument(antrag.getUuid())
                    .log("{}: UUID [{}]");
            fehlerRepository.persistiereFehlerFuerAntrag(antrag);

            exchange.setProperty(Exchange.EXCEPTION_CAUGHT, kontoinformationException);
            exchange.setRouteStop(true);
        }

    }
}
