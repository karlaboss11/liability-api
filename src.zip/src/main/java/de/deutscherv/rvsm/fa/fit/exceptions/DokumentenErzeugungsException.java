package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * DokumentenErzeugungsException.
 */
public class DokumentenErzeugungsException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Grund des Fehlers
     */
    public DokumentenErzeugungsException(String message, Throwable cause) {
        super(message, cause);
    }

}
