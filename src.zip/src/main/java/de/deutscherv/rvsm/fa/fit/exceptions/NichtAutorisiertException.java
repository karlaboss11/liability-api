package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * Nicht-autorisiert-Exception.
 */
public class NichtAutorisiertException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param resource  Resource
     * @param userIdent User-ID
     * @param message   Fehlernachricht.
     */
    public NichtAutorisiertException(final String resource, final String userIdent,
            final String message) {
        super(resource, userIdent, message);
    }
}
