package de.deutscherv.rvsm.fa.fit.antraege.orchestration;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.verarbeitung.mapper.ArtMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentendatenService;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * VerarbeitungsService.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
@SuppressWarnings("javaarchitecture:S7091")
public class VerarbeitungsService {

    private final DokumentendatenService dokumentendatenService;

    private final AntragService antragService;

    private final ArtMapper artMapper;

    public static boolean automatischeBewilligung(@Nonnull final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream().map(AntragPruefergebnis::getErgebnis)
                .allMatch(p -> p.equals(PruefErgebnis.ERFUELLT));
    }

    public static boolean automatischeAblehnung(@Nonnull final Antrag antrag) {
        return !PruefergebnisUtils.personendatenabgleichFailed(antrag) && antrag.getAntragPruefergebnisse().stream()
                .map(AntragPruefergebnis::getErgebnis)
                .anyMatch(p -> p.equals(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN));
    }

    /**
     * Erstellt ein DokumentenklassenDto anhand der übergebenen Vorlage.
     *
     * @param vorlageEnum Vorlagenart des zu erzeugenden Dokumentes
     * @return DokumentenklasseDto
     */
    private static DokumentenklasseDto getDokumentendatenVorlage(
            final DokumentenklasseDto.VorlageEnum vorlageEnum) {
        final DokumentenklasseDto dokumentenklasseDto = new DokumentenklasseDto();
        dokumentenklasseDto.setVorlage(vorlageEnum);
        return dokumentenklasseDto;
    }

    /**
     * Verarbeite automatisch falls es eine Bewilligung oder Ablehnung ist.
     *
     * @param antrag zu verarbeitender Antrag
     */
    public void verarbeiteAutomatischFallsBewilligungOderAblehnung(final Antrag antrag) {
        if (automatischeBewilligung(antrag)) {
            verarbeiteAutomatisch(antrag, DokumentenklasseDto.VorlageEnum.BEWILLIGUNG,
                    "Automatische Bewilligung");
            if (antrag.getStatus() != AntragStatus.BESCHEID_ABGESCHLOSSEN) {
                antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
            }
        } else if (automatischeAblehnung(antrag)) {
            verarbeiteAutomatisch(antrag, DokumentenklasseDto.VorlageEnum.ABLEHNUNG,
                    "Automatische Ablehnung");
            if (antrag.getStatus() != AntragStatus.BESCHEID_ABGESCHLOSSEN) {
                antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
            }
        }

    }

    private void verarbeiteAutomatisch(final Antrag antrag,
            final DokumentenklasseDto.VorlageEnum vorlageEnum, final String meldung) {
        final AuftragsStatusDTO auftragsStatusDTO = sendeDokument(antrag, vorlageEnum);
        verarbeiteVersandergebnis(antrag, vorlageEnum, meldung, auftragsStatusDTO);
    }

    private void verarbeiteVersandergebnis(final Antrag antrag, final DokumentenklasseDto.VorlageEnum vorlageEnum,
            final String meldung, final AuftragsStatusDTO auftragsStatusDTO) {
        final VersandErgebnisDto versandErgebnisDto = new VersandErgebnisDto();
        versandErgebnisDto.setAuftragId(auftragsStatusDTO.getAuftragId());
        versandErgebnisDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);
        versandErgebnisDto.setMeldung(meldung);

        antragService.verarbeiteMitVersandergebnis(antrag.getUuid(), versandErgebnisDto,
                artMapper.toArt(vorlageEnum));
    }

    private AuftragsStatusDTO sendeDokument(final Antrag antrag,
            final DokumentenklasseDto.VorlageEnum vorlage) {
        return switch (vorlage) {
            case BEWILLIGUNG -> {
                final BewilligungsdatenDto bewilligungsdatenDto = new BewilligungsdatenDto();
                bewilligungsdatenDto.setFreitextEinrichtung("");
                bewilligungsdatenDto.setFreitextVersicherter("");
                yield dokumentendatenService.getDokumentendatenBewilligung(antrag,
                        bewilligungsdatenDto, true);
            }
            case ABLEHNUNG, SACHVERHALTSAUFKLAERUNG -> dokumentendatenService
                    .getDokumentendaten(antrag, getDokumentendatenVorlage(vorlage), true);
        };
    }
}
