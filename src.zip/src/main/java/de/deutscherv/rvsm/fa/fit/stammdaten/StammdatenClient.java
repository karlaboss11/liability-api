package de.deutscherv.rvsm.fa.fit.stammdaten;

import de.deutscherv.rvsm.fa.fit.openapi.api.KontenApi;
import de.deutscherv.rvsm.fa.fit.security.JwtOidcFilter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Interface StammdatenClient.
 */
@ApplicationScoped
@RegisterRestClient(configKey = "personendaten")
@RegisterProvider(JwtOidcFilter.class)
@Path("/konten/{versicherungsnummer}")
public interface StammdatenClient extends KontenApi {

    @Override
    @GET
    @Produces({ "application/json", "application/problem+json" })
    Response getKonto(@PathParam("versicherungsnummer") @Size(min = 11, max = 12) String vsnr,
            @HeaderParam("drv-mandant") @Parameter(description = "KTAN des Traegers") @Size(min = 2, max = 2) String ktan);

}
