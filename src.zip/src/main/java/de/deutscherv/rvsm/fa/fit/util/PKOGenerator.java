package de.deutscherv.rvsm.fa.fit.util;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Generiere Vorgangskennung.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class PKOGenerator {

    private static final String BUSINESS_DIVISION = "RV";
    private static final String PRODUCER_CODE = "32";

    /**
     * Typen der Vorgangskennung.
     */
    public enum Type {
        /**
         * Typ V.
         */
        V,
        /**
         * Typ A.
         */
        A,
        /**
         * Type U.
         */
        U,
        /**
         * Typ W.
         */
        W
    }

    /**
     * Neue Vorgangskennung erstellen.
     * @param type Type der Vorgangskennung
     * @param nextSeq Nummer
     * @param currentYear laufendes Jahr
     * @return erstellte Kennung
     */
    public static String generateVorgangskennung(final Type type,
            final int nextSeq, final int currentYear) {

        return type + String.format("%02d", currentYear)
                + String.format("%07d", nextSeq) + BUSINESS_DIVISION + PRODUCER_CODE;
    }
}