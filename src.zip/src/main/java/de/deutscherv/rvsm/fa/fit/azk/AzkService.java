package de.deutscherv.rvsm.fa.fit.azk;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.azk.openapi.model.PruefungRequestDto;
import de.deutscherv.rvsm.fa.fit.azk.openapi.model.PruefungResponseDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 * Service für die Azk Schnittstelle. Beinhaltet Methoden zur Zugriffsprüfung von Anträgen.
 *
 * @author U38322
 */
@Slf4j
@ApplicationScoped
public class AzkService {

    /**
     * Text SERVERFEHLER.
     */
    public static final String SERVERFEHLER = "AZK - Serverfehler ";

    private final boolean disableAzk;
    private final AzkClient azkClient;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final JsonWebToken jwt;
    private final AntragRepository antragRepository;

    /**
     * Konstruktor.
     *
     * @param disableAzk               true wenn AKZ Disabled ist.
     * @param azkClient                AzkClient
     * @param rVFitJsonSchemaValidator rvFitJsonSchema-Validator
     * @param jwt                      JSON-Web-Tocken
     * @param antragRepository         Antrag-Repository.
     */
    @Inject
    public AzkService(@ConfigProperty(name = "azk.disabled", defaultValue = "false") final boolean disableAzk,
        @RestClient final AzkClient azkClient,
        final RVFitJsonSchemaValidator rVFitJsonSchemaValidator, final JsonWebToken jwt,
        final AntragRepository antragRepository) {
        this.disableAzk = disableAzk;
        this.azkClient = azkClient;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.jwt = jwt;
        this.antragRepository = antragRepository;
    }

    /**
     * Prüft den Zugriff auf einen Antrag anhand seiner UUID.
     *
     * @param antragUuid die Uuid des Antrags
     * @throws AzkException             wenn die Berechtigung nich geprüft werden konnte oder keine Berechtigung vorligt
     * @throws IllegalArgumentException wenn die Azk Schnittstelle keine Valide antwort leifert
     */
    @Transactional
    public void pruefeZugriff(final UUID antragUuid) {
        antragRepository.findByUuid(antragUuid)
            .filter(antrag -> antrag.getAtad() != null)
            .ifPresent(this::pruefeZugriff);
    }

    /**
     * Prüft den Zugriff auf einen Antrag.
     *
     * @param antrag der Antrag
     * @throws AzkException             wenn die Berechtigung nich geprüft werden konnte oder keine Berechtigung vorligt
     * @throws IllegalArgumentException wenn die Azk Schnittstelle keine Valide antwort leifert
     */
    public void pruefeZugriff(final Antrag antrag) {
        if (disableAzk) {
            return;
        }

        final String drvId = JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt);
        LOG.atDebug().addArgument(antrag.getUuid()).addArgument(drvId)
            .log("Pruefe zugriff auf Antrag mit UUID [{}] für DrvId [{}]");

        final String atad = "%04d".formatted(antrag.getAtad());

        final var azkRequest = new PruefungRequestDto()
            .atad(atad)
            .drvid(drvId)
            .zkgruppe("71")
            .versicherungsnummer(antrag.getVsnr());

        try (final Response response = azkClient.pruefeATAD(antrag.getKtan(), azkRequest)) {
            if (response.getStatus() != Status.OK.getStatusCode()) {
                LOG.atError().addArgument(azkRequest)
                    .log("########### PruefungRequestDto [{}]");
                LOG.atError().addArgument(response::getStatus).addArgument(antrag::getKtan)
                    .addArgument(antrag::getVsnr).addArgument(antrag::getUuid).log(
                        "Serverfehler bei Azk Pruefung. Serverstatus: [{}], Ktan [{}], Vsnr [{}], UUID [{}]");
                throw new AzkException(SERVERFEHLER + response.getStatus());
            }

            final var azkResponse = response.readEntity(PruefungResponseDto.class);
            if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.AZK,
                azkResponse)) {
                throw new IllegalArgumentException("Keine valide Azk Antwort angegeben: " + azkResponse);
            }

            if (Boolean.FALSE.equals(azkResponse.getBerechtigung())) {
                throw new AzkException("Keine Zugriffsberechtigung vorhanden");
            }
        } catch (WebApplicationException e) {
            LOG.atError().addArgument(azkRequest)
                .log("########### PruefungRequestDto [{}]");
            LOG.atError().addArgument(e::getMessage).addArgument(antrag::getKtan)
                .addArgument(antrag::getVsnr).addArgument(antrag::getUuid).log(
                    "Serverfehler bei Azk Pruefung. Exceptionmeldung: [{}], Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new AzkException(SERVERFEHLER + e.getMessage(), e);
        }
    }

}
