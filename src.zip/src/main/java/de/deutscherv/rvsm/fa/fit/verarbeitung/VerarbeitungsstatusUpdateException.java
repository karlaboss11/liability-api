package de.deutscherv.rvsm.fa.fit.verarbeitung;

import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;

/**
 * Wird geworfen, falls der Verfarbeitungsstatus nicht geupdatet werden kann.
 */
public class VerarbeitungsstatusUpdateException extends RvfitException {

    /**
     * Konstruktor.
     *
     * @param cause Fehlergrund
     */
    public VerarbeitungsstatusUpdateException(final Throwable cause) {
        super(cause);
    }

}
