/**
 * Beinhaltet Mapper für JPA Entities und DTOs für die rvPuR-Anbindung.
 */
package de.deutscherv.rvsm.fa.fit.rvpur.mapper;
