package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor um den Status Verarbeitung ohne Versand zu setzen.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class ErstelleVerarbeitungsStatusErledigungOhneBescheidProcessor implements Processor {

    private final VerarbeitungsstatusService verarbeitungsstatusService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        final Art erledigungsArt = exchange.getMessage().getHeader(RVFitCamelHeader.ERLEDIGUNG_OHNE_BESCHEID_ART,
                Art.class);
        final Verarbeitungsstatus verarbeitungsstatus = verarbeitungsstatusService
                .saveVerarbeitungsstatusOhneVersand(antrag.getUuid(), erledigungsArt);

        LOG.atDebug().addArgument(verarbeitungsstatus.getStatus())
                .addArgument(verarbeitungsstatus.getArt())
                .addArgument(antrag.getKtan())
                .addArgument(antrag.getUuid())
                .addArgument(antrag.getVsnr())
                .addArgument(antrag.getVorgangskennung())
                .log("Verarbeitung für einen Antrag wurde zur Erledigung ohne Bescheid gesetzt. Status [{}] Art [{}]"
                        + " KTAN [{}] UUID [{}] VSNR [{}] VOGID [{}]");
    }
}
