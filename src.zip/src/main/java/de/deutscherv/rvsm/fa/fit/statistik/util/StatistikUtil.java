package de.deutscherv.rvsm.fa.fit.statistik.util;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.exceptions.BestandsfehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.StatistikBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.DatenphaseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.KopfDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestFesterTeilDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestVariablerTeilAntragserfassungDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestVariablerTeilBescheidDto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

import static de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService.AF_FEHLER_SCHUTZBEDARF;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ABLEHNUNG_AUS_SONSTIGEN_GRUENDEN;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ALTERSRENTE_VON_23_DER_VOLLRENTE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.AT731_TAGE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.AT731_WOCHE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.AUFFRISCHUNGSPHASE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.BEAT_EANTRAG_MIT_AUSSTEUERUNG;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.BEAT_EANTRAG_OHNE_AUSSTEUERUNG;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.BEAT_PAPIERANTRAG;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.DF_AMBULANT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.DF_GANZTAEGIG_AMBULANT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.KEIN_ZUKUNFTSOFFENER_AUSLANDSTITEL;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSANWARTSCHAFT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSBEZUEGEN;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.MTEP_ERFUELLT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.MTEP_NICHT_ERFUELLT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.MTEP_STORNO;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.RUECKNAHME_DES_ANTRAGS_VOR_ENTSCHEIDUNG;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.STARTPHASE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.TRAININGSPHASE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.VERSICHERUNGSRECHTLICHE_VORAUSSETZUNGEN_NICHT_ERFUELLT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ZGAT_STATIONAER;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ZKBY_FRISTGERECHT_GEPRUEFT;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.ZKPY_SONSTIGE_GRUENDE;
import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.ATAD;
import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.DA731;
import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.MSNR;
import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.ZLHBTG;

/**
 * Util-Klasse Statistik.
 */
@Slf4j
public class StatistikUtil {

    private StatistikUtil() {}
    
    /**
     * Ermittelt die Durchfuehrungsart (DF) einer Rehaeinrichtung. werden, welche davon relevant ist? Aktuell wird 1.Treffer ermittel und
     * die Durchführungsart dort ausgelesen
     *
     * @param rehaEinrichtung die gelesen wird
     * @param phase           betroffene Phase
     * @return ermittelte Durchfuehrungsart (Schluessel)
     */
    public static String getDF(final RehaEinrichtung rehaEinrichtung, final String phase) {
        if (rehaEinrichtung == null) {
            return "0";
        }

        final Angebot erstesAngebot = rehaEinrichtung.getAngebote().stream().filter(
            angebot -> angebot.getPhase().equalsIgnoreCase(phase)).toList().getFirst();
        final PhaseEnumDto phaseErstesAngebot =
            StatistikUtil.getPhaseEnumFuerStringBezeichner(erstesAngebot.getPhase());

        return Optional.of(erstesAngebot).map(Angebot::getDurchfuehrungsart)
            .map(DurchfuehrungsArt::fuerBezeichnung).orElse(DurchfuehrungsArt.KEINE)
            .getZahlWert(phaseErstesAngebot);
    }

    /**
     * Fester Teil der Nachricht wird erstellt.
     *
     * @param pnr PNR
     * @return erstellter Nachrichtenteil
     */
    public static RequestFesterTeilDto createFesterTeil(final StatistikTyp pnr) {
        final RequestFesterTeilDto requestFesterTeilDto = new RequestFesterTeilDto();

        requestFesterTeilDto.setPNR(pnr.getPnrWert());
        requestFesterTeilDto.setSUSY("RHFIT");
        requestFesterTeilDto.setDATENBANK(Collections.nCopies(20, ""));

        return requestFesterTeilDto;
    }

    /**
     * Ermittelt den String für MTEP (Kennzeichen) für den Statistiksatz.
     *
     * @param verarbeitungsart           Art der Verarbeitung
     * @param pruefergebnis              Prüfergebnis
     * @param erledigungVorRegelPruefung der Antrag wurde vor Regelprüfung erledigt
     * @return String Kennzeichen
     */
    static String ermittleMTEP(final Art verarbeitungsart, final boolean pruefergebnis, final boolean erledigungVorRegelPruefung) {
        if (verarbeitungsart == Art.STORNO) {
            return MTEP_STORNO;
        }

        if (erledigungVorRegelPruefung
            || verarbeitungsart == Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE
            || verarbeitungsart == Art.RUECKNAHME) {
            return MTEP_NICHT_ERFUELLT;
        }

        if (pruefergebnis) {
            return MTEP_ERFUELLT;
        }

        return MTEP_NICHT_ERFUELLT;
    }

    /**
     * Ermittelt die Textnummer (TXNR) für den Statistiksatz.
     *
     * @param verarbeitungsart        Art der Verarbeitung
     * @param isPruefergebnisErfuellt boolean des Prüfergebnisses
     * @param antrag                  Antrag
     * @return String Textnummer (TXNR)
     */
    static String ermittleTXNR(final Art verarbeitungsart, final boolean isPruefergebnisErfuellt,
        final Antrag antrag) throws StatistikException {
        if (verarbeitungsart == Art.STORNO) {
            return "000";
        }

        if (verarbeitungsart == Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE) {
            return ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE;
        }

        if (verarbeitungsart == Art.RUECKNAHME) {
            return RUECKNAHME_DES_ANTRAGS_VOR_ENTSCHEIDUNG;
        }

        if (isPruefergebnisErfuellt) {
            return null;
        }

        return getAuspraegungPruefergebnis(antrag);
    }

    /***
     * Ermittelt das Erledigungsdatum (DTEL) des rvFit Antrages für die Statistik.
     *
     * @param antrag rvFit-Antrag
     * @param verarbeitungsart Art der Verarbeitung
     * @return Erledigungsdatum (DTEL)
     */
    static LocalDate ermittleDTEL(final Antrag antrag, final Art verarbeitungsart) {
        // Bei STORNO wird immer das aktuelle Datum gesetzt
        if (verarbeitungsart.equals(Art.STORNO)) {
            return LocalDate.now();
        }

        // Wenn kein Bescheiddatum vorhanden ist wird DTEL auf das akutelle Datum gesetzt
        if (antrag.getBescheiddatum() == null) {
            return LocalDate.now();
        }

        return antrag.getBescheiddatum();
    }

    /**
     * Ermittelt den Zahlungsgrund (ZGAT) für die Statistik.
     *
     * @param verarbeitungsart Art der Verarbeitung
     * @return Zahlungsgrund (ZGAT)
     */
    static String ermittleZGAT(final Art verarbeitungsart) {
        if (verarbeitungsart == Art.BEWILLIGUNG) {
            return ZGAT_STATIONAER;
        }

        return null;
    }

    /**
     * Notwendige Felder fuer den Kopfteil der Nachricht wirden erstellt.
     *
     * @param antrag betroffener Antrag
     * @return erstellter Nachrichtenteil
     */
    public static KopfDto createKopf(final Antrag antrag) {
        final KopfDto kopfDto = new KopfDto();
        kopfDto.setVsnr(antrag.getVsnr());

        return kopfDto;
    }

    /**
     * Ermittelt welche Auspraegung fuer das Pruefergebnis geliefert werden soll. Ist nur fuer die Junit-Test als public deklariert.
     *
     * @param antrag betroffener Antrat
     * @return ermittele Auspraegung
     * @throws StatistikException Fehler bei den Pruefergebnissen
     */
    public static String getAuspraegungPruefergebnis(final Antrag antrag)
        throws StatistikException {
        final Optional<AntragPruefergebnis> antragPruefergebnis = getActivePruefergebnise(antrag).stream()
            .filter(p -> (p.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN
                || p.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN)
                && p.getPrioritaet() != null)
            .min(Comparator.comparing(AntragPruefergebnis::getPrioritaet));

        if (antragPruefergebnis.isEmpty()) {
            LOG.atWarn().addArgument(antrag.getKtan()).addArgument(antrag.getVsnr())
                .addArgument(antrag.getUuid())
                .log("Kein Pruefergebnis enthalten im Antrag. Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new StatistikException(
                "Kein Pruefergebnis enthalten in Antrag [" + antrag.getUuid() + " ]");
        }

        return switch (antragPruefergebnis.get().getRegelName()) {
            case REGEL_STAATSANGEHOERIGKEIT, REGEL_AUFENTHALT -> KEIN_ZUKUNFTSOFFENER_AUSLANDSTITEL;
            case REGEL_BEZUGALTERSRENTE, REGEL_ANTRAGALTERSRENTE -> ALTERSRENTE_VON_23_DER_VOLLRENTE;
            case REGEL_BEAMTENEIGENSCHAFT_BEZUEGE -> LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSBEZUEGEN;
            case REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT -> LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSANWARTSCHAFT;
            case REGEL_WARTEZEITPRUEFUNG -> VERSICHERUNGSRECHTLICHE_VORAUSSETZUNGEN_NICHT_ERFUELLT;
            case REGEL_AKTIVEBESCHAEFTIGUNG, REGEL_BEZUGEMRENTE, REGEL_ANTRAGEMRENTE, REGEL_MASSNAHME,
                REGEL_ALTERSTEILZEIT, REGEL_WIDERSPRUCHSVERFAHREN, REGEL_LAUFENDERREHAANTRAG -> ABLEHNUNG_AUS_SONSTIGEN_GRUENDEN;
            default -> {
                LOG.atWarn().addArgument(antragPruefergebnis.get().getRegelName())
                    .addArgument(antrag.getKtan()).addArgument(antrag.getVsnr())
                    .addArgument(antrag.getUuid()).log(
                        "Unbekanntes Pruefergebnis im Antrag. Pruefergebnis [{}], Ktan [{}], Vsnr [{}], UUID [{}]");
                throw new StatistikException(
                    "Unbekanntes Pruefergebnis [" + antragPruefergebnis.get().getRegelName()
                        + "] in Antrag [" + antrag.getUuid() + " ]");
            }
        };
    }

    /**
     * Der variable Teil der Nachricht fuer den Bescheid wird erzeugt. Ist nur fuer die Junit-Test als public deklariert.
     *
     * @param antrag                     betroffener Antrag
     * @param verarbeitungsart           die Vearbeitungsart
     * @param erledigungVorRegelPruefung true wenn die Erledigung vor der Regelpruefung erfolgt
     * @return erstellter variabler Nachrichtenteil
     * @throws StatistikException Fehler in der Verarbeitung
     */
    public static RequestVariablerTeilBescheidDto createRequestVariablerTeilBescheid(
        final Antrag antrag, final Art verarbeitungsart, final boolean erledigungVorRegelPruefung) throws StatistikException {
        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            new RequestVariablerTeilBescheidDto();
        requestVariablerTeilBescheidDto.setMSNR(MSNR.format(antrag.getMsnr()));
        requestVariablerTeilBescheidDto.setATAD(ATAD.format(antrag.getAtad()));
        requestVariablerTeilBescheidDto.setDTAQ(antrag.getAntragsDatum());

        requestVariablerTeilBescheidDto.setDTEL(ermittleDTEL(antrag, verarbeitungsart));

        final LocalDate eqdt14 = antrag.getEingangsdatum();
        requestVariablerTeilBescheidDto.setEQDT14(eqdt14);

        final boolean isAusgesteuert = antrag.getAntragPruefergebnisse().stream()
            .anyMatch((p -> p.getErgebnis() == PruefErgebnis.AUSSTEUERN
                || p.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN));
        if (isAusgesteuert || erledigungVorRegelPruefung) {
            requestVariablerTeilBescheidDto.setBEAT(BEAT_EANTRAG_MIT_AUSSTEUERUNG);
        } else {
            requestVariablerTeilBescheidDto.setBEAT(BEAT_EANTRAG_OHNE_AUSSTEUERUNG);
        }
        final LocalDate zkdt = getZkdt(antrag);

        requestVariablerTeilBescheidDto.setZKDT(zkdt);
        requestVariablerTeilBescheidDto.setZKPY(eqdt14.plusDays(14).isBefore(zkdt)
            ? ZKPY_SONSTIGE_GRUENDE : ZKBY_FRISTGERECHT_GEPRUEFT);

        final List<AntragPruefergebnis> activeAntragPruefergebnise = getActivePruefergebnise(antrag);

        final boolean isPruefergebnisErfuellt = activeAntragPruefergebnise.stream()
            .allMatch(p -> p.getErgebnis() == PruefErgebnis.ERFUELLT);

        requestVariablerTeilBescheidDto
            .setTXNR(ermittleTXNR(verarbeitungsart, isPruefergebnisErfuellt, antrag));
        requestVariablerTeilBescheidDto
            .setMTEP(ermittleMTEP(verarbeitungsart, isPruefergebnisErfuellt, erledigungVorRegelPruefung));
        final DatenphaseDto startDatenphaseDto = createDatenphaseStart(antrag);

        if (verarbeitungsart.equals(Art.BEWILLIGUNG)) {
            final DatenphaseDto trainingDatenphaseDto = createDatenphaseTraining(antrag);
            final DatenphaseDto auffrischungDatenphaseDto = createDatenphaseAuffrischung(antrag);
            requestVariablerTeilBescheidDto.setDATENPHASE(
                List.of(startDatenphaseDto, trainingDatenphaseDto, auffrischungDatenphaseDto));

            return requestVariablerTeilBescheidDto;
        }

        requestVariablerTeilBescheidDto.setDATENPHASE(List.of(startDatenphaseDto));
        return requestVariablerTeilBescheidDto;

    }

    /**
     * List das Feld ZKDT aus dem Papierantrag.
     *
     * @param antrag Antrag, der ausgelesen wird.
     * @return ermitteltes ZDK´T
     */
    private static LocalDate getZkdt(final Antrag antrag) {
        final LocalDate zkdt;
        if (antrag.getAntragsart() == AntragsArt.PAPIERANTRAG) {
            zkdt = Optional.of(antrag).map(Antrag::getCreated).map(LocalDateTime::toLocalDate)
                .orElseGet(antrag::getEingangsdatum);
        } else {
            zkdt = antrag.getEingangsdatum();
        }
        return zkdt;
    }

    /**
     * Der variable Teil der Nachricht fuer die Antragserfassung wird erzeugt.
     *
     * @param antrag betroffener Antrag A
     * @return erstellter variabler Nachrichtenteil
     */
    public static RequestVariablerTeilAntragserfassungDto createRequestVariablerTeilAntragserfassungDto(
        final Antrag antrag) {
        final RequestVariablerTeilAntragserfassungDto requestVariablerTeilAntragserfassungDto =
            new RequestVariablerTeilAntragserfassungDto();
        requestVariablerTeilAntragserfassungDto
            .setBEAT(antrag.getAntragsart() == AntragsArt.PAPIERANTRAG ? BEAT_PAPIERANTRAG
                : BEAT_EANTRAG_OHNE_AUSSTEUERUNG);
        requestVariablerTeilAntragserfassungDto.setDTAQ(antrag.getAntragsDatum());
        requestVariablerTeilAntragserfassungDto.setDTEQ(antrag.getEingangsdatum());
        requestVariablerTeilAntragserfassungDto.setDF(getDF(antrag.getEinrichtungStartObjekt(), STARTPHASE));

        return requestVariablerTeilAntragserfassungDto;
    }

    /**
     * Es wird die Datenphase fuer die Startphase erstellt. Ist nur fuer die Junit-Test als public deklariert.
     *
     * @param antrag betroffener Antrag
     * @return erstellter Nachrichtenteil fuer die Startphase
     * @throws StatistikException Fehler in der Verarbeitung
     */
    public static DatenphaseDto createDatenphaseStart(final Antrag antrag) throws StatistikException {
        final DatenphaseDto datenphaseDto = new DatenphaseDto();

        if (antrag.getEinrichtungStartObjekt() == null) {
            datenphaseDto.setDF(getDF(null, STARTPHASE));
        } else {

            final String df = getDF(antrag.getEinrichtungStartObjekt(), STARTPHASE);
            createEinrichtungsDaten(datenphaseDto, antrag.getEinrichtungStartObjekt());
            datenphaseDto.setDF(df);

            final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameter =
                new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungStartObjekt(), df,
                    STARTPHASE, DA731);
            datenphaseDto.setDA731(
                extrahiereAngebotsDauerFuerRehaeinrichtung(angebotsdauerFormatierungsParameter));

            datenphaseDto.setAT731(AT731_TAGE);
            if (df.equals(DF_AMBULANT) || df.equals(DF_GANZTAEGIG_AMBULANT)) {
                final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameterZLHBGT =
                    new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungStartObjekt(), df,
                        STARTPHASE, ZLHBTG);
                datenphaseDto.setZLHBTG(extrahiereAngebotsDauerFuerRehaeinrichtung(
                    angebotsdauerFormatierungsParameterZLHBGT));
            } else {
                datenphaseDto.setZLHBTG(null);
            }
        }
        return datenphaseDto;
    }

    /**
     * Es wird die Datenphase fuer die Trainingsphase erstellt.
     *
     * @param antrag betroffener Antrag
     * @return erstellter Nachrichtenteil fuer die Trainingsphase
     * @throws StatistikException Fehler in der Verarbeitung
     */
    public static DatenphaseDto createDatenphaseTraining(final Antrag antrag) throws StatistikException {
        final DatenphaseDto datenphaseDto = new DatenphaseDto();

        if (antrag.getEinrichtungTrainingObjekt() != null) {

            final String df = getDF(antrag.getEinrichtungTrainingObjekt(), TRAININGSPHASE);
            createEinrichtungsDaten(datenphaseDto, antrag.getEinrichtungTrainingObjekt());

            datenphaseDto.setDF(df);

            final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameter =
                new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungTrainingObjekt(), df,
                    TRAININGSPHASE, DA731);
            datenphaseDto.setDA731(
                extrahiereAngebotsDauerFuerRehaeinrichtung(angebotsdauerFormatierungsParameter));

            datenphaseDto.setAT731(AT731_WOCHE);
            if (df.equals(DF_AMBULANT) || df.equals(DF_GANZTAEGIG_AMBULANT)) {
                final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameterZLHBGT =
                    new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungTrainingObjekt(),
                        df, TRAININGSPHASE, ZLHBTG);
                datenphaseDto.setZLHBTG(extrahiereAngebotsDauerFuerRehaeinrichtung(
                    angebotsdauerFormatierungsParameterZLHBGT));
            } else {
                datenphaseDto.setZLHBTG(null);
            }

        }
        return datenphaseDto;
    }

    /**
     * Es wird die Datenphase fuer die Auffrischungsphase erstellt.
     *
     * @param antrag betroffener Antrag
     * @return erstellter Nachrichtenteil fuer die Aufrischungssphase
     * @throws StatistikException Fehler in der Verarbeitung
     **/
    public static DatenphaseDto createDatenphaseAuffrischung(final Antrag antrag) throws StatistikException {
        final DatenphaseDto datenphaseDto = new DatenphaseDto();

        if (antrag.getEinrichtungAufObjekt() != null) {

            final String df = getDF(antrag.getEinrichtungAufObjekt(), AUFFRISCHUNGSPHASE);
            createEinrichtungsDaten(datenphaseDto, antrag.getEinrichtungAufObjekt());
            datenphaseDto.setDF(df);

            final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameter =
                new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungAufObjekt(), df,
                    AUFFRISCHUNGSPHASE, DA731);
            datenphaseDto.setDA731(
                extrahiereAngebotsDauerFuerRehaeinrichtung(angebotsdauerFormatierungsParameter));

            datenphaseDto.setAT731(AT731_TAGE);

            if (df.equals(DF_AMBULANT) || df.equals(DF_GANZTAEGIG_AMBULANT)) {
                final AngebotsdauerFormatierungsParameter angebotsdauerFormatierungsParameterZLHBGT =
                    new AngebotsdauerFormatierungsParameter(antrag.getEinrichtungAufObjekt(), df,
                        AUFFRISCHUNGSPHASE, ZLHBTG);
                datenphaseDto.setZLHBTG(extrahiereAngebotsDauerFuerRehaeinrichtung(
                    angebotsdauerFormatierungsParameterZLHBGT));

            } else {
                datenphaseDto.setZLHBTG(null);
            }

        }
        return datenphaseDto;
    }

    /***
     * Extrahiert die Dauer eines Angebotes aus einer Rehaeinrichtung auf Grundlage der Übergebenen
     * Durchführungsart.
     * Der Returnwert wird im übergebenen Format formatiert
     *
     * @param parameter Record AngebotsdauerFormatierungsParameter (bestehend aus Rehaeinrichtung,
     *            Durchführungsart,
     *            Phase, String Format für Returnstring)
     * @return Dauer des Angebotes für die Angegebene Rehaeinrichtung und Phase
     */
    private static String extrahiereAngebotsDauerFuerRehaeinrichtung(
        final AngebotsdauerFormatierungsParameter parameter) {
        final String phase = parameter.phase();
        final List<Angebot> angeboteZurPhase = parameter.einrichtung().getAngebote().stream()
            .filter(angebot -> angebot.getPhase().equalsIgnoreCase(phase)).toList();
        return angeboteZurPhase.stream()
            .filter(art -> DurchfuehrungsArt.fuerBezeichnung(art.getDurchfuehrungsart())
                .getZahlWert(getPhaseEnumFuerStringBezeichner(phase))
                .equalsIgnoreCase(parameter.durchfuehrungsart()))
            .map(Angebot::getDauer).map(i -> parameter.format().format(i)).findFirst().orElse(null);
    }

    /**
     * Liefert die Phase aus PhaseEnumDto.
     *
     * @param phase zu ermittelnde Phase
     * @return Phase aus PhaseEnumDto
     */
    public static PhaseEnumDto getPhaseEnumFuerStringBezeichner(final String phase) {
        return switch (phase) {
            case STARTPHASE -> PhaseEnumDto.STARTPHASE;
            case AUFFRISCHUNGSPHASE -> PhaseEnumDto.AUFFRISCHUNG;
            case TRAININGSPHASE -> PhaseEnumDto.TRAININGSPHASE;
            default -> {
                LOG.atWarn().addArgument(phase).log("Unbekannte Phase [{}]");
                throw new IllegalArgumentException(phase);
            }
        };
    }

    private static void createEinrichtungsDaten(final DatenphaseDto datenphaseDto, final RehaEinrichtung rehaEinrichtung) {
        datenphaseDto.setRESC(rehaEinrichtung.getResc());
        if (datenphaseDto.getRESC() == null || !datenphaseDto.getRESC().matches("^[a-zA-Z]\\d*")) {
            datenphaseDto.setAdresse(trimmed(rehaEinrichtung.getAdresse().getStrasse() + " "
                + rehaEinrichtung.getAdresse().getHausnummer(), 42));
            datenphaseDto.setNameEinrichtung(trimmed(rehaEinrichtung.getName(), 30));
            datenphaseDto.setOrt(trimmed(rehaEinrichtung.getAdresse().getOrt(), 34));
            datenphaseDto.setPostleitzahl(rehaEinrichtung.getAdresse().getPlz());
        }
    }

    private static List<AntragPruefergebnis> getActivePruefergebnise(final Antrag antrag) {
        /*
          Es werden aus allen Pruefergebnisse eines Antrag gefiltert nach den aktuell aktiven Ergebnisse.
          Dann wird geprüft ob alle Regeln erfüllt sind
         */
        final var prueferNameListMap = antrag.getAntragPruefergebnisse().stream()
            .filter(antragPruefergebnis -> antragPruefergebnis.getRegelName() != null)
            .filter(antragPruefergebnis -> !PruefergebnisUtils.EINRICHTUNG_REGELN.contains(antragPruefergebnis.getRegelName()))
            .filter(antragPruefergebnis -> antragPruefergebnis.getRegelName() != RegelName.REGEL_BEMERKUNG)
            .filter(antragPruefergebnis -> antragPruefergebnis.getRegelName() != RegelName.REGEL_DIGITALER_ANHANG)
            .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName));
        final List<AntragPruefergebnis> activeAntragPruefergebnise = new ArrayList<>();
        prueferNameListMap.keySet().forEach(regelName ->
            prueferNameListMap.get(regelName)
                .stream().max(Comparator.comparing(AntragPruefergebnis::getCreated))
                .ifPresent(activeAntragPruefergebnise::add));
        return activeAntragPruefergebnise;
    }

    /**
     * String wird getrimmt.
     *
     * @param string     String der getrimmt wird.
     * @param maxZeichen Maximale Anzahl an Zeichen die der Ergebnisstring enthalten darf.
     * @return String nach Trim.
     */
    static String trimmed(final String string, int maxZeichen) {
        final String checkedString = Optional.ofNullable(string)
            .filter(Predicate.not(String::isBlank))
            .orElse("?");
        return checkedString.substring(0, Math.clamp(checkedString.length(), 1, maxZeichen)).trim();
    }

    /**
     * Pruefung ob es sich um ein schutbeduertiges Konto handelt.
     *
     * @param bestandsfehler zu untersuchender Bestandsfehler
     * @return true wenn das Konto schutzbedürftig ist.
     */
    public static boolean istKontoSchutzbeduerftig(final BestandsfehlerDto bestandsfehler) {
        return Optional.ofNullable(bestandsfehler)
            .map(BestandsfehlerDto::getUnerwartererFehler)
            .map(UnerwartererFehlerDto::getFehlercode)
            .map(AF_FEHLER_SCHUTZBEDARF::contains)
            .orElse(false);
    }

    /**
     * Pruefung ob es sich um ein schutbeduertiges Konto handelt.
     *
     * @param bestandsfehlerException zu untersuchende BestandsfehlerException
     * @return true wenn das Konto schutzbedürftig ist.
     */
    public static boolean istKontoSchutzbeduerftig(final BestandsfehlerException bestandsfehlerException) {
        if (bestandsfehlerException instanceof StatistikBestandsFehlerException e) {
            return Optional.of(e)
                .map(StatistikBestandsFehlerException::getBestandsfehlerDto)
                .map(BestandsfehlerDto::getUnerwartererFehler)
                .map(UnerwartererFehlerDto::getFehlercode)
                .map(AF_FEHLER_SCHUTZBEDARF::contains)
                .orElse(false);
        }

        if (bestandsfehlerException instanceof KontoinformationBestandsFehlerException e) {
            return Optional.of(e)
                .map(KontoinformationBestandsFehlerException::getFehlerEintragDto)
                .map(FehlerEintragDto::getStatuscode)
                .map(AF_FEHLER_SCHUTZBEDARF::contains)
                .orElse(false);
        }

        if (bestandsfehlerException instanceof StammdatenBestandsFehlerException e) {
            return Optional.of(e)
                .map(StammdatenBestandsFehlerException::getFehlerEintragDto)
                .map(FehlerEintragDto::getStatuscode)
                .map(AF_FEHLER_SCHUTZBEDARF::contains)
                .orElse(false);
        }

        return false;
    }
}
