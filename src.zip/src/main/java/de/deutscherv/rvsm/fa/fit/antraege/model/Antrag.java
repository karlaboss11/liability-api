package de.deutscherv.rvsm.fa.fit.antraege.model;

import de.deutscherv.rvsm.fa.fit.antraege.repository.BooleanToNumberConverter;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.ArtZugaenglichkeitDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto.GeschlechtEnum;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.StatusValidator;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Klasse für alle Antragsdaten, derzeit inkl. dem Prüfergebnis */
@Entity
@Table(name = "antrag")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Antrag {

    /** technische id des Antrags. */
    @Id
    @Column
    @Builder.Default
    private UUID uuid = UUID.randomUUID();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "antrag_id", referencedColumnName = "uuid")
    @Builder.Default
    private List<Stammdaten> versichertenStammdaten = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "antrag_id", referencedColumnName = "uuid")
    @Builder.Default
    private List<Kontoinformation> kontoinformationen = new ArrayList<>();

    /** das Prüfergebnis für diesen Antrag. Hinweis: dies wird später ausgelagert */
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "antrag_id", referencedColumnName = "uuid")
    @Builder.Default
    private List<AntragPruefergebnis> antragPruefergebnisse = new LinkedList<>();

    /** das Prüfergebnis für diesen Antrag. Hinweis: dies wird später ausgelagert */
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "antrag_id", referencedColumnName = "uuid")
    @Builder.Default
    private List<Aufgabe> aufgaben = new ArrayList<>();

    @Column
    @Enumerated(EnumType.STRING)
    private AntragsArt antragsart;

    @Column(name = "hat_digitalen_anhang", nullable = false)
    @Convert(converter = BooleanToNumberConverter.class)
    private boolean hatDigitalenAnhang;

    @Column
    private String vsnr;

    @Column
    @Enumerated(EnumType.STRING)
    private AntragStatus status;

    @Column
    private String vorname;

    @Column
    private String nachname;

    @Column
    @Enumerated(EnumType.STRING)
    private GeschlechtEnum geschlecht;

    @Column
    private LocalDate geburtsdatum;

    @Column(name = "geburtsdatum_status")
    @Enumerated(EnumType.STRING)
    private GeburtsdatumStatus geburtsdatumStatus;

    @Column
    private String geburtsort;

    @Column
    private String geburtsland;

    @Column
    private String strasse;

    @Column
    private String hausnummer;

    @Column
    private String plz;

    @Column
    private String wohnort;

    @Column
    private String land;

    @Column
    private String staatsangehoerigkeit;

    @Column
    private String bemerkungen;

    @Column(name = "antragsdatum")
    private LocalDate antragsDatum;

    @Column
    private String xml;
    
    @Column
    private Long version;

    @Column(name = "angebot_start_smp_id")
    private Long angebotStartSmpId;

    @Column(name = "angebot_start_name")
    private String angebotStartName;

    @Column(name = "angebot_start_ort")
    private String angebotStartOrt;

    @Column(name = "angebot_start_plz")
    private String angebotStartPlz;

    @Column(name = "angebot_start_strasse")
    private String angebotStartStrasse;

    @Column(name = "angebot_training_smp_id")
    private Long angebotTrainingSmpId;

    @Column(name = "angebot_training_name")
    private String angebotTrainingName;

    @Column(name = "angebot_training_ort")
    private String angebotTrainingOrt;

    @Column(name = "angebot_training_plz")
    private String angebotTrainingPlz;

    @Column(name = "angebot_training_strasse")
    private String angebotTrainingStrasse;

    @Column(name = "angebot_auf_smp_id")
    private Long angebotAufSmpId;

    @Column(name = "angebot_auf_name")
    private String angebotAufName;

    @Column(name = "angebot_auf_ort")
    private String angebotAufOrt;

    @Column(name = "angebot_auf_plz")
    private String angebotAufPlz;

    @Column(name = "angebot_auf_strasse")
    private String angebotAufStrasse;

    @OneToOne(cascade = CascadeType.ALL, optional = true)
    @JoinColumn(name = "einrichtung_start_uuid", referencedColumnName = "uuid")
    private RehaEinrichtung einrichtungStartObjekt;

    @OneToOne(cascade = CascadeType.ALL, optional = true)
    @JoinColumn(name = "einrichtung_auf_uuid", referencedColumnName = "uuid")
    private RehaEinrichtung einrichtungAufObjekt;

    @OneToOne(cascade = CascadeType.ALL, optional = true)
    @JoinColumn(name = "einrichtung_training_uuid", referencedColumnName = "uuid")
    private RehaEinrichtung einrichtungTrainingObjekt;

    @Column(name = "last_modified_start")
    private LocalDateTime lastModifiedStart;

    @Column(name = "last_modified_auf")
    private LocalDateTime lastModifiedAuf;

    @Column(name = "last_modified_training")
    private LocalDateTime lastModifiedTraining;

    @Column
    private String telefon;

    @Column
    private String fax;

    @Column(name = "art_zugaenglichkeit")
    @Enumerated(EnumType.STRING)
    private ArtZugaenglichkeitDto artZugaenglichkeit;

    @Column
    private LocalDate eingangsdatum;

    @Column
    private LocalDate bescheiddatum;

    @CreationTimestamp
    @Column(updatable = false, nullable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;

    @Column(name = "ktan")
    private String ktan;

    @Column(unique = true)
    private String vorgangskennung;

    @Column
    private Integer msnr;

    @Column
    private Integer atad;

    @Column
    private String vorsatzwort;

    @Column
    private String namenszusatz;

    @Column
    private String titel;
    
    @Column
    @Enumerated(EnumType.STRING)
    private DoppelvergabeStatus doppelvergabe;

    /**
     * Fügt Stammdaten hinzu.
     *
     * @param versicherte die Stammdaten
     */
    public void addVersicherte(final Stammdaten versicherte) {
        if (Objects.isNull(versichertenStammdaten)) {
            versichertenStammdaten = new ArrayList<>();
        }
        if (Objects.isNull(versicherte)) {
            return;
        }
        versichertenStammdaten.add(versicherte);
    }

    /**
     * Fügt Kontoinformationen hinzu.
     *
     * @param kontoinformation die Kontoinformationen
     */
    public void addKontoinformation(final Kontoinformation kontoinformation) {
        if (Objects.isNull(kontoinformationen)) {
            kontoinformationen = new ArrayList<>();
        }
        if (Objects.isNull(kontoinformation)) {
            return;
        }
        kontoinformationen.add(kontoinformation);
    }

    /**
     * Fürgt ein Prüfergebnis hinzu.
     *
     * @param pruefergebnis das Prüfergebnis
     */
    public void addAntragPruefergebnis(final AntragPruefergebnis pruefergebnis) {
        if (Objects.isNull(pruefergebnis)) {
            return;
        }
        antragPruefergebnisse.add(pruefergebnis);
    }

    /**
     * Fügt eine Aufgabe hinzu.
     *
     * @param aufgabe die Aufgabe.
     */
    public void addAufgabe(final Aufgabe aufgabe) {
        if (Objects.isNull(aufgaben)) {
            aufgaben = new ArrayList<>();
        }
        if (Objects.isNull(aufgabe)) {
            return;
        }
        aufgaben.add(aufgabe);
    }

    /**
     * Antragsstatus wird gesetzt.
     * Ist der neue Antragsstatus nicht erlaubt als Folge des aktuellen Status wird eine {@code UnsupportedOperationException} geworfen.
     * @param status zu setzender Status.
     * @throws UnsupportedOperationException falls der neue Status nicht auf den aktuellen Status folgen darf
     */
    public void setStatus(final AntragStatus status) {
        if (!StatusValidator.isReihenfolge(this.status, status)) {
            throw new UnsupportedOperationException(
                    "Antragsstatus darf nicht von " + this.status + " auf " + status + " geändert werden");
        }
        this.status = status;
    }

}
