package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG;

/**
 * Processor das Kannzeichen VOR-REGELPREUEFUNG setzt.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class ErledigungVorRegelpruefungEnricher implements Processor {

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Art erledigungsArt = exchange.getProperty(PROPERTY_ERLEDIGUNGSART, Art.class);
        final Antrag antrag = exchange.getMessage().getBody(Antrag.class);

        final boolean vorRegelpruefung;
        if (antrag.getStatus() == AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT && erledigungsArt == Art.STORNO) {
            antrag.setDoppelvergabe(DoppelvergabeStatus.STORNIEREN);
            vorRegelpruefung = true;
        } else {
            vorRegelpruefung = false;
        }
        exchange.setProperty(PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG, vorRegelpruefung);
    }
}
