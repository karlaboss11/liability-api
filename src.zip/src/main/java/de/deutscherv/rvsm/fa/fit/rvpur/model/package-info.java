/**
 * Beinhaltet DTOs für die Anbindung an rvPuR.
 */
package de.deutscherv.rvsm.fa.fit.rvpur.model;
