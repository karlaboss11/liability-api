package de.deutscherv.rvsm.fa.fit.stammdaten.model;

import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto.GeschlechtEnum;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Entity Stammdaten.
 */
@Entity
@Table(name = "versicherten_stammdaten")
@Cacheable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Stammdaten {

    /** technische id der Stammdaten. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @Column(name = "antrag_id")
    private UUID antragId;

    @Column
    private String vsnr;

    @Column
    @Enumerated(EnumType.STRING)
    private GeschlechtEnum geschlecht;

    @Column
    private String vorname;

    @Column
    private String nachname;

    @Column
    private LocalDate geburtsdatum;

    @Column(name = "geburtsdatum_status")
    @Enumerated(EnumType.STRING)
    private GeburtsdatumStatus geburtsdatumStatus;

    @Column
    private String geburtsort;

    @Column
    private String geburtsland;

    @Column
    private String strasse;

    @Column
    private String hausnummer;

    @Column
    private String plz;

    @Column
    private String wohnort;

    @Column
    private String land;

    @Column
    private String staatsangehoerigkeit;

    @Column
    private String vorsatzwort;

    @Column
    private String namenszusatz;

    @Column
    private String titel;

    @Column(name = "ktan")
    private String ktan;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;
}
