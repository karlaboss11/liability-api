package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.Regel;

/**
 * Eröffnet die Möglichkeit defaultverhalten Einzubauen ist auch ein Artefakt der alten RegelEngine.
 */
public abstract class BasisRegel implements Regel {
    // erstmal leer
}
