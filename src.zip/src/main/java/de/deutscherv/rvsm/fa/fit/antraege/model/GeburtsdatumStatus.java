package de.deutscherv.rvsm.fa.fit.antraege.model;

/**
 * Wert für den Status des Geburtsdatums. Es gibt Fälle, bei denen das genaue Geburtsdatum nicht bekannt ist. Solche Fälle können über
 * LocalDate nicht abgedeckt werden, da ein Datum wie z.B. 2024-09-00 ungültig ist. Mit Hilfe dieses Enums kann überprüft werden, ob das
 * eingetragene Geburtsdatum der Antrags-Person korrekt ist oder eine Unregelmäßigkeit aufweist. Im dem Beispiel wäre dann das Geburtsdatum
 * 2024-09-00 und der GeburtsdatumStatus TAG_NULL.
 */
public enum GeburtsdatumStatus {
    /**
     * Normales Geburtsdatum.
     */
    OK("OK"),
    /**
     * Tag des Geburtstags ist 0. Für Fälle, in denen Monat und Jahr, aber nicht der genaue Tag bekannt sind.
     */
    TAG_NULL("TAG_NULL"),
    /**
     * Tag und Monat des Geburtstags ist 0. Für Fälle, in denen nur das Jahr, aber nicht der genaue Tag und Monat bekannt sind.
     */
    MONAT_TAG_NULL("MONAT_TAG_NULL");

    /**
     * Wert für den Status des Geburtsdatums.
     */
    public final String wert;

    GeburtsdatumStatus(String wert) {
        this.wert = wert;
    }
}
