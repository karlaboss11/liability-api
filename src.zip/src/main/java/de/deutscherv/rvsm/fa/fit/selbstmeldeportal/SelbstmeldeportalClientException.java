package de.deutscherv.rvsm.fa.fit.selbstmeldeportal;

import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import java.io.Serial;

/**
 * SelbstmeldeportalClientException.
 */
public class SelbstmeldeportalClientException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     */
    public SelbstmeldeportalClientException(final String message) {
        super(message);
    }

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Fehlergrund
     */
    public SelbstmeldeportalClientException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * Konstruktor.
     *
     * @param resource  Resource
     * @param userIdent User-ID
     * @param message   Fehlernachricht
     */
    public SelbstmeldeportalClientException(final String resource, final String userIdent,
            final String message) {
        super(resource, userIdent, message);
    }

}
