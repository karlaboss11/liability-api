package de.deutscherv.rvsm.fa.fit.management;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import jakarta.inject.Inject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Service zum Steuern der (via Cronjob getriggerten) Aktionen.
 * Aktuell einzig fuer Reset der Fehler Retries eingesetzt
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor(onConstructor_ = {@Inject})
public class CronService extends RouteBuilder {

    /**
     * Name der Route.
     */
    public static final String RESET_FEHLER_RETRIES = "direct:resetFehlerRetries";

    private final FehlerRepository fehlerRepository;

    @ConfigProperty(name = "antrag.retry.retries")
    private int retries;

    private final RequestContextController requestContext;
    private final DrvMandant mandant;

    @Override
    public void configure() throws Exception {
        from(RESET_FEHLER_RETRIES)
                .routeId(RESET_FEHLER_RETRIES)
                .trace(true)
                .process(x -> requestContext.activate())
                .process(x -> {
                    final var ktan = x.getMessage().getBody(String.class);
                    x.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, ktan);
                    mandant.setInScope(ktan);
                })
                .process(x -> fehlerRepository.updateFehlerRetries(retries));
    }
}
