package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Ruft {@link RvfitLogger} auf, um die statistische Erfassung ans Fachprotokoll zu melden.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class BescheiderstellungFachprotokollProcessor implements Processor {
    private final RvfitLogger rvfitLogger;
    private final JsonWebToken jwt;

    @Override
    public void process(final Exchange exchange) {

        var antrag = exchange.getMessage().getBody(Antrag.class);

        final EreignisTyp ereignisTyp = EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL;
        final Ereignistext ereignisText = Ereignistext.STATISTIK_GEBILDET;
        final EreignisFreitext ereignisFreiText = EreignisFreitext.STATISTIK_GEBILDET_BESCHEID;

        LOG.atInfo()
                .addArgument(ereignisTyp)
                .addArgument(ereignisText)
                .addArgument(ereignisFreiText)
                .addArgument(antrag.getUuid())
                .addArgument(antrag.getVorgangskennung())
                .addArgument(antrag.getVsnr())
                .log("Sende ans Ereignis ans Fachprotoll. Typ [{}] Text [{}] Freitext [{}] VOG-ID: [{}], UUID [{}], VSNR [{}]");

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(ereignisTyp, ereignisText, ereignisFreiText,
                null, antrag, null, jwt, null));
    }
}
