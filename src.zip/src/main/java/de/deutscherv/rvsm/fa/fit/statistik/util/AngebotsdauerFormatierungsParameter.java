package de.deutscherv.rvsm.fa.fit.statistik.util;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.util.DRVStringFormat;

/**
 * AngebotsdauerFormatierungsparameter.
 *
 * @param einrichtung       Einrichtung
 * @param durchfuehrungsart Durchfuehrungsart
 * @param phase             Phase
 * @param format            Format
 */
public record AngebotsdauerFormatierungsParameter(RehaEinrichtung einrichtung,
                                                  String durchfuehrungsart, String phase, DRVStringFormat format) {

}
