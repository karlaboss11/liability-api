package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;

import java.time.LocalDate;
import java.util.Optional;
import lombok.experimental.UtilityClass;

/**
 * In bestimmten Faellen ist es moeglich dass es auch Geburtsdaten gibt bei denen der Tag oder Tag und Monat Null ist.
 * Da es sich dabei dann nicht mehr um ein gueltiges Datum handelt mit dem eine Datumsberechnung moeglich ist wird
 * jeweils der 1. eingesetzt. Zusaetzlich gibt es das Feld GeburstsdatumStatus das anzeigt ob solch ein Nullerfall
 * gegeben ist oder es ich um ein korrektes Datum handelt.<br>
 * <br>
 * Beispiele:<br>
 * <table>
 * <td>
 *     <tr>
 *         <th>Geburtsdatum aus rvDialog</th>
 *         <th>Geburtsdatum in rvFit</th>
 *         <th>GeburtsdatumStatus</th>
 *     </tr>
 *     <tr>
 *         <td>02.05.1970</td>
 *         <td>02.05.1970</td>
 *         <td>OK</td>
 *     </tr>
 *     <tr>
 *         <td>00.05.1970</td>
 *         <td>01.05.1970</td>
 *         <td>TAG_NULL</td>
 *     </tr>
 *     <tr>
 *         <td>00.00.1970</td>
 *         <td>01.01.1970</td>
 *         <td>MONAT_TAG_NULL</td>
 *     </tr>
 * </td>
 * </table>

 */
@UtilityClass
public class GeburtsdatumUtils {

    /**
     * Aus der Kombination von geburtsdatum und geburtsdatumStatus wird ein String erzeugt. Dabei wird abhaengig von geburtsdatumStatus
     * evtl. der Tag und/oder Monat als "00" ausgegeben.
     *
     * @param geburtsdatum       Geburtsdatum das ausgegeben werden soll
     * @param geburtsdatumStatus Status des Geburtsdatums
     * @return Geburtsdatum im ISO-Format allerdings evtl. mit Tag und/oder Monat als "00"
     */
    public static String getGeburtsdatumAsString(LocalDate geburtsdatum, GeburtsdatumStatus geburtsdatumStatus) {
        if (Optional.ofNullable(geburtsdatum).isEmpty()) {
            return null;
        }
        int year = geburtsdatum.getYear();
        int month = geburtsdatum.getMonthValue();
        int day = geburtsdatum.getDayOfMonth();
        switch (geburtsdatumStatus) {
            case MONAT_TAG_NULL:
                month = 0;
                day = 0;
                break;
            case TAG_NULL:
                day = 0;
                break;
            default:
                break;
        }
        return String.format("%04d-%02d-%02d", year, month, day);
    }


    /**
     * Mappt String mit dem Geburtsdatum zu einem LocalDate. Falls Monat und/oder Tag den Wert "00" haben wird jeweils "01" eingetragen.
     *
     * @param geburtsdatum String mit dem Datum im ISO-Format "YYYY-MM-DD"
     * @return Geburtsdatum als LocalDate.
     */
    public static LocalDate getGeburtsdatumAsLocalDate(String geburtsdatum) {
        if (Optional.ofNullable(geburtsdatum).isEmpty()) {
            return null;
        }
        String gebDat = geburtsdatum;
        // Ist der Tag = "00" und evtl. der  Monat = "00"
        if (gebDat.startsWith("00", 5)) {
            gebDat = gebDat.substring(0, 5).concat("01-01");
        } else if (gebDat.startsWith("00", 8)) {
            gebDat = gebDat.substring(0, 8).concat("01");
        }

        return LocalDate.parse(gebDat);

    }

    /**
     * Aus dem Geburtsdatum wird der GeburtsdatumStatus ermittelt. Ist der Tag = "00" wird GeburtsdatumStatus.TAG_NULL gesetzt. Ist der Tag
     * und der Monat gleich Null wird GeburtsdatumStatus.MONAT_TAG_NULL gesetzt. In allen anderen Fällen wird Geburtsdatum.OK gesetzt.
     *
     * @param geburtsdatum im ISO-Format "YYYY-MM-DD"
     * @return ermittelter GeburtsdatumStatus
     */
    public static GeburtsdatumStatus detectGeburtsdatumStatus(final String geburtsdatum) {
        if (Optional.ofNullable(geburtsdatum).isPresent()) {
            if (geburtsdatum.startsWith("00", 5)) {
                return GeburtsdatumStatus.MONAT_TAG_NULL;
            } else if (geburtsdatum.startsWith("00", 8)) {
                return GeburtsdatumStatus.TAG_NULL;
            }
        }
        return GeburtsdatumStatus.OK;
    }

}
