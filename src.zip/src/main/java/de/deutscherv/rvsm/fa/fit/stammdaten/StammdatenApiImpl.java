package de.deutscherv.rvsm.fa.fit.stammdaten;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.exceptions.BestandsfehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.openapi.api.StammdatenApi;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.util.TimeoutFallbackHandler;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_BST;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_EF;
import static de.deutscherv.rvsm.fa.fit.util.VsnrValidator.isValidVsnr;

/**
 * StammdatenApiImpl.
 */
@Slf4j
@RequiredArgsConstructor
@SecurityRequirement(name = "keycloak")
@Path("/stammdaten/{vsnr}")
public final class StammdatenApiImpl implements StammdatenApi {

    /**
     * Versicherungsnummer mit Format-Fehler.
     */
    public static final String FEHLER_VSNR = "Ungueltige VSNR Format.";

    private static final String BESTANDSFEHLERCODE = "Es wurde ein Bestandsfehlercode zurück gegeben";

    private final StammdatenService stammdatenService;

    private final JsonWebToken jwt;

    private final DrvMandant drvMandant;

    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF })
    @Timeout(value = 20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response getStammdatenByVsnr(final String vsnr) {
        LOG.atWarn().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vsnr).log(
                "Suche Stammdaten aus Versichertenstammdaten Service mit VSNR. DrvId [{}] Vsnr [{}]");

        // VSNR Validierung
        if (!isValidVsnr(vsnr)) {
            LOG.atError().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vsnr)
                    .log("input_validation_fail[vsnr]: Ungueltiges VSNR Format. DrvId [{}] Vsnr [{}]");
            return Response.status(Status.BAD_REQUEST).entity(FEHLER_VSNR).build();
        }

        try {
            // Mappt die Daten aus dem Stammdatenservice (Personendatenservice) ins StammmdatenDto
            final StammdatenDto stammdaten =
                    stammdatenService.getStammdatenDtoByVsnr(JwtUtils.GET_KTAN.apply(jwt, drvMandant), vsnr);

            return Response.ok(stammdaten).build();

        } catch (StammdatenBestandsFehlerException exception) {
            LOG.atWarn().addArgument(exception)
                    .log("Es wurde ein Bestandsfehlercode zurück gegeben: [{}]");
            final FehlerEintragDto fehlerEintragDto =
                    exception.getFehlerEintragDto();
            final UnerwartererFehlerDto unerwartererFehlerDto = new UnerwartererFehlerDto();
            unerwartererFehlerDto.setFehlercode(fehlerEintragDto.getStatuscode());
            final BestandsfehlerDto bestandsfehlerDto = new BestandsfehlerDto();
            bestandsfehlerDto.setUnerwartererFehler(unerwartererFehlerDto);

            final BestandsfehlerException.VersichertenInfo versichertenInfo = exception.getVersichertenInfo();
            bestandsfehlerDto.setVsnr(versichertenInfo.vsnr());
            bestandsfehlerDto.setName(versichertenInfo.nachname());
            bestandsfehlerDto.setVorname(versichertenInfo.vorname());

            return Response.status(Status.INTERNAL_SERVER_ERROR)
                    .entity(new AntwortDto()
                            .code(Status.INTERNAL_SERVER_ERROR.getStatusCode()).bestandsfehler(bestandsfehlerDto)
                            .nachricht(BESTANDSFEHLERCODE))
                    .build();
        }
    }
}
