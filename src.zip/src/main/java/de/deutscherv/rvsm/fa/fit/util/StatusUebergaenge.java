package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import java.util.List;
import java.util.Map;

/**
 * Definiert die Übergänge zwischen Status von Anträgen, um sicherzustellen, dass hier keine undefinierten Zustände entstehen können.
 * <p>
 * Zur Dokumentation siehe <a href="https://rvwiki.drv.drv/x/qqq9O">RV Fit Status-Modell</a>.
 */
public final class StatusUebergaenge {

    private static final Map<AntragStatus, List<AntragStatus>> VALIDE_UEBERGAENGE;

    static {
        VALIDE_UEBERGAENGE = Map.ofEntries(
            Map.entry(AntragStatus.ENTWURF,
                List.of(AntragStatus.VORGANG_WIRD_ERSTELLT,
                    AntragStatus.VORGANG_ERZEUGT,
                    AntragStatus.PAPIERANTRAG_GESPEICHERT,
                    AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.PAPIERANTRAG_GESPEICHERT,
                List.of(AntragStatus.VORGANG_ERZEUGT)),

            // workaround, muss korrigiert werden sobald Vorgangserzeugung passt
            Map.entry(AntragStatus.VORGANG_WIRD_ERSTELLT,
                List.of(AntragStatus.VORGANG_ERZEUGT,
                    AntragStatus.STATISTIK_ERFASST)),

            Map.entry(AntragStatus.VORGANG_ERZEUGT,
                List.of(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.KONTOINFORMATION_ABGEFRAGT,
                    AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.KONTOINFORMATION_ABGEFRAGT,
                List.of(AntragStatus.STATISTIK_ERFASST,
                    AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STATISTIK_ERFASST,
                List.of(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK,
                    AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK,
                List.of(AntragStatus.AUTOMATISCH,
                    AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                    AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT,
                List.of(AntragStatus.AUTOMATISCH,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                    AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
                    AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.DOPPELVERGABE_AUFGABE_SCHLIESSEN)),

            Map.entry(AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
                List.of(AntragStatus.AUTOMATISCH,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.RVPUR_AUFGABE_GESCHLOSSEN,
                List.of(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                    AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.AUTOMATISCH,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.AUTOMATISCH,
                List.of(AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.BESCHEID_ABGESCHLOSSEN,
                List.of(AntragStatus.AUFGABE_ABGESCHLOSSEN,
                    AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                List.of(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                    AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
                    AntragStatus.AUTOMATISCH,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN,
                    AntragStatus.RVPUR_AUFGABE_GESCHLOSSEN)),

            Map.entry(AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                List.of(AntragStatus.AUFGABE_SCHLIESSEN_OHNE_STATISTIK,
                    AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.AUFGABE_ABGESCHLOSSEN,
                List.of(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.AUFGABE_SCHLIESSEN_OHNE_STATISTIK,
                List.of(AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN,
                List.of(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT)),

            Map.entry(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT,
                List.of(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN,
                List.of(AntragStatus.VORGANG_ERZEUGT)),

            Map.entry(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN,
                List.of(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT)),

            Map.entry(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT,
                List.of(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN,
                List.of(AntragStatus.KONTOINFORMATION_ABGEFRAGT)),

            Map.entry(AntragStatus.DOPPELVERGABE_AUFGABE_SCHLIESSEN,
                List.of(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK)),

            Map.entry(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN,
                List.of(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT)),

            Map.entry(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT,
                List.of(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN,
                List.of(AntragStatus.STATISTIK_ERFASST)),

            Map.entry(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN,
                List.of(AntragStatus.STATISTIK_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT,
                List.of(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN,
                    AntragStatus.BESCHEID_ABGESCHLOSSEN)),

            Map.entry(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN,
                List.of(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT)));
    }

    private StatusUebergaenge() {
        throw new UnsupportedOperationException();
    }

    /**
     * Überprüft af valide Stausübergänge.
     *
     * @param alt alter Antragsstatus
     * @param neu neuer Antragsstatus
     * @return true wenn der Übergang valide ist
     */
    public static boolean valid(final AntragStatus alt, final AntragStatus neu) {
        return VALIDE_UEBERGAENGE.get(alt).contains(neu);
    }

}
