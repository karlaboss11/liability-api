package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import lombok.experimental.UtilityClass;

/**
 * Enthält die Namen der Antragsrouten.
 */
@UtilityClass
public class RouteNames {
    /**
     * Routenname: Extrahiere Mandant.
     */
    public static final String DIRECT_EXTRACT_MANDANT = "direct:extractMandant";
    /**
     * Routenname: Erstelle Vorgang.
     */
    public static final String DIRECT_ERSTELLE_VORGANG = "direct:erstelleVorgang";
    /**
     * Routenname: Checke Vorgang.
     */
    public static final String DIRECT_CHECK_VORGANG = "direct:checkVorgang";
    /**
     * Routenname: Erfasse Statistik.
     */
    public static final String DIRECT_ERFASSE_STATISTIK = "direct:erfasseStatistik";
    /**
     * Routenname: Setze SMP-Einrichtungen.
     */
    public static final String DIRECT_SETSMP_EINRICHTUNGEN = "direct:setSmpEinrichtungen";
    /**
     * Routenname: Pruefe Regeln.
     */
    public static final String DIRECT_PRUEFE_REGELN = "direct:pruefeRegeln";
    /**
     * Routenname: Generiere Vorgangskennung.
     */
    public static final String DIRECT_GENERATE_VORGANGSKENNUNG = "direct:generateVorgangskennung";
    /**
     * Routenname: Routing ohne Bescheid.
     */
    public static final String DIRECT_OHNE_BESCHEID_ROUTING = "direct:ohneBescheidRouting";
    /**
     * Routenname: Verarbeite Bewilligung.
     */
    public static final String DIRECT_VERARBEITE_BEWILLIGUNG= "direct:antrag:verarbeiteBewilligung";
    /**
     * Routenname: Erstelle Bescheid.
     */
    public static final String DIRECT_ERSTELLE_BESCHEID = "direct:erstelleBescheid";
    /**
     * Routenname: Sende Fachereignis.
     */
    public static final  String DIRECT_SEND_FACHEREIGNIS ="direct:sendFachereignis";

    /**
     * Routenname: Schliesse Statistik ab.
     */
    public static final String DIRECT_SCHLIESSE_STATISTIK_AB = "direct:schliesseStatistikAb";
    /**
     * Routenname: Schliesse offene Aufgabe.
     */
    public static final String DIRECT_SCHLIESSE_OFFENE_AUFGABEN = "direct:schliesseOffeneAufgaben";
    /**
     * Routenname: Sichere eAntrag.
     */
    public static final String DIRECT_SAVE_EANTRAG = "direct:saveEantrag";
    /**
     * Routenname: Aktualisiere eAntrag.
     */
    public static final String DIRECT_MERGE_EANTRAG = "direct:mergeEantrag";
    /**
     * Routenname: Erstelle PDF-Archiv.
     */
    public static final String DIRECT_CREATE_PDF_ARCHIVE = "direct:createPdfArchive";
    /**
     * Routenname: Pruefe Doppelvergabe.
     */
    public static final String DIRECT_CHECK_DOPPELVERGABE = "direct:checkDoppelvergabe";
    /**
     * Routenname: Weiter mit Doppelvergabe.
     */
    public static final String DIRECT_CONTINUE_DOPPELVERGABE = "direct:continueDoppelvergabe";
    /**
     * Routenname: Lese Stammdaten.
     */
    public static final String DIRECT_FETCH_STAMMDATEN = "direct:fetchStammdaten";
    /**
     * Routenname: Lese Kontoinformationen.
     */
    public static final String DIRECT_FETCH_KONTOINFORMATIONEN = "direct:fetchKontoinformationen";
    /**
     * Routenname: Erstelle rvDialog-Fehleraufgabe.
     */
    public static final String DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE = "direct:erstelleRVDialogFehlerAufgabe";
    /**
     * Routenname: Gleiche Personendaten ab.
     */
    public static final String DIRECT_PERSONENDATENABGLEICH = "direct:personendatenabgleich";
    /**
     * Routenname: Aktualisiere Antragsdaten.
     */
    public static final String DIRECT_AKTUALISIEREANTRAGSDATEN = "direct:aktualisiereAntragsdaten";
    /**
     * Routenname: rvFitStatus-Baserouting.
     */
    public static final String RVFIT_STATUS_BASED_ROUTING = "direct:rvfitStatusBasedRouting";
    /**
     * Routenname: Lese Metadaten.
     */
    public static final String DIRECT_GET_METADATA = "direct:getMetadata";
    /**
     * Routenname: Erledigung ohne Bescheid.
     */
    public static final String DIRECT_ERLEDIGUNG_OHNE_BESCHEID = "direct:erledigungOhneBescheid";
    /**
     * Routenname: Erledigung ohne Bescheid und Aufgabe schliessen.
     */
    public static final String DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN = "direct:erledigungOhneBescheidAufgabeSchliessen";
    /**
     * Routenname: Erledigung ohne Bescheid und Statistik schreiben.
     */
    public static final String DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN = "direct:erledigungOhneBescheidStatistikSchreiben";
    /**
     * Routenname: Ereldigung ohne Bescheid Fachprotokoll Abschluss schreiben.
     */
    public static final String DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS =
            "direct:erledigungOhneBescheidFachprotokollAbschluss";
    /**
     * Routenname: Erledigung ohne Bescheid mit Weiterbearbeitung in rvDialog.
     */
    public static final String DIRECT_ERLEDIGUNG_OHNE_BESCHEID_WEITERBEARBEITUNG_IN_RV_DIALOG =
            "direct:erledigungOhneBescheidWeiterbearbeitungInRvDialog";

    /**
     * Routenname: Papierantrag erfasst, Erledigung ohne Bescheid.
     */
    public static final String DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID = "direct:papierantragErfassenErledigungOhneBescheid";
    /**
     * Routenname: Papierantrag erfasst, Bearbeitung abgeschlossen.
     */
    public static final String DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN =
            "direct:papierantragErfassenBearbeitungAbgeschlossen";
    /**
     * Routenname: Papierantrag erfasst, Weiterbearbeitung in rvDialog.
     */
    public static final String DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG =
            "direct:papierantragErfassenWeiterbearbeitungInRvDialog";
    /**
     * Routenname:Setze Status Statistik abgeschlossen.
     */
    public static final String DIRECT_SETZE_STATUS_STATISTIK_ABGESCHLOSSEN = "direct:setzeStatusStatistikAbgeschlossen";
    /**
     * Routenname: Status Statistik erfasst.
     */
    public static final String DIRECT_SETZE_STATUS_STATISTIK_ERFASST = "direct:setzeStatusStatistikErfasst";
}
