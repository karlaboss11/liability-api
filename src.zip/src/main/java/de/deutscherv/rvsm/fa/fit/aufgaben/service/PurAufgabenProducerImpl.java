package de.deutscherv.rvsm.fa.fit.aufgaben.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.vom.adapter.mq.common.DrvJmsHeaders;
import de.deutscherv.rvsm.fa.fit.aufgaben.jms.PurRoutes;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCompleteDTO;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCreateDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.slf4j.MDC;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_KTAN;
import static de.deutscherv.rvsm.fa.fit.util.MessagingUtils.getTraceparent;

/**
 * Implementation von PurAufgabenProducer.
 */
@Slf4j
@ApplicationScoped
public class PurAufgabenProducerImpl implements PurAufgabenProducer {

    private static final String HEADER_TRACEPARENT = "traceparent";

    private final ProducerTemplate producerTemplate;
    private final JsonWebToken jsonWebToken;
    private final DrvMandant drvMandant;
    private final String absender;
    private final String apiVersion;
    private final boolean asyncMessagingEnabled;

    /**
     * Konstruktor.
     * @param producerTemplate ProducerTemplate
     * @param jsonWebToken Json Web Token
     * @param drvMandant DRV-Mandant
     * @param absender Absender
     * @param apiVersion API-Version
     * @param asyncMessagingEnabled Async-Message-Enabled
     */
    @Inject
    public PurAufgabenProducerImpl(final ProducerTemplate producerTemplate,
            final JsonWebToken jsonWebToken,
            final DrvMandant drvMandant,
            @ConfigProperty(name = "quarkus.http.header.\"absender\"") final String absender,
            @ConfigProperty(name = "vom.asyncapi.version") final String apiVersion,
            @ConfigProperty(name = "quarkus.artemis.messaging.enabled", defaultValue = "true") final boolean asyncMessagingEnabled) {
        this.producerTemplate = producerTemplate;
        this.jsonWebToken = jsonWebToken;
        this.drvMandant = drvMandant;
        this.absender = absender;
        this.apiVersion = apiVersion;
        this.asyncMessagingEnabled = asyncMessagingEnabled;
    }

    @Override
    public void createAufgabe(final AufgabeCreateDTO aufgabeCreateDTO) {
        sendMessage(aufgabeCreateDTO, PurRoutes.DIRECT_ERSTELLE_PUR_AUFGABE);
    }

    @Override
    public void completeAufgabe(final AufgabeCompleteDTO aufgabeCompleteDTO) {
        sendMessage(aufgabeCompleteDTO, PurRoutes.DIRECT_SCHLIESSE_PUR_AUFGABE);
    }


    private void sendMessage(final Object body, final String routeName) {
        if(!asyncMessagingEnabled) {
            return;
        }

        final Map<String, Object> headers = Map.of(
                DrvJmsHeaders.MANDANT, GET_KTAN.apply(jsonWebToken, drvMandant),
                HEADER_TRACEPARENT, getTraceparent(),
                DrvJmsHeaders.API_VERSION, apiVersion,
                DrvJmsHeaders.ABSENDER, absender,
                "JMSMessageID", String.format("ID:%s", UUID.randomUUID()),
                "JMSCorrelationID", Optional.ofNullable(MDC.get(MDCKey.HEADER_CORRELATION_ID.valueOf()))
                        .orElse("")
        );

        producerTemplate.sendBodyAndHeaders(routeName, body, headers);
    }
}
