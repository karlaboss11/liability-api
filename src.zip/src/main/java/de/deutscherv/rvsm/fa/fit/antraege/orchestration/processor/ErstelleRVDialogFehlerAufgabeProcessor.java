package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum Erstellen einer Fehleraufgabe in rvDialog.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class ErstelleRVDialogFehlerAufgabeProcessor implements Processor {
    private static final List<AntragStatus> VALID_ANTRAG_STATUS_LIST =
            List.of(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN,
                    AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN);
    private final AufgabeService aufgabeService;
    private final AntragRepository antragRepository;

    @Override
    public void process(Exchange exchange) throws Exception {

        Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        if (!VALID_ANTRAG_STATUS_LIST.contains(antrag.getStatus())) {
            throw new IllegalStateException("Ein Antrag in diesem Status darf keine RVDialog Fehler Aufgabe erstellen");
        }
        aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.BESTANDSFEHLER);

        switch (antrag.getStatus()) {
            case STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN -> antrag.setStatus(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT);
            case STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN -> antrag.setStatus(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT);
            case STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN -> antrag.setStatus(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT);
            case KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN -> antrag.setStatus(AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT);
            default -> throw new IllegalStateException("");
        }
        final Antrag updatedAntrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(updatedAntrag);
        exchange.setRouteStop(true);
    }
}
