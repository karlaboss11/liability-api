package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;

/**
 * Ruft {@link AntragMapper} auf um einen eingehenden Papierantrag zu einer Entity zu mappen.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragZuEntityMapper implements Processor {

    /**
     * Routennamen zum Mapping der Papierantragsdaten zum Entity.
     */
    public static final String DIRECT_PAPIERANTRAG_ZU_ENTITY = "direct:papierantragZuEntity";


    private final AntragMapper antragMapper;

    @Override
    public void process(final Exchange exchange) {
        final PapierantragDto papierantragDto = exchange.getMessage().getBody(PapierantragDto.class);
        final String ktan = exchange.getMessage().getHeader(DRVHeader.MANDANT_PROPERTY_KEY, String.class);
        final UUID uuid = extractUuid(papierantragDto).orElse(UUID.randomUUID());

        Long rehaEinrichtungStartAufId = Optional.of(papierantragDto).map(PapierantragDto::getEinrichtung1)
                .map(RehaEinrichtungDto::getSelbstmeldeportalId)
                .orElse(null);
        Long rehaEinrichtungTrainingId = Optional.of(papierantragDto).map(PapierantragDto::getEinrichtung2)
                .map(RehaEinrichtungDto::getSelbstmeldeportalId)
                .orElse(null);
        exchange.getMessage().setHeader(RVFitCamelHeader.REHA_EINRICHTUNG_STARTAUF_ID, rehaEinrichtungStartAufId);
        exchange.getMessage().setHeader(RVFitCamelHeader.REHA_EINRICHTUNG_TRAINING_ID, rehaEinrichtungTrainingId);

        final String vorgangsId = papierantragDto.getVorgangsId();
        final String aufgabenId = papierantragDto.getAufgabenId();

        final Antrag antrag = antragMapper.toEntity(papierantragDto);
        antrag.setGeburtsdatumStatus(GeburtsdatumStatus.OK);
        antrag.setUuid(uuid);
        antrag.setKtan(ktan);
        antrag.setAntragsart(AntragsArt.PAPIERANTRAG);

        exchange.getMessage().setHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString());
        exchange.getMessage().setHeader(RVFitCamelHeader.PUR_AUFGABEN_ID, aufgabenId);
        exchange.getMessage().setBody(antrag);

        LOG.atInfo()
                .addArgument(antrag.getUuid())
                .addArgument(vorgangsId)
                .addArgument(aufgabenId)
                .addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr())
                .log("Entity aus PapierantragsDto erzeugt. UUID [{}], VorgangsId [{}], "
                        + "AufgabenId [{}], KTAN [{}] VSNR [{}]");
    }

    private Optional<UUID> extractUuid(final PapierantragDto papierantragDto) {
        return Optional.of(papierantragDto)
                .map(PapierantragDto::getAntrag)
                .map(AntragDto::getUuid)
                .filter(StringUtils::isNotBlank)
                .map(UUID::fromString);
    }
}
