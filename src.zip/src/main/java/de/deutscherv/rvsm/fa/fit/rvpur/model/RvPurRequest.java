package de.deutscherv.rvsm.fa.fit.rvpur.model;

import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.DokumentDto;

import java.util.List;
import lombok.Builder;
import lombok.Data;

/**
 * RvPurRequest.
 */
@Data
@Builder
public class RvPurRequest {

    private Stammdaten stammdaten;
    private List<DokumentDto> dokumente;
}
