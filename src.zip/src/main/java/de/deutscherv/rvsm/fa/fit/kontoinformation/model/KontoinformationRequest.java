package de.deutscherv.rvsm.fa.fit.kontoinformation.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

/**
 * Request Dto.
 *
 * @author V215169
 */
@Data
@Builder
public class KontoinformationRequest {
    private String vsnr;
    private LocalDate aktuellesDatum;
}
