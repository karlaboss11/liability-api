package de.deutscherv.rvsm.fa.fit.database;

import de.deutscherv.rvsm.ba.multitenants.runtime.persistence.DataSourceConfigurer;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.function.BiConsumer;
import oracle.jdbc.OracleConnection;

/**
 * Setzt Security Konfigurationen für Oracle Datenbanken.
 */
@ApplicationScoped
@DataSourceConfigurer.DbKind("oracle")
public class OracleConfigurer implements DataSourceConfigurer {
    /**
     * Legt JDBC-Parameter fest.
     * @param propertySetter Der {@link BiConsumer}, der die Key-Value-Paare entgegen nimmt.
     */
    public void setJdbcProperties(final BiConsumer<String, String> propertySetter) {
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT, "10");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_DEFAULT_CONNECTION_VALIDATION, "SERVER");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ALLOW_WEAK_CRYPTO, "FALSE");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_LEVEL, "REQUIRED");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_TYPES, "(AES256)");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CHECKSUM_LEVEL, "REQUIRED");
        propertySetter.accept(OracleConnection.CONNECTION_PROPERTY_THIN_NET_CHECKSUM_TYPES, "(SHA256, SHA512)");
    }
}

