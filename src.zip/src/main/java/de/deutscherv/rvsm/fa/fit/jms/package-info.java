/**
 * Beinhaltet Klassen, die sich mit JMS Queues beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.jms;
