package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Processor zum Antragstatus setzen auf STATISTIK_ABGESCHLOSSEN.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class AntragStatusStatistikAbgeschlossenProcessor implements Processor {
    private final AntragRepository antragRepository;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(Exchange exchange) throws Exception {
        Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
    }
}
