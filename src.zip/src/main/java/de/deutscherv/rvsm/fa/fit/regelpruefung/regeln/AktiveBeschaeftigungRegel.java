package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;

/**
 * Regelpruefung - Aktive Beschaeftigung.
 */
@Singleton
public class AktiveBeschaeftigungRegel extends BasisRegel {

    private static final List<String> BESCHAEFTIGUNGSGRUPPEN = List.of("101", "104", "109", "110", "140", "143");
    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL =
            Map.of(RegelUtils.ERFUELLT, "Eine aktive Beschäftigung liegt vor.",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Prüfung auf Vorlage einer aktiven Beschäftigung nicht möglich.",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es liegt keine aktive Beschäftigung vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_AKTIVEBESCHAEFTIGUNG;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!RegelUtils.kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final Boolean selbststaendigkeit = kontoinformation.getSelbstaendigkeit();
        final String beschaeftigungGruppe = kontoinformation.getBeschaeftigungGruppe();
        final String beschaeftigungGrund = kontoinformation.getBeschaeftigungGrund();
        final LocalDate beschaeftigungKobs = kontoinformation.getBeschaeftigungKobs();
        final LocalDate antragsDatum = kontext.getAntrag().getAntragsDatum();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(beschaeftigungGruppe).firstExpected("???")
                .secondValue(beschaeftigungGrund).secondExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (Boolean.TRUE.equals(selbststaendigkeit)
                || isBeschaeftigt(beschaeftigungGruppe, beschaeftigungGrund, beschaeftigungKobs, antragsDatum)) {
            return ergebnisErfuellt(this);
        }

        if ((Objects.isNull(selbststaendigkeit)) &&
                !isBeschaeftigungGruppe(beschaeftigungGruppe) ||
                !isBeschaeftigungGrund(beschaeftigungGrund) ||
                !isBeschaeftigungKobs(beschaeftigungKobs, kontext.getAntrag().getAntragsDatum())
        ) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        return ergebnisAussteuernKeineDaten(this);
    }

    private boolean isBeschaeftigt(final String beschaeftigungGruppe, final String beschaeftigungGrund,
            final LocalDate beschaeftigungKobs, final LocalDate antragsDatum) {
        return isBeschaeftigungGruppe(beschaeftigungGruppe)
                && isBeschaeftigungGrund(beschaeftigungGrund)
                && isBeschaeftigungKobs(beschaeftigungKobs, antragsDatum);
    }

    private boolean isBeschaeftigungGruppe(final String beschaeftigungGruppe) {
        return !StringUtils.isBlank(beschaeftigungGruppe)
                && BESCHAEFTIGUNGSGRUPPEN.contains(beschaeftigungGruppe.trim());
    }

    private boolean isBeschaeftigungGrund(final String beschaeftigungGrund) {
        return !StringUtils.isBlank(beschaeftigungGrund)
                && List.of("10", "50").contains(beschaeftigungGrund.trim());
    }

    private boolean isBeschaeftigungKobs(final LocalDate beschaeftigungKobs,
            final LocalDate antragsDatum) {
        return Objects.nonNull(beschaeftigungKobs) && Objects.nonNull(antragsDatum)
                && (beschaeftigungKobs.isEqual(antragsDatum.minusMonths(12))
                || beschaeftigungKobs.isAfter(antragsDatum.minusMonths(12)));
    }

}
