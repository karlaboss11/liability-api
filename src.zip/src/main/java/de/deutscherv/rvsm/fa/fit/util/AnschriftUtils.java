package de.deutscherv.rvsm.fa.fit.util;

import java.util.function.IntFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Strings;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Anschift-Utils.
 */
@UtilityClass
public class AnschriftUtils {

    private static final String PLZ_REGEXP = "\\d+";
    private static final String WHITESPACES_REGEXP = "\\s+";
    private static final String ANSCHRIFT_REGEXP =
            "^([\\p{L} .-]{1,300})\\s{1,20}(\\d{1,300}(?:\\s{0,300}[a-zA-Z])?[-\\/\\d]{0,300})$";

    /**
     * Liefert die Postleitzahl aus einem String.
     * @param text zu parsender String
     * @return gefundene Postleitzahl
     */
    public static String getPlz(final String text) {
        if (!StringUtils.isBlank(text)) {
            final String fixText = text.replaceAll(WHITESPACES_REGEXP, "");
            final Pattern pattern = Pattern.compile(PLZ_REGEXP);
            final Matcher matcher = pattern.matcher(fixText);
            while (matcher.find()) {
                final String plz = matcher.group();
                if (plz.length() == 5) {
                    return plz;
                }
            }
        }
        return null;
    }

    /**
     * Liefert die Hausnummer aus einem String.
     * @param strasseHausnummer String aus Strasse und Hausnummer
     * @return gefundene Hausnummer
     */
    public static String getHausnummer(final String strasseHausnummer) {
        return StringUtils.stripToEmpty(separateStreetAndNumber(strasseHausnummer).getRight());
    }

    /**
     * Liefert den Strassennamen aus einem String.
     * @param strasseHausnummer String aus Strasse und Hausnummer
     * @return gefundener Strassennamen
     */
    public static String getStrasse(final String strasseHausnummer) {
        return StringUtils.stripToEmpty(separateStreetAndNumber(strasseHausnummer).getLeft());
    }

    /**
     * Gibt je nach angegebener Gruppennummer entweder die Straße oder die Hausnummer eines Gesamtstring zurück. Die Straße ist mit der
     * Gruppennummer 1 und die Hausnummer mit der Gruppennummer 2 abzufragen.
     *
     * @param strasseHausnummer Strasse und Hausnummer in einem String
     * @return Pair mit Strasse und Hausnummer
     */
    private static Pair<String, String> separateStreetAndNumber(final String strasseHausnummer) {
        if (strasseHausnummer == null) {
            return Pair.of(null, null);
        }

        String streetStr = StringUtils.EMPTY;
        String numberStr = StringUtils.EMPTY;

        final Pattern pattern = Pattern.compile(ANSCHRIFT_REGEXP);
        final Matcher matcher = pattern.matcher(strasseHausnummer);
        final boolean matchFound = matcher.find();
        final int groups = matcher.groupCount();

        if (matchFound) {
            final IntFunction<String> captureValueFunction =
                    groupNr -> StringUtils.defaultIfBlank(matcher.group(groupNr), StringUtils.EMPTY);
            if (groups > 0) {
                streetStr = captureValueFunction.apply(1);
            }
            if (groups > 1) {
                numberStr = captureValueFunction.apply(2);
            }
        }

        if (Strings.CS.equals(streetStr, numberStr)) {
            numberStr = StringUtils.EMPTY;

        } else if (StringUtils.isBlank(streetStr) && StringUtils.isNotBlank(numberStr)) {
            streetStr = numberStr;
            numberStr = StringUtils.EMPTY;
        }

        return Pair.of(StringUtils.defaultIfBlank(StringUtils.trim(streetStr), strasseHausnummer),
                numberStr.trim().replaceAll(WHITESPACES_REGEXP, ""));
    }
}
