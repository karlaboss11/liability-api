package de.deutscherv.rvsm.fa.fit.exceptions.annotation;

import jakarta.enterprise.util.Nonbinding;
import jakarta.interceptor.InterceptorBinding;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * ExceptionPersist.
 */
@InterceptorBinding
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD, ElementType.TYPE })
public @interface ExceptionPersist {

    /**
     * Fehlernachricht.
     * @return Inhalt der Nachricht.
     */
    @Nonbinding
    String message() default "Ein Fehler wurde persistiert";
}