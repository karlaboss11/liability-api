package de.deutscherv.rvsm.fa.fit.antraege.model;

/**
 * Enum für den Status eines Antrags.
 */
public enum AntragStatus {

    /**
     * Entwurf ist erstellt.
     */
    ENTWURF,

    /**
     * Vorgang ist erstellt.
     */
    VORGANG_WIRD_ERSTELLT,

    /**
     * Vorgang ist erzeugt.
     */
    VORGANG_ERZEUGT,

    /**
     * Antrag Statistik ist erfasst.
     */
    STATISTIK_ERFASST,

    /**
     * Papierantrag erfassen Aufgaben sind geschlossen.
     */
    PAPIERANTRAG_GESPEICHERT,

    /**
     * Doppelvergabe, rvPur Aufgabe ist erstellt.
     */
    DOPPELVERGABE_AUFGABE_ERSTELLT,

    /**
     * Doppelvergabeprüfung ergab ok (keine Doppelvergabe).
     */
    DOPPELVERGABE_PRUEFUNG_OK,

    /**
     * Antrag ist automatisch bewilligt oder abgelehnt.
     */
    AUTOMATISCH,

    /**
     * Personendatenprüfung Fehler, rvPur Aufgabe ist erstellt.
     */
    PERSONENDATEN_AUFGABE_ERSTELLT,

    /**
     * Personenabgleich rvPur Aufagabe ist geschlossen.
     */
    RVPUR_AUFGABE_GESCHLOSSEN,

    /**
     * Anspruchprüfungs Fehler, rvPur Aufgabe ist erstellt.
     */
    ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,

    /**
     * Bemerkung im Antrag vorhanden, rvPur Aufgabe ist erstellt.
     */
    BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,

    /**
     * Entwurf ist abgeschlossen.
     */
    BESCHEID_ABGESCHLOSSEN,

    /**
     * Statistik ist abgeschlossen.
     */
    STATISTIK_ABGESCHLOSSEN,

    /**
     * Alle offenen Aufgaben sind abgeschlossen.
     */
    AUFGABE_ABGESCHLOSSEN,

    /**
     * Statistik abschließen bestandsfehler Aufgabe , rvPur Aufgabe ist zu erstellen.
     */
    STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN,

    /**
     * Statistik abschließen bestandsfehler Aufgabe , rvPur Aufgabe ist erstellt.
     */
    STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT,

    /**
     * Statistik abschließen bestandsfehler Aufgabe , rvPur Aufgabe ist erstellt.
     */
    STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN,

    /**
     * Aufgabe schließen ohne Statistik schreiben, wird benötigt für Weiterverarbeitung im RvDialog.
     */

    AUFGABE_SCHLIESSEN_OHNE_STATISTIK,

    /**
     * Statistik Antragserstellung Bestandsfehler, rvPur-Aufgabe ist zu erstellen.
     */
    STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN,
    /**
     * Statistik Antragserstellung Bestandsfehler, rvPur-Aufgabe wurde erstellt.
     */
    STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT,
    /**
     * Statistik Antragserstellung Bestandsfehler, rvPur-Aufgabe soll geschlossen werden.
     */
    STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN,
    /**
     * Bestandsfehler beim Abrufen der Kontoinformation, rvPur-Aufgabe ist zu erstellen.
     */
    KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN,
    /**
     * Bestandsfehler beim Abrufen der Kontoinformation, rvPur-Aufgabe wurde erstellt.
     */
    KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT,
    /**
     * Bestandsfehler beim Abrufen der Kontoinformation, rvPur-Aufgabe soll geschlossen werden.
     */
    KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN,
    /**
     * Kontoinformation wurde abgefragt.
     */
    KONTOINFORMATION_ABGEFRAGT,
    /**
     * Status welcher als indikator für das Erzeugen einer Aufgabe zur manuellen bearbeitung eines Stammdatenfehlers dient.
     */
    STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN,
    /**
     * Status welcher als indikator für eine Aufgabe zur manuellen bearbeitung eines Stammdatenfehlers dient.
     */
    STAMMDATEN_FEHLER_AUFGABE_ERSTELLT,
    /**
     * Status welcher als indikator für das Schließen einer Aufgabe zur manuellen bearbeitung eines Stammdatenfehlers dient.
     */
    STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN,
    /**
     * Status welcher als indikator für das Schließen einer Aufgabe zur Doppelvergabe dient.
     */
    DOPPELVERGABE_AUFGABE_SCHLIESSEN

}
