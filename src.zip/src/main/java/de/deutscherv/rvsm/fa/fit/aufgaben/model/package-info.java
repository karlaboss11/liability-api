/**
 * Enthält JPA Entities für Aufgaben.
 */
package de.deutscherv.rvsm.fa.fit.aufgaben.model;
