package de.deutscherv.rvsm.fa.fit.verarbeitung.mapper;

import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VerarbeitungsartDto;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

/**
 * Mapper für die Art wie ein Antrag geschlossen wurde.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface ArtMapper {

    /**
     * Mapping von Art zu VerarbeitungsartDto.
     * @param art zu mappen
     * @return ermittelter VararbeitungsartDto
     */
    @ValueMapping(source = "BEWILLIGUNG", target = "BEWILLIGUNG")
    @ValueMapping(source = "ABLEHNUNG", target = "ABLEHNUNG")
    @ValueMapping(source = "SACHVERHALTSAUFKLAERUNG", target = "SACHVERHALTSAUFKLAERUNG")
    @ValueMapping(source = "ERLEDIGUNG_ANDERE_ART_UND_WEISE", target = "ERLEDIGUNG_ANDERE_ART_UND_WEISE")
    @ValueMapping(source = "STORNO", target = "STORNO")
    @ValueMapping(source = "RUECKNAHME", target = "RUECKNAHME")
    @ValueMapping(source = "GESPERRT", target = "GESPERRT")
    @ValueMapping(source = "WEITERBEARBEITUNG_IN_RVDIALOG", target = "WEITERBEARBEITUNG_IN_RVDIALOG")
    VerarbeitungsartDto toDto(Art art);

    /**
     * Mapping von DokumentenklasseDto.VorlageEnum zu Art.
     * @param vorlageEnum zu mappen
     * @return ermittelte Art
     */
    @ValueMapping(source = "BEWILLIGUNG", target = "BEWILLIGUNG")
    @ValueMapping(source = "ABLEHNUNG", target = "ABLEHNUNG")
    @ValueMapping(source = "SACHVERHALTSAUFKLAERUNG", target = "SACHVERHALTSAUFKLAERUNG")
    Art toArt(DokumentenklasseDto.VorlageEnum vorlageEnum);

}
