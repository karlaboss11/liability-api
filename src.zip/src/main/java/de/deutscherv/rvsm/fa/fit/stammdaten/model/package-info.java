/**
 * Beinhaltet JPA Entities für Stammdaten.
 */
package de.deutscherv.rvsm.fa.fit.stammdaten.model;
