package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto.StatusEnum;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import static java.util.Objects.isNull;

/**
 * Diese Klasse stellt Validierungsmethoden bereit, um den Status eines Antrags zu überprüfen und sicherzustellen, dass keine Änderungen
 * zulässig sind, sobald ein Antragsverarbeitungsprozess geschlossen ist.
 *
 * @author e0180224
 */
public class StatusValidator {

    /**
     * Fehlermeldung, wenn versucht wird, einen Antrag mit geschlossenem Status zu ändern.
     */
    public static final String ERROR_CLOSED = "Die Antragsverarbeitung ist bereits abgeschlossen";

    /**
     * Liste der Status, die angeben, dass der Antragsverarbeitung abgeschlossen ist und nicht mehr geändert werden kann.
     */
    public static final List<String> CLOSED_STATUSES =
        List.of("BESCHEID_ABGESCHLOSSEN");

    /**
     * Liste der offenen Status, die angeben, dass der Antragsverarbeitung möglich ist.
     */
    public static final Set<StatusEnum> OPENED_STATUSES = EnumSet.of(
        StatusEnum.PERSONENDATEN_AUFGABE_ERSTELLT,
        StatusEnum.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
        StatusEnum.DOPPELVERGABE_AUFGABE_ERSTELLT,
        StatusEnum.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT);

    private StatusValidator() {
    }

    /**
     * Diese Methode prüft, ob ein Antragstatus ein geschlossener Status ist. Wenn der Antragstatus geschlossen ist, wird eine
     * EingabevalidierungException ausgelöst, um zu signalisieren, dass die Antragsverarbeitung nicht weiter geändert werden kann.
     *
     * @param status   Der aktuelle Status des zu validierenden Antrag.
     * @param resource Die Ressource, in dem versucht wird, die Antragsverarbeitung zu ändern.
     * @param userId   Die ID des Benutzers, der versucht, die Antragsverarbeitung zu ändern.
     * @throws EingabevalidierungException Wenn der Antragstatus geschlossen ist und eine Änderung nicht zulässig ist.
     */
    public static void canModify(final String status, final String resource, final String userId) {

        final boolean isClosed = CLOSED_STATUSES.stream().anyMatch(s -> s.equalsIgnoreCase(status));

        if (isClosed) {
            throw new EingabevalidierungException(resource, userId, ERROR_CLOSED);
        }
    }

    /**
     * Diese Methode prüft, ob ein Antragstatus ein offener Status ist. Wenn der Antragstatus offen ist, wird true zurückgegeben, um zu
     * signalisieren, dass der Antrag abgerufen werden kann.
     *
     * @param status Der aktuelle Status des zu validierenden Antrag.
     * @return {@code true}, wenn der Status offen ist
     */
    public static boolean isOpenedStatus(final StatusEnum status) {
        return OPENED_STATUSES.contains(status);
    }

    /**
     * Prüft ob der angegebene Status auf den Derzeitigen Status im übergebenen Antrag folgen kann.
     *
     * @param aktuellerStatus der Antrag Status
     * @param neuerStatus     der neue Status
     * @return {@code true}, wenn der neue Status auf den derzeitigen Status folgen kann
     */
    public static boolean isReihenfolge(final AntragStatus aktuellerStatus,
        final AntragStatus neuerStatus) {
        if (isNull(aktuellerStatus)) {
            return true;
        }
        return StatusUebergaenge.valid(aktuellerStatus, neuerStatus);

    }

}
