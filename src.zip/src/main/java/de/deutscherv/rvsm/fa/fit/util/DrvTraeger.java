package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.exceptions.MapperException;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;

/**
 * Mapping von KTAN und Namen aller DRV-Tröger.
 */
@Getter
public enum DrvTraeger {

    /**
     * DRV Nord.
     */
    NORD("02", "Nord"),
    /**
     * DRV Mitteldeutschland.
     */
    MITTELDEUTSCHLAND("09", "Mitteldeutschland"),
    /**
     * DRV Braunschweig Hannover.
     */
    BRAUNSCHWEIG_HANNOVER("10", "Braunschweig Hannover"),
    /**
     * DRV Westfalen.
     */
    WESTFALEN("11", "Westfalen"),
    /**
     * DRV Hessen.
     */
    HESSEN("12", "Hessen"),
    /**
     * DRV Rheinland.
     */
    RHEINLAND("13", "Rheinland"),
    /**
     * DRV Bayern-Süd.
     */
    BAYERN_SUED("15", "Bayern Süd"),
    /**
     * DRV Rheinland-Pfalz.
     */
    RHEINLAND_PFALZ("16", "Rheinland-Pfalz"),
    /**
     * DRV Saarland.
     */
    SAARLAND("17", "Saarland"),
    /**
     * DRV Nordbayern.
     */
    NORDBAYERN("18", "Nordbayern"),
    /**
     * DRV Schwaben.
     */
    SCHWABEN("21", "Schwaben"),
    /**
     * DRV Baden-Württemberg.
     */
    BADEN_WUERTTEMBERG("24", "Baden-Württemberg"),
    /**
     * DRV Berlin-Brandenburg.
     */
    BERLIN_BRANDENBURG("25", "Berlin-Brandenburg"),
    /**
     * DRV Oldenburg-Bremen.
     */
    OLDENBURG_BREMEN("28", "Oldenburg-Bremen"),
    /**
     * DRV Bund.
     */
    BUND("70", "Bund"),
    /**
     * DRV Knappschaft-Bahn-See.
     */
    KNAPPSCHAFT_BAHN_SEE("80", "Knappschaft-Bahn-See");

    private static final Map<String, DrvTraeger> KTAN_MAPPING = new HashMap<>();

    final String ktan;
    final String klartextName;

    DrvTraeger(final String ktan, final String klartextName) {
        this.ktan = ktan;
        this.klartextName = klartextName;
    }

    static {
        for (DrvTraeger traeger : DrvTraeger.values()) {
            KTAN_MAPPING.put(traeger.ktan, traeger);
        }
    }

    /**
     * Liefert zu einer KTAN den dazugehörigen DRV-Träger.
     *
     * @param ktan die KTAN des DRV-Trägers
     * @return den DRV-Träger
     */
    public static DrvTraeger getDrvTraeger(final String ktan) {
        return Optional.ofNullable(ktan)
            .map(KTAN_MAPPING::get)
            .orElseThrow(() -> new MapperException(
                String.format("Kein Träger für KTAN gefunden. KTAN: [%s]", ktan)));
    }

}
