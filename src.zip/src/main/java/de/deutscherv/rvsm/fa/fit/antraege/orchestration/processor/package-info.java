/**
 * {@link org.apache.camel.Processor} Klassen zur Orchestrierung von Anträgen.
 */
package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;