package de.deutscherv.rvsm.fa.fit.log;

/**
 * Enum mit Ereignisfreitexten fuer Fachereignisse.
 * <a href="https://rvwiki.drv.drv/x/74lmHw">Dokumentation Fachprotokoll</a>
 */
public enum EreignisFreitext {
    /**
     * Antragsdaten aus dem Backend abgerufen.
     */
    ANTRAGSDATEN_UEBERMITTELT("Die RV Fit-Antragsdaten wurden aus der Datenbank abgerufen."),

    /**
     * Personendaten eingegangen.
     */
    PERSONENDATEN_EINGEGANGEN("Die Personendaten wurden aus dem Versicherungskonto abgerufen."),

    /**
     * Einrichtungsdaten eingegangen.
     */
    EINRICHTUNGSDATEN_EINGEGANGEN("Die Einrichtungsdaten wurden aus dem Selbstmeldeportal abgerufen."),

    /**
     * Kontoinformationen eingegangen.
     */
    KONTOINFORMATIONEN_EINGEGANGEN("Die Kontoinformationen wurden aus dem Versicherungskonto abgerufen."),

    /**
     * Papierantrag zwischengespeichert.
     */
    PAPIERANTRAG_ZWISCHENGESPEICHERT("Während der Papierantragserfassung wurde die Eingabe zwischengespeichert."),

    /**
     * Papierantrag erfasst.
     */
    PAPIERANTRAG_GESPEICHERT("Der Papierantrag wurde gespeichert."),

    /**
     * Einrichtungsdaten gespeichert bei Papierantragserfassung.
     */
    EINRICHTUNGSDATEN_GESPEICHERT_PAPIER("Die im Papierantrag angegebenen Einrichtungsdaten wurden gespeichert."),

    /**
     * Bearbeitung des Antrags auf Erfassungsmaske abgeschlossen durch weitere Aktionen.<p> Benutzung:
     * BEARBEITUNG_ABGESCHLOSSEN_PAPIER.getText("In RV Dialog bearbeiten")</p>
     */
    BEARBEITUNG_ABGESCHLOSSEN_PAPIER("Die Bearbeitung des Papierantrags wurde ohne Entscheidung abgeschlossen. "
        + "Grund: %s."),

    /**
     * Bearbeitung des Antrags auf anderen Aussteuerungsseiten abgeschlossen durch weitere Aktionen.<p> Benutzung:
     * EreignisFreitext.BEARBEITUNG_ABGESCHLOSSEN.getText("In RV Dialog bearbeiten")</p>
     */
    BEARBEITUNG_ABGESCHLOSSEN("Die Bearbeitung des Antrags wurde ohne Entscheidung abgeschlossen. Grund: %s."),

    /**
     * eAntrag eingegangen.
     */
    ANTRAG_EINGEANGEN_E("Der elektronische Antrag ist eingegangen."),

    /**
     * eAntrag gespeichert.
     */
    ANTRAG_GESPEICHERT_E("Der elektronische Antrag wurde gespeichert."),

    /**
     * Personendaten gespeichert.
     */
    PERSONENDATEN_GESPEICHERT("Die Personendaten wurden gespeichert."),

    /**
     * Antragsdaten mit Personendaten überschrieben.
     */
    ANTRAGSDATEN_UBERSCHRIEBEN("Die Personendaten aus dem Antrag wurden mit den Personendaten aus dem "
        + "Versicherungskonto überschrieben."),

    /**
     * Einrichtungsdaten gespeichert.
     */
    EINRICHTUNGSDATEN_GESPEICHERT("Die Einrichtungsdaten wurden gespeichert."),

    /**
     * Kontoinformationen gespeichert.
     */
    KONTOINFORMATIONEN_GESPEICHERT("Die Kontoinformationen wurden gespeichert."),

    /**
     * Personendatenprüfung erfüllt nach maschineller Prüfung.
     */
    PERSONENDATEN_PRUEFUNG_ERFUELLT_MASCHINELL("Der maschinelle Abgleich zwischen Personendaten aus dem Antrag "
        + "und dem Versicherungskonto ergab keine Abweichungen."),

    /**
     * Personendatenprüfung erfüllt nach manuellem Eingriff.
     */
    PERSONENDATEN_PRUEFUNG_ERFUELLT_USER("Die Abweichungen der Personendaten aus dem Antrag und dem"
        + " Versicherungskonto wurden korrigiert."),

    /**
     * Personendatenprüfung aussteuern nach maschineller Prüfung.
     */
    PERSONENDATEN_PRUEFUNG_AUSSTEUERN_MASCHINELL("Der maschinelle Abgleich zwischen Personendaten aus dem Antrag "
        + "und dem Versicherungskonto ergab Abweichungen."),

    /**
     * Anspruchsprüfung erfüllt nach maschineller Prüfung.
     */
    ANSPRUCHS_PRUEFUNG_ERFUELLT_MASCHINELL("Die maschinelle Anspruchsprüfung wurde durchgeführt."
        + " Die Anspruchsvoraussetzungen sind erfüllt."),

    /**
     * Anspruchsprüfung erfüllt nach manuellem Eingriff.
     */
    ANSPRUCHS_PRUEFUNG_ERFUELLT_USER("Die Anspruchsprüfung wurde manuell durchgeführt."
        + " Die Anspruchsvoraussetzungen sind erfüllt."),

    /**
     * Anspruchsprüfung aussteuern nach maschineller Prüfung.
     */
    ANSPRUCHS_PRUEFUNG_AUSSTEUERN_MASCHINELL("Die maschinelle Anspruchsprüfung wurde durchgeführt."
        + " Die Anspruchsvoraussetzungen müssen manuell überprüft werden."),

    /**
     * Anspruchsprüfung führt zur Ablehnung nach maschineller Prüfung.
     */
    ANSPRUCHS_PRUEFUNG_ABLEHNEN_MASCHINELL("Die maschinelle Anspruchsprüfung wurde durchgeführt."
        + " Die Anspruchsvoraussetzungen sind nicht erfüllt."),

    /**
     * Anspruchsprüfung führt zur Ablehnung nach manuellem Eingriff.
     */
    ANSPRUCHS_PRUEFUNG_ABLEHNEN_USER("Die Anspruchsprüfung wurde manuell durchgeführt."
        + " Die Anspruchsvoraussetzungen sind nicht erfüllt."),

    /**
     * Einrichtungsprüfung erfüllt nach maschineller Prüfung.
     */
    EINRICHTUNGS_PRUEFUNG_ERFUELLT_MASCHINELL("Die maschinelle Einrichtungsprüfung wurde durchgeführt."
        + " RV Fit kann in den im Antrag angegebenen Einrichtungen durchgeführt werden."),

    /**
     * Einrichtungsprüfung erfüllt nach manuellem Eingriff.
     */
    EINRICHTUNGS_PRUEFUNG_ERFUELLT_USER("Die Einrichtungsprüfung wurde manuell durchgeführt."
        + " RV Fit kann in den im Antrag angegebenen Einrichtungen durchgeführt werden."),

    /**
     * Einrichtungsprüfung aussteuern nach maschineller Prüfung.
     */
    EINRICHTUNGS_PRUEFUNG_AUSSTEUERN_MASCHINELL("Die maschinelle Einrichtungsprüfung wurde durchgeführt."
        + " Die Einrichtungen müssen manuell überprüft werden."),

    /**
     * Bescheid versendet.
     */
    ANTRAG_BESCHIEDEN("Der RV Fit-Bescheid wurde erstellt und zur weiteren Verarbeitung übergeben."),

    /**
     * Statistik zur Antragserfassung gebildet.
     */
    STATISTIK_GEBILDET_ERFASSUNG("Die Statistik zur Antragserfassung wurde erfolgreich gebildet."),

    /**
     * Statistik zur Bescheiderteilung gebildet.
     */
    STATISTIK_GEBILDET_BESCHEID("Die Statistik zur Bescheiderteilung wurde erfolgreich gebildet."),

    /**
     * Statistik zur Bescheiderteilung gebildet.
     */
    STATISTIK_GEBILDET_ERLEDIGUNG("Die Statistik zur Antragserledigung wurde erfolgreich gebildet."),

    /**
     * Verdacht auf Doppelvergabe nach maschineller Prüfung.
     */
    DOPPELVERGABE_PRUEFUNG_AUSSTEUERN_MASCHINELL("Die maschinelle Prüfung auf Doppelvergabe wurde durchgeführt."
        + " Es liegt ein Verdacht auf Doppelvergabe vor."),

    /**
     * Keine Doppelvergabe nach manueller Prüfung.
     */
    DOPPELVERGABE_PRUEFUNG_ERFUELLT_USER("Die Prüfung auf Doppelvergabe wurde manuell durchgeführt."
        + " Der Antrag kann mit der vorliegenden Versicherungsnummer weiterverarbeitet werden."),

    /**
     * Bemerkungsfeld befüllt.
     */
    BEMERKUNG_PRUEFUNG_AUSSTEUERN_MASCHINELL("Die maschinelle Bemerkungsfeldprüfung wurde durchgeführt."
        + " Das Bemerkungsfeld ist befüllt."),

    /**
     * Bemerkungsfeld befüllt.
     */
    BEMERKUNG_PRUEFUNG_ERFUELLT_MASCHINELL("Die maschinelle Bemerkungsfeldprüfung wurde durchgeführt."
        + " Das Bemerkungsfeld ist nicht befüllt."),

    /**
     * Dokument zur Sachverhaltsaufklärung erstellt und versendet.
     */
    SACHVERHALTAUFKLAERUNG_DOKUMENT_ERSTELLT("Das Schreiben zur Sachverhaltsaufklärung wurde erstellt"
        + " und zur Weiteren Verarbeitung übergeben."),

    /**
     * Regelergebnis der Anspruchsprüfung geändert.<p> Benutzung: EreignisFreitext.ANSPRUCHSPRUEFUNG_ANGEPASST.getText("Wartezeit")</p>
     */
    ANSPRUCHSPRUEFUNG_ANGEPASST("Das Prüfergebnis zur Anspruchsvoraussetzung %s wurde manuell geändert."),

    /**
     * Regelergebnis der Anspruchsprüfung zurückgesetzt:<p> Benutzung:
     * EreignisFreitext.ANSPRUCHSPRUEFUNG_ZURUECKGESETZT.getText("Wartezeit")</p>>
     */
    ANSPRUCHSPRUEFUNG_ZURUECKGESETZT("Das Prüfergebnis zur Anspruchsvoraussetzung %s wurde manuell"
        + " auf das maschinelle Ergebnis zurückgesetzt."),

    /**
     * Einrichtungsprüfung manuell angepasst.<p> Benutzung: EreignisFreitext.EINRICHTUNGSPRUEFUNG_ANGEPASST.getText("Startphase")</p>
     */
    EINRICHTUNGSPRUEFUNG_ANGEPASST("Die Einrichtung der %s wurde manuell geändert."),

    /**
     * Vorgang erzeugt.
     */
    VORGANG_ERZEUGT("Der rvPuR-Vorgang wurde erstellt."),

    /**
     * Aufgabe erzeugt.<p> Benutzung: EreignisFreitext.EINRICHTUNGSPRUEFUNG_ANGEPASST.getText("Anspruch prüfen")</p>
     */
    AUFGABE_ERZEUGT("Die rvPuR-Aufgabe %s wurde erstellt."),

    /**
     * Aufgabe geschlossen.
     */
    AUFGABE_GESCHLOSSEN("Die rvPuR-Aufgabe %s wurde abgeschlossen.");

    private final String text;

    EreignisFreitext(final String text) {
        this.text = text;
    }

    /**
     * Text für ENUM.
     *
     * @param args der Zusatztext, der statt %s in EreignisFreitext.text() gesetzt wird
     * @return EreignisFreitext.text(), in dem %s mit args ersetzt ist
     */
    public String getText(final Object... args) {
        if (args == null || args.length == 0) {
            return text;
        }
        return String.format(text, args);
    }
}
