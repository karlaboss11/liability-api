package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import jakarta.enterprise.context.Dependent;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Extraktor fuer den Header der Antragsdaten.
 */
@Dependent
public class AntragsdatenHeaderExtractor implements Processor {
    @Override
    public void process(final Exchange exchange) throws Exception {
        final var antragsdaten = exchange.getMessage().getBody(Antragsdaten.class);
        final var vsnr = antragsdaten.getSteuerdaten().getVsnr();
        MDCUtils.setVsnr(vsnr);
        exchange.getMessage().setHeader("VSNR", vsnr);
    }
}
