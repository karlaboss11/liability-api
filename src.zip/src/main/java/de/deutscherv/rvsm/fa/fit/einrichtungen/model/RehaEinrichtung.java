package de.deutscherv.rvsm.fa.fit.einrichtungen.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.QueryHint;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity RehaEinrichtung.
 */
@Entity
@Table(name = "einrichtung")
@NamedQuery(name = "RehaEinrichtung.findAll", query = "SELECT r FROM RehaEinrichtung r ORDER BY r.id",
        hints = @QueryHint(name = "org.hibernate.cacheable", value = "true"))
@Cacheable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RehaEinrichtung {

    /** technische id der Einrichtung. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "einrichtung_uuid", referencedColumnName = "uuid")
    private List<Angebot> angebote;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "adresse_uuid", referencedColumnName = "uuid")
    private EinrichtungAnschrift adresse;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "postanschrift_uuid", referencedColumnName = "uuid")
    private EinrichtungAnschrift postanschrift;

    @Column(name = "smp_einrichtungs_id")
    private Long smpEinrichtungsId;

    @Column
    private String resc;

    @Column
    private String name;

    @Column
    private String email;

    @Column
    private String telefonnummer;

    @Column
    private Integer distanz;

    @Column(name = "distanz_versicherter")
    private Integer distanzVersicherter;

    @Column(name = "ktan")
    private String ktan;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;

    /**
     * Fügt ein Angebot hinzu.
     *
     * @param angebot die Angebot
     */
    public void addAngebot(final Angebot angebot) {
        if (Objects.isNull(angebote)) {
            angebote = new ArrayList<>();
        }
        if (Objects.isNull(angebot)) {
            return;
        }
        angebote.add(angebot);
    }
}
