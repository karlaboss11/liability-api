package de.deutscherv.rvsm.fa.fit.einrichtungen;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.einrichtungen.mapper.EinrichtungMapper;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import de.deutscherv.rvsm.fa.fit.openapi.api.RehaeinrichtungenApi;
import de.deutscherv.rvsm.fa.fit.util.TimeoutFallbackHandler;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_BST;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_EF;

/**
 * RehaEinrichtungenApiImpl.
 */
@Slf4j
@RequiredArgsConstructor
@SecurityRequirement(name = "keycloak")
@Path("/rehaeinrichtungen")
public final class RehaEinrichtungenApiImpl implements RehaeinrichtungenApi {

    private final SelbstmeldeportalService selbstmeldeportalService;
    private final EinrichtungMapper einrichtungMapper;

    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @RequiresMandant
    @Timeout(value =  20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response getAllRehaeinrichtungen() {
        LOG.atDebug().log("Suche alle Einrichtungen.");
        final var result = selbstmeldeportalService.getAlleEinrichtungen().stream()
            .map(einrichtungMapper::toAutovervollstaendigungDto).toList();

        LOG.atInfo().addArgument(result::size).log("Einrichtungen gefunden: [{}]");
        return Response.ok(result).build();
    }

    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST})
    @RequiresMandant
    @Timeout(value =  20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response suche(final String q, final Integer umkreis, final String phase,
        final String durchfuehrungsart) {
        LOG.atDebug().addArgument(q).addArgument(phase).addArgument(durchfuehrungsart)
            .log("Suche Einrichtungen gem. Filter [{}], Phase [{}], Durchfuerungsart [{}]");
        final var result = selbstmeldeportalService.suche(q, umkreis, phase, durchfuehrungsart)
            .stream().map(einrichtungMapper::toDto).toList();

        LOG.atInfo().addArgument(result::size).log("Einrichtungen gefunden: [{}]");
        return Response.ok(result).build();
    }
}
