package de.deutscherv.rvsm.fa.fit.log;

import de.deutscherv.rvsm.fa.fit.jms.producer.FachprotokollProducer;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.qs.fap.async.model.FachereignisDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * RvfitLogger.
 */
@ApplicationScoped
@Slf4j
public class RvfitLogger {

    private final FachprotokollProducer fachprotokollProducer;

    private final String ordnungsbegriff;

    private final boolean fapEnabled;

    /**
     * Konstruktor.
     *
     * @param ordnungsbegriff Ordnungsbegriff
     * @param fapEnabled      true wenn das Fachprotokoll enabled ist.
     * @param producer        Fachprotokoll-Producer
     */
    @Inject
    public RvfitLogger(@ConfigProperty(name = "fap.ordnungsbegriff") String ordnungsbegriff,
                       @ConfigProperty(name = "quarkus.artemis.messaging.enabled", defaultValue = "true") boolean fapEnabled,
                       FachprotokollProducer producer) {
        this.ordnungsbegriff = ordnungsbegriff;
        this.fapEnabled = fapEnabled;
        this.fachprotokollProducer = producer;
    }

    /**
     * Sendet ein Fachereignis, wenn das Feature Toggle enabled ist.
     *
     * @param fachereignis das Facheregnis, welches gesendet werden soll
     */
    public void sendeFachprotokollEreignis(final Fachereignis fachereignis) {
        if (!fapEnabled) {
            return;
        }
        final FachereignisDTO fachereignisDTO = new FachereignisDTO();
        fachereignisDTO
                .setAufgetretenZeitstempel(OffsetDateTime.now(ZoneId.ofOffset("UTC", ZoneOffset.UTC)));
        fachereignisDTO.setOrdnungsbegriff(
                Objects.isNull(fachereignis.ordnungsbegriff()) ? ordnungsbegriff : fachereignis.ordnungsbegriff());
        fachereignisDTO.setOrdnungsbegriffTyp(fachereignis.ordnungsbegriffTyp());
        fachereignisDTO.setEreignis(fachereignis.ereignis());
        fachereignisDTO.setEreignisTyp(fachereignis.ereignisTyp().name());
        fachereignisDTO.setFreitext(fachereignis.freitext());
        fachereignisDTO.setAufgabe(fachereignis.aufgabeDTO());
        fachereignisDTO.setVorgang(fachereignis.vorgangDTO());
        fachereignisDTO.setAusloeser(fachereignis.ausloeserDTO());

        if (Objects.nonNull(fachereignis.jwt()) && (Objects.nonNull(fachereignis.ausloeserDTO().getAusloesendePerson()))) {
            fachereignisDTO.getAusloeser().getAusloesendePerson().setDrvId(JwtUtils.GET_DRV_ID_AUS_JWT.apply(fachereignis.jwt()));
        }

        fachprotokollProducer.createFachereignis(fachereignisDTO, fachereignis.jwt());
    }
}