package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Speichert einen Antrag.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class MergeEantragsProcessor implements Processor {

    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var eantrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), eantrag);

        if (eantrag.getUuid() == null) {
            eantrag.setUuid(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.class));
            exchange.getMessage().setHeader(RVFitCamelHeader.ANTRAG_UUID, eantrag.getUuid());
        }
        eantrag = antragRepository.merge(eantrag);
        antragRepository.flush();
        exchange.getMessage().setBody(eantrag);
    }
}
