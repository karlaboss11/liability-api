package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import java.util.UUID;

/**
 * Speichert einen Antrag.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class SaveEantragsProccessor implements Processor {

    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var eantrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), eantrag);

        var uuidHeader = exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class);
        eantrag.setUuid(uuidHeader != null ? UUID.fromString(uuidHeader) : null);

        // Falls die UUID aus dem Header null war
        if (eantrag.getUuid() == null) {
            eantrag.setUuid(UUID.randomUUID());
            exchange.getMessage().setHeader(RVFitCamelHeader.ANTRAG_UUID, eantrag.getUuid().toString());
        }

        LOG.atInfo().addArgument(eantrag::getVsnr).addArgument(eantrag::getUuid)
                .setMessage("Speichere Antrag mit der VSNR [{}] unter UUID [{}]").log();
        antragRepository.persistAndFlush(eantrag);
        exchange.getMessage().setBody(eantrag);
    }
}
