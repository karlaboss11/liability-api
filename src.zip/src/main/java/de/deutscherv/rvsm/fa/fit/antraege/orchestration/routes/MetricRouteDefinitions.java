package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import lombok.experimental.UtilityClass;

import static de.deutscherv.rvsm.fa.fit.util.MetricNames.EINGEHENDE_E_ANTRAEGE;
import static de.deutscherv.rvsm.fa.fit.util.MetricNames.EINGEHENDE_PAPIERANTRAEGE;
import static de.deutscherv.rvsm.fa.fit.util.MetricNames.ERGEBNIS_REGELPRUEFUNG;

/**
 * Beinhaltet die Definitionen der Metrik Routen.
 */
@UtilityClass
public class MetricRouteDefinitions {
    /**
     * Die Basis Routenbezeichnung fuer Counter.
     */
    private static final String COUNTER_BASIS_ROUTE = "micrometer:counter:";

    /**
     * Die zusammengesetzte Route fuer den Counter von eingehenden eAntraegen.
     */
    public static final String METRIC_COUNTER_EINGEHENDE_EANTRAEGE =
            COUNTER_BASIS_ROUTE + EINGEHENDE_E_ANTRAEGE.getName() + ":simple.counter?tags=ktan=${header.drv_mandant}";

    /**
     * Die zusammengesetzte Route fuer den Counter von eingehenden Papierantraegen.
     */
    public static final String METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE =
            COUNTER_BASIS_ROUTE + EINGEHENDE_PAPIERANTRAEGE.getName() + ":simple.counter?tags=ktan=${header.drv_mandant}";

    /**
     * Die zusammengesetzte Route fuer den Counter von Regelergebnissen.
     */
    public static final String METRIC_COUNTER_ERGEBNIS_REGELPRUEFUNG =
            COUNTER_BASIS_ROUTE + ERGEBNIS_REGELPRUEFUNG.getName() + ":simple.counter";
}