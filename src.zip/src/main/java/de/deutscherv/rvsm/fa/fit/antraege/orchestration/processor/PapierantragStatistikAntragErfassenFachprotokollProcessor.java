package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Ruft {@link RvfitLogger} auf, um die statistische Erfassung ans Fachprotokoll zu melden.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragStatistikAntragErfassenFachprotokollProcessor implements Processor {

    private static final EreignisTyp EREIGNIS_TYP = EreignisTyp.ANTRAG_ERFASST;
    private static final Ereignistext EREIGNIS_TEXT = Ereignistext.VORGANG_STATISTISCH_ERFASST;
    private static final EreignisFreitext EREIGNIS_FREITEXT = EreignisFreitext.VORGANG_ERZEUGT;
    private final RvfitLogger rvfitLogger;
    private final AntragRepository antragRepository;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(final Exchange exchange) {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        LoggingUtils.logProcessorUuid(exchange.getFromRouteId(), getClass().getSimpleName(), uuid);
        final Antrag antrag = antragRepository.findByUuid(uuid).orElseThrow(() -> new NotFoundException(uuid.toString()));

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EREIGNIS_TYP,
                EREIGNIS_TEXT, EREIGNIS_FREITEXT, null, antrag, null, jwt, drvMandant));
    }
}
