package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import io.quarkus.arc.All;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;

/**
 * RegelEngine.
 */
@ApplicationScoped
public class RegelEngine {

    /**
     * Liste der registrierten Regeln.
     */
    private final List<Regel> registrierteRegeln;

    /**
     * Konstruktor.
     *
     * @param registrierteRegeln Liste der registrierten Regeln.
     */
    public RegelEngine(@All List<Regel> registrierteRegeln) {
        this.registrierteRegeln = registrierteRegeln;
    }

    /**
     * Prüft die angegebenen Regeln mit dem übergebenen Kontext.
     *
     * @param regelIds     die Namen der Regeln
     * @param regelKontext der Kontext
     * @return das Ergebnis der Prüfung
     */
    public RegelErgebnis check(final List<RegelName> regelIds, final RegelKontext regelKontext) {
        final RegelErgebnis gesamtErgebnis;
        if (regelIds == null || regelIds.isEmpty() || regelKontext == null) {
            return new RegelErgebnis(PruefErgebnis.AUSSTEUERN,
                "Interner Fehler: keine Daten übergeben!");
        }

        // auszuführende Regeln
        final List<Regel> regeln =
            registrierteRegeln.stream().filter(r -> regelIds.contains(r.getRegelName())).toList();
        // alle detailErgebnisse
        final List<RegelErgebnis> detailErgebnisse = regeln.stream()
            .map(regel -> regel.pruefeRegel(regelKontext)).flatMap(List::stream).toList();

        // Vorauswahl für das Gesamtergebnis
        final List<PruefErgebnis> ergebnisse =
            detailErgebnisse.stream().map(RegelErgebnis::getPruefErgebnis).distinct().toList();

        // Gesamtergebnis NICHT_ERFUELLT_ABLEHNEN nur wenn keine abweichende Personendaten vorhanden sind
        final boolean personendatenabgleichFailed = PruefergebnisUtils.personendatenabgleichFailed(detailErgebnisse);

        if (ergebnisse.contains(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN) && !personendatenabgleichFailed) {
            gesamtErgebnis = new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN,
                RegelErgebnis.getGesamtDetail(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN));
        } else if (ergebnisse.contains(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)) {
            gesamtErgebnis = new RegelErgebnis(PruefErgebnis.AUSSTEUERN,
                RegelErgebnis.getGesamtDetail(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN));
        } else if (ergebnisse.isEmpty() || ergebnisse.contains(PruefErgebnis.AUSSTEUERN)) {
            gesamtErgebnis = new RegelErgebnis(PruefErgebnis.AUSSTEUERN,
                RegelErgebnis.getGesamtDetail(PruefErgebnis.AUSSTEUERN));
        } else {
            gesamtErgebnis = new RegelErgebnis(PruefErgebnis.ERFUELLT,
                RegelErgebnis.getGesamtDetail(PruefErgebnis.ERFUELLT));
        }

        gesamtErgebnis.setDetailErgebnisse(detailErgebnisse);
        return gesamtErgebnis;
    }
}
