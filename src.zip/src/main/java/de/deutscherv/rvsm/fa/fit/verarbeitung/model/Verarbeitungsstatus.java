package de.deutscherv.rvsm.fa.fit.verarbeitung.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Enttity Verarbeitungsstatus.
 */
@Entity
@Table(name = "verarbeitungsstatus")
@NamedQuery(name = "Verarbeitungsstatus.findAll", query = "SELECT vs FROM Verarbeitungsstatus vs")
@Cacheable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Verarbeitungsstatus {

    /**
     * UUID des Verbeitungsstatus.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastmodified;

    @Column(name = "antrag_id")
    private UUID antragId;

    @Column(name = "art")
    @Enumerated(EnumType.STRING)
    private Art art;

    @Column(name = "auftrag_id")
    private UUID auftragId;

    @Column
    @Enumerated(EnumType.STRING)
    private VerarbeitungStatus status;

    @Column
    private String meldung;

}