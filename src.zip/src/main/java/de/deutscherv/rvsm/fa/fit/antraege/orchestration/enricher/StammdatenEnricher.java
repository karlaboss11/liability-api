package de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Erweitert einen Antrag um die Stammdaten aus RVDialog und speichert diesen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class StammdatenEnricher implements Processor {
    private final StammdatenService stammdatenService;
    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;

    @Override
    @RequiresMandant
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        try {
            bestandsfehlerRepository.schliesseAlleBestandsfehlerZuAntrag(antrag.getUuid());
            final var stammdatenByVsnr = stammdatenService.getStammdatenByVsnr(antrag, true);

            antrag.addVersicherte(stammdatenByVsnr);
            if (antrag.getStatus() == AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT) {
                antrag.setStatus(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN);
            }
        } catch (StammdatenBestandsFehlerException sbf) {
            FehlerEintragDto fehlerEintragDto = sbf.getFehlerEintragDto();
            bestandsfehlerRepository.persist(Bestandsfehler.builder().antragId(antrag.getUuid()).bestandsfehlercode(
                    fehlerEintragDto.getStatuscode()).build());

            Set<AntragStatus> statusMitOffenerAufgabe = Set.of(AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
                    AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                    AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT);

            if (!statusMitOffenerAufgabe.contains(antrag.getStatus())) {
                antrag.setStatus(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN);
            }
            exchange.getMessage().setHeader(RVFitCamelHeader.STAMMDATEN_BESTANDSFEHLER, sbf);
        }

        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
    }
}
