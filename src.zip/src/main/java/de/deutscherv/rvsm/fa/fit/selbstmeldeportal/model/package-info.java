/**
 * Beinhaltet DTOs für das Selbstmeldeportal.
 */
package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;
