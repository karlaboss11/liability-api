package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Processor für die Prüfung auf Doppelvergabe.
 * 
 * @author U38322
 *
 */
@ApplicationScoped
@RequiredArgsConstructor
public class DoppelvergabeProcessor implements Processor {

    private final AufgabeService aufgabeService;
    private final AntragRepository antragRepository;
    private final RvfitLogger rvfitLogger;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    /**
     * Prüft, ob die VSNR des Antrags doppelt vergeben ist.
     * Wenn ja wird eine entsprechende rvPur Ausgabe erstellt
     * und die Weiterverarbeitung an dieser stelle gestoppt.
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        if (antrag.getDoppelvergabe() == DoppelvergabeStatus.PRUEFEN) {
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.DOPPELVERGABE);
            antrag.setStatus(AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT);

            rvfitLogger.sendeFachprotokollEreignis(
                    LogUtils.getFachereignis(
                            EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                            Ereignistext.DOPPELVERGABE_PRUEFUNG_DURCHGEFUEHRT,
                            EreignisFreitext.DOPPELVERGABE_PRUEFUNG_AUSSTEUERN_MASCHINELL,
                            null,
                            antrag,
                            null,
                            jwt,
                            drvMandant)
            );

            exchange.setRouteStop(true);
        } else {
            antrag.setStatus(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);
        }
        
        antrag = antragRepository.merge(antrag);
        exchange.getMessage().setBody(antrag);
    }

}
