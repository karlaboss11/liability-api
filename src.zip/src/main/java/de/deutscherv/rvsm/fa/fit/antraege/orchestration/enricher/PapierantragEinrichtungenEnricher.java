package de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Ruft {@link SelbstmeldeportalService} auf um die Einrichtungsobjekte im Antrag zu setzen.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragEinrichtungenEnricher implements Processor {

    /**
     * Routename zum Hinzufügen von Einrichtungen bei Papieranträgen.
     */
    public static final String DIRECT_PAPIERANTRAG_EINRICHTUNGEN_HINZUFUEGEN = "direct:papierantragEinrichtungen";

    private final AntragRepository antragRepository;
    private final SelbstmeldeportalService selbstmeldeportalService;

    @Override
    public void process(final Exchange exchange) {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        final Antrag antrag = antragRepository.findByUuid(uuid).orElseThrow(NotFoundException::new);

        final Long rehaEinrichtungStartAufId = exchange.getMessage().getHeader(RVFitCamelHeader.REHA_EINRICHTUNG_STARTAUF_ID, Long.class);
        getEindeutigeEinrichtungStartUndAuffrischung(rehaEinrichtungStartAufId, PhaseEnumDto.STARTPHASE)
                .ifPresent(rehaEinrichtung -> {
                    antrag.setEinrichtungStartObjekt(rehaEinrichtung);
                    antrag.setAngebotStartSmpId(Optional.of(rehaEinrichtung).map(RehaEinrichtung::getAngebote).map(List::getFirst).map(
                            Angebot::getSmpAngebotId).orElse(null));
                });
        getEindeutigeEinrichtungStartUndAuffrischung(rehaEinrichtungStartAufId, PhaseEnumDto.AUFFRISCHUNG)
                .ifPresent(rehaEinrichtung -> {
                    antrag.setEinrichtungAufObjekt(rehaEinrichtung);
                    antrag.setAngebotAufSmpId(Optional.of(rehaEinrichtung).map(RehaEinrichtung::getAngebote).map(List::getFirst).map(
                            Angebot::getSmpAngebotId).orElse(null));
                });


        final Long rehaEinrichtungTrainingId = exchange.getMessage().getHeader(RVFitCamelHeader.REHA_EINRICHTUNG_TRAINING_ID, Long.class);
        getEindeutigeEinrichtungTraining(rehaEinrichtungTrainingId)
                .ifPresent(rehaEinrichtung -> {
                    antrag.setEinrichtungTrainingObjekt(rehaEinrichtung);
                    antrag.setAngebotTrainingSmpId(Optional.of(rehaEinrichtung).map(RehaEinrichtung::getAngebote).map(List::getFirst).map(
                            Angebot::getSmpAngebotId).orElse(null));
                });

        final Antrag antragMerged = antragRepository.merge(antrag);
        exchange.getMessage().setBody(antragMerged);

        LOG.atInfo()
                .addArgument(rehaEinrichtungStartAufId)
                .addArgument(rehaEinrichtungTrainingId)
                .addArgument(antrag.getUuid())
                .addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr())
                .log("RehaEinrichtungen mit SMP-IDs hinzugefügt. START/AUF: [{}] TRAINING: [{}] UUID: [{}], KTAN [{}] VSNR [{}]");
    }

    private Optional<RehaEinrichtung> getEindeutigeEinrichtungTraining(final Long rehaEinrichtungSmpId) {
        return Optional.ofNullable(rehaEinrichtungSmpId)
                .map(smpId -> getRehaEinrichtung(smpId, PhaseEnumDto.TRAININGSPHASE))
                .map(rehaEinrichtung -> {
                    EinrichtungsdatenUtils.deleteAngeboteOhneFreiePlaetzeFromEinrichtung(PhaseEnumDto.TRAININGSPHASE, rehaEinrichtung);
                    return rehaEinrichtung;
                })
                .filter(rehaEinrichtung -> Optional.ofNullable(rehaEinrichtung.getAngebote()).map(List::size).orElse(0) == 1);
    }

    private Optional<RehaEinrichtung> getEindeutigeEinrichtungStartUndAuffrischung(final Long rehaEinrichtungSmpId,
            final PhaseEnumDto phase) {
        return Optional.ofNullable(rehaEinrichtungSmpId)
                .map(smpId -> getRehaEinrichtung(smpId, phase))
                .map(rehaEinrichtung -> selbstmeldeportalService.eindeutigeEinrichtungMitStartphase(phase, rehaEinrichtung));
    }

    private RehaEinrichtung getRehaEinrichtung(final Long rehaEinrichtungSmpId, final PhaseEnumDto phase) {
        return selbstmeldeportalService.getEinrichtungById(rehaEinrichtungSmpId)
                .orElseThrow(() -> new RuntimeException(getFehlerTextForPhase(phase)));
    }

    private String getFehlerTextForPhase(final PhaseEnumDto phase) {
        return String.format("Keine passende Einrichtung zur Phase [%s] gefunden.", phase.name());
    }
}
