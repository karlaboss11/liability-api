package de.deutscherv.rvsm.fa.fit.stammdaten;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.exceptions.annotation.ExceptionPersist;
import de.deutscherv.rvsm.fa.fit.openapi.model.ErrorResponseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.StammdatenMapper;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.util.LandIsoCodes;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 * Service für Stammdaten.
 */
@ApplicationScoped
@Slf4j
public class StammdatenService {

    /**
     * Fehlercode aus Bestand fuer Mitarbeiterschutz.
     */
    public static final String MITARBEITERSCHUTZ = "EA-KTO-025";
    /**
     * Fehlercode aus Bestand fuer Zeugenschutz.
     */
    public static final String ZEUGENSCHUTZ = "EA-KTO-026";

    /**
     * Set der Fehlermeldung die einen Schutzbedarf anzeigen.
     */
    public static final Set<String> AF_FEHLER_SCHUTZBEDARF = Set.of("AF0064", "AF0075", "AF0079",
        "GBAF0064", "GBAF0075", "GBAF0079");

    // kein AF oder nicht exakt 6 Ziffern
    private static final Pattern KEIN_AF_FEHLER = Pattern.compile("^(?!.*AF)(?!.*\\b\\d{6}\\b).+$");

    private final StammdatenClient stammdatenClient;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final StammdatenMapper stammdatenMapper;
    private final AntragRepository antragRepository;
    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;

    /**
     * Konstruktor.
     *
     * @param stammdatenClient         Stammdaten-Client
     * @param rVFitJsonSchemaValidator rvFit-Json-Schema-Validator
     * @param stammdatenMapper         Stammdaten-Mapper
     * @param antragRepository         Antrag-Repository
     * @param drvMandant               DRV-Mandant
     * @param jwt                      JWT
     * @param rvfitLogger              rvFit-Logger
     */
    @Inject
    public StammdatenService(
        @RestClient final StammdatenClient stammdatenClient,
        final RVFitJsonSchemaValidator rVFitJsonSchemaValidator,
        final StammdatenMapper stammdatenMapper,
        final AntragRepository antragRepository,
        final DrvMandant drvMandant,
        final JsonWebToken jwt, RvfitLogger rvfitLogger) {
        this.stammdatenClient = stammdatenClient;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.stammdatenMapper = stammdatenMapper;
        this.antragRepository = antragRepository;
        this.jwt = jwt;
        this.drvMandant = drvMandant;
        this.rvfitLogger = rvfitLogger;
    }

    /**
     * Personenstammdaten werden über Schnittstelle gelesen & als StammdatenDto zurueckgegeben.
     *
     * @param antrag der Antrag
     * @return Stammdaten-Dto
     * @throws StatistikException Fehler beim Erstellen der Statistik
     */
    public StammdatenDto getStammdatenDtoByVsnr(final Antrag antrag) {
        return stammdatenMapper.toStammdatenDtoFromKontoDto(getKontoDto(antrag));
    }

    /**
     * Personenstammdaten werden über Schnittstelle gelesen & als StammdatenDto zurueckgegeben.
     *
     * @param ktan KTAN des Traegers
     * @param vsnr Versicherungsnr.
     * @return Stammdaten-Dto
     * @throws StatistikException Fehler beim Erstellen der Statistik
     */
    public StammdatenDto getStammdatenDtoByVsnr(final String ktan, final String vsnr) {
        return stammdatenMapper.toStammdatenDtoFromKontoDto(getKontoDto(Antrag.builder().ktan(ktan).vsnr(vsnr)
            .vorname("").nachname("").build()));
    }

    /**
     * Personenstammdaten werden über Schnittstelle gelesen & als Entity zurueckgegeben.
     *
     * @param antrag der Antrag
     * @param telefonAktualisieren <code>true</code>, falls die Telefonnummer aus dem Konto im Antrag gespeichert
     *                             werden soll, ansonsten <code>false</code>
     * @return Stammdaten-Entity
     * @throws StatistikException Fehler beim Erstellen der Statistik
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Stammdaten")
    public Stammdaten getStammdatenByVsnr(final Antrag antrag, final boolean telefonAktualisieren) {
        final var kontoDto = getKontoDto(antrag);
        if(telefonAktualisieren) {
            aktualisiereTelefonnummer(antrag, kontoDto);
        }
        return stammdatenMapper.toStammdatenFromKontoDto(kontoDto);
    }

    /**
     * Prüft, ob im Antrag eine Telefonnummer angegeben wurde.
     * Fallls nicht, wird die im Konto hinterlegte Telefonnummer im Antrag gespeichert.
     *
     * @param antrag der Antrag
     * @param kontoDto das Dto zum Konto der versicherten Person
     */
    private static void aktualisiereTelefonnummer(final Antrag antrag, final KontoDto kontoDto) {
        if(antrag.getTelefon() == null || antrag.getTelefon().isBlank()) {
            Optional.ofNullable(kontoDto)
                    .map(KontoDto::getPersonen)
                    .map(List::getFirst)
                    .map(PersonDto::getTelefon)
                    .ifPresent(antrag::setTelefon);
        }
    }

    /**
     * Personenstammdaten werden über Schnittstelle gelesen & als Entity zurueckgegeben.
     *
     * @param antrag der Antrag
     * @return Stammdaten-Entity
     * @throws StatistikException Fehler beim Erstellen der Statistik
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Stammdaten")
    public Stammdaten getStammdatenByVsnr(final Antrag antrag) {
        return getStammdatenByVsnr(antrag, false);
    }


    /**
     * Kontoinfos werden über Schnittstelle gelesen & als KontoDto zurueckgegeben.
     *
     * @param antrag der Antrag
     * @return Stammdaten-Entity
     * @throws StatistikException                Fehler beim Erstellen der Statistik
     * @throws StammdatenBestandsFehlerException Wenn beim Abrufen der Stammdaten ein Fehler aufgetreten ist
     * @throws StammdatenException               Wenn das Konto gesperrt ist
     */
    public KontoDto getKontoDto(final Antrag antrag)
        throws StammdatenBestandsFehlerException, StatistikException, StammdatenException {
        final String vsnr = antrag.getVsnr();
        final String ktan = antrag.getKtan();
        LOG.atInfo().addArgument(vsnr).addArgument(ktan)
            .log("Lese Stammdaten für Versicherungsnummer [{}], KTAN [{}]");
        MDCUtils.setInScope(MDCKey.DRV_MANDANT, ktan);
        try (Response response = stammdatenClient.getKonto(vsnr, ktan)) {
            final KontoDto kontoDto = response.readEntity(KontoDto.class);
            if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.STAMMDATEN, kontoDto)) {
                throw new IllegalArgumentException("Kein valides Konto angegeben: " + kontoDto);
            }

            kontoDto.getPersonen().forEach(personDto ->
            {
                LOG.atInfo().addArgument(personDto.toString())
                    .log("Erhaltene Stammdaten(PersonDto):  [{}]");
                if (personDto.getAnschrift().getLaenderschluessel() == null) {
                    personDto.getAnschrift().setLaenderschluessel(LandIsoCodes.DEUTSCHLAND.getNtsc());
                }
            });

            EreignisTyp ereignisTyp = EreignisTyp.NACHRICHTEN_EINGANG_MASCHINELL;
            if (JwtUtils.isJwtVonUser(jwt)) {
                ereignisTyp = EreignisTyp.NACHRICHTEN_EINGANG_USER;
            }
            rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignisOhneAntrag(
                ereignisTyp,
                Ereignistext.PERSONENDATEN_EINGEGANGEN,
                EreignisFreitext.PERSONENDATEN_EINGEGANGEN,
                vsnr,
                jwt,
                drvMandant
            ));

            return kontoDto;
        } catch (final WebApplicationException e) {
            handleException(antrag, e);
        }
        return null;
    }

    private void handleException(final Antrag antrag, final WebApplicationException e) {
        switch (e.getResponse().getStatus()) {
            case 423:
                stammdatenSindGesperrt(antrag.getKtan(), antrag.getVsnr(), e);
                break;

            case 404:
                stammdatenNichtGefunden(antrag.getKtan(), antrag.getVsnr());
                break;

            case 500:
                bestandsfehlerAufgetreten(antrag, e);
                break;

            default:
                allgemeinerStammdatenfehler(antrag.getKtan(), antrag.getVsnr(), e);
        }
    }

    /**
     * Bearbeitung wenn die Stammdaten gesperrt sind.
     *
     * @param ktan                    KTAN des Traegers
     * @param vsnr                    Versicherungsnr.
     * @param webApplicationException aufgetretene Exception
     */
    private void stammdatenSindGesperrt(final String ktan, final String vsnr, final WebApplicationException webApplicationException) {
        if (isSchutzbedarf(webApplicationException)) {
            erledigeWegenSchutzbedarfUndWirfException(ktan, vsnr, webApplicationException);
        }
        LOG.atWarn().addArgument(ktan).addArgument(vsnr)
            .log("Stammdaten gesperrt KTAN [{}], VSNR [{}]");
        throw new StammdatenException("Stammdaten gesperrt");
    }

    /**
     * Bearbeitung wenn keine Stammdaten gefunden wurden.
     *
     * @param ktan KTAN des Traegers
     * @param vsnr Versicherungsnr.
     */
    private void stammdatenNichtGefunden(final String ktan, final String vsnr) {
        LOG.atWarn().addArgument(ktan).addArgument(vsnr)
            .log("Stammdaten wurde nicht gefunden KTAN [{}], VSNR [{}]");
        throw new NotFoundException("Stammdaten wurden nicht gefunden");
    }

    /**
     * Bearbeitung wenn ein Bestandsfehler aufgetreten ist.
     *
     * @param antrag                  der Antrag
     * @param webApplicationException aufgetretene Exception
     */
    private void bestandsfehlerAufgetreten(final Antrag antrag, final WebApplicationException webApplicationException)
        throws StammdatenBestandsFehlerException {
        final String ktan = antrag.getKtan();
        final String vsnr = antrag.getVsnr();

        if (webApplicationException.getResponse().hasEntity()) {
            final FehlerEintragDto fehlerEintragDto = webApplicationException.getResponse().readEntity(FehlerEintragDto.class);

            String statuscode = Optional.ofNullable(fehlerEintragDto).map(FehlerEintragDto::getStatuscode).orElse("");

            LOG.atWarn().addArgument(ktan).addArgument(vsnr).addArgument(statuscode)
                .log("Ein Bestandsfehler ist aufgetreten KTAN [{}], VSNR [{}], STATUSCODE [{}]");

            if (AF_FEHLER_SCHUTZBEDARF.contains(statuscode)) {
                erledigeWegenSchutzbedarfUndWirfException(ktan, vsnr, webApplicationException);
            }

            // nicht-AF-Fehler
            if (KEIN_AF_FEHLER.matcher(statuscode).matches()) {
                throw new StammdatenException("Stammdaten konnten nicht eingeholt werden");
            }

            throw new StammdatenBestandsFehlerException("Es sind Bestandsfehler aufgetreten", antrag, fehlerEintragDto);
        }
        throw webApplicationException;
    }

    private void erledigeWegenSchutzbedarfUndWirfException(final String ktan, final String vsnr,
        final WebApplicationException webApplicationException) {
        LOG.atDebug().log("Zugriff auf Versicherungsnummer wegen Schutzbedarf gesperrt.");
        loescheEntwurf(ktan, vsnr);
        throw new KontoGesperrtException(vsnr, ktan, webApplicationException);
    }

    /**
     * Bearbeitung wenn ein sonstiger Fehler aufgetreten ist.
     *
     * @param ktan                    KTAN des Traegers
     * @param vsnr                    Versicherungsnr.
     * @param webApplicationException aufgetretene Exception
     */
    private void allgemeinerStammdatenfehler(final String ktan, final String vsnr, final WebApplicationException webApplicationException) {
        LOG.atWarn().addArgument(webApplicationException.getResponse().getStatus()).addArgument(ktan).addArgument(vsnr)
            .log("Stammdaten konnten nicht ermittelt werden. StatusCode [{}], KTAN [{}], VSNR [{}]");
        throw new StammdatenException("Stammdaten konnten nicht eingeholt werden");
    }

    /**
     * Löscht evtl. vorhandene Papierantragsentwürfe.
     *
     * @param ktan DRV
     * @param vsnr Versicherungsnummer
     */
    @Transactional
    public void loescheEntwurf(final String ktan, final String vsnr) {
        drvMandant.setInScope(ktan);
        antragRepository.deletePapierantragEntwurfByVsnr(vsnr);
        antragRepository.flush();
    }

    /**
     * Feststellen, ob Schutzbedarf besteht.
     *
     * @param e Exception
     * @return true - Schutzbedarf
     */
    private static boolean isSchutzbedarf(final WebApplicationException e) {
        if (e.getResponse().hasEntity()) {
            final ErrorResponseDto errorResponseDto = e.getResponse().readEntity(ErrorResponseDto.class);
            return errorResponseDto.getConstraintViolations().stream().
                anyMatch(b -> b.getValue().equals(MITARBEITERSCHUTZ)
                    || b.getValue().equals(ZEUGENSCHUTZ));
        }
        return false;
    }

}
