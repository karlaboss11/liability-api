package de.deutscherv.rvsm.fa.fit.statistik.util;

import lombok.Getter;

/**
 * Moegliche StatistikTypen.
 */
@Getter
public enum StatistikTyp {

    /**
     * PNR-Wert fuer die Antragserfassung.
     */
    ANTRAGSERFASSUNG("5"),

    /**
     * PNR-Wert fuer die Uebermittlung von Bescheiddaten.
     */
    BESCHEIDDATEN("15");

    private final String pnrWert;

    /**
     * Konstrukto mit pnrWert.
     *
     * @param pnrWert PnrWert
     */
    StatistikTyp(final String pnrWert) {
        this.pnrWert = pnrWert;
    }
}
