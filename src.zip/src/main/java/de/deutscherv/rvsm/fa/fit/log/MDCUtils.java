package de.deutscherv.rvsm.fa.fit.log;

import java.util.Map;
import lombok.experimental.UtilityClass;
import org.slf4j.MDC;

/**
 * Utility Klasse zur Arbeit mit dem MDC.
 *
 * @author U38322
 */
@UtilityClass
public class MDCUtils {

    /**
     * Setzt das MDC Feld {@code event-success} auf {@code false}.
     */
    public static void setFailed() {
        MDC.put(MDCKey.EVENT_SUCCESS.valueOf(), "false");
    }

    /**
     * Setzt das MDC Feld {@code vsnr} auf die uebrgebene Vsnr.
     *
     * @param vsnr die Vsnr
     */
    public static void setVsnr(final String vsnr) {
        MDC.put(MDCKey.VSNR.valueOf(), vsnr);
    }

    /**
     * Setzt das MDC Feld {@code correlationId} auf die üebrgebene CorreltaionId.
     *
     * @param correlationId die CcorreltaionId
     */
    public static void setCorrelationId(final String correlationId) {
        MDC.put(MDCKey.HEADER_CORRELATION_ID.valueOf(), correlationId);
    }

    /**
     * Setzt alle MDC-Felder auf die uebergenene Werte.
     *
     * @param map die uebernommen werden soll
     */
    public static void setAllInScope(final Map<MDCKey, String> map) {
        map.forEach((key, value) -> MDC.put(key.valueOf(), value));
    }

    /**
     * Setzt ein MDC auf einen den uebergebenen Wert.
     *
     * @param key   der gesetzt werden soll
     * @param value der gesetzt werden soll
     */
    public static void setInScope(final MDCKey key, final String value) {
        MDC.put(key.valueOf(), value);
    }

    /**
     * Entfernt die MDC Felder, die von der Anwendung gesetzt wurden aus dem MDC.
     */
    public static void clearMDC() {
        MDC.remove(MDCKey.EVENT_SUCCESS.valueOf());
        MDC.remove(MDCKey.SECURITY_LEVEL.valueOf());
        MDC.remove(MDCKey.SESSION_ID.valueOf());
        MDC.remove(MDCKey.SOURCE_IP.valueOf());
        MDC.remove(MDCKey.USER_ID.valueOf());
        MDC.remove(MDCKey.VSNR.valueOf());
        MDC.remove(MDCKey.HEADER_CORRELATION_ID.valueOf());
    }
}
