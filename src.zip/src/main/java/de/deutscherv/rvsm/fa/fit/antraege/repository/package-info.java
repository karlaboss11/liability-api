/**
 * Beinhaltet Repositories für Anträge.
 */
package de.deutscherv.rvsm.fa.fit.antraege.repository;
