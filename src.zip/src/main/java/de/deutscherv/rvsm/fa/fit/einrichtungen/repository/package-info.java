/**
 * Beinhaltet Repositories für Einrichtungen.
 */
package de.deutscherv.rvsm.fa.fit.einrichtungen.repository;
