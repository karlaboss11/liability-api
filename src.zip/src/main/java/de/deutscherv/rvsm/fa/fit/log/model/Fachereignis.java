package de.deutscherv.rvsm.fa.fit.log.model;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.qs.fap.async.model.AufgabeDTO;
import de.deutscherv.rvsm.qs.fap.async.model.AusloeserDTO;
import de.deutscherv.rvsm.qs.fap.async.model.VorgangDTO;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Daten Klasse für Fachereignisse.
 *
 * @param ordnungsbegriff    Ordungsbegriff
 * @param ordnungsbegriffTyp Typ Ordnungsbegriff
 * @param ereignis           Ereignis
 * @param ereignisTyp        Typ Ereignis
 * @param freitext           Freitext
 * @param aufgabeDTO         Aufgaben-DTO
 * @param vorgangDTO         Vorgang-DTO
 * @param ausloeserDTO       Ausloeser-DTO
 * @param jwt                JSON-Web-Ticket
 * @param drvMandant         DRV-Mandatn
 */
public record Fachereignis(String ordnungsbegriff, String ordnungsbegriffTyp, String ereignis,
    EreignisTyp ereignisTyp, String freitext, AufgabeDTO aufgabeDTO, VorgangDTO vorgangDTO,
    AusloeserDTO ausloeserDTO, JsonWebToken jwt, DrvMandant drvMandant) {

}
