package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor Regelpruefung.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class RegelpruefungsProcessor implements Processor {

    private final PruefergebnisService pruefergebnisService;
    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);

        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);

        final RegelErgebnis regelErgebnis = pruefergebnisService.berechnePruefergebnis(antrag);

        pruefergebnisService.speicherePruefergebnis(antrag, regelErgebnis);

        pruefergebnisService.erstelleAufgabenZumPruefergebnis(antrag, regelErgebnis);

        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
        LOG.atDebug().addArgument(antrag).log("Persistiere Antrag [{}] in DB");

    }
}
