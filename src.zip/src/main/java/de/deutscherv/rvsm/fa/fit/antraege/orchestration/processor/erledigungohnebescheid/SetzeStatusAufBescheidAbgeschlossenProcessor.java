package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.RVPUR_AUFGABE_GESCHLOSSEN;

/**
 * Processor um den Status Abgeschlossen zu setzen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SetzeStatusAufBescheidAbgeschlossenProcessor implements Processor {

    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        if (antrag.getStatus() == PERSONENDATEN_AUFGABE_ERSTELLT) {
            antrag.setStatus(RVPUR_AUFGABE_GESCHLOSSEN);
        }
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag = antragRepository.merge(antrag);
        exchange.getMessage().setBody(antrag);
    }
}
