package de.deutscherv.rvsm.fa.fit.aufgaben;

/**
 * Hilfsklasse mit Konstanten für die Abschlussgründe von Aufgaben.
 */
public final class AufgabenAbschlussGrund {

    /**
     * Abschlussgrund: Antrag bewilligt.
     */
    public static final String BEWILLIGT = "bewilligt";

    /**
     * Abschlussgrund: Antrag abgelehnt.
     */
    public static final String ABLEHNUNG = "ablehnung";

    /**
     * Abschlussgrund: Antrag auf andere Art und Weise erledigt.
     */
    public static final String ANDERE_ART_UND_WEISE = "andere_art_und_weise";

    /**
     * Abschlussgrund: Antrag zurückgenommen.
     */
    public static final String RUECKNAHME = "ruecknahme";

    /**
     * Abschlussgrund: Antrag storniert.
     */
    public static final String STORNIERUNG = "storno";

     /**
     * Abschlussgrund: An anderen Träger weitergeleitet.
     */
    public static final String GESPERRT = "gesperrt";

    /**
     * Abschlussgrund: Weiterbearbeitung in rvDialog.
     */
    public static final String WEITERBEARBEITUNG_IN_RVDIALOG = "rvDialog";

    /**
     * Privater Konstruktor.
     */
    private AufgabenAbschlussGrund() {
    }
}
