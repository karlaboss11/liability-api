package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.slf4j.MDC;

/**
 * Filter, der die Sicherheitsanfoderungen bzgl. Http-Headern für Web-Server im Allgemeinen und für das Ausliefern von REST-APIs im
 * Speziellen umsetzt.
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class SecurityHeaderFilter
    implements ContainerRequestFilter, ContainerResponseFilter, ClientRequestFilter {

    @ConfigProperty(name = "quarkus.http.header.\"api_version\".value")
    private String apiVersion;

    @ConfigProperty(name = "quarkus.http.header.\"absender\"")
    private String absender;

    @Getter
    @Setter
    @ConfigProperty(name = "disable.authorization", defaultValue = "false")
    private boolean disableAuthorization;

    @Override
    public void filter(final ContainerRequestContext containerRequestContext) throws IOException {
        fillSecurityHeaders(containerRequestContext.getHeaders());
    }

    @Override
    public void filter(final ClientRequestContext clientRequestContext) throws IOException {
        fillSecurityHeadersClient(clientRequestContext.getHeaders());
    }

    @Override
    public void filter(final ContainerRequestContext requestContext,
        final ContainerResponseContext containerResponseContext) throws IOException {
        fillSecurityHeaders(containerResponseContext.getHeaders());
    }

    private <T> void fillSecurityHeadersClient(final MultivaluedMap<String, T> headers) {
        headers.remove(HttpHeaders.CONTENT_TYPE);
        getHeaders().forEach((k, v) -> headers.add(k, (T) v));
    }

    private <T> void fillSecurityHeaders(final MultivaluedMap<String, T> headers) {
        getHeaders().forEach((k, v) -> headers.add(k, (T) v));
    }

    private Map<String, String> getHeaders() {
        final Map<String, String> headers = new HashMap<>();

        // Explizite Definition von Content Types für Responses; pauschal für REST-API immer json
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);

        // Strict-Transport-Security: HTTP Strict Transport Security
        headers.put("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        // X-Content-Type-Options: Disables content-type sniffing
        headers.put("X-Content-Type-Options", "nosniff");
        // X-Frame-Options: Prevents clickjacking
        headers.put("X-Frame-Options", "SAMEORIGIN");
        // Content-Security-Policy: Helps prevent cross-site scripting attacks
        headers.put("Content-Security-Policy", "default-src 'self'");
        // X-XSS-Protection: For older browsers that don't support CSP
        headers.put("X-XSS-Protection", "0");
        // Feature-Policy: Controls which features and APIs can be used in the browser
        headers.put("Feature-Policy",
            "geolocation 'none'; midi 'none'; notifications 'none'; push 'none'; sync-xhr 'none'; microphone 'none'; camera 'none'; "
                + "magnetometer 'none'; gyroscope 'none'; speaker 'none'; vibrate 'none'; fullscreen 'self'; payment 'none';");
        // Cache Control
        headers.put("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.put("Referrer-Policy", "same-origin");

        // Kommunikation innerhalb von Modern
        Optional.ofNullable(MDC.get(MDCKey.DRV_MANDANT.valueOf()))
            .ifPresent(drvMandant -> headers.put(MDCKey.DRV_MANDANT.valueOf(), drvMandant));
        headers.put("api_version", apiVersion);
        headers.put("absender", absender);
        headers.put(MDCKey.HEADER_CORRELATION_ID.valueOf(), MDC.getCopyOfContextMap()
            .getOrDefault(MDCKey.HEADER_CORRELATION_ID.valueOf(), ""));
        return headers;
    }
}
