package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Bezug Erwerbsminderungsrente.
 */
@Singleton
public class BezugEMRenteRegel extends BasisRegel {

    private static final List<String> RENTE_LEAT_CODES = List.of("74", "14", "75", "76", "43", "15");

    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL =
            Map.of(RegelUtils.ERFUELLT, "Es besteht kein laufender Bezug einer EM-Rente",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es besteht ein laufender Bezug einer EM-Rente");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_BEZUGEMRENTE;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String bezugRenteLeat = kontoinformation.getBezugRenteLeat();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(bezugRenteLeat).firstExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (StringUtils.isBlank(bezugRenteLeat)
                || !RENTE_LEAT_CODES.contains(bezugRenteLeat.trim())) {
            return ergebnisErfuellt(this);
        }
        if (!StringUtils.isBlank(bezugRenteLeat)
                && RENTE_LEAT_CODES.contains(bezugRenteLeat.trim())) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        return ergebnisAussteuernKeineDaten(this);

    }
}
