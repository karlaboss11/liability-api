package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.util.DataProcessingUtils;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernAntragsdatenStimmtNicht;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * Regelpruefung - Hausnummer.
 */
@Singleton
public class AbgleichHausnummerRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(RegelUtils.ERFUELLT, "Antragsdaten und Stammdaten stimmen überein",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Stammdaten sind nicht vorhanden",
                    RegelUtils.AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT, "Antragsdaten und Stammdaten stimmen nicht überein");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_ABGLEICH_HAUSNUMMER;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (Objects.isNull(kontext.getStammdaten())) {
            return ergebnisAussteuernKeineDaten(this);
        }
        if (DataProcessingUtils.matchValues(
                kontext.getAntrag().getHausnummer(), kontext.getStammdaten().getHausnummer())) {

            return ergebnisErfuellt(this);
        }
        return ergebnisAussteuernAntragsdatenStimmtNicht(this);

    }
}
