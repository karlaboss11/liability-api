package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import java.util.List;
import lombok.Data;

/**
 * EinrichtungResponseExtended.
 */
@Data
@SuppressWarnings("java:S1068")
public class EinrichtungResponseExtended {

    private String id;
    private String resc;
    private String name;
    private String email;
    private String telefonnummer;
    private Long distanz;
    private Long distanzVersicherter;
    private Geokoordinaten standort;
    private Adresse adresse;
    private Adresse postanschrift;
    private List<AngebotExtended> angebote;
}
