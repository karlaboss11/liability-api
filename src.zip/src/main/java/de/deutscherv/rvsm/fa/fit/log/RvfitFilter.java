package de.deutscherv.rvsm.fa.fit.log;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * RvfitFilter.
 */
@RequestScoped
@WebFilter(urlPatterns = "/antraege/*")
public class RvfitFilter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(RvfitFilter.class);

    private final String jwtUserId;
    private final String jwtDrvMandant;
    private final JsonWebToken jwt;

    /**
     * Konstruktor.
     *
     * @param jwtUserId     User-ID
     * @param jwtDrvMandant DRV-Mandant
     * @param jwt           JSON-Web-Token
     */
    @Inject
    public RvfitFilter(@ConfigProperty(name = "jwt.feld.user.name") String jwtUserId,
            @ConfigProperty(name = "jwt.feld.ktan.name") String jwtDrvMandant,
            JsonWebToken jwt) {
        this.jwtUserId = jwtUserId;
        this.jwtDrvMandant = jwtDrvMandant;
        this.jwt = jwt;
    }

    @Override
    public void init(final FilterConfig filterConfig) throws ServletException {
        LOGGER.info("########## Initiating RvfitFilter ##########");
    }

    @Override
    public void doFilter(final ServletRequest servletRequest, final ServletResponse response,
            final FilterChain chain) throws IOException, ServletException {
        putMDC(servletRequest);
        try {
            chain.doFilter(servletRequest, response);
        } finally {
            MDCUtils.clearMDC();
        }
    }

    private void putMDC(final ServletRequest servletRequest) {
        final var httpRequest = (HttpServletRequest) servletRequest;

        final String userId = jwt.claim(jwtUserId).map(Object::toString).orElse("system");

        final Optional<String> drvMandant = jwt.claim(jwtDrvMandant).map(Object::toString);

        final String sessionId = httpRequest.getSession().getId();
        final String sourceIp = servletRequest.getRemoteAddr();
        String correlationId = httpRequest.getHeader(MDCKey.HEADER_CORRELATION_ID.valueOf());

        MDC.put(MDCKey.EVENT_SUCCESS.valueOf(), "true");
        MDC.put(MDCKey.USER_ID.valueOf(), userId);
        drvMandant.ifPresent(mandant -> MDC.put(MDCKey.DRV_MANDANT.valueOf(), mandant));
        MDC.put(MDCKey.SESSION_ID.valueOf(), sessionId);
        MDC.put(MDCKey.SOURCE_IP.valueOf(), sourceIp);
        if (Objects.isNull(correlationId)) {
            correlationId = UUID.randomUUID().toString();
        }
        MDCUtils.setCorrelationId(correlationId);
    }
}
