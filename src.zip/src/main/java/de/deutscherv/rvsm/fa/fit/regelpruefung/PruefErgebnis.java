package de.deutscherv.rvsm.fa.fit.regelpruefung;

/**
 * PruefErgebnis.
 */
public enum PruefErgebnis {
    /**
     * Regel wurde erfüllt.
     */
    ERFUELLT,

    /**
     * Regel wurde nicht erfüllt. Der Sachberarbeiter muss das Ergebnis manuell überprüfen.
     */
    NICHT_ERFUELLT_AUSSTEUERN,

    /**
     * Regel wurde nicht erfüllt. Der Antrag wird automatisch abgelehnt.
     */
    NICHT_ERFUELLT_ABLEHNEN,

    /**
     * Regel konnte nicht geprüft werden.
     */
    AUSSTEUERN
}
