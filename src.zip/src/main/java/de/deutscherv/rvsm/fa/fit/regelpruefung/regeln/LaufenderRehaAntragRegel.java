package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;
import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * Regelpruefung - Laufender Reha-Antrag.
 */
@Singleton
public class LaufenderRehaAntragRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL =
        Map.of(RegelUtils.ERFUELLT, "Es gibt keinen laufenden Reha-Antrag.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es gibt einen laufenden Reha-Antrag.");
    private static final List<String> MSAT_AUSSTEUERUNGEN = List.of("4", "8");
    private static final List<String> ANTRAGSARTEN_REHA = List.of("11", "12", "13", "99", "33", "32");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_LAUFENDERREHAANTRAG;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String antragRehaMsat = kontoinformation.getAntragRehaMsat();
        final String antragRehaArt = kontoinformation.getAntragRehaArt();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(antragRehaMsat).firstExpected("?")
            .secondValue(antragRehaArt).secondExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (isErfuellt(antragRehaMsat, antragRehaArt)) {
            return ergebnisErfuellt(this);
        }

        if (isNichtErfuelltAussteuern(antragRehaMsat, antragRehaArt)) {
            return ergebnisNichtErfuelltAussteuern(this);

        }

        return ergebnisAussteuernKeineDaten(this);
    }

    private static boolean isNichtErfuelltAussteuern(final String antragRehaMsat, final String antragRehaArt) {
        return !isBlank(antragRehaMsat)
            && MSAT_AUSSTEUERUNGEN.contains(antragRehaMsat.trim())
            && !isBlank(antragRehaArt)
            && ANTRAGSARTEN_REHA.contains(antragRehaArt.trim());
    }

    private static boolean isErfuellt(final String antragRehaMsat, final String antragRehaArt) {
        return (!isBlank(antragRehaMsat)
            && !MSAT_AUSSTEUERUNGEN.contains(antragRehaMsat.trim()))
            || (isBlank(antragRehaMsat) && isBlank(antragRehaArt));
    }
}
