package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.EAntragsBestaetigungErrorMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.EAntragsBestaetigungsMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.EantragsBestaetigungsHeaderMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DrvMandantExtractor;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EXTraNachrichtDTO;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import de.deutscherv.rvsm.fa.fit.util.DauerMetricUtil;
import de.deutscherv.rvsm.fa.fit.util.MetricNames;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Processor;
import org.apache.camel.ValidationException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.MDC;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_ERSTES_BELADEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_VOLLVERARBEITUNG;

/**
 * EantragIncomingRoutes.
 */
@Slf4j
@ApplicationScoped
public class EantragIncomingRoutes extends RouteBuilder {

    /**
     * Routenname: Bestaetigung Antragsannahme.
     */
    public static final String DIRECT_BESTAETIGE_ANTRAGSANNAHME = "direct:bestaetigeeantragsannahme";
    /**
     * Routenname: Verarbeite eAntrag.
     */
    public static final String DIRECT_VERARBEITEEANTRAG = "direct:verarbeiteeantrag";
    private static final String DIRECT_FEHLER_RUECKMELDUNG = "direct:fehlerrueckmeldung";
    private static final String DIRECT_INVALID_MESSAGE = "direct:invalid";
    private static final String DIRECT_DUPLICATE = "direct:antragduplikat";
    private static final String DIRECT_ANNAHME_FEHLER = "direct:annahmeerror";
    private final Processor useOriginalMessage = exchange -> exchange.setMessage(exchange.getUnitOfWork().getOriginalInMessage());
    private final DrvMandantExtractor mandantExtractionProcessor;
    private final int maxConcurrentRequests;
    private final int timePeriodMillis;
    private final String transferEantragQueue;
    private final String bestaetigeEantrag;
    private final RequestContextController requestContext;

    private final EantragsBestaetigungsHeaderMapper eantragsBestaetigungsHeaderMapper;
    private final EAntragsBestaetigungsMapper eantragsBestaetigungsMapper;
    private final EAntragsBestaetigungErrorMapper eantragsBestaetigungErrorMapper;
    private final DauerMetricUtil dauerMetricUtil;

    private final ObjectMapper objectMapper;

    /**
     * Konstruktor.
     *
     * @param mandantExtractionProcessor        Mandant-Extraction-Processor
     * @param maxConcurrentRequests             Maximale Anzahl Concurrent-Requests
     * @param timePeriodMillis                  Time-Perion in Millis
     * @param transferEantragQueue              Transfer-eAntrag-Queue
     * @param bestaetigeEantrag                 Bestaetige eAntrag
     * @param requestContext                    Request-Kontext
     * @param eantragsBestaetigungsHeaderMapper eAntrag-Bestaetigung-Header-Mapper
     * @param eantragsBestaetigungsMapper       eAntrag-Bestaetigung-Mapper
     * @param eantragsBestaetigungErrorMapper   eAntrag-Bestaetigung-Error-Mapper
     * @param dauerMetricUtil                   Dauer-Metric-Util
     * @param objectMapper                      Object-Mapper
     */
    @Inject
    public EantragIncomingRoutes(final DrvMandantExtractor mandantExtractionProcessor,
        @ConfigProperty(name = "camel.route.throttle.maximum-concurrent-requests",
            defaultValue = "1") final int maxConcurrentRequests,
        @ConfigProperty(name = "camel.route.throttle.time-period-millis",
            defaultValue = "5000") final int timePeriodMillis,
        @ConfigProperty(name = "spoc-adapter.transfer-eantrag") final String transferEantragQueue,
        @ConfigProperty(name = "spoc-adapter.bestaetige-eantrag") final String bestaetigeEantrag,
        final RequestContextController requestContext,
        final EantragsBestaetigungsHeaderMapper eantragsBestaetigungsHeaderMapper,
        final EAntragsBestaetigungsMapper eantragsBestaetigungsMapper,
        final EAntragsBestaetigungErrorMapper eantragsBestaetigungErrorMapper,
        final DauerMetricUtil dauerMetricUtil,
        final ObjectMapper objectMapper) {
        this.mandantExtractionProcessor = mandantExtractionProcessor;
        this.maxConcurrentRequests = maxConcurrentRequests;
        this.timePeriodMillis = timePeriodMillis;
        this.transferEantragQueue = transferEantragQueue;
        this.bestaetigeEantrag = bestaetigeEantrag;
        this.requestContext = requestContext;
        this.eantragsBestaetigungsHeaderMapper = eantragsBestaetigungsHeaderMapper;
        this.eantragsBestaetigungsMapper = eantragsBestaetigungsMapper;
        this.eantragsBestaetigungErrorMapper = eantragsBestaetigungErrorMapper;
        this.dauerMetricUtil = dauerMetricUtil;
        this.objectMapper = objectMapper;
    }

    @Override
    public void configure() {
        //Eigenes Jackson Data Format, mit dem Object Mapper von Quarkus
        final var jackson = new JacksonDataFormat();
        jackson.setObjectMapper(objectMapper);

        //@formatter:off
        interceptFrom(XAJmsComponent.getxajmsRouteName("*"))
                .routeId("everyJmsRoute")
                .process(ex -> {
                    // JmsMessage provides JMSMessageID as Camel Message ID
                    MDC.put(MDCKey.JMS_MESSAGE_ID.valueOf(), ex.getMessage().getMessageId());
                    LOG.trace("Activating RequestContext.");
                    requestContext.activate();
                }).id("jmsMessageIdInMdc");
        from( XAJmsComponent.getxajmsRouteName( transferEantragQueue) + "?concurrentConsumers=1")
                .trace(true)
                .transacted()
                .routeId(XAJmsComponent.getxajmsRouteName(transferEantragQueue))
                .throttle(maxConcurrentRequests).timePeriodMillis(timePeriodMillis)
                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_EANTRAEGE)
                .process(ex -> dauerMetricUtil.startTimerMetric(MetricNames.E_ANTRAG_DAUER.getName(), ex))
                .log(LoggingLevel.DEBUG, LOG, "Processing EAntrag ${body}")
                .doTry()
                .process(mandantExtractionProcessor)
                .unmarshal()
                .json(JsonLibrary.Jackson, EXTraNachrichtDTO.class)
                .to("bean-validator://valid").id("validate-body")
                .setBody(exc -> exc.getMessage().getBody(EXTraNachrichtDTO.class).getXml())
                .to(DIRECT_VERARBEITEEANTRAG)
                .endDoTry()
                .doCatch(ValidationException.class)
                .log(LoggingLevel.WARN, LOG, "Validation Exception ${exception}")
                .to(DIRECT_INVALID_MESSAGE)
                .doCatch(ConstraintViolationException.class)
                .log(LoggingLevel.WARN, LOG, "Constraint Violation Exception ${exception}")
                .to(DIRECT_DUPLICATE)
                .doCatch(Exception.class)
                .log(LoggingLevel.WARN, LOG, "Exception ${exception}")
                .to(DIRECT_ANNAHME_FEHLER)
                .end();
        from(DIRECT_VERARBEITEEANTRAG)
                .routeId(DIRECT_VERARBEITEEANTRAG)
                .trace(true)
                .log(LoggingLevel.INFO, LOG, "Processing EAntrag ${body}")
                .to(DIRECT_ERSTES_BELADEN)
                .wireTap(DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG)
                .wireTap(DIRECT_BESTAETIGE_ANTRAGSANNAHME)
                .wireTap(DIRECT_VOLLVERARBEITUNG)
                .end();
        from(DIRECT_BESTAETIGE_ANTRAGSANNAHME)
                .routeId(DIRECT_BESTAETIGE_ANTRAGSANNAHME)
                .trace(true)
                .log(LoggingLevel.INFO, LOG, "Processing EantragsBestaetigungDTO ${body}")
                .doTry()
                .process(eantragsBestaetigungsMapper)
                .process(eantragsBestaetigungsHeaderMapper)
                .filter(exchange -> exchange.getMessage().getBody(EantragsBestaetigungDTO.class).getMessageId() != null)
                .marshal(jackson)
                .process(exchange -> {
                    exchange.getMessage().removeHeader(RVFitCamelHeader.ANTRAGSDATEN);
                    exchange.getMessage().removeHeader(RVFitCamelHeader.EANTRAG_XML);
                })
                .to(XAJmsComponent.getxajmsRouteName(bestaetigeEantrag))
                .endDoTry()
                .doCatch(Exception.class)
                .log(LoggingLevel.INFO, LOG, "Processing EantragsBestaetigungDTO Exception ${exception}")
                .end();
        from(DIRECT_INVALID_MESSAGE).routeId(DIRECT_INVALID_MESSAGE)
                .process(useOriginalMessage)
                .log(LoggingLevel.WARN, LOG, "EAntrag empfangen aber invalid")
                .to(DIRECT_FEHLER_RUECKMELDUNG)
                .stop()
                .end();
        
        from(DIRECT_DUPLICATE).routeId(DIRECT_DUPLICATE)
                .log(LoggingLevel.WARN, LOG, "EAntrag empfangen aber ist ein Duplikat")
                .to(DIRECT_FEHLER_RUECKMELDUNG)
                .stop()
                .end();
        
        from(DIRECT_ANNAHME_FEHLER).routeId(DIRECT_ANNAHME_FEHLER)
                .log(LoggingLevel.WARN, LOG, "EAntrag emfangen aber ein Fehler trat auf: ${exception}")
                .to(DIRECT_FEHLER_RUECKMELDUNG)
                .stop()
                .end();
        
        from(DIRECT_FEHLER_RUECKMELDUNG).routeId(DIRECT_FEHLER_RUECKMELDUNG)
                .trace(true)
                .log(LoggingLevel.INFO, LOG, "Processing EantragsBestaetigungDTO mit Fehler ${body}")
                .doTry()
                    .process(eantragsBestaetigungErrorMapper)
                    .process(eantragsBestaetigungsHeaderMapper)
                    .filter(exchange -> exchange.getMessage().getBody(EantragsBestaetigungDTO.class).getMessageId() != null)
                    .marshal(jackson)
                    .process(exchange -> {
                        exchange.getMessage().removeHeader(RVFitCamelHeader.ANTRAGSDATEN);
                        exchange.getMessage().removeHeader(RVFitCamelHeader.EANTRAG_XML);
                    })
                    .to(XAJmsComponent.getxajmsRouteName(bestaetigeEantrag))
                .endDoTry()
                .doCatch(Exception.class)
                    .log(LoggingLevel.INFO, LOG, "Processing EantragsBestaetigungDTO Exception ${exception}")
                .end();
        //@formatter:on
    }

}
