package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import java.util.List;
import lombok.Data;

/**
 * EinrichtungResponse.
 */
@Data
@SuppressWarnings("java:S1068")
public class EinrichtungResponse {

    private Long id;
    private String resc;
    private String name;
    private Adresse adresse;
    private List<Angebot> angebote;
}
