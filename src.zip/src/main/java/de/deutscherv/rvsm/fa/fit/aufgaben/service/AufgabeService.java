package de.deutscherv.rvsm.fa.fit.aufgaben.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.repository.AufgabeRepository;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCompleteDTO;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCreateDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * Service für Aufgaben im Vorgangsmanagement.
 *
 * @author U38322
 */
@Slf4j
@ApplicationScoped
public class AufgabeService {

    private final PurAufgabenProducer purAufgabenProducer;
    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;
    private final AntragRepository antragRepository;
    private final AufgabeRepository aufgabeRepository;
    private final AntragMapper antragMapper;
    private final String urlPersonendatenabgleich;
    private final String urlAnspruchsvoraussetzung;
    private final String urlEinrichtungswahl;
    private final String urlEinrichtungenUndAnspruch;
    private final String urlDoppelvergabe;

    private final String urlBemerkungVorhanden;
    private final String urlBestandsFehler;

    /**
     * Konstruktor.
     *
     * @param purAufgabenProducer         rvPuR-Aufgaben-Producer
     * @param jwt                         Json-Web-Token
     * @param drvMandant                  DRV-Mandant
     * @param rvfitLogger                 rvFit-Logger
     * @param antragRepository            Antrag-Repository
     * @param aufgabeRepository           Aufgaben-Repostitory
     * @param antragMapper                Antrag-Mapper
     * @param urlPersonendatenabgleich    URL Personendatenabgleich
     * @param urlAnspruchsvoraussetzung   URL Anspruchsvoraussetung
     * @param urlEinrichtungswahl         URL Einrichtungswahl
     * @param urlEinrichtungenUndAnspruch URL Einrichtungen und Anspruch
     * @param urlDoppelvergabe            URL Doppelvergabe
     * @param urlBestandsFehler           URL Bestandsfehler
     * @param urlBemerkungVorhanden       URL Bemerkung vorhanden
     */
    @Inject
    public AufgabeService(final PurAufgabenProducer purAufgabenProducer, final JsonWebToken jwt, final DrvMandant drvMandant,
            final RvfitLogger rvfitLogger,
            final AntragRepository antragRepository, final AufgabeRepository aufgabeRepository, final AntragMapper antragMapper,
            @ConfigProperty(name = "vom.url.personendatenabgleich") final String urlPersonendatenabgleich,
            @ConfigProperty(name = "vom.url.anspruchsvoraussetzung") final String urlAnspruchsvoraussetzung,
            @ConfigProperty(name = "vom.url.einrichtungswahl") final String urlEinrichtungswahl,
            @ConfigProperty(name = "vom.url.einrichtungen-und-anspruch") final String urlEinrichtungenUndAnspruch,
            @ConfigProperty(name = "vom.url.doppelvergabe") final String urlDoppelvergabe,
            @ConfigProperty(name = "vom.url.bestandsfehler") final String urlBestandsFehler,
            @ConfigProperty(name = "vom.url.bemerkung-vorhanden") final String urlBemerkungVorhanden) {
        this.purAufgabenProducer = purAufgabenProducer;
        this.jwt = jwt;
        this.drvMandant = drvMandant;
        this.rvfitLogger = rvfitLogger;
        this.antragRepository = antragRepository;
        this.aufgabeRepository = aufgabeRepository;
        this.antragMapper = antragMapper;
        this.urlPersonendatenabgleich = urlPersonendatenabgleich;
        this.urlAnspruchsvoraussetzung = urlAnspruchsvoraussetzung;
        this.urlEinrichtungswahl = urlEinrichtungswahl;
        this.urlEinrichtungenUndAnspruch = urlEinrichtungenUndAnspruch;
        this.urlDoppelvergabe = urlDoppelvergabe;
        this.urlBemerkungVorhanden = urlBemerkungVorhanden;
        this.urlBestandsFehler = urlBestandsFehler;
    }

    /**
     * Lese Antrag mit der Transaktionsid.
     *
     * @param transaktionId Transaktionsid.
     * @return ermittelter Antrag
     */
    @Transactional
    public AntragDto getAntragByTransaktionsId(final UUID transaktionId) {
        LOG.atDebug().addArgument(transaktionId).addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt))
                .log("Suche Antrag anhand der UUID der Transaktion. Transaktion UUID [{}], KTAN [{}]");
        final Antrag antrag = antragRepository.findAntragByTransaktionsId(transaktionId);
        MDCUtils.setVsnr(antrag.getVsnr());
        return antragMapper.toDto(antrag);
    }

    /**
     * Erstellt eine Aufgabe in RV PuR.
     *
     * @param antrag      Antrag, zu dem die Aufgabe erstellt werden soll
     * @param aufgabenArt die Art der Aufgabe
     */
    public void erstellePurAufgabe(final Antrag antrag, final AufgabenArt aufgabenArt) {
        LOG.atDebug().addArgument(aufgabenArt).addArgument(antrag.getUuid())
                .addArgument(antrag.getKtan()).addArgument(antrag.getVsnr()).log(
                        "Die Aufgabe des Antrags wird erstellt. Aufgabenart [{}], Antrag UUID [{}], KTAN [{}], VSNR [{}]");
        final UUID aufruferReferenzId = UUID.randomUUID();

        final AufgabeCreateDTO dto = new AufgabeCreateDTO();
        dto.setAufruferReferenzId(aufruferReferenzId.toString());
        dto.setOrdnungsbegriff(antrag.getVorgangskennung());

        final String url =
                getUrl(aufgabenArt).replace("{TRANSAKTION}", antrag.getUuid().toString());
        dto.itpZiel(url);
        dto.setAufgabenart(String.valueOf(aufgabenArt.value));
        dto.setErstellzeitpunkt(LocalDateTime.now().atOffset(ZoneOffset.UTC));
        dto.setName(antrag.getNachname());
        dto.setVorname(antrag.getVorname());
        dto.setFreigabe(null);
        dto.setGeschaeftsprozessDefinition(null);

        purAufgabenProducer.createAufgabe(dto);

        final Aufgabe aufgabe =
                Aufgabe.builder().aufgabenArt(aufgabenArt).transaktionId(aufruferReferenzId).build();

        antrag.addAufgabe(aufgabe);
        antragRepository.merge(antrag);

        LOG.atDebug().addArgument(antrag).log("Persistiere Antrag [{}] in DB");

        LOG.atDebug().addArgument(dto).addArgument(aufgabe).addArgument(antrag.getUuid())
                .addArgument(antrag.getKtan()).addArgument(antrag.getVsnr()).log(
                        "Die Aufgabe des Antrags wurde erstellt. AufgabeDto [{}], Aufgabe [{}], Antrag UUID [{}], KTAN [{}], VSNR [{}]");

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                Ereignistext.AUFGABE_ERZEUGT,
                EreignisFreitext.AUFGABE_ERZEUGT, dto.getAufgabenart(),
                antrag, aufgabe, jwt, drvMandant));
    }

    /**
     * Gibt die URL entsprechend der uebergebenen Aufgabenart zurueck.
     *
     * @param aufgabenArt fuer die URL die erstellt werden soll
     * @return url je nach {@code AufgabenArt}
     */
    private String getUrl(final AufgabenArt aufgabenArt) {
        return switch (aufgabenArt) {
            case PERSONENDATENABGLEICH -> urlPersonendatenabgleich;
            case EINRICHTUNGENUNDANSPRUCH -> urlEinrichtungenUndAnspruch;
            case EINRICHTUNGSWAHL -> urlEinrichtungswahl;
            case ANSPRUCHSVORAUSSETZUNG -> urlAnspruchsvoraussetzung;
            case DOPPELVERGABE -> urlDoppelvergabe;
            case BEMERKUNG_ODER_ANHANG_VORHANDEN -> urlBemerkungVorhanden;
            case BESTANDSFEHLER -> urlBestandsFehler;
            case ANTRAGSERFASSUNG -> ""; // ? nicht notwendig für Erfassung, da die Aufgabe von PuR
            // selbst generiert wird
            default -> {
                LOG.atWarn().addArgument(aufgabenArt)
                        .log("Keine valide Aufgabenart angegeben. AufgabenArt [{}]");
                throw new EingabevalidierungException(AufgabeService.class.getName(), GET_DRV_ID_AUS_JWT.apply(jwt),
                        "Keine valide AufgabenArt angegeben: " + aufgabenArt);
            }
        };
    }

    /**
     * Schließt eine Aufgabe ab.
     *
     * @param antrag      der Antrag
     * @param aufgabenArt die Aufgabenart
     * @param grund       der Grund für den Abschluss
     */
    public void schliesseAufgabe(final Antrag antrag, final AufgabenArt aufgabenArt, final String grund) {
        final AufgabeCompleteDTO aufgabeCompleteDTO = new AufgabeCompleteDTO();

        final Aufgabe aufgabe = getOffeneAufgabeFuerArt(antrag, aufgabenArt);
        aufgabeCompleteDTO.setAufruferReferenzId(aufgabe.getTransaktionId().toString());
        aufgabeCompleteDTO.setErledigungsdatum(LocalDate.now());
        aufgabeCompleteDTO.setAbschlussgrund(grund);

        aufgabe.setDatumErledigt(LocalDateTime.now());
        aktualisiereStatus(antrag, aufgabenArt);

        aufgabeRepository.merge(aufgabe);
        LOG.atDebug().addArgument(aufgabe).log("Persistiere Aufgabe [{}] in DB");
        try {
            purAufgabenProducer.completeAufgabe(aufgabeCompleteDTO);
        } catch (Exception e) {
            LOG.atWarn().log("Fehler beim schreiben in die Aufgaben schlißen Queue");
        }

        LOG.atDebug().addArgument(aufgabe).addArgument(grund)
                .log("Schließe Aufgabe [{}] mit Grund [{}]");

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                Ereignistext.AUFGABE_GESCHLOSSEN,
                EreignisFreitext.AUFGABE_GESCHLOSSEN, aufgabe.getAufgabenArt().name(),
                antrag, aufgabe, jwt, drvMandant));
    }

    private static Aufgabe getOffeneAufgabeFuerArt(final Antrag antrag, final AufgabenArt aufgabenArt) {
        return antrag.getAufgaben().stream()
                .filter(aufgabe -> aufgabe.getDatumErledigt() == null)
                .filter(aufgabe -> aufgabe.getAufgabenArt() == aufgabenArt)
                .findFirst()
                .orElseThrow(() ->
                        new NoSuchElementException(
                                String.format(
                                        "Es existiert keine offene Aufgabe vom Typ %s im Antrag mit der UUID %s",
                                        aufgabenArt,
                                        antrag.getUuid())));
    }

    private static void aktualisiereStatus(final Antrag antrag, final AufgabenArt aufgabenArt) {
        final AntragStatus antragStatus = antrag.getStatus();
        if (aufgabenArt != AufgabenArt.BESTANDSFEHLER) {
            return;
        }
        final AntragStatus neuerStatus = switch (antragStatus) {
            case AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN -> AntragStatus.STATISTIK_ERFASST;
            case AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN -> AntragStatus.STATISTIK_ABGESCHLOSSEN;
            case AntragStatus.STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN -> AntragStatus.VORGANG_ERZEUGT;
            case AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN -> AntragStatus.KONTOINFORMATION_ABGEFRAGT;
            case AntragStatus.DOPPELVERGABE_AUFGABE_SCHLIESSEN -> AntragStatus.DOPPELVERGABE_PRUEFUNG_OK;
            default -> antragStatus;
        };
        if (neuerStatus != antrag.getStatus()) {
            antrag.setStatus(neuerStatus);
        }
    }

    /**
     * Schliesse Aufgabe Papierantrag erfasst.
     *
     * @param aufgabe    zu schliessende Aufgabe
     * @param aufgabenId ID der Aufgabe
     */
    public void schliesseAufgabePapierantragErfasst(final Aufgabe aufgabe,
            final String aufgabenId) {
        final AufgabeCompleteDTO aufgabeCompleteDTO = new AufgabeCompleteDTO();
        aufgabeCompleteDTO.setAufruferReferenzId(aufgabenId);
        aufgabeCompleteDTO.setErledigungsdatum(LocalDate.now());
        aufgabeCompleteDTO.setAbschlussgrund("Papierantrag erfasst");

        aufgabe.setDatumErledigt(LocalDateTime.now());

        aufgabeRepository.persist(aufgabe);
        LOG.atDebug().addArgument(aufgabe).log("Persistiere Aufgabe [{}] in DB");

        purAufgabenProducer.completeAufgabe(aufgabeCompleteDTO);
    }

    /**
     * Alle noch offenen rvPuR-Aufgaben werden geschlossen.
     *
     * @param antrag betroffener Antrag
     * @return Antrag desen Aufgabe geschlossen wurde.
     */
    public Antrag purAufgabeSchliessen(final Antrag antrag) {
        final var status = antrag.getStatus();
        switch (status) {
            case BESCHEID_ABGESCHLOSSEN -> {
                // Es wird hier nur ein nach einer nicht geschlossen Aufgabe gesucht,
                // da man über mehrere Wege zu diesen Status kommen kann und es nur in einem Fall noch eine Aufgabe gibt
                // Bewilligung, Ablehnung, Erledigung auf andere Art etc. in der Anspruchsprüfung.
                final Optional<Aufgabe> aufgabe =
                        antrag.getAufgaben().stream().filter(aufgabe1 ->
                                aufgabe1.getDatumErledigt() == null).findFirst();
                aufgabe.ifPresent(value -> schliesseAufgabe(antrag, value.getAufgabenArt(), ""));
                antrag.setStatus(AntragStatus.AUFGABE_ABGESCHLOSSEN);
            }
            case PERSONENDATEN_AUFGABE_ERSTELLT -> schliesseAufgabe(antrag, AufgabenArt.PERSONENDATENABGLEICH,
                    "");
            case PAPIERANTRAG_GESPEICHERT -> schliesseAufgabe(
                    antrag, AufgabenArt.ANTRAGSERFASSUNG, "");
            case AUFGABE_SCHLIESSEN_OHNE_STATISTIK -> {
                // Es wird hier nur ein nach einer nicht geschlossen Aufgabe gesucht,
                // da man über mehrere Wege zu diesen Status kommen kann und es nur in einem Fall noch eine Aufgabe gibt
                // Bewilligung, Ablehnung, Erledigung auf andere Art etc. in der Anspruchsprüfung.
                final Optional<Aufgabe> aufgabe =
                        antrag.getAufgaben().stream().filter(aufgabe1 ->
                                aufgabe1.getDatumErledigt() == null).findFirst();
                if (aufgabe.isPresent()) {
                    schliesseAufgabe(antrag, aufgabe.get().getAufgabenArt(),
                            "");
                } else {
                    antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
                }
            }
            case STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN,
                    STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN,
                    STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN,
                    KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN -> schliesseAufgabe(antrag, AufgabenArt.BESTANDSFEHLER, "");
            case DOPPELVERGABE_AUFGABE_SCHLIESSEN -> {
                schliesseAufgabe(antrag, AufgabenArt.DOPPELVERGABE, "");
                antrag.setStatus(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);
            }
            default -> throw new IllegalStateException(
                    "Eine Aufgabe kann nicht aus dem State: " + status + " geschlossen werden");
        }
        return antrag;
    }
}
