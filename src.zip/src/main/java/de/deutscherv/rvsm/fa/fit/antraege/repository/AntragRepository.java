package de.deutscherv.rvsm.fa.fit.antraege.repository;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import java.time.Year;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Repository fuer rvFit-Anträge.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public final class AntragRepository {

    private static final String ANTRAG_IDS = "antragIds";
    private static final String STATUS = "status";

    private final EntityManager entityManager;
    /**
     * Diese Methode liefert einen Antrag anhand der UUID zurück.
     *
     * @param uuid die UUID
     * @return ein Optional mit dem Antrag, falls für die mitgelieferte UUID ein Eintrag gefunden wurde, ansonsten ein leeres Optional
     */
    @RequiresMandant
    public Optional<Antrag> findByUuid(final UUID uuid) {
        return Optional.ofNullable(entityManager.find(Antrag.class, uuid));
    }

    /**
     * List anhand der Liste von UUIDs alle Antraege.
     *
     * @param antragUuids Liste der UUIDs
     * @return gefundene Antraege
     */
    @RequiresMandant
    public List<Antrag> findByUuids(final List<String> antragUuids) {
        return entityManager.createQuery("""
                SELECT an
                FROM Antrag an
                WHERE an.uuid IN :antragUuids
                """, Antrag.class).setParameter("antragUuids", antragUuids).getResultStream()
            .toList();
    }

    /**
     * Diese Methode liefert einen Antrag anhand der Vorgangskennung zurück.
     *
     * @param vorgangskennung die Vorgangskennung
     * @return ein Antrag, falls für die mitgelieferte Vorgangskennung ein Eintrag gefunden wurde, ansonsten null
     */
    @RequiresMandant
    public Antrag findByVorgangskennung(final String vorgangskennung) {

        final TypedQuery<Antrag> query = entityManager.createQuery(
            "select an from Antrag an where an.vorgangskennung = :vorgangskennung",
            Antrag.class);

        query.setParameter("vorgangskennung", vorgangskennung);

        return query.getResultStream().findFirst().orElse(null);
    }

    /**
     * Diese Methode liefert die nächste Vorgangskennung Sequence.
     *
     * @param year Jahr als Suffix zur Vorgangskennung
     * @return die nächste Sequence Integer
     */
    @RequiresMandant
    public int getVorgangskennungNextSequence(final int year) {
        Object result = entityManager.createNativeQuery("SELECT VORGANGSKENNUNG_SEQ_" + year + ".NEXTVAL FROM dual").getSingleResult();
        return ((Number) result).intValue();
    }

    /**
     * Sequence der Vorgangskennung wird zu Beginn eines neuen Jahres neu gestartet.
     */
    @RequiresMandant
    public void createNewYearVorgangskennungSequence() {
        entityManager.createNativeQuery("BEGIN create_yearly_vorgangskennung_seq(:year) END;")
            .setParameter("year", Year.now().getValue())
            .executeUpdate();
    }

    /**
     * Diese Methode liefert den Entwurf eines Papierantrags für die übergebene Versicherungsnummer. Falls kein Entwurf vorhanden ist, wird
     * null zurückgegeben.
     *
     * @param vsnr die Versicherungsnummer
     * @return Entwurf eines Papierantrags mit der übergebenen VSNR oder null, falls nicht vorhanden
     */
    @RequiresMandant
    public Antrag findPapierantragEntwurfByVsnr(final String vsnr) {

        final TypedQuery<Antrag> query = entityManager.createQuery(
            "select an from Antrag an where an.vsnr = :vsnr and an.status = :status and an.antragsart = :antragsart "
                + "ORDER BY created desc",
            Antrag.class);

        query.setParameter("vsnr", vsnr);
        query.setParameter(STATUS, AntragStatus.ENTWURF);
        query.setParameter("antragsart", AntragsArt.PAPIERANTRAG);

        return query.getResultStream().findFirst().orElse(null);
    }

    /**
     * Diese Methode löscht den Entwurf eines Papierantrags für die übergebene Versicherungsnummer.
     *
     * @param vsnr die Versicherungsnummer
     */
    @RequiresMandant
    public void deletePapierantragEntwurfByVsnr(final String vsnr) {
        final List<UUID> uuidsZumLoeschen = entityManager.createQuery(
                "select an from Antrag an where an.vsnr = :vsnr and an.status = :status and an.antragsart = :antragsart",
                Antrag.class)
            .setParameter("vsnr", vsnr).setParameter(STATUS, AntragStatus.ENTWURF)
            .setParameter("antragsart", AntragsArt.PAPIERANTRAG)
            .getResultStream()
            .map(Antrag::getUuid)
            .toList();

        entityManager.createNativeQuery("delete from Aufgabe where antrag_id in :antragIds")
            .setParameter(ANTRAG_IDS, uuidsZumLoeschen)
            .executeUpdate();

        entityManager.createNativeQuery("delete from Versicherten_Stammdaten where antrag_id in :antragIds")
            .setParameter(ANTRAG_IDS, uuidsZumLoeschen)
            .executeUpdate();

        entityManager.createQuery(
                "delete from Antrag a where a.uuid in :antragIds")
            .setParameter(ANTRAG_IDS, uuidsZumLoeschen)
            .executeUpdate();
    }

    /**
     * Diese Methode liefert die Anträge für die übergebene Versicherungsnummer im Status STATISTIK_ERFASST oder VORGANG_WIRD_ERSTELLT.
     * Falls kein Antrag vorhanden ist, wird null zurückgegeben.
     *
     * @param vsnr die Versicherungsnummer
     * @return Gefunden Antraege mit der übergebenen VSNR oder null, falls nicht vorhanden
     */
    @RequiresMandant
    public List<Antrag> findAntraegeInBearbeitungUndVorgangWirdErstelltByVsnr(final String vsnr) {

        final TypedQuery<Antrag> query = entityManager.createQuery(
            "select an from Antrag an where an.vsnr = :vsnr and (an.status = :statusInBearbeitung or an.status = "
                + ":statusVorgangWirdErstellt)",
            Antrag.class);

        query.setParameter("vsnr", vsnr);
        query.setParameter("statusInBearbeitung", AntragStatus.STATISTIK_ERFASST);
        query.setParameter("statusVorgangWirdErstellt", AntragStatus.VORGANG_WIRD_ERSTELLT);

        return query.getResultStream().toList();
    }

    /**
     * Diese Methode liefert eine Liste von Anträgen, für die die Vorgangserzeugung noch nicht abgeschlossen ist. Die Liste ist
     * chronologisch nach Erstellung sortiert. Falls kein solcher Antrag vorhanden ist, wird eine leere Liste zurückgegeben.
     *
     * @param status Antragsstatus
     * @param limit  maximale Anzahl
     * @return Liste von Anträgen mit offener Vorgangserzeugung
     */
    @RequiresMandant
    public List<Antrag> findAntraegeimStatus(final AntragStatus status, final int limit) {
        final TypedQuery<Antrag> query = entityManager.createQuery(
            "select an from Antrag an where an.status = :status ORDER BY created LIMIT :limit",
            Antrag.class);

        query.setParameter(STATUS, status);
        query.setParameter("limit", limit);
        return query.getResultStream().toList();
    }

    /**
     * Die Methode liefert einen Antrag für die übergebene TransaktionsID. Falls kein Antrag gefunden wurde, wird null zurückgegeben.
     *
     * @param transaktionsId die TransaktionsID
     * @return einen Antrag mit der passenden TransaktionsId oder null, falls kein Antrag gefunden wurde
     */
    @RequiresMandant
    public Antrag findAntragByTransaktionsId(final UUID transaktionsId) {

        final TypedQuery<Antrag> query = entityManager.createQuery(
            "select an from Antrag an join an.aufgaben au where au.transaktionId = :transaktionId",
            Antrag.class);

        query.setParameter("transaktionId", transaktionsId);

        return query.getResultStream().findFirst().orElse(null);

    }

    /**
     * Entfernt einen Antrag aus der Datenbank.
     *
     * @param antrag der zu entfernende Antrag
     */
    @RequiresMandant
    @Transactional
    public void delete(final Antrag antrag) {
        entityManager.remove(antrag);
    }

    /**
     * Synchronisiert den Persistenz-Kontext mit der darunterliegenden Datenbank.
     */
    @RequiresMandant
    @Transactional
    public void flush() {
        entityManager.flush();
    }

    /**
     * Speichert einen Antrag in der Datenbank.
     *
     * @param antrag zu persistierender Antrag
     */
    @RequiresMandant
    public void persist(final Antrag antrag) {
        entityManager.persist(antrag);
    }

    /**
     * Speichert einen Antrag in der Datenbank. Synchronisiert den Persistenz-Kontext mit der darunterliegenden Datenbank.
     *
     * @param antrag zu persistierender Antrag
     */
    @RequiresMandant
    @Transactional
    public void persistAndFlush(final Antrag antrag) {
        LOG.atDebug().addArgument(antrag::getVsnr).addArgument(antrag::getUuid)
            .setMessage("Speichere Antrag mit der VSNR [{}] unter UUID [{}]").log();
        entityManager.persist(antrag);
        entityManager.flush();
    }

    /**
     * Sucht nach der letzten hinzugefügten Vorgangskennung und gibt diese als Optional zurück. Falls keine gefunden wird, wird ein leeres
     * Optional zurückgegeben.
     *
     * @return zuletzt hinzugefügte Vorgangskennung als Optional oder ein leeres Optional, falls keine gefunden wurde
     */
    @RequiresMandant
    @Transactional
    public synchronized Optional<String> getLastInsertedVorgangskennung() {
        final TypedQuery<String> query = entityManager.createQuery("""
            SELECT an.vorgangskennung
            FROM Antrag an
            WHERE an.vorgangskennung IS NOT NULL AND an.antragsart = 'E_ANTRAG'
            ORDER BY an.vorgangskennung DESC
            """, String.class);
        query.setMaxResults(1);
        return query.getResultStream().findFirst();
    }

    /**
     * Antragstatus wird von {@code VORGANG_WIRD_ERSTELLT} auf {@code VORGANG_ERZEUGT} umgesetzt.
     *
     * @param antragUuids UUID-Liste von umzusetzenden Antraegen
     * @return Anzahl der umgesetzen Antraegen
     */
    @RequiresMandant
    public int setzeStatusVonVorgangWirdErstelltAufVorgangErzeugt(final List<String> antragUuids) {
        final List<Antrag> antraege = findByUuids(antragUuids);

        int i = 0;
        for (final Antrag antrag : antraege) {
            if (antrag.getStatus() == AntragStatus.VORGANG_WIRD_ERSTELLT) {
                antrag.setStatus(AntragStatus.VORGANG_ERZEUGT);
                merge(antrag);
                i++;
            }
        }
        flush();
        return i;
    }

    /**
     * Ermittle Antraege mit vorgegebener Vorgangskennung im Status {@code VORGANG_WIRD_ERSTELLT}.
     *
     * @param vorgangsKennungen Vorgangskennung mit der gesucht wird.
     * @return Liste der gefundenen Antraeg
     */
    @RequiresMandant
    public List<Antrag> getAntraegeFuerVorgangsKennungenMitStatusVorgangErstellt(final List<String> vorgangsKennungen) {
        return entityManager.createQuery("""
                SELECT an
                FROM Antrag an
                WHERE an.vorgangskennung IN :vorgangskennungen
                AND an.status = :status
                """, Antrag.class).setParameter("vorgangskennungen", vorgangsKennungen)
            .setParameter(STATUS, AntragStatus.VORGANG_WIRD_ERSTELLT)
            .getResultStream().toList();
    }

    /**
     * Geaenderter Antrag wird persistiert.
     *
     * @param antrag betroffener Antrag
     * @return geschriebner Antrag
     */
    @RequiresMandant
    @Transactional
    public Antrag merge(final Antrag antrag) {
        return entityManager.merge(antrag);
    }

    /**
     * Test, ob die VorgangsID bereits belegt ist.
     *
     * @param vorgangskennung mit der ein Antrag gesucht wird
     * @return true wenn eine Antrag gefunden wurde.
     */
    @RequiresMandant
    public boolean istVorgangsIdBelegt(final String vorgangskennung) {
        final List<Antrag> antraege = entityManager.createQuery("""
                SELECT an
                FROM Antrag an
                WHERE an.vorgangskennung = :vorgangskennung
                AND an.status <> :status
                """, Antrag.class)
            .setParameter("vorgangskennung", vorgangskennung)
            .setParameter(STATUS, AntragStatus.ENTWURF)
            .getResultList();
        return !antraege.isEmpty();
    }
}
