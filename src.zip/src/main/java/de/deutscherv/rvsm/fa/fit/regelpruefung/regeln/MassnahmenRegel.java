package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Massnahmen.
 */
@Singleton
public class MassnahmenRegel extends BasisRegel {

    private static final List<String> MASSNAHME_REHA_ELAT = List.of("10", "42", "99", "23", "25", "24", "26", "31", "32", "43", "22");
    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "In den letzten 12 Monaten wurde keine Rehabilitations-Maßnahme abgeschlossen.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
            RegelUtils.AUSSTEUERN, "Es liegen keine vollstaendigen Daten der Maßnahme vor",
            RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "In den letzten 12 Monaten wurde eine Rehabilitations-Maßnahme abgeschlossen.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_MASSNAHME;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String massnahmeRehaElat = kontoinformation.getMassnahmeRehaElat();
        final LocalDate massnahmeRehaKobs = kontoinformation.getMassnahmeRehaKobs();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(massnahmeRehaElat).firstExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuern(this);
        }

        if (massnahmeErfuellt(kontext)) {
            return ergebnisErfuellt(this);
        }

        if ((isMassnahmeRehaElat(massnahmeRehaElat) && isMassnahmeRehaKobsAfter(massnahmeRehaKobs, kontext.getAntrag().getAntragsDatum()))
                || (isMassnahmeRehaElat(massnahmeRehaElat) && Objects.isNull(massnahmeRehaKobs))) {
            return ergebnisNichtErfuelltAussteuern(this);

        }
        return ergebnisAussteuern(this);
    }

    private static boolean massnahmeErfuellt(final RegelKontext kontext) {
        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String massnahmeRehaElat = kontoinformation.getMassnahmeRehaElat();
        final LocalDate massnahmeRehaKobs = kontoinformation.getMassnahmeRehaKobs();
        // beides Leer -> Regel erfüllt
        if ((StringUtils.isBlank(massnahmeRehaElat) && Objects.isNull(massnahmeRehaKobs))) {
            return true;
        }
        // wenn keine Maßnahme der Liste
        if (!isMassnahmeRehaElat(massnahmeRehaElat)) {
            return true;
        }

        return isMassnahmeRehaKobsBefore(massnahmeRehaKobs, kontext.getAntrag().getAntragsDatum());
    }

    private static boolean isMassnahmeRehaElat(final String massnahmeRehaElat) {
        return !StringUtils.isBlank(massnahmeRehaElat) && MASSNAHME_REHA_ELAT.contains(massnahmeRehaElat.trim());
    }

    private static boolean isMassnahmeRehaKobsBefore(final LocalDate massnahmeRehaKobs,
            final LocalDate antragsDatum) {
        return Objects.nonNull(massnahmeRehaKobs) && Objects.nonNull(antragsDatum)
                && massnahmeRehaKobs.isBefore(antragsDatum.minusMonths(12));
    }

    private static boolean isMassnahmeRehaKobsAfter(final LocalDate massnahmeRehaKobs,
            final LocalDate antragsDatum) {
        return Objects.nonNull(massnahmeRehaKobs) && Objects.nonNull(antragsDatum)
                && (massnahmeRehaKobs.isEqual(antragsDatum.minusMonths(12))
                || massnahmeRehaKobs.isAfter(antragsDatum.minusMonths(12)));
    }
}
