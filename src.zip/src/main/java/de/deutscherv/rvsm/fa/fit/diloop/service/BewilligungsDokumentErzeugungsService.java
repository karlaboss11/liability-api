package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentenErzeugungConfig;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.util.LandIsoCodes;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import static de.deutscherv.rvsm.fa.fit.diloop.util.DokumentenWerteMappingUtil.erstelleAdressenString;
import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.MSNR;

/**
 * Implementierung des DokumentErzeugungsService für Bewilligungsbescheide.
 */
@ApplicationScoped
public final class BewilligungsDokumentErzeugungsService extends DokumentErzeugungsService {

    private static final String AMBULANT = "ambulant";
    private static final String ONLINE = "online";
    private static final String STATIONAER = "stationär";

    private final DokumentenErzeugungConfig dokumentenErzeugungConfig;

    /**
     * Konstruktor.
     *
     * @param dokumentenErzeugungConfig Konfiguration zur Dokumentenerzeugung
     */
    public BewilligungsDokumentErzeugungsService(final DokumentenErzeugungConfig dokumentenErzeugungConfig) {
        this.dokumentenErzeugungConfig = dokumentenErzeugungConfig;
    }

    /**
     * Ermittelt in Abhängigkeit der ausgewählten Einrichtungen die Template-ID für den Bewilligungsbescheid Unterschiedliche ID wenn
     * Einrichtung der Start- und Trainingsphase abweichen.
     *
     * @param dokumentenErstellungsDaten Daten des Antrages
     * @return UUID für den Template-UUID für entsprechenden Bewilligungsbescheid
     */
    @Override
    protected UUID getTemplateId(final DokumentenErstellungsDaten dokumentenErstellungsDaten) {
        if (dokumentenErstellungsDaten.antrag().getEinrichtungStartObjekt().getSmpEinrichtungsId()
            .equals(dokumentenErstellungsDaten.antrag().getEinrichtungTrainingObjekt().getSmpEinrichtungsId())) {
            return UUID.fromString(dokumentenErzeugungConfig.getVorlagenIdBescheidBewilligung());
        } else {
            return UUID.fromString(dokumentenErzeugungConfig.getVorlagenIdBescheidBewilligungUnterschiedlicheEinrichtungen());
        }
    }

    @Override
    protected AllgemeineDokumentenDaten getAllgemeineDokumentenDaten(@Nonnull final DokumentenErstellungsDaten daten) {
        final KontoDto konto = daten.konto();
        final Antrag antrag = daten.antrag();
        return AllgemeineDokumentenDaten.builder()
            .fall(konto.getVersicherungsnummer())
            .ktan(konto.getKtan())
            .aigr(getAigr(antrag))
            .doReview(!daten.dunkelVerarbeitung())
            .isBatchPrint(false)
            .build();
    }

    @Override
    protected Map<String, String> getVariablen(@Nonnull final DokumentenErstellungsDaten daten) {
        final Map<String, String> variablen = new HashMap<>();
        variablen.put("rvEvolution", "1");
        variablen.putAll(getVariablenZurBefuellungDerKonkretenVorlage(daten));
        variablen.putAll(getVariablenZurKommunikationMitRvPur(daten));
        return variablen;
    }

    /**
     * Daten für die Kommunikation mit rvPuR.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return Variablen für die Kommunikation mit rvPur
     */
    private Map<String, String> getVariablenZurKommunikationMitRvPur(@Nonnull final DokumentenErstellungsDaten daten) {
        final Antrag antrag = daten.antrag();
        final Map<String, String> bescheid = new HashMap<>();

        bescheid.put("vorgangsID", antrag.getVorgangskennung());

        bescheid.put("terminUebergeben", "1");
        bescheid.put("terminDatum", LocalDate.now().plusDays(300).format(
            DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        bescheid.put("terminBemerkung", "Aufnahme oder Abschluss RV Fit");
        bescheid.put("inWiedervorlageSchieben", "0");
        bescheid.put("massnahmeArtNummer", "8".concat(MSNR.format(antrag.getMsnr())));

        return bescheid;
    }

    /**
     * Daten zur Befüllung der konkreten neuen Vorlage gemäß <a href="https://rvwiki.drv.drv/x/829wFw"> SST_004_RV Fit und
     * Dokumentenerzeugung (DoE) bzw. DiLooP</a>
     * <p>
     * 5.1. Datenbedarf DiLooP (NEU) für die Konstellation: eine beteiligte Reha-Einrichtung (G9852-00))
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return die Variablen zur Befüllung der konkreten Vorlage
     */
    private Map<String, String> getVariablenZurBefuellungDerKonkretenVorlage(@Nonnull final DokumentenErstellungsDaten daten) {
        final Map<String, String> variablen = new HashMap<>();

        // Daten zur Befüllung der konkreten Vorlage
        variablen.put("dd_Bk_Bezugszeichenzeile", "Datum Ihres Antrags:");
        variablen.put("t_Bezugszeichenzeile", daten.antrag().getAntragsDatum().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        variablen.put("sv_kk_maschineller_Aufruf", "true");
        variablen.put("USEQ_RBH_11_op_Bekanntg_SGG", "Bekanntgabe");
        variablen.put("USEQ_RBH_22_op_Inland_Ausland_EU", getOptionFuerWiderspruchstextInlandAusland(daten));

        variablen.putAll(getSpezielleVariablenZurEinrichtung(daten));

        return variablen;
    }

    /***
     * Je nachdem ob die ausgewählten Einrichtungen bei Start und Trainingsphase identisch sind oder abweichen,
     * erfolgt eine andere Variablenbefüllung bzgl. der Einrichtungsdaten
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return die Variablen zur Befüllung bzgl. der konkreten Einrichtungsdaten
     */
    private Map<String, String> getSpezielleVariablenZurEinrichtung(final DokumentenErstellungsDaten daten) {
        final EinrichtungenUndAngebote angebote = getAngebote(daten);

        return new HashMap<>(daten.antrag().getEinrichtungStartObjekt().getSmpEinrichtungsId()
            .equals(daten.antrag().getEinrichtungTrainingObjekt().getSmpEinrichtungsId())
            ? getVariablenEinrichtungStartTrainingIdentisch(daten, angebote)
            : getVariablenEinrichtungStartTrainingUnterschiedlich(daten, angebote));
    }

    /**
     * Daten zur Befüllung der konkreten Vorlage bei einer beteiligten Rehaeinrichtung gemäß <a
     * href="https://rvwiki.drv.drv/x/829wFw">SST_004_RV Fit und Dokumentenerzeugung (DoE) bzw. DiLooP</a> 6. Datenbedarf DiLooP (NEU) für
     * die Konstellation: eine beteiligte Reha-Einrichtung (G9582-00))
     *
     * @param daten    die Daten zur Dokumentenerstellung
     * @param angebote die zum Antrag ausgewählten Angebote
     * @return die Variablen zur Befüllung bzgl. der konkreten Einrichtungsdaten
     */
    private Map<String, String> getVariablenEinrichtungStartTrainingIdentisch(final DokumentenErstellungsDaten daten,
        EinrichtungenUndAngebote angebote) {
        final Map<String, String> variablenEinrichtung = new HashMap<>();
        variablenEinrichtung.put("sv_kk_G9582_00_Hinweis_Ausschlussgrund", getHinweisAusschlussgrund(daten.antrag().getGeburtsdatum()));
        variablenEinrichtung.put("sv_op_G9582_00_Durchführungsart_Phase_1", angebote.angebotStart().map(Angebot::getDurchfuehrungsart)
            .map(durchfuerungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuerungsArtName, 1))
            .orElse(""));
        variablenEinrichtung.put("sv_gz_G9582_00_Dauer_Phase_1", angebote.angebotStart().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_op_G9582_00_Durchführungsart_Phase_2", angebote.angebotTraining().map(Angebot::getDurchfuehrungsart)
            .map(durchfuehrungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuehrungsArtName, 2))
            .orElse(""));
        variablenEinrichtung.put("sv_gz_G9582_00_Einheiten", angebote.angebotTraining().map(
            Angebot::getAnzahlTrainingseinheiten).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_gz_G9582_00_Wochen", angebote.angebotTraining().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_op_G9582_00_Durchführungsart_Phase_4",
            angebote.angebotAuffrischung().map(Angebot::getDurchfuehrungsart)
                .map(durchfuehrungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuehrungsArtName, 4))
                .orElse(""));
        variablenEinrichtung.put("sv_gz_G9582_00_Dauer_Phase_4", angebote.angebotAuffrischung().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_tm_G9582_00_Name_und_Anschrift_der_Ei", erstelleAdressenString(angebote.rehaEinrichtungStart()));
        variablenEinrichtung.put("sv_t_G9582_00_Telefon", angebote.rehaEinrichtungStart().getTelefonnummer());
        variablenEinrichtung.put("sv_t_G9582_00_E_Mail", angebote.rehaEinrichtungStart().getEmail());

        variablenEinrichtung.put("sv_tm_G9582_00_Freie_Eingabe_Versicherte",
            daten.variableFelder().get(VariablesFeld.FREITEXT_VERSICHERTER));
        variablenEinrichtung.put("sv_tm_G9582_00_Freie_Eingabe_Einrichtung",
            daten.variableFelder().get(VariablesFeld.FREITEXT_EINRICHTUNG));
        return variablenEinrichtung;
    }

    /**
     * Daten zur Befüllung der konkreten Vorlage bei ZWEI beteiligten Rehaeinrichtungen gemäß <a
     * href="https://rvwiki.drv.drv/x/829wFw">SST_004_RV Fit und Dokumentenerzeugung (DoE) bzw. DiLooP</a> 7. Datenbedarf DiLooP (NEU) für
     * die Konstellation: zwei beteiligte Reha-Einrichtungen (G9583-00)
     *
     * @param daten    die Daten zur Dokumentenerstellung
     * @param angebote die zum Antrag ausgewählten Angebote
     * @return die Variablen zur Befüllung bzgl. der konkreten Einrichtungsdaten
     */
    private Map<String, String> getVariablenEinrichtungStartTrainingUnterschiedlich(final DokumentenErstellungsDaten daten,
        EinrichtungenUndAngebote angebote) {
        final Map<String, String> variablenEinrichtung = new HashMap<>();
        variablenEinrichtung.put("sv_kk_G9583_00_Hinweis_Ausschlussgrund", getHinweisAusschlussgrund(daten.antrag().getGeburtsdatum()));
        variablenEinrichtung.put("sv_op_G9583_00_Durchführungsart_Phase_1", angebote.angebotStart().map(Angebot::getDurchfuehrungsart)
            .map(durchfuerungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuerungsArtName, 1))
            .orElse(""));
        variablenEinrichtung.put("sv_gz_G9583_00_Dauer_Phase_1", angebote.angebotStart().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_op_G9583_00_Durchführungsart_Phase_2", angebote.angebotTraining().map(Angebot::getDurchfuehrungsart)
            .map(durchfuehrungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuehrungsArtName, 2))
            .orElse(""));
        variablenEinrichtung.put("sv_gz_G9583_00_Einheiten", angebote.angebotTraining().map(
            Angebot::getAnzahlTrainingseinheiten).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_gz_G9583_00_Wochen", angebote.angebotTraining().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_op_G9583_00_Durchführungsart_Phase_4",
            angebote.angebotAuffrischung().map(Angebot::getDurchfuehrungsart)
                .map(durchfuehrungsArtName -> getDurchfuehrungsArtFuerNameUndPhase(durchfuehrungsArtName, 4))
                .orElse(""));
        variablenEinrichtung.put("sv_gz_G9583_00_Dauer_Phase_4", angebote.angebotAuffrischung().map(
            Angebot::getDauer).map(Objects::toString).orElse(""));
        variablenEinrichtung.put("sv_tm_G9583_00_Name_Anschr_Einrichtung", erstelleAdressenString(angebote.rehaEinrichtungStart()));
        variablenEinrichtung.put("sv_t_G9583_00_Telefon", angebote.rehaEinrichtungStart().getTelefonnummer());
        variablenEinrichtung.put("sv_t_G9583_00_E_Mail", angebote.rehaEinrichtungStart().getEmail());

        //Adresse Einrichtung Training
        variablenEinrichtung.put("sv_tm_G9583_00_Name_Anschr_Einr_Phase_2", erstelleAdressenString(angebote.rehaEinrichtungTraining()));
        variablenEinrichtung.put("sv_t_G9583_00_Telefon_Phase_2", angebote.rehaEinrichtungTraining().getTelefonnummer());
        variablenEinrichtung.put("sv_t_G9583_00_E_Mail_Phase_2", angebote.rehaEinrichtungTraining().getEmail());

        variablenEinrichtung.put("sv_tm_G9583_00_Freie_Eingabe_Versicherte",
            daten.variableFelder().get(VariablesFeld.FREITEXT_VERSICHERTER));
        variablenEinrichtung.put("sv_tm_G9583_00_Freie_Eing_Einr_Phase_1_4",
            daten.variableFelder().get(VariablesFeld.FREITEXT_EINRICHTUNG));
        return variablenEinrichtung;
    }

    private String getOptionFuerWiderspruchstextInlandAusland(final DokumentenErstellungsDaten daten) {
        final LandIsoCodes land = Optional.of(daten.antrag()).map(Antrag::getLand)
            .flatMap(s -> LandIsoCodes.findeLandFuerCode(s, LandIsoCodes.Typ.NTSC))
            .orElse(LandIsoCodes.DEUTSCHLAND);
        if (land == LandIsoCodes.DEUTSCHLAND) {
            return "1";
        }
        return "2";
    }

    /**
     * Liefert an Hand der Durchführungsbezeichnung den Wert der Durchführungsart in Abhängigkeit der Phase (Grund Sonderlocke bei
     * ONLINE-Durchführungsarten).
     *
     * @param durchfuehrungsArtName Bezeichnung der Durchführungsart
     * @param phase                 Phase um die es sich bei der Durchführung handelt (1 - Start, 2 Training, 4 Auffrischung)
     * @return Durchführungsart
     */
    String getDurchfuehrungsArtFuerNameUndPhase(final String durchfuehrungsArtName, final int phase) {
        if (durchfuehrungsArtName.toLowerCase().contains(AMBULANT)) {
            return "0";
        }
        if (durchfuehrungsArtName.toLowerCase().contains(STATIONAER)) {
            return "1";
        }
        if (phase == 2 && durchfuehrungsArtName.toLowerCase().contains(ONLINE)) {
            return "1";
        }
        if (phase == 4 && durchfuehrungsArtName.toLowerCase().contains(ONLINE)) {
            return "2";
        }
        return "";
    }

    private String getHinweisAusschlussgrund(final LocalDate geburtsDatum) {
        return Boolean.toString(geburtsDatum.isBefore(LocalDate.now().minusYears(60)));
    }

    private EinrichtungenUndAngebote getAngebote(DokumentenErstellungsDaten daten) {
        final RehaEinrichtung rehaEinrichtungStart = daten.antrag().getEinrichtungStartObjekt();
        final RehaEinrichtung rehaEinrichtungTraining = daten.antrag().getEinrichtungTrainingObjekt();
        RehaEinrichtung rehaEinrichtungAuffrischung = daten.antrag().getEinrichtungAufObjekt();

        final Optional<Angebot> angebotStart = rehaEinrichtungStart.getAngebote().stream()
            .filter(angebot -> angebot.getPhase().equalsIgnoreCase("Startphase"))
            .findFirst();
        final Optional<Angebot> angebotTraining = rehaEinrichtungTraining.getAngebote().stream()
            .filter(angebot -> angebot.getPhase().equalsIgnoreCase("Trainingsphase"))
            .findFirst();
        final Optional<Angebot> angebotAuffrischung = rehaEinrichtungAuffrischung.getAngebote().stream()
            .filter(angebot -> angebot.getPhase().equalsIgnoreCase("Auffrischungsphase"))
            .findFirst();
        return new EinrichtungenUndAngebote(rehaEinrichtungStart, rehaEinrichtungTraining, angebotStart, angebotTraining,
            angebotAuffrischung);
    }

    /**
     * Record mit Einrichtungen und Angeboten.
     *
     * @param rehaEinrichtungStart    Reha-Einrichtung fuer die Startphase
     * @param rehaEinrichtungTraining Reha-Einrichtung fuer die Trainingsphase
     * @param angebotStart            Angebot fuer die Startphase
     * @param angebotTraining         Angebot fuer die Trainingsphase
     * @param angebotAuffrischung     Angebot fuer die Auffrischungsphase
     */
    private record EinrichtungenUndAngebote(RehaEinrichtung rehaEinrichtungStart, RehaEinrichtung rehaEinrichtungTraining,
        Optional<Angebot> angebotStart, Optional<Angebot> angebotTraining, Optional<Angebot> angebotAuffrischung) {

    }
}
