package de.deutscherv.rvsm.fa.fit.jms;

import java.io.Serial;

/**
 * Exception im Messaging-Umfeld.
 */

public class MessagingException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -3531417001139454531L;

    /**
     * Konstruktor.
     *
     * @param cause Grund der Exception.
     */
    public MessagingException(final Throwable cause) {
        super(cause);
    }

    /**
     * Konstruktor.
     *
     * @param message Beschreibung der Exception.
     * @param cause   Grund der Exception.
     */
    public MessagingException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
