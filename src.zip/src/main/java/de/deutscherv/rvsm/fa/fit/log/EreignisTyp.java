package de.deutscherv.rvsm.fa.fit.log;

/**
 *
 * Enum mit EreignisTypen fuer Fachereignisse.
 * <a href="https://rvwiki.drv.drv/x/74lmHw">Dokumentation Fachprotokoll</a>
 */
public enum EreignisTyp {

    /**
     * Papierantrag wurde erfasst.
     */
    ANTRAG_ERFASST,

    /**
     * Nachrichteneingang maschinell.
     */
    NACHRICHTEN_EINGANG_MASCHINELL,

    /**
     * Nachrichteneingang User.
     */
    NACHRICHTEN_EINGANG_USER,

    /**
     * Nachrichtenausgang maschinell.
     */
    NACHRICHTEN_AUSGANG_MASCHINELL,

    /**
     * Nachrichtenausgang User.
     */
    NACHRICHTEN_AUSGANG_USER,

    /**
     * Zwischenereignis maschinell.
     */
    ZWISCHENEREIGNIS_MASCHINELL,

    /**
     * Zwischenereignis User.
     */
    ZWISCHENEREIGNIS_USER,

    /**
     * Endereignis User.
     */
    ENDEREIGNIS_USER,

    /**
     * Endereignis maschinell.
     */
    ENDEREIGNIS_MASCHINELL,

    /**
     * Bescheid wurde erteilt.
     */
    BESCHEID_ERTEILT

}
