package de.deutscherv.rvsm.fa.fit.util;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

/**
 * DataProcessingUtils.
 */
@UtilityClass
public class DataProcessingUtils {

    private static final int TOLERANZ = 95;
    private static final String WORD_REGEXP = "\\W+";
    private static final String STRASSE_REGEXP = "straße|strasse|str";

    /**
     * Bereitet einen Text für den Vergelcih vor.
     *
     * @param text der Text
     * @return der vorbereitete Text
     */
    public static String formatStringToCompare(final String text) {
        if (StringUtils.isBlank(text)) {
            return null;
        }

        String newText = text;
        newText = newText.trim().toLowerCase();
        newText = newText.replace("ä", "ae");
        newText = newText.replace("ö", "oe");
        newText = newText.replace("ü", "ue");
        newText = newText.replace("ß", "ss");
        return newText;
    }

    /**
     * Formattiert die Straße.
     *
     * @param text der Text
     * @return die formattierte Straße
     */
    public static String formatStrasseToCompare(final String text) {
        if (StringUtils.isBlank(text)) {
            return null;
        }

        String newText = formatStringToCompare(text);
        if (Objects.isNull(newText)) {
            return null;
        }
        newText = newText.replaceAll(STRASSE_REGEXP, "");
        return newText.trim();
    }

    /**
     * Zwei Texts werden analysiert, um festzusetellen, ob sie übereinstimmen oder nicht. Die Texts sind allgemein Daten. True,
     * Übereinstimmung Prozentsatz liegt innerhalb der Toleranz False, otherwise Bevor die Analyse beginnt, sollte die Daten vorbereiten.
     *
     * @param text       der Text
     * @param targetText der Zieltext
     * @return trifft / nicht trifft
     */
    public static boolean matchValues(final String text, final String targetText) {
        if (StringUtils.isBlank(text) || StringUtils.isBlank(targetText)) {
            return false;
        }

        final String formattedText = formatStringToCompare(text);
        final String formattedTargetText = formatStringToCompare(targetText);
        if (formattedTargetText == null || formattedText == null) {
            return false;
        }
        final int tippFehler = getDistanceBetweenTwoStrings(formattedText, formattedTargetText);

        return successRate(targetText.length(), tippFehler);
    }

    /**
     * Zwei Texts werden analysiert, um festzusetellen, ob sie übereinstimmen oder nicht. Die Texts sind Strasse Daten. True,
     * Übereinstimmung Prozentsatz liegt innerhalb der Toleranz False, otherwise Bevor die Analyse beginnt, sollte die Daten vorbereiten.
     *
     * @param text       der Text
     * @param targetText der Zieltext
     * @return trifft / nicht trifft
     */
    public static boolean matchStrasseValues(final String text, final String targetText) {
        if (StringUtils.isBlank(text) || StringUtils.isBlank(targetText)) {
            return false;
        }

        final String formattedText = formatStrasseToCompare(text);
        final String formattedTargetText = formatStrasseToCompare(targetText);
        if (formattedTargetText == null || formattedText == null) {
            return false;
        }
        final int tippFehler = getDistanceBetweenTwoStrings(formattedText, formattedTargetText);

        return successRate(targetText.length(), tippFehler);
    }

    /**
     * Der Abstand zwischen zwei Strings wird berechnet. Beide Strings werden in Wörter getrennt. Distance zwischen die Wörter werden
     * gesammelt.
     *
     * @param text       der Text
     * @param targetText der Zieltext
     * @return distance
     */
    public static int getDistanceBetweenTwoStrings(final String text, final String targetText) {
        if (StringUtils.isBlank(text) || StringUtils.isBlank(targetText)) {
            return -1;
        }

        final AtomicInteger distance = new AtomicInteger(0);
        final String[] words = text.split(WORD_REGEXP);
        final String[] targetWords = targetText.split(WORD_REGEXP);

        if (words.length == targetWords.length) {
            for (int i = 0; i < words.length; i++) {
                distance.addAndGet(getDistanceBetweenTwoWords(words[i], targetWords[i]));
            }
            return distance.get();
        } else {
            return stringsDistanceDiferentLength(words, targetWords);
        }
    }

    /**
     * Berechnet die Destanz für zwei Arrays aus Wörtern unterschiedlicher Länge.
     *
     * @param words       Wörter 1
     * @param targetWords Wörter 2
     * @return die Distanz
     */
    private int stringsDistanceDiferentLength(final String[] words, final String[] targetWords) {
        final AtomicInteger distance = new AtomicInteger(0);

        final int min = Math.min(words.length, targetWords.length);
        for (int i = 0; i < min; i++) {
            distance.addAndGet(getDistanceBetweenTwoWords(words[i], targetWords[i]));
        }
        if (words.length < targetWords.length) {
            for (int i = min; i < targetWords.length; i++) {
                distance.addAndGet(targetWords[i].length());
            }
        } else {
            for (int i = min; i < words.length; i++) {
                distance.addAndGet(words[i].length());
            }
        }
        return distance.get();
    }

    /**
     * Der Abstand zwischen zwei Wörter wird berechnet. Wie viele Buchstabenbewegungen müssen ausgeführt werden, um ein Wort (word) in ein
     * anderes (targetWord) umzuwandeln grundsätzlich equal distance(tail(a), tail(b)) tail(a), b distance(a,b) not equal 1 + distance( a,
     * tail(b) ) tail(a), tail(b) grundsätzlich equal distance(tail(a), tail(b)) tail(a), b distance(a,b) not equal 1 + distance( a, tail(b)
     * ) tail(a), tail(b)
     *
     * @param word       Wort 1
     * @param targetWord Wort 2
     * @return distance
     */
    public static int getDistanceBetweenTwoWords(final String word, final String targetWord) {

        if (word.equals(targetWord)) {
            return 0;
        }

        if (word.length() == 1) {
            return targetWord.indexOf(word.charAt(0)) > -1 ? targetWord.length() - 1
                    : targetWord.length();
        }

        if (targetWord.length() == 1) {
            return word.indexOf(targetWord.charAt(0)) > -1 ? word.length() - 1 : word.length();
        }

        return wordsDistance(word, targetWord);
    }

    /**
     * Bestimmt die Distanz zwischen zwei Wörtern.
     *
     * @param word       Wort 1
     * @param targetWord Wort 2
     * @return die Distanz
     */
    private int wordsDistance(final String word, final String targetWord) {
        final AtomicInteger distance = new AtomicInteger(0);
        if (word.charAt(0) == targetWord.charAt(0)) {
            distance.set(getDistanceBetweenTwoWords(word.substring(1), targetWord.substring(1)));
        } else {
            if (word.length() == targetWord.length()) {
                distance.set(
                        1 + getDistanceBetweenTwoWords(word.substring(1), targetWord.substring(1)));
            } else {
                if (word.charAt(0) == targetWord.charAt(1)) {
                    distance.set(1 + getDistanceBetweenTwoWords(word, targetWord.substring(1)));
                } else {
                    if (word.charAt(1) == targetWord.charAt(0)) {
                        distance.set(1 + getDistanceBetweenTwoWords(word.substring(1), targetWord));
                    } else {
                        distance.set(1 + getDistanceBetweenTwoWords(word.substring(1),
                                targetWord.substring(1)));
                    }
                }
            }
        }
        return distance.get();
    }

    /**
     * Prüft, ob die Anzahl der Tippfehler in der Toleranz liegt.
     *
     * @param length     die Wortlänge
     * @param tippFehler die Anzahl der Tippfehler
     * @return {@code true}, wenn die Anzahl der Tippfehler unter der Toleranz liegt.
     */
    public static boolean successRate(final int length, final int tippFehler) {
        if (length > 0) {
            final int cover = (length - tippFehler) * 100 / length;
            return cover >= TOLERANZ;
        }

        return false;
    }

}
