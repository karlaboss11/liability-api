package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerDto;
import java.util.Collections;
import java.util.List;
import lombok.Getter;

/**
 * PapierantragValidierungException.
 */
@Getter
public class PapierantragValidierungException extends RvfitException {

    private final transient List<FehlerDto> fehlerListe;

    /**
     * Konstruktor.
     *
     * @param message     Fehlernachricht
     * @param fehlerListe Liste der FehlerDTOs
     */
    public PapierantragValidierungException(final String message, final List<FehlerDto> fehlerListe) {
        super(message);
        this.fehlerListe = fehlerListe;
    }

    /**
     * Konstruktor.
     * @param message Fehlernachricht
     */
    public PapierantragValidierungException(final String message) {
        this(message, Collections.emptyList());
    }
}
