package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotFoundException;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor um den Status Statistik abgeschlossen zu setzen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SetzeStatusAufStatistikAbgeschlossenProcessor implements Processor {

    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        Antrag antrag = antragRepository.findByUuid(uuid).orElseThrow(NotFoundException::new);
        antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        antrag = antragRepository.merge(antrag);
        exchange.getMessage().setBody(antrag);
    }
}
