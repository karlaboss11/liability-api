/**
 * Beinhaltet Klassen, die sich mit dem Mapping von Anträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.antraege.mapper;
