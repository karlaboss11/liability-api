package de.deutscherv.rvsm.fa.fit.statistik.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

/**
 * Entity Bestandsfehler.
 */
@Entity
@Table(name = "bestandsfehler")
@Cacheable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bestandsfehler {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column
    private UUID uuid;

    @Column(name = "antrag_id")
    private UUID antragId;

    @Column(name = "bestandsfehlercode")
    private String bestandsfehlercode;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @Column
    private LocalDateTime deleted;
}
