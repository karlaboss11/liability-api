/**
 * Beinhaltet Mapper für Stammdaten.
 */
package de.deutscherv.rvsm.fa.fit.stammdaten.mapper;
