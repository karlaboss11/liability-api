package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 *  Processor zum Erzeugen von Vorgaengen.
 */
@ApplicationScoped
@Slf4j
public class VorgangErzeugungsCheckProcessor implements Processor {
    private final AntragRepository antragRepository;
    private final DrvMandant drvMandant;
    private final AntragService antragService;
    private final int limitAntraegeProDurchlauf;
    private final RvPurService rvPurService;

    /**
     * Konstruktor.
     *
     * @param antragRepository AntragRepository
     * @param drvMandant betroffener Mandant
     * @param antragService AntragService
     * @param rvPurService rvPurService
     * @param limitAntraegeProDurchlauf  Anzahl der Durchlaueufe eines Antrags
     */
    public VorgangErzeugungsCheckProcessor(AntragRepository antragRepository,
            DrvMandant drvMandant,
            AntragService antragService,
            RvPurService rvPurService,
            @ConfigProperty(name = "vorgangserzeugung.cron.limit") int limitAntraegeProDurchlauf) {
        this.antragRepository = antragRepository;
        this.drvMandant = drvMandant;
        this.antragService = antragService;
        this.limitAntraegeProDurchlauf = limitAntraegeProDurchlauf;
        this.rvPurService = rvPurService;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        String ktan = (String) exchange.getProperty(DRVHeader.MANDANT_PROPERTY_KEY);
        try (AutoCloseable ignored = drvMandant.setInScope(ktan)) {
            final List<String> vorgangsKennungen = antragRepository
                    .findAntraegeimStatus(
                            AntragStatus.VORGANG_WIRD_ERSTELLT,
                            limitAntraegeProDurchlauf)
                    .stream().map(Antrag::getVorgangskennung).filter(Objects::nonNull).toList();
            if (vorgangsKennungen.isEmpty()) {
                LOG.atInfo().addArgument(ktan)
                        .log("KTAN [{}] Keine Anträge in Status VORGANG_WIRD_ERSTELLT");
                exchange.getMessage().setBody(new ArrayList<Antrag>());
                return;
            }
            LOG.atInfo().addArgument(ktan)
                    .addArgument(vorgangsKennungen.size())
                    .addArgument(StringUtils.join(",", vorgangsKennungen))
                    .log("KTAN [{}] Frage Status für {} Vorgänge an. Vorgangskennungen [{}]");

            final List<String> neuErzeugteVorgaenge =
                    rvPurService.pruefeRvPurVorgangsErzeugung(ktan, vorgangsKennungen);
            if (neuErzeugteVorgaenge.isEmpty()) {
                LOG.atInfo().addArgument(ktan)
                        .log("KTAN [{}] Keine Vorgänge neuerstellt im Dialog");
                exchange.getMessage().setBody(new ArrayList<Antrag>());
                return;
            }
            LOG.atInfo().addArgument(ktan)
                    .addArgument(neuErzeugteVorgaenge.size())
                    .addArgument(StringUtils.join(",", neuErzeugteVorgaenge))
                    .log("KTAN [{}] {} Vorgänge wurden erzeugt. Vorgangskennungen [{}]");

            final List<Antrag> antraegeZumAktualisieren =
                    antragService.getAntraegeFuerVorgangsKennungen(neuErzeugteVorgaenge);
            final List<String> antragUuids =
                    antraegeZumAktualisieren.stream().map(Antrag::getUuid).map(UUID::toString).toList();

            antragService.setzeStatusVonVorgangWirdErstelltAufVorgangErzeugt(antragUuids);
            final List<Antrag> updatedAntraege = antragRepository.findByUuids(antragUuids);
            exchange.getMessage().setBody(updatedAntraege);
        } catch (final Exception e) {
            LOG.atError().setCause(e).log("Fehler beim Ausführen des CronJobs!");
            throw e;
        }
    }
}
