/**
 * Enthält Repositories für Aufgaben.
 */
package de.deutscherv.rvsm.fa.fit.aufgaben.repository;
