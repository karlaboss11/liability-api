package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierantragValidierung;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Ruft {@link PapierantragValidierung} auf um einen eingehenden Papierantrag zu validieren.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragValidierungProcessor implements Processor {
    /**
     * Routenname zum Validieren eines Papierantrags.
     */
    public static final String DIRECT_PAPIERANTRAG_VALIDIERUNG = "direct:papierantragValidierung";

    private final PapierantragValidierung papierantragValidierung;

    @Override
    public void process(final Exchange exchange) {
        final PapierantragDto papierantragDto = exchange.getMessage().getBody(PapierantragDto.class);
        LoggingUtils.logProcessorPapierantrag(exchange.getFromRouteId(), getClass().getSimpleName(), papierantragDto);
        papierantragValidierung.validiere(papierantragDto);
    }
}
