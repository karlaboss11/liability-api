/**
 * Beinhaltet Klassen für Health- und Readiness-Endpunkte.
 */
package de.deutscherv.rvsm.fa.fit.health;
