package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.azk.AzkService;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum Aktualisierung der Antragsdaten.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class AntragsdatenAktualisierungProcessor implements Processor {

    private static final String DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB = "Delete Pruefergebnisse [{}] des Antrags " +
            "von DB";
    private final EntityManager entityManager;
    private final AntragService antragService;
    private final AzkService azkService;

    @Override
    public void process(Exchange exchange) throws Exception {
        final var uuid = exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.class);
        final Antrag antrag = antragService.getAntragByUuid(uuid);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);

        updateAntragsdaten(antrag);
        deleteAlleRegelnAusserPersonendatenabgleich(antrag);
        entityManager.merge(antrag);
        entityManager.flush();

        exchange.getMessage().setBody(antrag);
    }

    /**
     * Die Antragsdaten werden mit den Stammdaten üverschrieben.
     *
     * @param antrag der Antrags
     */
    @Transactional
    public void updateAntragsdaten(final Antrag antrag) {
        final Stammdaten stammdaten = antrag.getVersichertenStammdaten().getFirst();
        LOG.atDebug().addArgument(antrag.toString()).addArgument(stammdaten.toString())
                .log("Antragsdaten [{}] werden überschrieben mit den Stammdaten [{}]");
        antrag.setGeburtsdatum(stammdaten.getGeburtsdatum());
        antrag.setHausnummer(stammdaten.getHausnummer());
        antrag.setLand(stammdaten.getLand());
        antrag.setNachname(stammdaten.getNachname());
        antrag.setPlz(stammdaten.getPlz());
        antrag.setStaatsangehoerigkeit(stammdaten.getStaatsangehoerigkeit());
        antrag.setStrasse(stammdaten.getStrasse());
        antrag.setVorname(stammdaten.getVorname());
        antrag.setVsnr(stammdaten.getVsnr());
        antrag.setWohnort(stammdaten.getWohnort());
    }

    /**
     * Enfernt alle Regeln Prüfergebnisse außer Personendatenabgleich für einen Antrag.
     *
     * @param antrag der Antrags
     */
    private void deleteAlleRegelnAusserPersonendatenabgleich(final Antrag antrag) {
        LOG.atDebug().log(
                "Service check checkPersonendatenabgleich: Die Anspruchspruefung des Antrags wird berechnet");

        List<AntragPruefergebnis> antragPruefergebnisse = antrag.getAntragPruefergebnisse();
        antragPruefergebnisse.removeIf(ap -> Objects.isNull(ap.getRegelName())
                || ap.getRegelName().equals(RegelName.REGEL_BEMERKUNG)
                || PruefergebnisUtils.EINRICHTUNG_REGELN.contains(ap.getRegelName())
                || PruefergebnisUtils.ANSPRUCHSVORAUSSETZUNG_REGELN.contains(ap.getRegelName()));

        LOG.atDebug().addArgument(RegelName.REGEL_BEMERKUNG)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
        LOG.atDebug().addArgument(PruefergebnisUtils.EINRICHTUNG_REGELN)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
        LOG.atDebug().addArgument(PruefergebnisUtils.ANSPRUCHSVORAUSSETZUNG_REGELN)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
    }
}
