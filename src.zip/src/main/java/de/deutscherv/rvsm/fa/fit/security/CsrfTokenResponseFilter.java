package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.qute.Qute;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * CsrfTokenResponseFilter.
 */
@Provider
public class CsrfTokenResponseFilter implements ContainerResponseFilter {

    @ConfigProperty(name = "quarkus.csrf-reactive.enabled")
    private boolean csrfEnabled;

    @Override
    public void filter(final ContainerRequestContext requestContext,
            final ContainerResponseContext responseContext) throws IOException {
        if (csrfEnabled && requestMethodIsSafe(requestContext)) {
            final String headerName = Qute.fmt("{inject:csrf.headerName}").instance().render();
            final String csrfToken = Qute.fmt("{inject:csrf.token}").instance().render();
            responseContext.getHeaders().add(headerName, csrfToken);
        }
    }

    private static boolean requestMethodIsSafe(final ContainerRequestContext context) {
        return switch (context.getMethod()) {
            case "GET", "HEAD", "OPTIONS" -> true;
            default -> false;
        };
    }
}
