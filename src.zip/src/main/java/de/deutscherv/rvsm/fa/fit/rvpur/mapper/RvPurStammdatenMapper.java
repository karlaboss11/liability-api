package de.deutscherv.rvsm.fa.fit.rvpur.mapper;

import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.StammdatenDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

/**
 * RvPurStammdatenMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface RvPurStammdatenMapper {

    /**
     * Mappt eine Stammdaten in ein RvPur DTO.
     *
     * @param stammdaten Stammdaten
     * @return das RvPur DTO
     */
    @Mapping(source = "land", target = "ntsc")
    @Mapping(target = "herkunft", ignore = true)
    @Mapping(target = "sessionId", ignore = true)
    @Mapping(target = "verweisIOID", ignore = true)
    @Mapping(target = "vorgangskennung", ignore = true)
    StammdatenDto toStammdatenDto(Stammdaten stammdaten);

}
