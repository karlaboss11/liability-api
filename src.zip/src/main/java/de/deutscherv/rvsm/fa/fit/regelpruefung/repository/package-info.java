/**
 * Beinhaltet Repositories für Regeln.
 */
package de.deutscherv.rvsm.fa.fit.regelpruefung.repository;
