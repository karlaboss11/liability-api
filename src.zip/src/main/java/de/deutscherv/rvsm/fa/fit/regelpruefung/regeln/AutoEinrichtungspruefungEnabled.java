package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * Regel - AutoEinrichtungspruefungEnabled Prüft je nach konfigurierbarer Env-Variable eine korrekte Einrichtungsprüfung dennoch
 * ausgesteuert werden soll.
 */
@Singleton
public class AutoEinrichtungspruefungEnabled extends BasisRegel {

    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "Es ist für Ihren Träger keine zwingende manuelle Einrichtungprüfung konfiguriert.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.AUSSTEUERN, "Für ihren Träger ist die manuelle Einrichtungsprüfung konfiguriert.");

    private final String autoEinrichtungspruefungDisabledKtans;

    /**
     * .
     *
     * @param autoEinrichtungspruefungDisabledKtans String aufzählungen der KTANS die KEINE automatische Einrichtungsprüfung wollen
     */
    AutoEinrichtungspruefungEnabled(
            @ConfigProperty(name = "auto.einrichtungspruefung.disabled.ktans") String autoEinrichtungspruefungDisabledKtans) {
        this.autoEinrichtungspruefungDisabledKtans = autoEinrichtungspruefungDisabledKtans;
    }

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_AUTO_EINRICHTUNG_ENABLED;
    }

    @Override
    public Optional<String> getRegelDetail(String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(RegelKontext kontext) {
        if (Objects.isNull(kontext.getAntrag())) {
            return ergebnisAussteuernKeineDaten(this);
        }

        // Aussteuern wenn KTAN aus Antrag in Environment/Property hinterlegt ist
        return (autoEinrichtungspruefungDisabledKtans.contains(kontext.getAntrag().getKtan()))
                ? ergebnisAussteuern(this)
                : ergebnisErfuellt(this);

    }
}




