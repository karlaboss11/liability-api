package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import lombok.Data;

/**
 * SMP-Model: Angebot.
 */
@Data
@SuppressWarnings("java:S1068")
public class Angebot {

    private Long id;
    private String phase;
}
