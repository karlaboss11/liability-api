package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Kontext Objekt für die Regelverwaltung. Hiermit werden die nötigen Daten für die Regelprüfung durch die Regel-Engine gereicht.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("java:S1068")
public class RegelKontext {

    private Antrag antrag;
    private Stammdaten stammdaten;
    private List<RehaEinrichtung> startphaseEinrichtungen;
    private List<RehaEinrichtung> auffrishungsphaseEinrichtungen;
    private List<RehaEinrichtung> trainingsphaseEinrichtungen;
}
