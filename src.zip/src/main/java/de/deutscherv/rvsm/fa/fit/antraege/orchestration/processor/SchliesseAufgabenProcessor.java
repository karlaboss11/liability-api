package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;


/**
 * Processor Schliesse Aufgaben.
 **/
@ApplicationScoped
@RequiredArgsConstructor
public class SchliesseAufgabenProcessor implements Processor {
    private final AufgabeService aufgabeService;
    private final AntragRepository antragRepository;
    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        antrag = aufgabeService.purAufgabeSchliessen(antrag);
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
    }
}
