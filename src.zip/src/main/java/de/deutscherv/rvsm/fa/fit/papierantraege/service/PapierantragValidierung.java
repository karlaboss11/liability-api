package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;

/**
 * Validieruing eines Papiernatrags.
 */
public interface PapierantragValidierung {

    /**
     * Validiere Papierantrag.
     * @param papierantragDto Papierantrag
     */
    void validiere(final PapierantragDto papierantragDto);

    /**
     * Validiere Papierantragentwurf.
     * @param papierantragDto Papierantrag
     */
    void validiereEntwurf(final PapierantragDto papierantragDto);

}
