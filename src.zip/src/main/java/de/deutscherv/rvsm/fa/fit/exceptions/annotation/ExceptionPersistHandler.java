package de.deutscherv.rvsm.fa.fit.exceptions.annotation;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;
import lombok.extern.slf4j.Slf4j;

/**
 * ExceptionPersistHandler.
 */
@Interceptor
@Slf4j
@Priority(Interceptor.Priority.APPLICATION + 1)
@ExceptionPersist
public class ExceptionPersistHandler {

    private final ExceptionHandler exceptionHandler;

    /**
     * Konstruktor.
     *
     * @param exceptionHandler zu benutzender ExceptionHandler
     */
    @Inject
    public ExceptionPersistHandler(ExceptionHandler exceptionHandler) {
        this.exceptionHandler = exceptionHandler;
    }

    /**
     * Exceptiion aus dem Context wird ermittelt.
     *
     * @param context wird untersucht.
     * @return gefundenes Object.
     * @throws Exception Fehler bei der Ausfuehrung
     */
    public Object handleException(InvocationContext context) throws Exception {

        ExceptionPersist exceptionPersistAnnotation = context.getMethod().getAnnotation(ExceptionPersist.class);
        String message = exceptionPersistAnnotation != null ? exceptionPersistAnnotation.message() : "Eine Exception wurde geworfen.";

        Antrag antrag = null;
        try {
            for (Object param : context.getParameters()) {
                if (param instanceof Antrag an) {
                    antrag = an;
                    break;
                }
            }
        } catch (Exception e) {
            LOG.atWarn().addArgument(message).log("UUID konnte nicht aus Parameter extrahiert werden. [{}]");
        }

        try {
            return context.proceed();
        } catch (Exception e) {
            exceptionHandler.handleExceptionForRetry(e, antrag, message);
            throw e;
        }
    }
}