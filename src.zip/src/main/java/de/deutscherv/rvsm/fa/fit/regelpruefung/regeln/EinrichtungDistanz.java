package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungMehrAls50KmEntfernt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * The Regel Class EinrichtungAngebotEindeutig.
 */
@Singleton
public class EinrichtungDistanz extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(RegelUtils.ERFUELLT,
            "Die Einrichtung der Start- oder Trainingsphase liegt innerhalb von 50 Kilometern vom Wohnort des Versicherten.",
            RegelUtils.AUSSTEUERN_DISTANZ_MEHR_ALS_50,
            "Die Einrichtung der Start- oder Trainingsphase ist mehr als 50 Kilometer vom Wohnort des Versicherten entfernt.");

    /**
     * Gets the regel name.
     *
     * @return the regel name
     */
    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_EINRICHTUNG_DISTANZ;
    }

    /**
     * Gets the regel detail.
     *
     * @param regelErgebnis the regel ergebnis
     * @return the regel detail
     */
    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    /**
     * Pruefe regel.
     *
     * @param kontext the kontext
     * @return the RegelErgebnis list
     */
    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (EinrichtungsdatenUtils.keineEinrichtungenVorhanden(kontext.getAntrag())) {
            return new ArrayList<>();
        }

        final boolean hatStartAngeboteMehrAls50Km =
                EinrichtungsdatenUtils.einrichtungMehrAls50KmUndAmbulanteAngebote(
                        PhaseEnumDto.STARTPHASE, kontext.getStartphaseEinrichtungen());
        final boolean hatAuffrischungAngeboteMehrAls50Km =
                EinrichtungsdatenUtils.einrichtungMehrAls50KmUndAmbulanteAngebote(
                        PhaseEnumDto.AUFFRISCHUNG, kontext.getAuffrishungsphaseEinrichtungen());
        final boolean hatTrainingAngeboteMehrAls50Km =
                EinrichtungsdatenUtils.einrichtungMehrAls50KmUndAmbulanteAngebote(
                        PhaseEnumDto.TRAININGSPHASE, kontext.getTrainingsphaseEinrichtungen());

        if (hatStartAngeboteMehrAls50Km || hatAuffrischungAngeboteMehrAls50Km
                || hatTrainingAngeboteMehrAls50Km) {
            return ergebnisEinrichtungMehrAls50KmEntfernt(this);
        }
        return ergebnisErfuellt(this);
    }
}
