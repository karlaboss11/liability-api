package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.jms.MessagingException;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import jakarta.ws.rs.NotAllowedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.NotSupportedException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.jboss.resteasy.reactive.ClientWebApplicationException;

/**
 * GenericExceptionMapper.
 */
@Provider
@Slf4j
public class GenericExceptionMapper implements ExceptionMapper<Throwable> {

    private static final String EXCEPTION_LOG_PLACEHOLDER = ": [{}]";

    private static final String UNERWARTETER_FEHLER_NACHRICHT =
        "Ein unerwarteter Fehler ist aufgetreten";
    private static final String STAMMDATEN_FEHLER_NACHRICHT =
        "Ein Fehler in der Stammdatenverarbeitung ist aufgetreten";
    private static final String WEBAPPLICATION_FEHLER_NACHRICHT =
        "Ein Fehler in einem Rest Client ist aufgetreten";
    private static final String UNGUELTIGES_ARGUMENT_NACHRICHT =
        "Ein ungültiges Argument wurde übergeben";
    private static final String NOT_ALLOWED_FEHLER_NACHRICHT =
        "Diese HTTP Methode ist für die Ressource nicht erlaubt";
    private static final String NOT_SUPPORTED_FEHLER_NACHRICHT =
        "Dieser MediaType wird für die Ressource nicht unterstützt";
    private static final String NOT_FOUND_NACHRICHT =
        "Die angeforderte Resource wurde nicht gefunden";
    private static final String NOT_IMPLEMENTED_NACHRICHT =
        "Ein Fall oder eine Methode wurde nicht implementiert";

    private static final Map<Class<? extends Throwable>, Function<Throwable, Response>> EXCEPTION_MAPPING;

    static {
        Map<Class<? extends Throwable>, Function<Throwable, Response>> exceptionMapping = new HashMap<>();

        exceptionMapping.put(IllegalArgumentException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(UNGUELTIGES_ARGUMENT_NACHRICHT);
            return Response.status(Status.BAD_REQUEST).entity(
                    new AntwortDto().code(Status.BAD_REQUEST.getStatusCode()).nachricht(UNGUELTIGES_ARGUMENT_NACHRICHT))
                .build();
        });

        exceptionMapping.put(ClientWebApplicationException.class, exception -> {
            LOG.atWarn()
                .setCause(exception)
                .addArgument(exception.getMessage())
                .log(WEBAPPLICATION_FEHLER_NACHRICHT + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY).entity(
                    new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode()).nachricht(WEBAPPLICATION_FEHLER_NACHRICHT))
                .build();
        });

        exceptionMapping.put(ArrayIndexOutOfBoundsException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(STAMMDATEN_FEHLER_NACHRICHT);
            return Response.status(Status.SERVICE_UNAVAILABLE).entity(
                    new AntwortDto().code(Status.SERVICE_UNAVAILABLE.getStatusCode()).nachricht(STAMMDATEN_FEHLER_NACHRICHT))
                .build();
        });

        exceptionMapping.put(NotAllowedException.class, exception -> {
            LOG.atWarn().addArgument(matchHttpMethodInString(exception.getMessage())).addArgument(exception)
                .log(NOT_ALLOWED_FEHLER_NACHRICHT + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.METHOD_NOT_ALLOWED).entity(
                    new AntwortDto().code(Status.METHOD_NOT_ALLOWED.getStatusCode()).nachricht(NOT_ALLOWED_FEHLER_NACHRICHT))
                .header("Allow", ((NotAllowedException) exception).getResponse().getAllowedMethods())
                .build();
        });

        exceptionMapping.put(NotSupportedException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(NOT_SUPPORTED_FEHLER_NACHRICHT);
            return Response.status(Status.UNSUPPORTED_MEDIA_TYPE).entity(
                    new AntwortDto().code(Status.UNSUPPORTED_MEDIA_TYPE.getStatusCode()).nachricht(NOT_SUPPORTED_FEHLER_NACHRICHT))
                .header("Accept", ((NotSupportedException) exception).getResponse().getMediaType())
                .build();
        });

        exceptionMapping.put(ServiceUnavailableException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(exception.getMessage());
            return Response.status(Status.SERVICE_UNAVAILABLE).entity(
                    new AntwortDto().code(Status.SERVICE_UNAVAILABLE.getStatusCode()).nachricht(exception.getMessage()))
                .build();
        });

        exceptionMapping.put(MessagingException.class, exception -> {
            LOG.atWarn()
                .setCause(exception)
                .log(UNERWARTETER_FEHLER_NACHRICHT);
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                .entity(
                    new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode())
                        .nachricht(UNERWARTETER_FEHLER_NACHRICHT))
                .build();
        });

        exceptionMapping.put(NotFoundException.class, exception -> {
            LOG.atWarn()
                .setCause(exception)
                .log(NOT_FOUND_NACHRICHT);
            return Response.status(Status.NOT_FOUND)
                .entity(
                    new AntwortDto().code(Status.NOT_FOUND.getStatusCode())
                        .nachricht(NOT_FOUND_NACHRICHT))
                .build();
        });

        exceptionMapping.put(NotImplementedException.class, exception -> {
            LOG.atWarn()
                .setCause(exception)
                .log(NOT_IMPLEMENTED_NACHRICHT);
            return Response.status(Status.NOT_IMPLEMENTED)
                .entity(
                    new AntwortDto().code(Status.NOT_IMPLEMENTED.getStatusCode())
                        .nachricht(NOT_IMPLEMENTED_NACHRICHT))
                .build();
        });

        EXCEPTION_MAPPING = Map.copyOf(exceptionMapping);

    }

    @Override
    public Response toResponse(final Throwable exception) {
        MDCUtils.setFailed();
        var function = EXCEPTION_MAPPING.getOrDefault(exception.getClass(), ex -> {
            LOG.atWarn().addArgument(ex.getMessage())
                .log("sys_crash" + EXCEPTION_LOG_PLACEHOLDER + ": "
                    + UNERWARTETER_FEHLER_NACHRICHT);
            // all other errors -> 500
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                .entity(new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode())
                    .nachricht(UNERWARTETER_FEHLER_NACHRICHT))
                .build();
        });
        return function.apply(exception);
    }

    private static String matchHttpMethodInString(final String string) {
        final Pattern pattern =
            Pattern.compile("\\b(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|CONNECT|TRACE)\\b");
        final Matcher matcher = pattern.matcher(string);
        return matcher.find() ? matcher.group() : null;
    }
}
