package de.deutscherv.rvsm.fa.fit.security;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.core.HttpHeaders;
import java.io.IOException;
import java.util.Base64;
import lombok.Data;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * SelbstmeldeportalBasicAuthFilter.
 */
@Priority(Priorities.AUTHENTICATION)
@Data
public class SelbstmeldeportalBasicAuthFilter implements ClientRequestFilter {

    @ConfigProperty(name = "smp.disable.authorization", defaultValue = "false")
    private boolean disableAuthorization;
    @ConfigProperty(name = "quarkus.rest-client.selbstmeldeportal.user")
    private String user;

    @ConfigProperty(name = "quarkus.rest-client.selbstmeldeportal.password")
    private String password;

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        if (!disableAuthorization) {
            requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION,
                    "Basic " + Base64.getEncoder().encodeToString((user + ":" + password).getBytes()));
        }
    }
}
