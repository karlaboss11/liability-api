package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import lombok.Data;

/**
 * Geokoordinaten.
 */
@Data
@SuppressWarnings("java:S1068")
public class Geokoordinaten {

    private float latitude;
    private float longitude;
}
