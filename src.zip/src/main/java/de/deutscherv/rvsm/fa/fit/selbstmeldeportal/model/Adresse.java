package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import lombok.Data;

/**
 * SMP-Model: Adresse.
 */
@Data
@SuppressWarnings("java:S1068")
public class Adresse {

    private String strasse;
    private String nr;
    private String plz;
    private String ort;
    private String adressZusatz;
    private String anbindung;
}
