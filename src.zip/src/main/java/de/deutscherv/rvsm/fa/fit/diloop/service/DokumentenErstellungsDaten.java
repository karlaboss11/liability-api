package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentenErzeugungConfig;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import jakarta.annotation.Nonnull;

import java.util.Collections;
import java.util.Map;

/**
 * Wrapper für die Eingabeparameter zur Dokumentenerzeugung.
 *
 * @param antrag             ein rvFit-Antrag
 * @param konto              das Konto der versicherten Person
 * @param config             Konfigurationsparameter
 * @param variableFelder     Map mit möglichen zusätzlichen Variablen
 * @param dunkelVerarbeitung Schalter, der angibt, ob ein Dokument ohne Review im Frontend gedruckt werden soll
 */
public record DokumentenErstellungsDaten(
        @Nonnull Antrag antrag,
        @Nonnull KontoDto konto,
        @Nonnull DokumentenErzeugungConfig config,
        @Nonnull Boolean dunkelVerarbeitung,
        @Nonnull
        Map<VariablesFeld, String> variableFelder
) {

    /**
     * Konstruktor.
     *
     * @param antrag             Antrag
     * @param konto              Konto
     * @param config             Konfiguration zur Dokumenterzeugung
     * @param dunkelVerarbeitung true - Dunkelverarbeitung wird durchgefuehrt.
     */
    public DokumentenErstellungsDaten(@Nonnull final Antrag antrag, @Nonnull final KontoDto konto,
            @Nonnull final DokumentenErzeugungConfig config, @Nonnull final Boolean dunkelVerarbeitung) {
        this(antrag, konto, config, dunkelVerarbeitung, Collections.emptyMap());
    }
}

