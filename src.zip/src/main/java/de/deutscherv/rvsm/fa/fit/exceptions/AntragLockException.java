package de.deutscherv.rvsm.fa.fit.exceptions;

import java.util.UUID;

/**
 * Exception Antrag-Lock.
 */
public class AntragLockException extends RvfitException {

    /**
     * Konstruktor.
     * @param uuid  UUID des Antrags
     * @param cause Grund der Exception
     */
    public AntragLockException(UUID uuid, Throwable cause) {
        super(String.format("Fehler beim Lock des Antrags mit der ID [%s].", uuid.toString()),
                cause);
    }
}
