package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.StatistikBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor Schliesse Statistik ab.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SchliesseStatistikAbProcessor implements Processor {
    private final StatistikService statistikService;
    private final AntragRepository antragRepository;
    private final FehlerRepository fehlerRepository;
    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);

        final Boolean erledigungVorRegelPruefung = Optional.ofNullable(
                exchange.getProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG, Boolean.class)
        ).orElse(false);

        final Art erledigungsArt = exchange.getProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, Art.class);

        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        try {
            statistikService.createStatistik(antrag, erledigungsArt, erledigungVorRegelPruefung);
        } catch (final StatistikBestandsFehlerException e) {
            exchange.getMessage().setHeader(RVFitCamelHeader.STATISTIK_BESTANDSFEHLER, e);
            if (antrag.getStatus() == AntragStatus.AUFGABE_ABGESCHLOSSEN || antrag.getStatus() == AntragStatus.BESCHEID_ABGESCHLOSSEN) {
                antrag.setStatus(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN);
            }
        } catch (final StatistikException e) {
            fehlerRepository.persistiereFehlerFuerAntrag(antrag);
            exchange.setRouteStop(true);
        }
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
    }
}
