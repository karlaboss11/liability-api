package de.deutscherv.rvsm.fa.fit.verarbeitung.model;

/**
 * VerarbeitungStatus.
 */
public enum VerarbeitungStatus {

    /**
     * Bescheid wurde erstellt.
     */
    ERSTELLT,

    /**
     * Fehler beim Bescheid.
     */
    FEHLER,

    /**
     * Bescheid wurde versandt.
     */
    VERSANDT,

    /**
     * Bescheid wurde physisch verarbeitet.
     */
    PHYSISCH_VERSANDT,

    /**
     * Kein Bescheid notwendig, da erledigt aus sonstigen Gründen.
     * <ul>
     * <li>STORNO</li>
     * <li>RUECKNAMHE</li>
     * <li>ELEDIGUNG AUF ANDERE ART UND WEISE</li>
     * <li>GESPERRT</li>
     * </ul>
     */
    OHNE_VERSAND_ERLEDIGT
}
