package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import jakarta.enterprise.context.Dependent;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Named;
import jakarta.jms.XAConnectionFactory;
import jakarta.transaction.SystemException;
import jakarta.transaction.TransactionManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.component.jms.JmsComponent;
import org.messaginghub.pooled.jms.JmsPoolConnectionFactory;

/**
 * A component producer for a {@link JmsComponent} capable of XA transactions,
 * using {@link org.messaginghub.pooled.jms.JmsPoolXAConnectionFactory}.
 */
@Dependent
@Slf4j
public class XAJmsComponent {

    /**
     * The key under which this component can be accessed in routing.
     */
    public static final String COMPONENT_KEY = "xajms";
    private static final int TRANSACTION_TIMEOUT_SECONDS = 200;

    /**
     * Liefert xs-JMS-RouteName.
     *
     * @param queue Name
     * @return Routenname.
     */
    public static String getxajmsRouteName(String queue) {
        return COMPONENT_KEY + ":queue:" + queue;
    }

    /**
     * Erstellt die JMS Komponente inklusive Konfiguration für die Spoc adapter queue.
     *
     * @param connectionFactory  {@link XAConnectionFactory}
     * @param transactionManager {@link TransactionManager}
     * @return erstellte JMS Komponente
     * @throws SystemException Wenn was schief läuft.
     */
    @Produces
    @Named(COMPONENT_KEY)
    public JmsComponent xaJms(final XAConnectionFactory connectionFactory,
        final TransactionManager transactionManager) throws SystemException {
        final JmsPoolConnectionFactory pooledXaCf = new JmsPoolConnectionFactory();
        transactionManager.setTransactionTimeout(TRANSACTION_TIMEOUT_SECONDS);
        pooledXaCf.setConnectionFactory(connectionFactory);
        pooledXaCf.setMaxConnections(1);
        pooledXaCf.setMaxSessionsPerConnection(2);
        pooledXaCf.setUseAnonymousProducers(false);

        final JmsComponent jmsComponentTransacted = JmsComponent.jmsComponent(pooledXaCf);
        jmsComponentTransacted.setIncludeSentJMSMessageID(true);
        // disable local transactions as JTA TM will take care of enrolling
        jmsComponentTransacted.setTransacted(false);
        jmsComponentTransacted.setExceptionListener(null);

        // caching does not work with distributed transactions
        jmsComponentTransacted.setCacheLevelName("CACHE_NONE");

        return jmsComponentTransacted;
    }

}
