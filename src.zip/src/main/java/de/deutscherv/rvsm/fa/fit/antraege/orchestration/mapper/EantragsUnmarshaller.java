package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * EantragsUnmarshaller.
 */
@Singleton
@Slf4j
public class EantragsUnmarshaller implements Processor {
    private static final RVFitXmlMarshaller MARSHALLER = new RVFitXmlMarshaller();

    @Override
    public void process(final Exchange exchange) throws Exception {
        final var xml = exchange.getMessage().getBody(String.class);
        final var antragsdaten = MARSHALLER.unmarshall(Antragsdaten.class, xml);
        exchange.getMessage().setBody(antragsdaten);
        exchange.getMessage().setHeader(RVFitCamelHeader.EANTRAG_XML, xml);
    }
}
