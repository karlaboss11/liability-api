package de.deutscherv.rvsm.fa.fit.log;

import lombok.Getter;

/**
 * CEF-Reason.
 */
@Getter
public enum CEFReason {
    /**
     * Invalid Token.
     */
    INVALID_TOKEN("invalid_token", "Invalid Token"),
    /**
     * Expired Token.
     */
    EXPIRED_TOKEN("expired_token", "Expired Token"),
    /**
     * No Token.
     */
    NO_TOKEN("no_token", "No Token"),
    /**
     * No Permission.
     */
    NO_PERMISSION("no_permission", "No Permission"),
    /**
     * Validation failed.
     */
    VALIDATION_FAILED("validation_failed", "Validation failed"),
    /**
     * Unauthorized Request.
     */
    UNAUTHORIZED_REQUEST("unauthorized_request", "Unauthorized Request"),
    /**
     * Token Create.
     */
    TOKEN_CREATE("token_create", "Token Create"),
    /**
     * Resource Not found.
     */
    RESOURCE_NOT_FOUND("resource_not_found", "Resource not found"),
    /**
     * User Auto Logout.
     */
    USER_AUTO_LOGOUT("user_auto_logout", "User Auto Logout");

    private final String value;
    private final String msg;

    /**
     * Konstruktor.
     *
     * @param value zu setzender Wert
     * @param msg   zu setzende Nachricht
     */
    CEFReason(final String value, final String msg) {
        this.value = value;
        this.msg = msg;
    }

}
