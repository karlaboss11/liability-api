/**
 * Beinhaltet Klassen für die Kommunikation mit dem rvSystem Bestand für die Kontoinformationen.
 */
package de.deutscherv.rvsm.fa.fit.kontoinformation;
