package de.deutscherv.rvsm.fa.fit.jms;

import de.deutscherv.rvsm.fa.fit.util.MessagingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.eclipse.microprofile.config.ConfigProvider;

/**
 * Routen Fachprotokoll.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class FapRoutes extends RouteBuilder  {


    /**
     * Routenname: sende fachliches Protokoll.
     */
    public static final String DIRECT_SENDE_FACHLICHES_PROTOKOLL = "direct:sendeFachlichesProtokoll";

    @Override
    public void configure() throws Exception {
        // @formatter:off
        from(DIRECT_SENDE_FACHLICHES_PROTOKOLL)
                .transacted()
                .to(MessagingUtils.getJmsRouteForTextMessageType(ConfigProvider.getConfig()
                        .getValue("fap.queue.outgoing.request.create.fachereignis", String.class)));
        // @formatter:on
    }


}
