package de.deutscherv.rvsm.fa.fit.antraege.repository;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * Konvertiert einen Boolean nach Number.
 * true -> 1, false -> 0
 */
@Converter
public class BooleanToNumberConverter implements AttributeConverter<Boolean, Integer> {
    @Override
    public Integer convertToDatabaseColumn(final Boolean attribute) {
        return (attribute != null && attribute) ? 1 : 0;
    }

    @Override
    public Boolean convertToEntityAttribute(final Integer attribute) {
        return attribute != null && attribute == 1;
    }
}
