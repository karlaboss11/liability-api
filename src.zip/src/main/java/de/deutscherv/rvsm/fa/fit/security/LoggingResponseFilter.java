package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.ba.observe.quarkus.cef.logging.runtime.CEF;
import de.deutscherv.rvsm.fa.fit.log.CEFCommons;
import de.deutscherv.rvsm.fa.fit.log.CEFEventType;
import de.deutscherv.rvsm.fa.fit.log.CEFLogger;
import de.deutscherv.rvsm.fa.fit.log.CEFOutCome;
import de.deutscherv.rvsm.fa.fit.log.CEFReason;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpStatus;

/**
 * Ein Filter, der das MDC-Feld statusCode befuellt.
 */
@Provider
@Priority(Priorities.AUTHENTICATION + 1)
@RequiredArgsConstructor
public class LoggingResponseFilter implements ContainerResponseFilter {

    private final LoggingRequestFilter loggingRequestFilter;
    private final CEFLogger cefLogger;
    private final CEFCommons cefCommons;

    @Override
    public void filter(final ContainerRequestContext requestContext,
        final ContainerResponseContext responseContext) throws IOException {
        if (responseContext.getStatus() == HttpStatus.SC_UNAUTHORIZED) {
            cefLogUnauthorized(requestContext, CEFReason.INVALID_TOKEN);
        }

        if (responseContext.getStatus() == HttpStatus.SC_FORBIDDEN) {
            cefLogUnauthorized(requestContext, CEFReason.NO_PERMISSION);
        }

        if (responseContext.getStatus() == HttpStatus.SC_BAD_REQUEST) {
            cefLogBadRequest(requestContext, responseContext);
        }

        if (responseContext.getStatus() == HttpStatus.SC_NOT_FOUND
            && !requestContext.getUriInfo().getPath().contains("/entwurf")) {
            cefLogNotFound(requestContext, responseContext);
        }

        if (responseContext.getStatus() == HttpStatus.SC_LOCKED) {
            cefLogLocked(requestContext, responseContext);
        }

        if (responseContext.getStatusInfo().getFamily() == Response.Status.Family.SUCCESSFUL) {
            cefLogAccessSuccessful(requestContext, responseContext);
        }

        if (responseContext.getStatusInfo().getFamily() == Response.Status.Family.SERVER_ERROR) {
            cefLogAccessFailure(requestContext, responseContext);
        }

        if (responseContext.getStatusInfo().getFamily() == Response.Status.Family.CLIENT_ERROR) {
            cefLogAccessDenied(requestContext, responseContext);
        }

        MDCUtils.setInScope(MDCKey.STATUS_CODE, String.valueOf(responseContext.getStatus()));
    }

    /**
     * Behandelt den SIEM-CASE-20 für den Fall, dass der Zugriff verweigert wurde.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogAccessDenied(final ContainerRequestContext requestContext, final ContainerResponseContext responseContext) {
        final String user = loggingRequestFilter.getUserId();
        final Integer bytesOut = Optional.ofNullable(responseContext.getEntity()).map(Object::toString)
            .map(String::getBytes).map(a -> a.length).orElse(0);
        cefLogger.atMedium(CEFEventType.APPLICATION, 3030)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(user)
            .customerKey(55L)
            .deviceAction(CEF.DeviceAction.DENY)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .bytesOut(bytesOut)
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log("Request of user {} to {} was denied.", user, cefCommons.getDestinationHostName());
    }

    /**
     * Behandelt den SIEM-CASE-20 für den Fall, dass beim Zugriff ein Fehler im Backend aufgetreten ist.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogAccessFailure(final ContainerRequestContext requestContext, final ContainerResponseContext responseContext) {
        final String user = loggingRequestFilter.getUserId();
        final Integer bytesOut = Optional.ofNullable(responseContext.getEntity()).map(Object::toString)
            .map(String::getBytes).map(a -> a.length).orElse(0);
        cefLogger.atDebug(CEFEventType.APPLICATION, 3030)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(user)
            .customerKey(55L)
            .deviceAction(CEF.DeviceAction.FAIL)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .bytesOut(bytesOut)
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log("Request of user {} to {} failed", user, cefCommons.getDestinationHostName());
    }

    /**
     * Behandelt den SIEM-CASE-20 für den Fall, dass der Zugriff erfolgreich war.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogAccessSuccessful(final ContainerRequestContext requestContext, final ContainerResponseContext responseContext) {
        final String user = loggingRequestFilter.getUserId();
        final Integer bytesOut = Optional.ofNullable(responseContext.getEntity()).map(Object::toString)
            .map(String::getBytes).map(a -> a.length).orElse(0);
        cefLogger.atDebug(CEFEventType.APPLICATION, 3030)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(user)
            .customerKey(55L)
            .deviceAction(CEF.DeviceAction.SUCCEED)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .bytesOut(bytesOut)
            .eventOutcome(CEFOutCome.SUCCESS.getValue())
            .log("Request of user {} to {} was successful", user, cefCommons.getDestinationHostName());
    }

    /**
     * Behandelt den SIEM-CASE-11 für den Fall, dass der Zugriff auf eine Resource versucht wurde, die nicht existiert.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogNotFound(final ContainerRequestContext requestContext,
        ContainerResponseContext responseContext) {
        final String userId = loggingRequestFilter.getUserId();
        cefLogger.atMedium(CEFEventType.AUTHENTICATION, 3040)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(userId)
            .customerKey(55L)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .message(cefCommons.getMessage(responseContext))
            .reason(CEFReason.RESOURCE_NOT_FOUND.getValue())
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log("User {} requested non-existing resource.", userId);
    }

    /**
     * Behandelt den fachlichen SIEM-CASE für den Fall, dass der Zugriff auf ein gesperrtes Konto versucht wurde.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogLocked(final ContainerRequestContext requestContext,
        ContainerResponseContext responseContext) {
        final String userId = loggingRequestFilter.getUserId();
        cefLogger.atHigh(CEFEventType.APPLICATION, 3010)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(userId)
            .customerKey(55L)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .deviceAction(CEF.DeviceAction.BLOCK)
            .message(cefCommons.getMessage(responseContext))
            .reason("account_locked")
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log("User {} requested access to a locked account.", userId);
    }

    /**
     * Behandelt den SIEM-CASE-10 für den Fall, dass die Eingabevalidierung fehlgeschlagen ist.
     *
     * @param requestContext  der RequestContext
     * @param responseContext der ResponseContext
     */
    private void cefLogBadRequest(final ContainerRequestContext requestContext,
        ContainerResponseContext responseContext) {
        cefLogger.atMedium(CEFEventType.APPLICATION, 3150)
            .startTime(Optional.of(requestContext).map(ContainerRequestContext::getDate).map(
                Date::toInstant).orElseGet(Instant::now))
            .sourceAddress(loggingRequestFilter.getHostOrIpAddress(requestContext))
            .destinationHostName(cefCommons.getDestinationHostName())
            .sourceUserName(loggingRequestFilter.getUserId())
            .customerKey(55L)
            .deviceAction(CEF.DeviceAction.BLOCK)
            .destinationServiceName(cefCommons.getDestinationServiceName())
            .requestUrl(cefCommons.getRequestUrl(requestContext))
            .requestMethod(requestContext.getMethod())
            .message(cefCommons.getMessage(responseContext))
            .reason("validation_failed")
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log();
    }

    /**
     * Behandelt den SIEM-CASE-1 für den Fall, dass kein gültiges JWT vorliegt oder die notwendigen Berechtigungen nicht vorhanden sind.
     *
     * @param requestContext der RequestContext
     * @param reason         der Grund für das Event
     */
    private void cefLogUnauthorized(final ContainerRequestContext requestContext, final CEFReason reason) {
        cefLogger.unauthorized(loggingRequestFilter.getHostOrIpAddress(requestContext),
                cefCommons.getDestinationHostName(),
                loggingRequestFilter.getUserId(),
                "spriv - tbd",
                CEF.DeviceAction.BLOCK,
                reason.getValue(),
                cefCommons.getRequestUrl(requestContext),
                requestContext.getMethod(),
                null, 55L)
            .eventOutcome(CEFOutCome.FAILURE.getValue())
            .log("Access to {} denied. Reason: {}", cefCommons.getRequestUrl(requestContext), reason.getMsg());
    }

}
