package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAblehnen;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Bezug Altersrente.
 */
@Singleton
public class BezugAltersrenteRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(
                    RegelUtils.ERFUELLT, "Es besteht kein laufender Bezug einer Altersrente",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.NICHT_ERFUELLT_ABLEHNEN, "Es besteht ein laufender Bezug einer Altersrente",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es besteht ein laufender Bezug einer Altersrente");
    //Leistungsart
    private static final List<String> LEAT_CODES = List.of("65", "18", "63", "62", "17", "16", "10", "19");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_BEZUGALTERSRENTE;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String bezugRenteLeat = kontoinformation.getBezugRenteLeat();
        // Teilrentenart
        final String bezugRenteTlrt = kontoinformation.getBezugRenteTlrt();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(bezugRenteLeat).firstExpected("??")
                .secondValue(bezugRenteTlrt).secondExpected("?").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (!StringUtils.isBlank(bezugRenteLeat)
                && !LEAT_CODES.contains(bezugRenteLeat.trim())
                || StringUtils.isBlank(bezugRenteTlrt)) {

            return ergebnisErfuellt(this);
        }

        if (hatLEATRente(bezugRenteLeat)
                && !StringUtils.isBlank(bezugRenteTlrt)
                && List.of("8", "9").contains(bezugRenteTlrt.trim())) {

            return ergebnisNichtErfuelltAussteuern(this);
        }
        if (hatLEATRente(bezugRenteLeat)
                && !StringUtils.isBlank(bezugRenteTlrt)
                && bezugRenteTlrt.trim().equals("0")) {
            return ergebnisNichtErfuelltAblehnen(this);

        }
        return ergebnisAussteuernKeineDaten(this);
    }

    private static boolean hatLEATRente(final String bezugRenteLeat) {
        return !StringUtils.isBlank(bezugRenteLeat) && LEAT_CODES.contains(bezugRenteLeat.trim());
    }

}
