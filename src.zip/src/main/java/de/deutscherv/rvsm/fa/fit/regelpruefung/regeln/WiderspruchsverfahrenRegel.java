package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Widerspruchsverfahren.
 */
@Singleton
public class WiderspruchsverfahrenRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(
                    RegelUtils.ERFUELLT, "Es besteht kein laufendes Wiederspruchsverfahren",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es besteht ein laufendes Wiederspruchsverfahren");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_WIDERSPRUCHSVERFAHREN;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation =
                kontext.getAntrag().getKontoinformationen().getFirst();
        final Boolean rechtsbehelfRente = kontoinformation.getRechtsbehelfRente();
        final Boolean rechtsbehelfReha = kontoinformation.getRechtsbehelfReha();

        if (Boolean.FALSE.equals(rechtsbehelfRente) && Boolean.FALSE.equals(rechtsbehelfReha)) {
            return ergebnisErfuellt(this);
        }
        if (Boolean.TRUE.equals(rechtsbehelfRente) || Boolean.TRUE.equals(rechtsbehelfReha)) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        return ergebnisAussteuernKeineDaten(this);

    }
}
