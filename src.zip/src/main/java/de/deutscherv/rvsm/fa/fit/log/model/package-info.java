/**
 * Model für die fachliche Protokollierung.
 */
package de.deutscherv.rvsm.fa.fit.log.model;
