package de.deutscherv.rvsm.fa.fit.fehler.model;

import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

/**
 * Klasse für Fehlerzustände.
 */
@Entity
@Table(name = "Fehler")
@Cacheable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fehler {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column
    private UUID uuid;

    @Column(name = "antragId")
    private UUID antragId;

    @Column
    @Enumerated(EnumType.STRING)
    private AntragStatus status;

    @Column(name = "retries")
    private int retries;

    private String nachricht;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    /**
     * Erhöht den retry Counter.
     *
     * @return den neuen Retry counter
     */

    public int inc() {
        retries++;
        return retries;
    }
}
