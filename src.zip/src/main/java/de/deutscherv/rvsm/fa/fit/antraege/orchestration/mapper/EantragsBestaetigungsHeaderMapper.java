package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Verarbeitet Eantrags Exchanges zu {@link EantragsBestaetigungDTO}s.
 */
@Slf4j
@ApplicationScoped
public class EantragsBestaetigungsHeaderMapper implements Processor {

    @Override
    public void process(final Exchange exchange) {
        final var message = exchange.getMessage();
        final var ack = message.getBody(EantragsBestaetigungDTO.class);

        ack.setMessageId(message.getHeader(DRVHeader.CORRELATION_ID, String.class));
        ack.setNutzdatenID(message.getHeader(DRVHeader.ANTRAG_NUTZDATENID, String.class));

        exchange.getMessage().setBody(ack);
    }
}
