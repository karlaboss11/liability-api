package de.deutscherv.rvsm.fa.fit.kontoinformation;

import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationRequest;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import de.deutscherv.rvsm.fa.fit.security.JwtOidcFilter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Client fuer das rvSystemBestand-Gateway.
 *
 * @author V215169
 */
@ApplicationScoped
@RegisterRestClient(configKey = "kontoinformation")
@RegisterProvider(JwtOidcFilter.class)
public interface KontoinformationClient {

    /**
     * Kontoinformationen werden gelesen.
     *
     * @param drvMandant              DRV-Mandant
     * @param kontoinformationRequest Request zur Anforderung
     * @return ermittelte Kontoinformationen
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/rvdialog-wartezeitabfrage")
    KontoinformationResponse getKontoinformationen(
            @HeaderParam("drv-mandant") @NotNull @Size(min = 2, max = 2) @Parameter(description = "KTAN des Traegers") String drvMandant,
            KontoinformationRequest kontoinformationRequest);
}
