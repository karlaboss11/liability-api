package de.deutscherv.rvsm.fa.fit.management;

import de.deutscherv.rvsm.fa.fit.fehler.orchestration.RetryRoutes;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.apache.camel.FluentProducerTemplate;

import static de.deutscherv.rvsm.fa.fit.management.CronService.RESET_FEHLER_RETRIES;
import static de.deutscherv.rvsm.fa.fit.rvpur.RvPurVorgangScheduledService.DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_TR_FIT_TE;

/**
 * API zum Ansteuern der Cron-Laeufe.
 */
@Path( "/cron")
@RequiredArgsConstructor(onConstructor_ = {@Inject})
public class CronApi {

    private final FluentProducerTemplate template;

    /**
     * Endpunkt zum triggern des Fehler Retry Verfahrens.
     *
     * @param ktan der Mandant der uebergeben wird
     * @return die Antwort als Rest Response - liefert 200
     */
    @PUT
    @Path("/retry/{ktan}")
    @Produces({ "application/json", "application/problem+json" })
    @Consumes(MediaType.WILDCARD)
    @RolesAllowed({ RVSM_TR_FIT_TE })
    public Response retry(@PathParam("ktan") String ktan){
        template.withBody(ktan).to(RetryRoutes.DIRECT_GET_FEHLER_BY_MANDANT).send();
        return Response.ok().build();
    }

    /**
     * Endpunkt zum triggern der Vorgangserzeugung.
     *
     * @param ktan der Mandant der uebergeben wird
     * @return die Antwort als Rest Response - liefert 200
     */
    @PUT
    @Path("/vorgang/{ktan}")
    @Produces({ "application/json", "application/problem+json" })
    @Consumes(MediaType.WILDCARD)
    @RolesAllowed({ RVSM_TR_FIT_TE })
    public Response checkVorgang(@PathParam("ktan") String ktan){
        template.withBody(ktan).to(DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT).send();
        return Response.ok().build();
    }

    /**
     * Endpunkt zum zuruecksetzen der Fehler Retries.
     *
     * @param ktan der Mandant der uebergeben wird
     * @return die Antwort als Rest Response - liefert 200
     */
    @PUT
    @Path("/fehlerreset/{ktan}")
    @Produces({ "application/json", "application/problem+json" })
    @Consumes(MediaType.WILDCARD)
    @RolesAllowed({ RVSM_TR_FIT_TE })
    public Response resetFehlertabelle(@PathParam("ktan") String ktan) {
        template.withBody(ktan).to(RESET_FEHLER_RETRIES).send();
        return Response.ok().build();
    }

}