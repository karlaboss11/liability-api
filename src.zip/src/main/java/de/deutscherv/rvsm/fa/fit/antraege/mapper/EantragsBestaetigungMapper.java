package de.deutscherv.rvsm.fa.fit.antraege.mapper;

import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypAntrag;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypVorgangID;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Organisationsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.SimTypKennung;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EAntragDatenDTO;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.VorgangIdDatenDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

/**
 * Mapping-Klasse für {@link EantragsBestaetigungDTO}.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface EantragsBestaetigungMapper {

    /**
     * Bestimmt die Auf VorgangIdDatenDTO aus den Antragsdaten.
     *
     * @param organisationsdaten die {@link Organisationsdaten}
     * @return die VorgangIdDatenDTO
     */
    @Named("antragsdatenToVorgangID")
    static List<VorgangIdDatenDTO> antragsdatenToVorgangID(final Organisationsdaten organisationsdaten) {

        if (organisationsdaten == null) {
            return List.of();
        }

        final List<KomTypVorgangID> vorgangIds = organisationsdaten.getVorgangID();

        if (vorgangIds == null) {
            return List.of();
        }

        return vorgangIds.stream()
                .map(it -> VorgangIdDatenDTO.builder().idxMehrfachantrag(it.getIdxMehrfachantrag().longValue()).value(it.getValue())
                        .build()).toList();
    }

    /**
     * Bestimmt die Auf dokumentID aus den Antragsdaten.
     *
     * @param daten die {@link Antragsdaten.Daten}
     * @return die Auf dokumentID
     */
    @Named("antragsdatenToDokmentID")
    static List<String> antragsdatenToDokmentID(final Antragsdaten.Daten daten) {

        if (daten == null) {
            return List.of();
        }

        final List<KomTypAntrag> antrags = daten.getAntrag();

        if (antrags == null) {
            return List.of();
        }

        return antrags.stream().map(KomTypAntrag::getDokumentID).toList();
    }

    /**
     * Bestimmt die KennungEnum aus den SimTypKennung von Antragsdaten.
     *
     * @param simTypKennung die {@link SimTypKennung}
     * @return die KennungEnum
     */
    @Named("simTypKennungToKennungEnum")
    static EAntragDatenDTO.KennungEnum simTypKennungToKennungEnum(final SimTypKennung simTypKennung) {
        if (simTypKennung == null) {
            return null;
        }
        return EAntragDatenDTO.KennungEnum.valueOf(simTypKennung.value());
    }

    /**
     * Bestimmt die KennungEnum aus den SimTypKennung von Antragsdaten.
     *
     * @param organisationsdaten die {@link Organisationsdaten}
     * @return die KennungEnum
     */
    @Named("antragsdatenToAtad")
    static String antragsdatenToAtad(final Organisationsdaten organisationsdaten) {

        if (organisationsdaten == null) {
            return null;
        }

        return organisationsdaten.getAtad();
    }

    /**
     * Mappt Antragsdaten in EantragsbestaetigungDTO.
     * @param antragsdaten zu untersuchender Antragsdaten
     * @return gemappte eAntrag-Bestaetigung.
     */
    @Mapping(target = "eAntragDaten", expression = "java(antragsdatenToEAntragDaten(antragsdaten))")
    @Mapping(target = "messageId", ignore = true)
    @Mapping(target = "nutzdatenID", ignore = true)
    EantragsBestaetigungDTO antragsdatenToEantragsBestaetigung(Antragsdaten antragsdaten);

    /**
     * Mappt einen eAntrag in einen EantragsBestaetigungDTO.
     *
     * @param antragsdaten der {@link Antragsdaten}
     * @return der {@link EantragsBestaetigungDTO}
     */
    @Mapping(source = "steuerdaten.vsnr", target = "vsnr")
    @Mapping(source = "steuerdaten.absender", target = "absender")
    @Mapping(source = "steuerdaten.empfaenger", target = "empfaenger")
    @Mapping(source = "steuerdaten.version", target = "version")
    @Mapping(source = "steuerdaten.kennung", target = "kennung", qualifiedByName = "simTypKennungToKennungEnum")
    @Mapping(source = "steuerdaten.zeitpunktErstellung", target = "zeitpunktErstellung")
    @Mapping(source = "steuerdaten.userId", target = "userId")
    @Mapping(source = "organisationsdaten", target = "atad", qualifiedByName = "antragsdatenToAtad")
    @Mapping(source = "organisationsdaten", target = "vorgangID", qualifiedByName = "antragsdatenToVorgangID")
    @Mapping(source = "daten", target = "dokumentID", qualifiedByName = "antragsdatenToDokmentID")
    @Mapping(target = "fehlerText", ignore = true)
    @Mapping(target = "fehlerNummer", ignore = true)
    EAntragDatenDTO antragsdatenToEAntragDaten(Antragsdaten antragsdaten);
}
