/**
 * {@link org.apache.camel.Route}s welche die Orchestrierung von Aträgen ermöglichen.
 */
package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;