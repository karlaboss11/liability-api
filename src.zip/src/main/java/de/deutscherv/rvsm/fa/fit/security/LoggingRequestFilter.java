package de.deutscherv.rvsm.fa.fit.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import jakarta.annotation.Priority;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.Provider;
import java.net.URI;
import java.security.Principal;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * Ein Filter, der die MDC-Felder UserId & SourceIp befüllt.
 */
@Provider
@RequestScoped
@Priority(Priorities.AUTHENTICATION + 1)
@RequiredArgsConstructor
public class LoggingRequestFilter implements ContainerRequestFilter {

    private static final String SYSTEM = "system";

    /**
     * Konstante für die source-ip.
     */
    private static final String SOURCE_IP_HEADER = "X-Forwarded-For";

    private final Instance<Principal> principal;
    private final UserService userService;

    @Override
    public void filter(final ContainerRequestContext requestContext) throws JsonProcessingException {
        final String userId = getUserId();

        final String clientId = userService.getCurrentClientId();

        MDCUtils.setAllInScope(Map.of(
                MDCKey.USER_ID, userId,
                MDCKey.CLIENT_ID, clientId,
                MDCKey.SOURCE_IP, getHostOrIpAddress(requestContext),
                MDCKey.USER_ROLES, userService.getCurrentRoles(),
                MDCKey.DRV_MANDANT, String.valueOf(getDrvMandant()))
        );
    }

    /**
     * Ermittelt die IpAdresse oder den Host der ankommenden Anfrage.
     *
     * @param containerRequestContext Der Context.
     * @return Die IPAdresse oder Host als String, 'UNBEKANNT' wenn der Host nicht ermittelt werden kann.
     */
    public String getHostOrIpAddress(final ContainerRequestContext containerRequestContext) {
        return Optional.ofNullable(containerRequestContext.getHeaderString(SOURCE_IP_HEADER))
                .or(() -> Optional.ofNullable(containerRequestContext.getUriInfo())
                        .map(UriInfo::getRequestUri)
                        .map(URI::getHost))
                .orElse("UNBEKANNT");
    }

    /**
     * Liefert die User-ID.
     *
     * @return User-ID
     */
    public String getUserId() {
        return userService.getCurrentDrvId().orElseGet(() -> Optional.of(principal)
                .filter(Instance::isResolvable)
                .map(Instance::get)
                .map(Principal::getName)
                .filter(Predicate.not(String::isBlank))
                .orElse(SYSTEM));
    }

    /**
     * Liefert den DRV-Mandant.
     *
     * @return DRV-Mandant
     */
    public Long getDrvMandant() {
        return userService.getCurrentDrvMandant()
                .filter(NumberUtils::isParsable)
                .map(Long::parseLong)
                .orElse(null);
    }
}