/**
 * Beinhaltet JPA Entities für Einrichtungen.
 */
package de.deutscherv.rvsm.fa.fit.einrichtungen.model;
