package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.cache.CacheInvalidate;
import io.quarkus.cache.CacheResult;
import io.quarkus.oidc.client.OidcClient;
import io.quarkus.oidc.client.Tokens;
import io.quarkus.oidc.client.filter.OidcClientFilter;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MultivaluedMap;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * AccessTokenFilter, der Jwt Access Token zu einem Client Request Header hinzufuegt.
 */
@Slf4j
@OidcClientFilter
@Priority(Priorities.AUTHENTICATION)
public class JwtOidcFilter implements ClientRequestFilter {

    /** The wait duration. */
    public static final Duration WAIT_DURATION = Duration.ofSeconds(45);

    /** The disable authorization. */
    private final boolean disableAuthorization;
    private final OidcClient oidcclient;

    /**
     * Instantiates a new access token filter.
     *
     * @param disableAuthorization true wenn Authorization Disabled ist.
     * @param oidcClient           the oidc client
     */
    @Inject
    public JwtOidcFilter(@ConfigProperty(name = "disable.authorization", defaultValue = "false") boolean disableAuthorization,
        @Context final OidcClient oidcClient) {
        this.disableAuthorization = disableAuthorization;
        this.oidcclient = oidcClient;
    }

    /**
     * Filter.
     *
     * @param requestContext the request context
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public void filter(final ClientRequestContext requestContext) throws IOException {
        if (disableAuthorization) {
            return;
        }
        LOG.atDebug()
            .addArgument(requestContext.getClass().getName())
            .log("Access Token Filter für [{}] aufgerufen");
        fillAccessTokenHeaders(requestContext.getHeaders());
    }

    /**
     * Fill access token headers.
     *
     * @param <T>     the generic type
     * @param headers the headers
     */
    private <T> void fillAccessTokenHeaders(final MultivaluedMap<String, T> headers) {
        getHeaders().forEach((k, v) -> headers.add(k, (T) v));
    }

    /**
     * Gets the headers.
     *
     * @return the headers
     */
    private Map<String, String> getHeaders() {
        final Map<String, String> headers = new HashMap<>();
        final String token = requestJwt();
        if (StringUtils.isBlank(token)) {
            LOG.atError()
                .log("JWT fuer Gateway Aufruf konnte nicht abgerufen werden. (Token ist Blank)");
        } else {
            headers.put("Authorization", "Bearer " + token);
            LOG.atDebug()
                .addArgument(headers)
                .log("Request Headers: [{}]");
        }
        return headers;
    }

    /**
     * Request jwt.
     *
     * @return the jwt
     */
    public String requestJwt() {
        Tokens tokens = getTokens();

        boolean isExpired = tokens.getAccessTokenExpiresAt() - (System.currentTimeMillis() / 1000) < 30;
        if (!isExpired) {
            return tokens.getAccessToken();
        }
        invalidateCache();
        Tokens newTokens = getTokens();
        String accessToken = newTokens.getAccessToken();
        LocalDateTime expirationTime =
            LocalDateTime.ofEpochSecond(newTokens.getAccessTokenExpiresAt(), 0,
                ZoneOffset.UTC);
        LOG.atInfo().addArgument(expirationTime.toString())
            .addArgument(accessToken)
            .log("Neuer Token gültig bis {}: {}");
        return accessToken;
    }

    /**
     * Liefert Tokens.
     *
     * @return Tokens
     */
    @CacheResult(cacheName = "jwt")
    Tokens getTokens() {
        return oidcclient.getTokens().await().atMost(WAIT_DURATION);
    }

    /**
     * Cache wird invalidiert.
     */
    @CacheInvalidate(cacheName = "jwt")
    void invalidateCache() {
        LOG.atDebug().log("Token für technischen User ist abgelaufen. Cache wird invalidiert.");
    }
}
