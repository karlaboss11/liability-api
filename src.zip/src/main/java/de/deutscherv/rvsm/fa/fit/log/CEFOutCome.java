package de.deutscherv.rvsm.fa.fit.log;

import lombok.Getter;

/**
 * CEFOutCome.
 */
@Getter
public enum CEFOutCome {
    /**
     * success.
     */
    SUCCESS("success"),
    /**
     * failure.
     */
    FAILURE("failure");

    private final String value;

    /**
     * Konstrutor.
     * @param value zu setzender Wert.
     */
    CEFOutCome(final String value) {
        this.value = value;
    }

}
