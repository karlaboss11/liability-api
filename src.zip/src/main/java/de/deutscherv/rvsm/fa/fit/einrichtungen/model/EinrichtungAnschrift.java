package de.deutscherv.rvsm.fa.fit.einrichtungen.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity EinrichtungAnschrift.
 */
@Entity
@Table(name = "einrichtung_anschrift")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EinrichtungAnschrift {

    /** technische id der Einrichtung Anschrift. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @Column
    private String strasse;

    @Column
    private String hausnummer;

    @Column

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private String plz;

    @Column
    private String ort;

    @Column
    private String adresszusatz;

    @Lob
    private String anbindung;

    @Column(name = "ktan")
    private String ktan;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;
}
