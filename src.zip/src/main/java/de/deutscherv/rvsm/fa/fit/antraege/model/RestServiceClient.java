package de.deutscherv.rvsm.fa.fit.antraege.model;

/**
 * Enum für den Name eines Rest Clients.
 */
public enum RestServiceClient {

    /**
     * Client Name fuer das Restapi.
     */
    RESTAPI,

    /**
     * Client Name fuer das Kontoinformation rvSystemBestand-Gateway.
     */
    KONTOINFORMATION,

    /**
     * Client Name fuer das RvPur rvSystemBestand-Gateway..
     */
    RVPUR,

    /**
     * Client Name fuer das Selbstmeldeportal rvSystemBestand-Gateway..
     */
    SELBSTMELDEPORTAL,

    /**
     * Client Name fuer das Stammdaten rvSystemBestand-Gateway.
     */
    STAMMDATEN,

    /**
     * Client Name fuer das Statistik rvSystemBestand-Gateway.
     */
    STATISTIK,

    /**
     * Client Name fuer das Azk rvSystemBestand-Gateway.
     */
    AZK
}
