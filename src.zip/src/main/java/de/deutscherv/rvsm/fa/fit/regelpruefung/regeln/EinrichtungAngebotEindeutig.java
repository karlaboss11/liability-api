package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static java.util.Objects.isNull;

/**
 * The Regel Class EinrichtungAngebotEindeutig.
 */
@Singleton
public class EinrichtungAngebotEindeutig extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(RegelUtils.ERFUELLT,
            "Die Einrichtungen für Start- und Trainingsphase haben eindeutige Angebote.",
            RegelUtils.AUSSTEUERN,
            "Es gibt mehrere Angebote in der Einrichtung der Start- oder Trainingsphase.");

    /**
     * Gets the regel name.
     *
     * @return the regel name
     */
    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_EINRICHTUNGANGEBOTEINDEUTIG;
    }

    /**
     * Gets the regel detail.
     *
     * @param regelErgebnis the regel ergebnis
     * @return the regel detail
     */
    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    /**
     * Pruefe regel.
     *
     * @param kontext the kontext
     * @return the RegelErgebnis list
     */
    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (EinrichtungsdatenUtils.keineEinrichtungenVorhanden(kontext.getAntrag())) {
            return new ArrayList<>();
        }

        final int nrStartEindeutigAngebote = EinrichtungsdatenUtils.anzahlEindeutigeAngebote(
                PhaseEnumDto.STARTPHASE, kontext.getStartphaseEinrichtungen());
        final int nrAuffrischungEindeutigAngebote = EinrichtungsdatenUtils.anzahlEindeutigeAngebote(
                PhaseEnumDto.AUFFRISCHUNG, kontext.getAuffrishungsphaseEinrichtungen());
        final int nrTrainingEindeutigAngebote = EinrichtungsdatenUtils.anzahlEindeutigeAngebote(
                PhaseEnumDto.TRAININGSPHASE, kontext.getTrainingsphaseEinrichtungen());

        final var angebotStart =
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.STARTPHASE, kontext.getAntrag());
        final var angebotAuffrischung =
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.AUFFRISCHUNG, kontext.getAntrag());
        final var angebotTraining =
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.TRAININGSPHASE, kontext.getAntrag());

        if (!angebotStart.freitextFelderGesetzt() && !angebotAuffrischung.freitextFelderGesetzt()
                && isNull(kontext.getAntrag().getAngebotAufSmpId())
                && isNull(kontext.getAntrag().getAngebotStartSmpId())) {
            return ergebnisAnhandDerAnzahlEindeutigerAngebote(nrTrainingEindeutigAngebote);
        }

        if (!angebotTraining.freitextFelderGesetzt() && isNull(kontext.getAntrag().getAngebotTrainingSmpId())) {
            if (einerMehrAlsEins(nrStartEindeutigAngebote, nrAuffrischungEindeutigAngebote)) {
                return ergebnisAussteuern(this);
            }
            if (alleNull(nrStartEindeutigAngebote, nrAuffrischungEindeutigAngebote)) {
                return new ArrayList<>();
            }
            return ergebnisErfuellt(this);
        }

        if (einerMehrAlsEins(nrStartEindeutigAngebote,
                nrTrainingEindeutigAngebote)) {
            return ergebnisAussteuern(this);
        }
        if (alleNull(nrStartEindeutigAngebote,
                nrAuffrischungEindeutigAngebote,
                nrTrainingEindeutigAngebote)) {
            return new ArrayList<>();
        }
        return ergebnisErfuellt(this);
    }

    private List<RegelErgebnis> ergebnisAnhandDerAnzahlEindeutigerAngebote(int nrTrainingEindeutigAngebote) {
        return switch (nrTrainingEindeutigAngebote) {
            case 0 -> new ArrayList<>();
            case 1 -> ergebnisErfuellt(this);
            default -> ergebnisAussteuern(this);
        };
    }

    private static boolean alleNull(int... numbers) {
        return Arrays.stream(numbers).allMatch(x -> x == 0);
    }

    private static boolean einerMehrAlsEins(int... numbers) {
        return Arrays.stream(numbers).anyMatch(x -> x > 1);
    }
}
