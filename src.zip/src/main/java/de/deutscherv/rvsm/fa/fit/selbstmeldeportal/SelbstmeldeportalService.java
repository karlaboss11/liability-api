package de.deutscherv.rvsm.fa.fit.selbstmeldeportal;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.mapper.SelbstmeldeportalMapper;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponse;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import io.quarkus.cache.CacheResult;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.function.Predicate.not;
import static org.apache.commons.collections.CollectionUtils.isEmpty;
import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

/**
 * Service für das Selbstmeldportal.
 */
@Slf4j
@ApplicationScoped
public class SelbstmeldeportalService {

    private static final String ONLINE = "ONLINE";
    private static final String STARTPHASE = "STARTPHASE";
    private static final int PHASE_START = 2;
    private static final int PHASE_AUFFRISCHUNG = 3;
    private static final int PHASE_TRAINING = 4;

    private static final Predicate<Angebot> HAT_KEINE_FREIEN_PLAETZE = angebot ->
        Objects.isNull(angebot.getFreiePlaetzeWert()) || List.of(-2, 0).contains(angebot.getFreiePlaetzeWert());
    private static final Predicate<Angebot> IST_ONLINE_ANGEBOT = angebot ->
        ONLINE.equalsIgnoreCase(Optional.ofNullable(angebot).map(Angebot::getDurchfuehrungsart).orElse(null));

    private final SelbstmeldeportalClient selbstmeldeportalClient;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final SelbstmeldeportalMapper mapper;
    private final ExceptionHandler exceptionHandler;

    /**
     * Konstruktor.
     *
     * @param selbstmeldeportalClient   Selbstmeldeportal-Client
     * @param rVFitJsonSchemaValidator  rvFit-JSON-Schema-Validator
     * @param mapper                    Selbstmeldeportal-Mapper
     * @param exceptionHandler          Exception-Handler
     */
    @Inject
    public SelbstmeldeportalService(@RestClient final SelbstmeldeportalClient selbstmeldeportalClient,
        final RVFitJsonSchemaValidator rVFitJsonSchemaValidator,
        final SelbstmeldeportalMapper mapper,
        final ExceptionHandler exceptionHandler) {
        this.selbstmeldeportalClient = selbstmeldeportalClient;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.mapper = mapper;
        this.exceptionHandler = exceptionHandler;
    }

    /**
     * Gets the alle einrichtungen.
     *
     * @return the alle einrichtungen
     */
    @CacheResult(cacheName = "einrichtung-cache")
    public List<RehaEinrichtung> getAlleEinrichtungen() {
        LOG.atDebug().log("Request für alle Einrichtungen des Selbstmeldeportals.");
        Response response;
        response = selbstmeldeportalClient.getAlleEinrichtungen();
        if (Objects.isNull(response) || response.getStatus() != 200) {
            throw new SelbstmeldeportalClientException(
                "Es konnten nicht alle Einrichtungen Abgerufen werden.");
        }
        final List<EinrichtungResponse> einrichtungenResponse =
            response.readEntity(new GenericType<>() {

            });
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.SELBSTMELDEPORTAL,
            einrichtungenResponse)) {
            throw new IllegalArgumentException(
                "Keine valide Einrichtungen Response angegeben: " + einrichtungenResponse);
        }
        return mapper.toEinrichtungenAlle(einrichtungenResponse);
    }

    /**
     * Gets the einrichtungen.
     *
     * @param plz               the plz
     * @param plzVersicherter   the plz versicherter
     * @param ort               the ort
     * @param umkreis           the umkreis
     * @param phase             the phase
     * @param durchfuehrungsart the durchfuehrungsart
     * @return the einrichtungen
     */
    public List<RehaEinrichtung> getEinrichtungen(final String plz, final String plzVersicherter,
        final String ort, final Integer umkreis, final Integer phase,
        final Integer durchfuehrungsart) {
        LOG.atDebug()
            .addArgument(plz)
            .addArgument(plzVersicherter)
            .addArgument(ort)
            .addArgument(umkreis)
            .addArgument(phase)
            .addArgument(durchfuehrungsart)
            .log("Request für Suche nach Einrichtungen des Selbstmeldeportals anhand Parameter. PLZ [{}], PLZ-Versicherter [{}], "
                + "Ort [{}], Umkreis [{}], Phase [{}], Durchfuehrungsart [{}]");
        final Response response = selbstmeldeportalClient.getEinrichtungen(plz, plzVersicherter,
            ort, umkreis, phase, durchfuehrungsart);

        if (Objects.isNull(response) || response.getStatus() != 200) {
            throw new SelbstmeldeportalClientException(
                "Einrichtungen konnten nicht gesucht werden.");
        }
        final List<EinrichtungResponseExtended> einrichtungenResponseExtended =
            response.readEntity(new GenericType<>() {
            });
        if (einrichtungenResponseExtended.isEmpty()) {
            return new ArrayList<>();
        }
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.SELBSTMELDEPORTAL,
            einrichtungenResponseExtended)) {
            throw new IllegalArgumentException(
                "Keine valide Einrichtung Response angegeben: " + einrichtungenResponseExtended);
        }
        return mapper.toEinrichtungen(einrichtungenResponseExtended);
    }

    /**
     * Gets the einrichtung by id.
     *
     * @param plzVersicherter PLZ der versicherten Person
     * @param id              the id
     * @return the einrichtung by id
     */
    public Optional<RehaEinrichtung> getEinrichtungByAngebotId(final String plzVersicherter, final Long id) {
        final List<RehaEinrichtung> einrichtungen =
            getEinrichtungen(null, plzVersicherter, null, null, null, null);
        return einrichtungen.stream()
            .filter(e -> e.getAngebote().stream().anyMatch(a -> a.getSmpAngebotId().equals(id)))
            .findFirst();
    }

    /**
     * Liefert zur übergebenen SelbstmeldeportalId die passende Einrichtung.
     *
     * @param selbstmeldeportalId die Selbstmeldeportal-ID der Einrichtung
     * @return die Einrichtung
     */
    public Optional<RehaEinrichtung> getEinrichtungById(final Long selbstmeldeportalId) {
        final List<RehaEinrichtung> einrichtungen =
            getEinrichtungen(null, null, null, null, null, null);
        return einrichtungen.stream()
            .filter(e -> Objects.equals(selbstmeldeportalId, e.getSmpEinrichtungsId())).findFirst();
    }

    /**
     * Ermittelt die Einrichtungen zu einer Phase.
     *
     * @param phase betroffene Phase
     * @return List der Reha-Einrichtungen zu der Phase
     */
    public List<RehaEinrichtung> getEinrichtungenByPhase(final int phase) {
        return getEinrichtungen(null, null, null, null, phase, null);
    }

    /**
     * Suche.
     *
     * @param q                 the q
     * @param umkreis           the umkreis
     * @param phase             the phase
     * @param durchfuehrungsart the durchfuehrungsart
     * @return the list
     */
    public List<RehaEinrichtung> suche(final String q, final Integer umkreis, final String phase,
        final String durchfuehrungsart) {
        final Integer phaseId = phaseTextToSmpPhaseId(phase);
        final Integer durchfuehrungsartId =
            EinrichtungsdatenUtils.getDurchfuehrungsartId(durchfuehrungsart);

        List<RehaEinrichtung> smpEinrichtungen;
        if ("ALL".equals(q)) {
            smpEinrichtungen = getEinrichtungen(null, null, null, null, phaseId, 6);
        } else {
            if (q != null && q.matches("^\\d{5}$")) {
                smpEinrichtungen =
                    getEinrichtungen(q, null, null, umkreis, phaseId, durchfuehrungsartId);
            } else {
                smpEinrichtungen =
                    getEinrichtungen(null, null, q, umkreis, phaseId, durchfuehrungsartId);
            }
        }

        // Enrichtungen Angebote mit "keine freie Plätze" oder "Angebot pausiert" werden entfernt
        for (final RehaEinrichtung rehaEinrichtung : smpEinrichtungen) {
            List<Angebot> angebote = rehaEinrichtung.getAngebote();
            angebote.removeIf(HAT_KEINE_FREIEN_PLAETZE.or(IST_ONLINE_ANGEBOT.and(istStartphase(phase))));
        }
        return getEinrichtungenByPhaseId(smpEinrichtungen, phaseId);
    }

    private static Predicate<Angebot> istStartphase(final String phase) {
        return a -> STARTPHASE.equalsIgnoreCase(phase);
    }

    // Die Einrichtungen ohne Angebote für ausgewählte phase oder ohne Angebote werden entfernt
    private List<RehaEinrichtung> getEinrichtungenByPhaseId(
        final List<RehaEinrichtung> einrichtungen, final Integer phaseId) {
        return einrichtungen.stream()
            .filter(not(e -> e.getAngebote().isEmpty()))
            .filter(e -> e.getAngebote().stream().anyMatch(istAngebotFuerPhase(phaseId)))
            .toList();
    }

    private Predicate<Angebot> istAngebotFuerPhase(final Integer phaseId) {
        return angebot -> Objects.nonNull(phaseId)
            && Objects.nonNull(angebot.getPhase())
            && phaseId.equals(phaseTextToSmpPhaseId(angebot.getPhase()));
    }

    /**
     * Phase text to smp phase id.
     *
     * @param phase the phase
     * @return the integer
     */
    private Integer phaseTextToSmpPhaseId(final String phase) {
        if (Objects.isNull(phase)) {
            return null;
        }
        return switch (phase.toUpperCase()) {
            case STARTPHASE -> 2;
            case "TRAININGSPHASE" -> 3;
            case "AUFFRISCHUNGSPHASE" -> 4;
            default -> null;
        };
    }

    /**
     * Fügt Einrichtungsobjekte zu Einrichtungen aus dem Selbstmeldeportal zum Antrag hinzu.
     *
     * @param antrag Antrag, für den die Einrichtungen gesetzt werden sollen.
     * @return Antrag mit eingefuegter Einrichtung
     */
    @Transactional
    public Antrag setSmpEinrichtungen(final Antrag antrag) {
        try {
            final var startSmpId = antrag.getAngebotStartSmpId();
            final var aufSmpId = antrag.getAngebotAufSmpId();
            if (nonNull(startSmpId)) {
                if (isNull(aufSmpId)) {
                    startGesetztUndAuffrischungNull(antrag, startSmpId);
                } else {
                    startGesetztUndAuffrischungNotNull(antrag, startSmpId, aufSmpId);
                }
            } else {
                if (hatStartphase(antrag) && hatAuffrischungsphase(antrag) && isNull(aufSmpId)) {
                    startNullUndstartAufNichtLeerAberaufSMPIDNull(antrag);
                }
            }

            if (antrag.getAngebotTrainingSmpId() != null) {
                final var einrichtung = einrichtungBySmpAngebotId(antrag.getPlz(), antrag.getAngebotTrainingSmpId());
                antrag.setEinrichtungTrainingObjekt(einrichtung);
            } else {
                final List<RehaEinrichtung> smpEinrichtungenTraining =
                    getEinrichtungenByPhase(PHASE_TRAINING);
                if (isNotEmpty(smpEinrichtungenTraining)) {
                    antrag.setEinrichtungTrainingObjekt(eindeutigesEinrichtung(
                        antrag, smpEinrichtungenTraining));
                }
            }
        } catch (SelbstmeldeportalClientException | IllegalArgumentException
            | ProcessingException e) {
            exceptionHandler.handleExceptionForRetry(e, antrag,
                "Fehler beim Abrufen der Einrichtungen [selbstmeldeportalService.getEinrichtungenByPhase(PHASE) "
                    + "in setSmpEinrichtungen]");
            throw e;
        }
        return antrag;
    }

    private boolean hatStartphase(final Antrag antrag) {
        return antrag.getAngebotStartName() != null && antrag.getAngebotStartOrt() != null
            && antrag.getAngebotStartPlz() != null && antrag.getAngebotStartStrasse() != null;
    }

    private boolean hatAuffrischungsphase(final Antrag antrag) {
        return antrag.getAngebotAufName() != null && antrag.getAngebotAufOrt() != null
            && antrag.getAngebotAufPlz() != null && antrag.getAngebotAufStrasse() != null;
    }

    private void startNullUndstartAufNichtLeerAberaufSMPIDNull(final Antrag antrag) {
        final List<RehaEinrichtung> smpEinrichtungenStart = getEinrichtungenByPhase(PHASE_START);
        if (isNotEmpty(smpEinrichtungenStart)) {
            final RehaEinrichtung einrichtungStartFromText =
                getEinrichtung(PhaseEnumDto.STARTPHASE, antrag, smpEinrichtungenStart);
            if (nonNull(einrichtungStartFromText)) {
                final RehaEinrichtung eindeutigeEinrichtungStart =
                    eindeutigeEinrichtungMitStartphase(PhaseEnumDto.STARTPHASE, einrichtungStartFromText);
                if (nonNull(eindeutigeEinrichtungStart)) {
                    final List<RehaEinrichtung> smpEinrichtungenAuf =
                        getEinrichtungenByPhase(PHASE_AUFFRISCHUNG);
                    if (isNotEmpty(smpEinrichtungenAuf)) {
                        final RehaEinrichtung einrichtungAufFromText =
                            getEinrichtung(PhaseEnumDto.AUFFRISCHUNG, antrag, smpEinrichtungenAuf);
                        if (nonNull(einrichtungAufFromText)) {
                            final RehaEinrichtung eindeutigeEinrichtungAuf =
                                eindeutigeEinrichtungMitStartphase(PhaseEnumDto.AUFFRISCHUNG, einrichtungAufFromText);
                            antrag.setEinrichtungStartObjekt(eindeutigeEinrichtungStart);
                            antrag.setEinrichtungAufObjekt(eindeutigeEinrichtungAuf);

                        }
                    }
                }
            }
        }
    }

    private void startGesetztUndAuffrischungNotNull(final Antrag antrag, final Long startSmpId,
        final Long aufSmpId) {
        /**
         * Record Einrichtungspaar.
         * @param start Reha-Einrichtung Startphase
         * @param auffrischung Reha-Einrichtung Auffrischungsphase
         */
        record EinrichtungsPaar(RehaEinrichtung start, RehaEinrichtung auffrischung) {
        }

        final List<RehaEinrichtung> smpEinrichtungenStart = getEinrichtungenByPhase(PHASE_START);

        final Optional<RehaEinrichtung> ersteEinrichtungStartMitAngebot =
            Optional.ofNullable(smpEinrichtungenStart).orElseGet(Collections::emptyList).stream()
                .filter(rehaEinrichtungEnthaeltAngebot(startSmpId)).findFirst();
        if (ersteEinrichtungStartMitAngebot.isEmpty()) {
            return;
        }

        final List<RehaEinrichtung> smpEinrichtungenAuf =
            getEinrichtungenByPhase(PHASE_AUFFRISCHUNG);

        ersteEinrichtungStartMitAngebot
            .map(start -> new EinrichtungsPaar(start,
                getErsteEinrichtungAuffrischungMitAngebot(smpEinrichtungenAuf, aufSmpId)
                    .orElse(null)))
            .filter(einrichtungen -> nonNull(einrichtungen.auffrischung()))
            .filter(einrichtungen -> Objects.equals(einrichtungen.start().getSmpEinrichtungsId(),
                einrichtungen.auffrischung().getSmpEinrichtungsId()))
            .map(
                einrichtungen -> new EinrichtungsPaar(
                    eindeutigeEinrichtungMitStartphase(PhaseEnumDto.STARTPHASE, einrichtungen.start()),
                    einrichtungen.auffrischung()))
            .filter(einrichtungen -> nonNull(einrichtungen.start()))
            .map(einrichtungen -> new EinrichtungsPaar(einrichtungen.start(),
                eindeutigeEinrichtungMitStartphase(PhaseEnumDto.AUFFRISCHUNG, einrichtungen.auffrischung())))
            .filter(einrichtungen -> nonNull(einrichtungen.auffrischung()))
            .ifPresent(einrichtungen -> {
                antrag.setEinrichtungStartObjekt(einrichtungen.start());
                antrag.setEinrichtungAufObjekt(einrichtungen.auffrischung());
            });
    }

    private Optional<RehaEinrichtung> getErsteEinrichtungAuffrischungMitAngebot(
        final List<RehaEinrichtung> einrichtungenAuffrischung, final Long angebotId) {

        return Optional.ofNullable(einrichtungenAuffrischung).orElseGet(Collections::emptyList)
            .stream().filter(rehaEinrichtungEnthaeltAngebot(angebotId)).findFirst();
    }

    private void startGesetztUndAuffrischungNull(final Antrag antrag, final Long startSmpId) {
        /**
         * Record Einrichtungspaar.
         * @param start Reha-Einrichtung Startphase
         * @param auffrischung Reha-Einrichtung Auffrischungsphase
         */
        record EinrichtungsPaar(RehaEinrichtung start, RehaEinrichtung auffrischung) {
        }

        final List<RehaEinrichtung> smpEinrichtungenStart = getEinrichtungenByPhase(PHASE_START);
        Optional.ofNullable(smpEinrichtungenStart).orElseGet(Collections::emptyList).stream()
            .filter(rehaEinrichtungEnthaeltAngebot(startSmpId)).findFirst()
            .map(ersteEinrichtungMitAngebot -> eindeutigeEinrichtungMitStartphase(PhaseEnumDto.STARTPHASE, ersteEinrichtungMitAngebot))
            .map(eindeutigeEinrichtungStart -> new EinrichtungsPaar(eindeutigeEinrichtungStart,
                getEindeutigeEinrichtungAuffrischungMitAngebotsId(startSmpId)))
            .filter(startAuf -> nonNull(startAuf.auffrischung())).ifPresent(startAuf -> {
                antrag.setEinrichtungStartObjekt(startAuf.start);
                antrag.setEinrichtungAufObjekt(startAuf.auffrischung);
            });
    }

    private RehaEinrichtung getEindeutigeEinrichtungAuffrischungMitAngebotsId(final Long angebotsId) {
        final List<RehaEinrichtung> smpEinrichtungenAuf =
            getEinrichtungenByPhase(PHASE_AUFFRISCHUNG);

        return Optional.ofNullable(smpEinrichtungenAuf).orElseGet(Collections::emptyList).stream()
            .filter(rehaEinrichtungEnthaeltAngebot(angebotsId)).findFirst()
            .map(rehaEinrichtung -> eindeutigeEinrichtungMitStartphase(PhaseEnumDto.AUFFRISCHUNG, rehaEinrichtung))
            .orElse(null);
    }

    /**
     * Ermittelt die Enrichtung.
     *
     * @param phaseEnumDto     Zugehoerige Phase
     * @param antrag           Antrag fuer die Einrchtung
     * @param smpEinrichtungen Liste der Einrichtung aus dem Selbstmeldeportal
     * @return Ermittelte Rehaeinrichtung.
     */
    private RehaEinrichtung getEinrichtung(final PhaseEnumDto phaseEnumDto, final Antrag antrag,
        final List<RehaEinrichtung> smpEinrichtungen) {

        final List<RehaEinrichtung> einrichtungen =
            EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(phaseEnumDto, antrag), smpEinrichtungen);
        if (isNull(einrichtungen) || einrichtungen.size() != 1) {
            return null;
        }
        return einrichtungen.getFirst();
    }

    /**
     * Sucht nach einer eindeutigen Einrichtung zu Start- und Auffrischungsphase für einen Antrag.
     *
     * @param phaseEnumDto gibt an, für welche Phase eine RehaEinrichtung gesucht werden soll
     * @param einrichtung  betroffene Einrichtung
     * @return eine eindeutige Einrichtung
     */
    public RehaEinrichtung eindeutigeEinrichtungMitStartphase(final PhaseEnumDto phaseEnumDto, final RehaEinrichtung einrichtung) {
        final List<Angebot> angeboteStartMitFreieplaetze = einrichtung.getAngebote().stream()
            .filter(a -> isAngebotStartphase(a) && isAngebotMitFreieplaetze(a)).toList();
        if (angeboteStartMitFreieplaetze.size() != 1) {
            return null;
        }
        final Angebot startAngebot = angeboteStartMitFreieplaetze.getFirst();
        // remove Trainings- und Auffrischungsphase ohne Freieplaetze Angebote
        einrichtung.getAngebote().removeIf(a -> isAngebotTrainingsphase(a)
            || isAngebotAuffrischungsphase(a) && !isAngebotMitFreieplaetze(a));

        final List<Angebot> aufAngeboteMitFreieplaetze = einrichtung.getAngebote().stream()
            .filter(a -> isAngebotAuffrischungsphase(a) && isAngebotMitFreieplaetze(a)).toList();
        if (isEmpty(aufAngeboteMitFreieplaetze)) {
            return null;
        }
        final Angebot aufAngebotMitGleichenDurchfuehrungsart = aufAngeboteMitFreieplaetze.getFirst();
        if (aufAngeboteMitFreieplaetze.size() > 1 &&
            aufAngeboteMitFreieplaetze.stream().
                noneMatch(a -> isAngebotDurchfuehrungsart(a, startAngebot.getDurchfuehrungsart()))) {
            return null;
        }
        if (phaseEnumDto.equals(PhaseEnumDto.STARTPHASE)) {
            einrichtung.getAngebote().removeIf(a -> !isAngebotStartphase(a));
        } else {
            einrichtung.getAngebote()
                .removeIf(a -> !(a.getSmpAngebotId()
                    .equals(aufAngebotMitGleichenDurchfuehrungsart.getSmpAngebotId())
                    && a.getDurchfuehrungsart().equalsIgnoreCase(
                    aufAngebotMitGleichenDurchfuehrungsart.getDurchfuehrungsart())));
        }
        return einrichtung;
    }

    /**
     * Pruefung, ob das ein Angebot der Startphase ist.
     *
     * @param angebot zu pruefendes Angebot
     * @return true - Phase ist korrekt
     */
    private boolean isAngebotStartphase(final Angebot angebot) {
        return nonNull(angebot.getPhase()) && STARTPHASE.equalsIgnoreCase(angebot.getPhase());
    }

    /**
     * Pruefung, ob das ein Angebot der Auffrischungsphase ist.
     *
     * @param angebot zu pruefendes Angebot
     * @return true - Phase ist korrekt
     */
    private boolean isAngebotAuffrischungsphase(final Angebot angebot) {
        return nonNull(angebot.getPhase()) && angebot.getPhase().equals("Auffrischungsphase");
    }

    /**
     * Pruefung, ob das ein Angebot der Trainingsphase ist.
     *
     * @param angebot zu pruefendes Angebot
     * @return true - Phase ist korrekt
     */
    private boolean isAngebotTrainingsphase(final Angebot angebot) {
        return nonNull(angebot.getPhase()) && angebot.getPhase().equals("Trainingsphase");
    }

    /**
     * Pruefung, ob es zu dem Angebot freie Plaetze gibt.
     *
     * @param angebot zu pruefendes Angebot
     * @return true - freie Plaetze vorhanden
     */
    private boolean isAngebotMitFreieplaetze(final Angebot angebot) {
        return nonNull(angebot.getFreiePlaetzeWert()) && angebot.getFreiePlaetzeWert() > 0;
    }

    /**
     * Pruefung, ob das Angebot die Durchfuehrugssart bietet.
     *
     * @param angebot           zu pruefendes Angebot
     * @param durchfuehrungsart gewuenschte Durchfuehrungsart
     * @return true - Angebot bietet die Durchfuerungsart
     */
    private boolean isAngebotDurchfuehrungsart(final Angebot angebot,
        final String durchfuehrungsart) {
        return nonNull(angebot.getDurchfuehrungsart())
            && angebot.getDurchfuehrungsart().equals(durchfuehrungsart);
    }

    /**
     * Prüft, ob ein Angebot in einer Einrichtung behalten werden soll. Das ist der Fall, wenn das Angebot die Selbstmeldeportal-Id aus dem
     * Antrag hat und freie Plätze vorhanden sind.
     *
     * @param angebot         das Angebot
     * @param antragAngebotId die Angebots-Id aus dem Antrag, mit der die Einrichtung gesucht wurde
     * @return {@code true}, wenn das Angebot gültig ist.
     */
    public boolean angebotGueltig(final Angebot angebot, final Long antragAngebotId) {
        if (!Objects.equals(angebot.getSmpAngebotId(), antragAngebotId)) {
            return false;
        }
        return angebot.getFreiePlaetzeWert() > 0;
    }

    /**
     * Bestimmt eine Einrichtung anhand der AngebotsId und filter die Angebote. Gibt {@code null} zurück, wenn
     * <ul>
     * <li>Kein Einrichtung gefunden wurde
     * <li>Mehr als ein Angebot gefunden wird
     * <li>Das Angebot keine freie Plätze hat
     * </ul>
     *
     * @param plzVersicherter die PLZ der versicherten Person
     * @param angebotId       die Id des Selbstmeldeportal-Angebots
     * @return eine Rehaeinrichtung oder {@code null}, wenn keine Einrichtung mit passenden Angeboten gefundne wird.
     */
    private RehaEinrichtung einrichtungBySmpAngebotId(final String plzVersicherter, final Long angebotId) {
        final var einrichtung = getEinrichtungByAngebotId(plzVersicherter, angebotId);
        einrichtung.ifPresent(
            e -> e.getAngebote().removeIf(angebot -> !angebotGueltig(angebot, angebotId)));
        return einrichtung.filter(e -> e.getAngebote().size() == 1).orElse(null);
    }

    /**
     * Sucht nach einer eindeutigen Einrichtung zu einer Phase für einen Antrag.
     *
     * @param antrag           der Antrag
     * @param smpEinrichtungen Einrichtungen aus dem Selbstmeldeportal
     * @return eine eindeutige Einrichtung
     */
    private RehaEinrichtung eindeutigesEinrichtung(final Antrag antrag, final List<RehaEinrichtung> smpEinrichtungen) {
        final List<RehaEinrichtung> einrichtungen =
            EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.TRAININGSPHASE, antrag), smpEinrichtungen);
        if (isNull(einrichtungen) || einrichtungen.size() != 1) {
            return null;
        }
        final RehaEinrichtung einrichtung = einrichtungen.getFirst();
        EinrichtungsdatenUtils.deleteAngeboteOhneFreiePlaetzeFromEinrichtung(PhaseEnumDto.TRAININGSPHASE,
            einrichtung);
        if (einrichtung.getAngebote().size() != 1) {
            return null;
        }
        return einrichtung;
    }

    private static Predicate<RehaEinrichtung> rehaEinrichtungEnthaeltAngebot(final Long angebotId) {
        return einrichtung -> einrichtung.getAngebote().stream()
            .anyMatch(angebot -> angebot.getSmpAngebotId().equals(angebotId));
    }
}
