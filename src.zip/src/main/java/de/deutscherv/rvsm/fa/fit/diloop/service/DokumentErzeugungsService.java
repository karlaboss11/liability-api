package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragDTO;
import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragInputsDTO;
import jakarta.annotation.Nonnull;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static de.deutscherv.rvsm.fa.fit.diloop.util.DokumentenWerteMappingUtil.mapZuNatuerlichePersonDto;

/**
 * Abstrakte Klasse zur Erzeugung von DokumentgenerierungsAuftragDTOs.
 */
@SuppressWarnings("javaarchitecture:S7027")
abstract sealed class DokumentErzeugungsService permits AblehnungsDokumentErzeugungsService, BewilligungsDokumentErzeugungsService,
    SachverhaltsaufklaerungsDokumentErzeugungsService {

    private static final NumberFormat NUMBER_FORMAT_4_DIGITS = NumberFormat.getIntegerInstance();

    /**
     * Liste der Debug Werte, die an die Schnittstelle zur Dokumentenerzeugung übergeben werden.
     */
    public static final List<DokumentgenerierungsAuftragDTO.DebugEnum> DEBUG =
        List.of(DokumentgenerierungsAuftragDTO.DebugEnum.DILOOP_RESPONSE,
            DokumentgenerierungsAuftragDTO.DebugEnum.JWT,
            DokumentgenerierungsAuftragDTO.DebugEnum.MAPPING_RESULT);

    static {
        NUMBER_FORMAT_4_DIGITS.setGroupingUsed(false);
        NUMBER_FORMAT_4_DIGITS.setMinimumIntegerDigits(4);
        NUMBER_FORMAT_4_DIGITS.setMaximumIntegerDigits(4);
    }

    /**
     * Erzeugt ein DokumentgenerierungsAuftragDTO. Implementierung der Ezeugung eines Dokumentengenerierungsauftrag gemäß
     * Schnittstellen-Spezifkation unter folgendem Link:
     * <a href="https://rvwiki.drv.drv/x/829wFw">SST_004_RV Fit und DiLoop (rvText)</a>
     *
     * @param daten alle notwendigen Daten zur Erzeugung des DokumentenGenerierungsauftrags
     * @return ein DokumentengenerierungsAuftrag, der an die DiLOOP-Schnittstelle gesendet werden kann
     */
    public DokumentgenerierungsAuftragDTO erzeugeAuftragsDto(
        @Nonnull final DokumentenErstellungsDaten daten) {
        final AllgemeineDokumentenDaten allgemeineDokumentenDaten =
            getAllgemeineDokumentenDaten(daten);

        final DokumentgenerierungsAuftragDTO dto = new DokumentgenerierungsAuftragDTO();
        dto.setTemplateUuid(getTemplateId(daten));
        dto.setDebug(DEBUG);
        dto.setFall(allgemeineDokumentenDaten.getFall());
        dto.setAigr(allgemeineDokumentenDaten.getAigr());
        dto.setDoReview(allgemeineDokumentenDaten.isDoReview());
        dto.setIsBatchPrint(allgemeineDokumentenDaten.isBatchPrint());
        dto.setCallingSystemMandant(allgemeineDokumentenDaten.getKtan());
        dto.setCallingSystemName(daten.config().getCallingSystemName());
        dto.setCallingSystemVersion(daten.config().getCallingSystemVersion());

        dto.setInputs(getInputs(daten));

        return dto;
    }

    /**
     * Gibt die UUID des Schreiben-Templates zurück.
     *
     * @param dokumentenErstellungsDaten die Daten zur Dokumentenerstellung
     * @return die UUID des Schreiben-Templates
     */
    protected abstract UUID getTemplateId(DokumentenErstellungsDaten dokumentenErstellungsDaten);

    /**
     * Erstellt die allgemeinen Daten, die zur Dokumentenerstellung benötigt werden.
     *
     * @param dokumentenErstellungsDaten die Daten zur Dokumentenerstellung
     * @return die allgemeinen Dokumentendaten
     */
    protected abstract AllgemeineDokumentenDaten getAllgemeineDokumentenDaten(
        @Nonnull final DokumentenErstellungsDaten dokumentenErstellungsDaten);

    /**
     * Erstellt die Variablen zur Dokumentenerzeugung aus den Antrags- und Kontodaten. Dazu gehoeren Variablen für den Anschriftenblock und
     * die Anrede, Variablen zur Befüllung der konreten Vorlage sowie Variablen zur Kommunikation mit rvPuR.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return die Variablen zur Dokumentenerzeugung
     */
    protected abstract Map<String, String> getVariablen(
        @Nonnull final DokumentenErstellungsDaten daten);

    /**
     * Fügt das DokumentgenerierungsAuftragInputsDTO zusammen aus den Variablen einer Implementierung dieser Klasse und den Daten der
     * natürlichen Person.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return das DokumentgenerierungsAuftragInputsDTO
     */
    private DokumentgenerierungsAuftragInputsDTO getInputs(final DokumentenErstellungsDaten daten) {
        final DokumentgenerierungsAuftragInputsDTO inputs =
            new DokumentgenerierungsAuftragInputsDTO();
        inputs.setVariablen(getVariablen(daten));
        inputs.setNatuerlichePersonen(mapZuNatuerlichePersonDto(daten.konto()));
        return inputs;
    }

    /**
     * Extrahiert die AIGR anhand ATAD aus dem Antrag.
     *
     * @param antrag der Antrag
     * @return String mit dem Wert für AIGR
     */
    public String getAigr(final Antrag antrag) {
        final Integer atad = antrag.getAtad();
        if (atad == null) {
            return null;
        }
        return NUMBER_FORMAT_4_DIGITS.format(atad);
    }

}
