package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;

/**
 * Regelpruefung - Altersteilzeit.
 */
@Singleton
public class AltersteilzeitRegel extends BasisRegel {

    private static final List<String> AZ_GRUENDE = List.of("10", "50");
    private static final List<String> AZ_GRUPPEN = List.of("103", "108", "142");
    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL =
            Map.of(RegelUtils.ERFUELLT, "Es liegt keine Altersteilzeit vor.",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN,
                    "Es konnte nicht ermittelt werden, ob Altersteilzeit vorliegt. Bitte manuell prüfen.",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es liegt Altersteilzeit vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_ALTERSTEILZEIT;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!RegelUtils.kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String altersteilzeitGruppe = kontoinformation.getAltersteilzeitGruppe();
        final String altersteilzeitGrund = kontoinformation.getAltersteilzeitGrund();
        final LocalDate altersteilzeitKobs = kontoinformation.getAltersteilzeitKobs();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(altersteilzeitGruppe).firstExpected("???")
                .secondValue(altersteilzeitGrund).secondExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if ((!isAltersteilzeitGruppe(altersteilzeitGruppe)
                || !isAltersteilzeitGrund(altersteilzeitGrund)
                || !isAltersteilzeitKobs(altersteilzeitKobs, kontext.getAntrag().getAntragsDatum()))) {
            return ergebnisErfuellt(this);
        }
        if (isAltersteilzeitGruppe(altersteilzeitGruppe)
                && isAltersteilzeitGrund(altersteilzeitGrund)
                && isAltersteilzeitKobs(altersteilzeitKobs, kontext.getAntrag().getAntragsDatum())) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        return ergebnisAussteuernKeineDaten(this);
    }

    private static boolean isAltersteilzeitGruppe(final String altersteilzeitGruppe) {
        return !StringUtils.isBlank(altersteilzeitGruppe) && AZ_GRUPPEN.contains(altersteilzeitGruppe.trim());
    }

    private static boolean isAltersteilzeitGrund(final String altersteilzeitGrund) {
        return !StringUtils.isBlank(altersteilzeitGrund) && AZ_GRUENDE.contains(altersteilzeitGrund.trim());
    }

    private static boolean isAltersteilzeitKobs(final LocalDate altersteilzeitKobs,
            final LocalDate antragsDatum) {
        return Objects.nonNull(altersteilzeitKobs) && Objects.nonNull(antragsDatum)
                && (altersteilzeitKobs.isEqual(antragsDatum.minusMonths(12))
                || altersteilzeitKobs.isAfter(antragsDatum.minusMonths(12)));
    }
}
