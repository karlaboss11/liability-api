package de.deutscherv.rvsm.fa.fit.stammdaten.repository;

import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.Optional;
import lombok.RequiredArgsConstructor;

/**
 * Repository Stammdaten.
 */
@RequiredArgsConstructor
@ApplicationScoped
public class StammdatenRepository {

    private final EntityManager entityManager;

    /**
     * Persistiert den Stammdatensatz.
     *
     * @param stammdaten zu persistierende Stammdaten
     */
    public void persist(final Stammdaten stammdaten) {
        entityManager.persist(stammdaten);
    }

    /**
     * Suche Stammdaten zu einer Versicherungsnr.
     *
     * @param vsnr Versicherungsnummer deren Stammdaten gelesen werden
     * @return gefundene Stammdaten
     */
    public Optional<Stammdaten> findByVSNR(final String vsnr) {
        final TypedQuery<Stammdaten> query = entityManager.createQuery(
                "select stamm from Stammdaten stamm where stamm.vsnr = :vsnr", Stammdaten.class);

        query.setParameter("vsnr", vsnr);

        return query.getResultStream().findFirst();
    }

}