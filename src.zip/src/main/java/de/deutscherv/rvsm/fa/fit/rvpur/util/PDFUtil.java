package de.deutscherv.rvsm.fa.fit.rvpur.util;

import de.deutscherv.anzeigetool.facade.AnzeigetoolFacade;
import de.deutscherv.anzeigetool.facade.DruckWerteListe;
import de.deutscherv.anzeigetool.facade.PuRDokument;
import de.deutscherv.anzeigetool.utils.AnzeigetoolException;
import de.deutscherv.anzeigetool.utils.AnzeigetoolKonstanten;
import de.deutscherv.anzeigetool.utils.MerkmalBeidseitigerDruck;
import de.deutscherv.anzeigetool.utils.MerkmalDruckWert;
import de.deutscherv.anzeigetool.utils.MerkmalDruckumfang;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.util.ValidationUtil;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * PDFUtil.
 */
@Slf4j
@UtilityClass
public class PDFUtil {
    /**
     * Erstellt ein PDF des Antrags.
     *
     * @param antrag Antrag
     * @return byte array mit dem erzeugten Druckprodukt
     */
    public static byte[] createPdf(final Antrag antrag) {
        LOG.atDebug().addArgument(antrag.getUuid())
            .log("Service create Pdf: PDF wird erstellt, Antrag UUID [{}]");
        final DruckWerteListe druckWerteListe = new DruckWerteListe();

        final String xmlAntrag = antrag.getXml();

        try {
            final String metadatenPfad = ValidationUtil.getMetadatenFromVersion(antrag.getVersion());
            final InputStream ioStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream(metadatenPfad);
            if (ioStream == null) {
                return new byte[] {};
            }

            final InputStreamReader metaDaten =
                new InputStreamReader(ioStream, StandardCharsets.UTF_8);

            druckWerteListe.setDruckWert(MerkmalDruckWert.AUSGABEFORMAT,
                AnzeigetoolKonstanten.DRUCKWERT_AUSGABEFORMAT_PDFA3);
            final AnzeigetoolFacade af = new AnzeigetoolFacade();

            return af.erzeugeDruckprodukt(xmlAntrag,
                MerkmalDruckumfang.ALLES,
                MerkmalBeidseitigerDruck.SIMPLEX,
                druckWerteListe,
                metaDaten).toByteArray();

        } catch (SecurityException | AnzeigetoolException e) {
            MDCUtils.setFailed();
            LOG.atError().addArgument(antrag.getUuid()).setCause(e)
                .log("Service create Pdf: Fehler beim Erstellen des PDF. Antrag UUDI: " + "[{}]");
            return new byte[] {};
        }
    }

    /**
     * Erstellt ein Array mit den anhängenden Dokumenten eines Antrags.
     *
     * @param antrag Antrag
     * @return byte array output stream
     */
    public static ArrayList<PuRDokument> createPuRDokumente(final Antrag antrag) {
        LOG.atDebug().addArgument(antrag.getUuid())
            .log("Service create Pdf: PDF wird erstellt, Antrag UUID [{}]");
        final DruckWerteListe druckWerteListe = new DruckWerteListe();

        final String xmlAntrag = antrag.getXml();

        try {
            final String metadatenPfad = ValidationUtil.getMetadatenFromVersion(antrag.getVersion());
            final InputStream ioStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream(metadatenPfad);
            if (ioStream == null) {
                Collections.emptyList();
            }

            final InputStreamReader metaDaten =
                new InputStreamReader(ioStream, StandardCharsets.UTF_8);

            druckWerteListe.setDruckWert(MerkmalDruckWert.AUSGABEFORMAT,
                AnzeigetoolKonstanten.DRUCKWERT_AUSGABEFORMAT_PDFA3);
            final AnzeigetoolFacade af = new AnzeigetoolFacade();

            return af.erzeugePuRDokumente(xmlAntrag,
                MerkmalBeidseitigerDruck.SIMPLEX,
                druckWerteListe,
                metaDaten);

        } catch (SecurityException | AnzeigetoolException e) {
            MDCUtils.setFailed();
            LOG.atError().addArgument(antrag.getUuid()).setCause(e)
                .log("Service create Pdf: Fehler beim Erstellen des PDF. Antrag UUDI: " + "[{}]");
            return null;
        }
    }

}
