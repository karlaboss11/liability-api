package de.deutscherv.rvsm.fa.fit.fehler.repository;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * Repository für Fehlerzustände.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class FehlerRepository {

    private final EntityManager entityManager;

    /**
     * Sucht einen Fehler anhand der UUID.
     *
     * @param uuid die UUID
     * @return ein Optional mit dem Fehler, falls dieser existiert.
     */
    @RequiresMandant
    public Optional<Fehler> findByUuid(final UUID uuid) {
        return Optional.ofNullable(entityManager.find(Fehler.class, uuid));
    }

    /**
     * Sucht einen Fehler anhand der UUID und des Antragstatus.
     *
     * @param antrag zugehoeriger Antrag
     * @param status Antragstatus
     * @return ein Optional mit dem Fehler, falls dieser existiert.
     */
    @RequiresMandant
    public Optional<Fehler> findByAntragAndStatus(final Antrag antrag, final AntragStatus status) {
        return entityManager.createQuery("select f from Fehler f where f.antragId = :uuid and f.status = :status", Fehler.class)
                .setParameter("uuid", antrag.getUuid())
                .setParameter("status", status)
                .getResultStream().findFirst();
    }

    /**
     * Listet alle Fehler.
     *
     * @return die Fehler
     */
    @RequiresMandant
    public List<Fehler> findAll() {
        return entityManager.createQuery("select f from Fehler f", Fehler.class).getResultList();
    }

    /**
     * Listet alle Fehler zu einem Antrag.
     *
     * @param antrag der Antrag
     * @return die Fehler zum angegebenen Antrag
     */
    @RequiresMandant
    @Transactional
    public List<Fehler> findByAntrag(final Antrag antrag) {
        return entityManager.createQuery("select f from Fehler f where f.antragId = :uuid", Fehler.class)
                .setParameter("uuid", antrag.getUuid())
                .getResultList();
    }

    /**
     * Listet alle Fehlereinträge, die noch nicht ihre max. Wiederholung erreicht haben
     *
     * @param limit die maximale Anzahl der Versuche
     * @param retries Anzahl Versuche
     * @return die Fehlereinträge, die noch nicht ihre max. Wiederholung erreicht haben
     */
    @RequiresMandant
    @Transactional
    public List<Fehler> findFehlerForRetry(final int retries, final int limit) {
        return entityManager.createQuery("select f from Fehler f where f.retries < :retries ORDER BY created LIMIT :limit", Fehler.class)
                .setParameter("retries", retries)
                .setParameter("limit", limit)
                .getResultStream()
                .toList();
    }

    /**
     * Setze die Retries der Fehlereinträge die Ihre max. Wiederholung (10) erreicht haben zurück
     *
     * @param retryLimit die maximale Anzahl der Versuche
     */
    @RequiresMandant
    @Transactional
    public void updateFehlerRetries(final int retryLimit) {
        entityManager.createQuery("UPDATE Fehler SET retries = 0 WHERE retries >= :retryLimit")
                .setParameter("retryLimit", retryLimit)
                .executeUpdate();
    }

    /**
     * Speichert einen Fehler.
     *
     * @param fehler der Fehler
     */
    @RequiresMandant
    @Transactional
    public void persist(final Fehler fehler) {
        entityManager.persist(fehler);
    }

    /**
     * Löscht einen Fehler.
     *
     * @param fehler der Fehler
     */
    @RequiresMandant
    @Transactional
    public void delete(final Fehler fehler) {
        entityManager.remove(
                entityManager.contains(fehler) ? fehler : entityManager.merge(fehler));
        entityManager.flush();
        entityManager.detach(fehler);
    }

    /**
     * Löscht eine Liste von  Fehler.
     *
     * @param fehler Liste der Fehler
     */
    @RequiresMandant
    @Transactional
    public void deleteAll(final List<Fehler> fehler) {
        entityManager.flush();
        List<UUID> uuids = fehler.stream().map(Fehler::getUuid).toList();
        entityManager.createQuery("DELETE FROM Fehler f WHERE f.uuid IN :uuids")
                .setParameter("uuids", uuids)
                .executeUpdate();
        fehler.forEach(entityManager::detach);
    }

    /**
     * Synchronisiert den Persistenz-Kontext mit der darunterliegenden Datenbank.
     */
    @RequiresMandant
    @Transactional
    public void flush() {
        entityManager.flush();
    }

    /**
     * Persistiere RepoFehler.
     * @param repofehler zu persisitierender Fehler
     * @return persistierter Fehler
     */
    @RequiresMandant
    @Transactional
    public Fehler merge(final Fehler repofehler) {
        return entityManager.merge(repofehler);
    }

    /**
     * Speichert einen neuen oder aktualisiert einen existierenden Fehlereintrag.
     *
     * @param antrag der Antrag
     */
    @RequiresMandant
    public void persistiereFehlerFuerAntrag(final Antrag antrag) {
        final Fehler fehler = findByAntrag(antrag).stream().findFirst().orElse(null);
        if (fehler != null) {
            fehler.setRetries(fehler.getRetries() + 1);
            fehler.setStatus(antrag.getStatus());
            merge(fehler);
        } else {
            persist(Fehler.builder().antragId(antrag.getUuid()).status(antrag.getStatus()).build());
        }
        flush();
    }
}
