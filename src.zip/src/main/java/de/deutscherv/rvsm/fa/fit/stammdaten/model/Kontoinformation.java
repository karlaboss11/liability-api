package de.deutscherv.rvsm.fa.fit.stammdaten.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.QueryHint;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity Kontoinformation.
 */
@Entity
@Table(name = "kontoinformation")
@NamedQuery(name = "Kontoinformation.findAll", query = "SELECT a FROM Kontoinformation a ORDER BY a.id",
    hints = @QueryHint(name = "org.hibernate.cacheable", value = "true"))
@Cacheable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Kontoinformation {

    /** technische id der Kontoinformation. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @Column(name = "antrag_id")
    private UUID antragId;

    @Column
    private String vsnr;

    @Column
    private Integer wartezeit6in24m;

    @Column
    private Integer wartezeit180m;

    @Column
    private Boolean wartezeitfehler;

    @Column(name = "antrag_reha_msat")
    private String antragRehaMsat;

    @Column(name = "antrag_reha_art")
    private String antragRehaArt;

    @Column(name = "massnahme_reha_elat")
    private String massnahmeRehaElat;

    @Column(name = "massnahme_reha_kobs")
    private LocalDate massnahmeRehaKobs;

    @Column(name = "antrag_rente_leat")
    private String antragRenteLeat;

    @Column(name = "bezug_rente_leat")
    private String bezugRenteLeat;

    @Column(name = "antrag_rente_tlrt")
    private String antragRenteTlrt;

    @Column(name = "bezug_rente_tlrt")
    private String bezugRenteTlrt;

    @Column(name = "bezug_rente_prozent")
    private String bezugRenteProzent;

    @Column(name = "beamteneigenschaft")
    private Boolean beamteneigenschaft;

    @Column(name = "rechtsbehelf_rente")
    private Boolean rechtsbehelfRente;

    @Column(name = "rechtsbehelf_reha")
    private Boolean rechtsbehelfReha;

    @Column(name = "beschaeftigung_gruppe")
    private String beschaeftigungGruppe;

    @Column(name = "beschaeftigung_grund")
    private String beschaeftigungGrund;

    @Column(name = "beschaeftigung_kobs")
    private LocalDate beschaeftigungKobs;

    @Column(name = "altersteilzeit_gruppe")
    private String altersteilzeitGruppe;

    @Column(name = "altersteilzeit_grund")
    private String altersteilzeitGrund;

    @Column(name = "altersteilzeit_kobs")
    private LocalDate altersteilzeitKobs;

    @Column
    private Boolean selbstaendigkeit;

    @Column(name = "rv_system_fehler")
    private String rvSystemFehler;

    @Column(name = "unerwarteter_fehler")
    private String unerwarteterFehler;

    @Column(name = "ktan")
    private String ktan;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;
}