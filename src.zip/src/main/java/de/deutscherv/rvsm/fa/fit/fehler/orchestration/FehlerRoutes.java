package de.deutscherv.rvsm.fa.fit.fehler.orchestration;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Fehlerrouten.
 */
@ApplicationScoped
@Slf4j
public class FehlerRoutes extends RouteBuilder {
    /**
     * Routenname: ermittle Fehler.
     */
    public static final String GET_FEHLER = "direct:getFehler";
    /**
     * Routenname: Error.
     */
    public static final String DIRECT_ERROR = "direct:error";

    private final FehlerRepository fehlerRepository;
    private final ExceptionHandler exceptionHandler;
    private final int retries;
    private final int limit;

    /**
     * Konstruktor.
     *
     * @param fehlerRepository Fehler-Repository
     * @param exceptionHandler Exception-Handler
     * @param retries          Anzahl Versuche
     * @param limit            Limit
     */
    public FehlerRoutes(FehlerRepository fehlerRepository,
        ExceptionHandler exceptionHandler,
        @ConfigProperty(name = "antrag.retry.retries") int retries,
        @ConfigProperty(name = "antrag.retry.limit") int limit) {
        this.fehlerRepository = fehlerRepository;
        this.exceptionHandler = exceptionHandler;
        this.retries = retries;
        this.limit = limit;
    }

    @Override
    public void configure() throws Exception {

        from(DIRECT_ERROR)
            .routeId(DIRECT_ERROR)
            .transacted()
            .filter(body().isInstanceOf(Antrag.class))
            .log(LoggingLevel.WARN, LOG, "Fehler in der Verarbeitung eines Antrags")
            .process(exceptionHandler);

        from(GET_FEHLER) //Mandant muss gesetzt sein
            .routeId(GET_FEHLER)
            .process(exchange -> exchange.getMessage().setBody(fehlerRepository.findFehlerForRetry(retries, limit)));
    }
}
