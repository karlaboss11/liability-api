/**
 * Beinhaltet Klassen für die Kommunikation mit dem Selbstmeldeportal.
 */
package de.deutscherv.rvsm.fa.fit.selbstmeldeportal;
