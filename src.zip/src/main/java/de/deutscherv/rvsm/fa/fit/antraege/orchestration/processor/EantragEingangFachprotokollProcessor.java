package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;


/**
 * Speichert einen Antrag.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class EantragEingangFachprotokollProcessor implements Processor {

    private final RvfitLogger rvfitLogger;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var eantrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), eantrag);

        rvfitLogger.sendeFachprotokollEreignis(
                LogUtils.getFachereignis(
                        EreignisTyp.NACHRICHTEN_EINGANG_MASCHINELL,
                        Ereignistext.ANTRAG_EINGEGANGEN,
                        EreignisFreitext.ANTRAG_EINGEANGEN_E,
                        "",
                        eantrag,
                        null,
                        jwt,
                        drvMandant)
        );

        rvfitLogger.sendeFachprotokollEreignis(
                LogUtils.getFachereignis(
                        EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                        Ereignistext.ANTRAGSDATEN_GESPEICHERT,
                        EreignisFreitext.ANTRAG_GESPEICHERT_E,
                        "",
                        eantrag,
                        null,
                        jwt,
                        drvMandant)
        );
    }
}
