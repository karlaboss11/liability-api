package de.deutscherv.rvsm.fa.fit.rvpur;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.config.DynamicMultiTenantsRunTimeConfig;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.VorgangErzeugungsCheckProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.cronlock.CronlockRepository;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;

/**
 * RvPurVorgangSchedulerService.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class RvPurVorgangScheduledService extends RouteBuilder {

    /**
     * Regelname fuer Ermitteln aller Tenants.
     */
    public static final String DIRECT_GET_ALL_TENANTS = "direct:getAllTenants";
    /**
     * Regelname fuer Check Vorgangserzeugung Mandant.
     */
    public static final String DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT = "direct:checkVorgangserzeugungByMandant";
    /**
     * Regelname fuer Check Vorgangserzeugung.
     */
    public static final String DIRECT_CHECK_VORGANGSERZEUGUNG = "direct:checkVorgangserzeugung";
    /**
     * Regelname fuer Lock-Vorgang-Scheduler.
     */
    public static final String DIRECT_LOCK_VORGANG_SCHEDULER = "direct:lockVorgangScheduler";
    private static final String DIRECT_CHECK_VORGANGSERZEUGUNG_INTERNAL = "direct:checkVorgangserzeugungInternal";

    private final RequestContextController requestContext;
    private final VorgangErzeugungsCheckProcessor vorgangErzeugungsCheckProcessor;
    private final DrvMandant mandant;
    private final CronlockRepository cronlockRepository;

    @Override
    public void configure() throws Exception {
        //Mandantenabhaengiger Scheduler
        //@formatter:off

        from(DIRECT_GET_ALL_TENANTS)
                .routeId(DIRECT_GET_ALL_TENANTS)
                .setBody()
                .method(DynamicMultiTenantsRunTimeConfig.class, "getActiveTenants")
                .log(LoggingLevel.DEBUG, LOG, "Vorgangerzeugen für Mandanten${body}")
                .split(body())
                .to(DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT);

        from(DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT)
                .routeId(DIRECT_CHECK_VORGANGSERZEUGUNG_BY_MANDANT)
                .trace(true)
                .process(x -> requestContext.activate())
                .process(x -> {
                    final var ktan = x.getMessage().getBody(String.class);
                    x.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, ktan);
                    mandant.setInScope(ktan);
                })
                .to(DIRECT_CHECK_VORGANGSERZEUGUNG);

        from(DIRECT_CHECK_VORGANGSERZEUGUNG)
                .routeId(DIRECT_CHECK_VORGANGSERZEUGUNG)
                .to(DIRECT_CHECK_VORGANGSERZEUGUNG_INTERNAL)
                .split(body())
                .throttle(10).concurrentRequestsMode()
                    .process(x -> {
                        final var ktan = x.getProperty(DRVHeader.MANDANT_PROPERTY_KEY, String.class);
                        mandant.setInScope(ktan);
                    })
                    .doTry()
                        .log(LoggingLevel.DEBUG, LOG, "Vorgang Scheduler Fehler Für Status Routing ${body}")
                        .to(RouteNames.RVFIT_STATUS_BASED_ROUTING)
                    .doCatch(Exception.class)
                        .log(LoggingLevel.DEBUG, LOG, "Vorgang Scheduler Fehler beim retry ${body}")
                        .to(FehlerRoutes.DIRECT_ERROR)
                    .endDoTry()
                .end();

        from(DIRECT_CHECK_VORGANGSERZEUGUNG_INTERNAL)
                .routeId(DIRECT_CHECK_VORGANGSERZEUGUNG_INTERNAL)
                .transacted()
                .process(vorgangErzeugungsCheckProcessor);

        //@formatter:on
    }

}
