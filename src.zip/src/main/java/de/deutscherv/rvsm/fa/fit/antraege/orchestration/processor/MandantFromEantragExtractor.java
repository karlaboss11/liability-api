package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.EventNotifierSupport;
import org.slf4j.MDC;

/**
 * MandantFromEantragExtractor.
 */
@ApplicationScoped
@Slf4j
public class MandantFromEantragExtractor extends EventNotifierSupport implements Processor {

    private static final String MANDANT_SCOPE_PROPERTY_KEY = "$" + MandantFromEantragExtractor.class.getSimpleName() + ".scope";
    private final DrvMandant mandantHolder;

    /**
     * Constructor.
     *
     * @param mandantHolder DrvMandant
     */
    @Inject
    public MandantFromEantragExtractor(final DrvMandant mandantHolder) {
        this.mandantHolder = mandantHolder;
        setIgnoreCamelContextEvents(true);
        setIgnoreRouteEvents(true);
        setIgnoreServiceEvents(true);
        setIgnoreExchangeAsyncProcessingStartedEvents(true);
        setupIgnore(true);
        setIgnoreExchangeEvents(false);
        setIgnoreExchangeCompletedEvent(false);
        setIgnoreExchangeFailedEvents(false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void process(final Exchange exchange) {
        final Optional<Antrag> antrag = Optional.ofNullable(exchange.getMessage().getBody(Antrag.class));
        antrag.ifPresent(a -> LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), a));

        antrag.map(Antrag::getKtan)
                .ifPresentOrElse(ktan -> {
                    exchange.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, ktan);
                    exchange.setProperty(MANDANT_SCOPE_PROPERTY_KEY, mandantHolder.setInScope(ktan));
                    MDC.put(MDCKey.DRV_MANDANT.valueOf(), ktan);
                }, () -> {
                    throw new UnsupportedOperationException();
                });

    }

    @Override
    public void notify(final CamelEvent event) throws Exception {
        final CamelEvent.ExchangeEvent exchangeEvent = (CamelEvent.ExchangeEvent) event;
        final Exchange ex = exchangeEvent.getExchange();
        final AutoCloseable property = ex.getProperty(MANDANT_SCOPE_PROPERTY_KEY, AutoCloseable.class);
        if(property!=null){
            property.close();
        }
    }
}
