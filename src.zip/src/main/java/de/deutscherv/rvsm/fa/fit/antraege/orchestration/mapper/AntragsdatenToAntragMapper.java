package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import jakarta.enterprise.context.Dependent;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * erstellt einen {@link de.deutscherv.rvsm.fa.fit.antraege.model.Antrag} aus {@link Antragsdaten}.
 */
@Dependent
@RequiredArgsConstructor
public class AntragsdatenToAntragMapper implements Processor {

    private final AntragMapper antragMapper;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final var antragsdaten = exchange.getMessage().getBody(Antragsdaten.class);
        final var antrag = antragMapper.antragsdatenToEntity(antragsdaten);

        antrag.setStatus(AntragStatus.ENTWURF);
        antrag.setXml(exchange.getMessage().getHeader(RVFitCamelHeader.EANTRAG_XML, String.class));
        final String vsnr = antragsdaten.getSteuerdaten().getVsnr();
        MDCUtils.setVsnr(vsnr);

        exchange.getMessage().setBody(antrag);
    }
}
