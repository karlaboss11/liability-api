package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import lombok.Getter;

/**
 * Exception für den Fall, dass zu ein Bestandsfehler zurückgeliefert wurde.
 */
@Getter
public class KontoinformationBestandsFehlerException extends BestandsfehlerException {

    private final transient FehlerEintragDto fehlerEintragDto;

    /**
     * Konstruktor für die Exception.
     *
     * @param message die Fehlernachricht
     * @param antrag der Antrag
     * @param fehlerEintragDto die Bestandsfehler die aufgetreten sind
     */
    public KontoinformationBestandsFehlerException(final String message, final Antrag antrag,
            final FehlerEintragDto fehlerEintragDto) {
        super(antrag, message);
        this.fehlerEintragDto = fehlerEintragDto;
    }
}
