package de.deutscherv.rvsm.fa.fit.fehler.orchestration;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.config.DynamicMultiTenantsRunTimeConfig;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DrvMandantExtractor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;

/**
 * Retry-Routes.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class RetryRoutes extends RouteBuilder {

    /**
     * Routenname: Lies Fehler Mandant.
     */
    public static final String DIRECT_GET_FEHLER_BY_MANDANT = "direct:getFehlerByMandant";
    /**
     * Routenname: Wiederholung.
     */
    public static final String DIRECT_RETRY = "direct:retry";
    /**
     * Routenname: Fehlerhandling.
     */
    public static final String DIRECT_FEHLERHANDLING = "direct:fehlerhandling";

    private final AntragRepository antragRepository;
    private final DrvMandant mandant;
    private final RequestContextController requestContext;

    @Override
    public void configure() throws Exception {
        //Mandantenabhaengiger Scheduler
        //@formatter:off

        from(DIRECT_RETRY)
            .routeId(DIRECT_RETRY)
            .setBody()
            .method(DynamicMultiTenantsRunTimeConfig.class, "getActiveTenants")
            .log(LoggingLevel.DEBUG, LOG, "Retry für Mandanten ${body}")
            .split(body())
            .to(DIRECT_GET_FEHLER_BY_MANDANT)
            .end();

        from(DIRECT_GET_FEHLER_BY_MANDANT)
            .routeId(DIRECT_GET_FEHLER_BY_MANDANT)
            .trace(true)
            .process(x -> requestContext.activate())
            .process(x -> {
                final var ktan = x.getMessage().getBody(String.class);
                x.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, ktan);
                x.setProperty(DrvMandantExtractor.MANDANT_SCOPE_PROPERTY_KEY, mandant.setInScope(ktan));
            })
            .to(DIRECT_FEHLERHANDLING)
            .log(LoggingLevel.DEBUG, LOG, "Fehler Handling für ${header.drv_mandant} fertig")
            .end();

        from(DIRECT_FEHLERHANDLING)
                .routeId(DIRECT_FEHLERHANDLING)
                .to(FehlerRoutes.GET_FEHLER)
                .split(body())
                .throttle(10).concurrentRequestsMode()
                    .process(exchange -> {
                        final var ktan = exchange.getProperty(DRVHeader.MANDANT_PROPERTY_KEY, String.class);
                        exchange.setProperty(DrvMandantExtractor.MANDANT_SCOPE_PROPERTY_KEY, mandant.setInScope(ktan));
                        final var fehler = exchange.getMessage().getBody(Fehler.class);
                        exchange.setProperty(RVFitCamelHeader.RVFIT_FEHLER, fehler);
                        final var antrag = antragRepository.findByUuid(fehler.getAntragId())
                            .orElseThrow(NotFoundException::new);
                        exchange.getMessage().setBody(antrag);
                    })
                    .doTry()
                        .log(LoggingLevel.DEBUG, LOG, "Fehler handling Fehler Für Status Routing ${body}")
                        .to(RouteNames.RVFIT_STATUS_BASED_ROUTING)
                    .endDoTry()
                    .doCatch(Exception.class)
                        .log(LoggingLevel.DEBUG, LOG, "Fehler handling Fehler beim retry ${body}")
                        .to(FehlerRoutes.DIRECT_ERROR)
                    .end()
                .end();

        //@formatter:on

    }
}
