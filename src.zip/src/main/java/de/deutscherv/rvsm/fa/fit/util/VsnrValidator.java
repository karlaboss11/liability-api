package de.deutscherv.rvsm.fa.fit.util;

import java.util.stream.IntStream;

/**
 * Validator für die Rentenversicherungsnummer. <h2>Grundlage</h2> <p><em>Verordnung über die Versicherungsnummer, die Kontoführung und den
 * Versicherungsverlauf in der gesetzlichen Rentenversicherung § 2 Abs. 6</em></p> <p>Die zwölfte Stelle, die Prüfziffer, wird errechnet,
 * indem der Buchstabe in der neunten Stelle durch eine zweistellige Zahl ersetzt wird, die die Position des Buchstabens im deutschen
 * Alphabet kennzeichnet. Die Ziffern der damit zwölfstelligen Nummer werden - an der ersten Stelle beginnend - mit den Faktoren 2, 1, 2, 5,
 * 7, 1, 2, 1, 2, 1, 2 und 1 multipliziert. Von den Produkten werden die Quersummen gebildet. Die Quersummen werden addiert. Die Summe wird
 * durch 10 dividiert. Der verbleibende Rest ist die Prüfziffer.</p>
 */
public class VsnrValidator {

    private static final byte[] FAKTOREN = { 2, 1, 2, 5, 7, 1, 2, 1, 2, 1, 2, 1 };
    private static final int MODULO = 10;
    private static final int CHARACTER_NUMERIC_OFFSET = 9;
    private static final int VSNR_LENGTH = 12;

    private VsnrValidator() {
    }

    /**
     * Prueft ob die Versicherungsnr. valide ist.
     *
     * @param vsnr zu pruefende Versicherungsnr.
     * @return true falls die Versicherungnr valide ist
     */
    public static boolean isValidVsnr(final String vsnr) {
        if (vsnr == null || vsnr.isBlank() || vsnr.length() != 12 || !isValidDate(
            vsnr.substring(2, 8))) {
            return false;
        }

        final int[] zerlegteVsnr = zerlegeVsnr(vsnr);
        return berechnePruefziffer(zerlegteVsnr) == extrahierePruefziffer(vsnr);
    }

    private static int berechnePruefziffer(final int[] payload) {
        return IntStream.range(0, payload.length).map(pos -> payload[pos] * FAKTOREN[pos])
            .map(VsnrValidator::quersumme).sum() % MODULO;

    }

    private static int quersumme(final int i) {
        int zahl = i;
        int summe = 0;
        while (0 != zahl) {
            // addiere die letzte Ziffer der uebergebenen Zahl zur Summe
            summe = summe + (zahl % 10);
            // entferne die letzte Ziffer der uebergebenen Zahl
            zahl = zahl / 10;
        }
        return summe;
    }

    private static int[] zerlegeVsnr(final String vsnr) {
        final String vsnrMitBuchstabeAlsZahl = String.format("%s%02d%s", vsnr.substring(0, 8),
            positionImDeutschenAlphabet(vsnr.charAt(8)), vsnr.substring(9, 11));
        final int[] zerlegt = new int[VSNR_LENGTH];
        IntStream.range(0, zerlegt.length).forEach(pos -> zerlegt[pos] =
            Character.getNumericValue(vsnrMitBuchstabeAlsZahl.charAt(pos)));
        return zerlegt;

    }

    private static int positionImDeutschenAlphabet(final char buchstabe) {
        return Character.getNumericValue(buchstabe) - CHARACTER_NUMERIC_OFFSET;
    }

    private static int extrahierePruefziffer(final String vsnr) {
        return Character.getNumericValue(vsnr.charAt(vsnr.length() - 1));
    }

    /**
     * Prueft, ob es es sich um ein valides Datum handelt.
     *
     * @param date zu pruefendes Datum
     * @return true falls das Datum valide ist
     */
    public static boolean isValidDate(final String date) {
        int day;
        int month;
        try {
            day = Integer.parseInt(date.substring(0, 2));
            month = Integer.parseInt(date.substring(2, 4));
        } catch (NumberFormatException e) {
            return false;
        }
        // Das Jahr wird hier nicht überprüft, da es immer zwei Ziffern hat und spezifische Regeln
        // dazu nicht angegeben sind

        // Monat 00 ist nur gültig, wenn der Tag 00 oder ein Spezial-Tag ist (32, 64, 97)
        if (month == 0 && day != 0 && !specialDay(day)) {
            return false;
        }

        // Monat muss zwischen 1 und 12 liegen, es sei denn, er ist 00 in Kombination mit einem
        // gültigen Tag
        if (month != 0 && monthNotInRange(month)) {
            return false;
        }

        // Tag muss zwischen 1 und 31 liegen, es sei denn, er ist 00 oder einer der speziellen Werte
        // 32, 64, 97
        return !(day != 0 && !specialDay(day) && dayNotInRange(day));
    }

    private static boolean dayNotInRange(final int day) {
        return day < 1 || day > 31;
    }

    private static boolean monthNotInRange(final int month) {
        return month < 1 || month > 12;
    }

    private static boolean specialDay(int day) {
        return day == 32 || day == 64 || day == 97;
    }

}