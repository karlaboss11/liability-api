package de.deutscherv.rvsm.fa.fit.stammdaten.mapper;

import de.deutscherv.rvsm.fa.fit.openapi.model.KontoinformationDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

/**
 * KontoinformationMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface KontoinformationMapper {

    /**
     * Mappt Kontoinformationen zu einem DTO.
     *
     * @param kontoinformation die Kontoinformationen
     * @return das DTO
     */
    @Mapping(source = "uuid", target = "id")
    KontoinformationDto toDto(Kontoinformation kontoinformation);

    /**
     * Mappt ein Kontoinformationen DTO zu Kontoinformationen.
     *
     * @param dto das DTO
     * @return die Kontoinformationen
     */
    @Mapping(source = "id", target = "uuid")
    @Mapping(target = "antragId", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    @InheritInverseConfiguration
    Kontoinformation toEntity(KontoinformationDto dto);
}
