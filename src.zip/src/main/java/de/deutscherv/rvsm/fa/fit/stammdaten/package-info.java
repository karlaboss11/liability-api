/**
 * Beinhaltet Klassen für Stammdaten.
 */
package de.deutscherv.rvsm.fa.fit.stammdaten;
