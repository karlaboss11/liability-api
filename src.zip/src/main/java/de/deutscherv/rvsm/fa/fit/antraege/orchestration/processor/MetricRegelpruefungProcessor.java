package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import io.micrometer.core.instrument.Tags;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.micrometer.MicrometerConstants;

/**
 * Processor fuer die Metric der Pruefergebnisse.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class MetricRegelpruefungProcessor implements Processor {

    private final PruefergebnisService pruefergebnisService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        String pruefergebnis = Optional.of(antrag).map(Antrag::getAntragPruefergebnisse).map(List::getFirst).map(Objects::toString)
                .orElse("null");

        exchange.getMessage().setHeader(MicrometerConstants.HEADER_METRIC_TAGS,
                Tags.of("ktan", antrag.getKtan(), "regelergebnis",
                        pruefergebnis));
    }
}
