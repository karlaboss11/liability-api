package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * RvPuRClentException.
 */
public class RvPurClientException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Fehlergrund
     */
    public RvPurClientException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
