package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.einrichtungen.repository.RehaEinrichtungRepository;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import de.deutscherv.rvsm.fa.fit.util.StatusValidator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * Service zum Update von Einrichtungen.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class EinrichtungenUpdateService {

    /**
     * Fehlermeldung für falsche Phase.
     */
    public static final String ERROR_PHASE_ID =
            "Die eingegebene url Phase parameter muss STARTPHASE oder TRAININGSPHASE sein";

    /**
     * Fehlermeldung, falls Einrichtung nicht eindeutig ist.
     */
    public static final String ERROR_EINRICHTUNG_STARTAUF_NICHT_EINDEUTIG =
            "Zur ausgewählten Einrichtung in der Startphase konnte kein eindeutiges Angebot für die Auffrischungsphase gefunden werden";

    /**
     * Fehlermeldung, falls in der Trainingsphase das Angebot nicht eindeutig ist.
     */
    public static final String ERROR_EINRICHTUNG_TRAINING_NICHT_EINDEUTIG =
            "Zur ausgewählten Einrichtung in der Trainingsphase konnte kein eindeutiges Angebot gefunden werden";

    /**
     * Loggingmeldung mit Platzhaltern für DRV-Id, Antrag-UUID und VSNR.
     */
    public static final String LOG_TEXT_WITH_KEY = "{} DrvId [{}], Antrag UUID [{}], VSNR [{}]";

    private static final String RESOURCE_NAME = EinrichtungenUpdateService.class.getName();

    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final AntragRepository antragRepository;
    private final RehaEinrichtungRepository einrichtungRepository;
    private final AntragService antragService;
    private final SelbstmeldeportalService selbstmeldeportalService;
    private final RvfitLogger rvfitLogger;

    /**
     * Aktualisiert basierend auf der Phase die Einrichtung zur Phase für einen Antrag.
     *
     * @param uuid                     die UUID des Antrags
     * @param phase                    die Phase
     * @param rehaEinrichtungUpdateDto das DTO zum RehaEinrichtungPhaseUpdate
     */
    @Transactional
    public void updateEinrichtungByPhase(final UUID uuid, final String phase,
            final RehaEinrichtungUpdateDto rehaEinrichtungUpdateDto) {

        final Antrag antrag = antragService.getAntragByUuid(uuid);

        StatusValidator.canModify(antrag.getStatus().name(), RESOURCE_NAME,
                GET_DRV_ID_AUS_JWT.apply(jwt));

        LOG.atDebug()
                .log("Service update Einrichtung By Phase: Die Einrichtung der Phase wird upgedated");
        switch (phase.toUpperCase()) {

            case "STARTPHASE":
                updateAntragStartAufEinrichtung(antrag, rehaEinrichtungUpdateDto.getAngebotId(),
                        rehaEinrichtungUpdateDto.getDurchfuehrungsart());
                break;
            case "TRAININGSPHASE":
                updateAntragTrainingEinrichtung(antrag, rehaEinrichtungUpdateDto.getAngebotId(),
                        rehaEinrichtungUpdateDto.getDurchfuehrungsart());
                break;
            default:
                LOG.atWarn().addArgument(ERROR_PHASE_ID).addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                        .addArgument(antrag.getUuid()).addArgument(antrag.getVsnr())
                        .log(LOG_TEXT_WITH_KEY);
                throw new EingabevalidierungException(RESOURCE_NAME, GET_DRV_ID_AUS_JWT.apply(jwt),
                        ERROR_PHASE_ID);
        }
        antragRepository.merge(antrag);
        LOG.atDebug().addArgument(antrag).log("Persistiere Antrag [{}] in DB");

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                EreignisTyp.ZWISCHENEREIGNIS_USER,
                Ereignistext.EINRICHTUNGSPRUEFUNG_ANGEPASST,
                EreignisFreitext.EINRICHTUNGSPRUEFUNG_ANGEPASST,
                phase, antrag, null, jwt, drvMandant));
    }

    /**
     * Aktualisiert die Antrag Start- und Auffrischungseinrichtung.
     *
     * @param antrag            the antrag
     * @param angebotId         the angebot id
     * @param durchfuehrungsart the durchfuehrungsart
     */
    private void updateAntragStartAufEinrichtung(final Antrag antrag, final Long angebotId,
            final String durchfuehrungsart) {
        final Integer durchfuehrungsartId =
                EinrichtungsdatenUtils.getDurchfuehrungsartId(durchfuehrungsart);
        try {
            if (isNeueEinrichtungWerte(antrag.getEinrichtungStartObjekt(), angebotId,
                    durchfuehrungsart)) {
                // Eindeutige Startphase Einrichtung von Selbstmeldeportal
                final List<RehaEinrichtung> smpStartEinrichtungen = selbstmeldeportalService
                        .getEinrichtungen(null, antrag.getPlz(), null, null, 2, durchfuehrungsartId);
                final RehaEinrichtung neueStartEinrichtung =
                        EinrichtungsdatenUtils.getEindeutigeEinrichtung(smpStartEinrichtungen,
                                PhaseEnumDto.STARTPHASE, angebotId, durchfuehrungsart);
                final Angebot aufAngebot = EinrichtungsdatenUtils
                        .getEindeutigeAufAngebot(neueStartEinrichtung, durchfuehrungsart);
                if (Objects.isNull(aufAngebot)) {
                    LOG.atWarn().addArgument("(Objects.isNull)")
                            .addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(antrag.getUuid())
                            .addArgument(antrag.getVsnr())
                            .log(ERROR_EINRICHTUNG_STARTAUF_NICHT_EINDEUTIG.concat(LOG_TEXT_WITH_KEY));
                    throw new EingabevalidierungException(RESOURCE_NAME, GET_DRV_ID_AUS_JWT.apply(jwt),
                            ERROR_EINRICHTUNG_STARTAUF_NICHT_EINDEUTIG);
                }
                // remove nicht eindeutige Startphase Angebote
                neueStartEinrichtung.getAngebote()
                        .removeIf(angebot -> !(angebot.getPhase().equalsIgnoreCase("Startphase")
                                && angebot.getSmpAngebotId().equals(angebotId)
                                && angebot.getDurchfuehrungsart().equals(durchfuehrungsart)));

                // Eindeutige Auffrischungsphase Einrichtung von Selbstmeldeportal
                final List<RehaEinrichtung> smpStartEinrichtungen2 = selbstmeldeportalService
                        .getEinrichtungen(null, null, null, null, 2, durchfuehrungsartId);
                final RehaEinrichtung neueAufEinrichtung =
                        EinrichtungsdatenUtils.getEindeutigeEinrichtung(smpStartEinrichtungen2,
                                PhaseEnumDto.STARTPHASE, angebotId, durchfuehrungsart);
                final Angebot aufAngebot2 = EinrichtungsdatenUtils
                        .getEindeutigeAufAngebot(neueAufEinrichtung, durchfuehrungsart);
                // remove nicht eindeutige Auffrischungsphase Angebote
                neueAufEinrichtung.getAngebote()
                        .removeIf(angebot -> !(angebot.getPhase().equalsIgnoreCase("Auffrischungsphase")
                                && angebot.getSmpAngebotId().equals(aufAngebot2.getSmpAngebotId())
                                && angebot.getDurchfuehrungsart()
                                .equals(aufAngebot2.getDurchfuehrungsart())));

                if (Objects.nonNull(antrag.getEinrichtungStartObjekt())) {
                    einrichtungRepository.delete(antrag.getEinrichtungStartObjekt());
                    einrichtungRepository.delete(antrag.getEinrichtungAufObjekt());
                }
                antrag.setEinrichtungStartObjekt(neueStartEinrichtung);
                antrag.setEinrichtungAufObjekt(neueAufEinrichtung);
                final LocalDateTime dateTimeNow = LocalDateTime.now();
                antrag.setLastModifiedStart(dateTimeNow);
                antrag.setLastModifiedAuf(dateTimeNow);
                LOG.atDebug().addArgument(antrag.getUuid()).addArgument("Startphase")
                        .addArgument(neueStartEinrichtung.getName())
                        .log("Antrag UUID [{}]: [{}] Einrichtung fuer den Antrag wurde auf [{}] geaendert");
            }
        } catch (final NotFoundException e) {
            LOG.atWarn().addArgument("(NotFoundException)").addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                    .addArgument(antrag.getUuid()).addArgument(antrag.getVsnr())
                    .log(ERROR_EINRICHTUNG_STARTAUF_NICHT_EINDEUTIG.concat(LOG_TEXT_WITH_KEY));
            throw new EingabevalidierungException(RESOURCE_NAME, GET_DRV_ID_AUS_JWT.apply(jwt),
                    ERROR_EINRICHTUNG_STARTAUF_NICHT_EINDEUTIG);
        }
    }

    /**
     * Aktualisiert die Antrag Trainingseinrichtung.
     *
     * @param antrag            the antrag
     * @param angebotId         the angebot id
     * @param durchfuehrungsart the durchfuehrungsart
     */
    private void updateAntragTrainingEinrichtung(final Antrag antrag, final Long angebotId,
            final String durchfuehrungsart) {
        final Integer durchfuehrungsartId =
                EinrichtungsdatenUtils.getDurchfuehrungsartId(durchfuehrungsart);
        try {
            if (isNeueEinrichtungWerte(antrag.getEinrichtungTrainingObjekt(), angebotId,
                    durchfuehrungsart)) {
                final List<RehaEinrichtung> smpEinrichtungen = selbstmeldeportalService
                        .getEinrichtungen(null, antrag.getPlz(), null, null, 3, durchfuehrungsartId);
                final RehaEinrichtung neueEinrichtung =
                        EinrichtungsdatenUtils.getEindeutigeEinrichtung(smpEinrichtungen,
                                PhaseEnumDto.TRAININGSPHASE, angebotId, durchfuehrungsart);

                EinrichtungsdatenUtils.deleteNichtEindeutigAngeboteFromEinrichtung(
                        PhaseEnumDto.TRAININGSPHASE, angebotId, durchfuehrungsart, neueEinrichtung);

                if (neueEinrichtung.getAngebote().size() != 1) {
                    LOG.atWarn().addArgument("(size != 1)").addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                            .addArgument(antrag.getUuid()).addArgument(antrag.getVsnr())
                            .log(ERROR_EINRICHTUNG_TRAINING_NICHT_EINDEUTIG.concat(LOG_TEXT_WITH_KEY));
                    throw new EingabevalidierungException(RESOURCE_NAME, GET_DRV_ID_AUS_JWT.apply(jwt),
                            ERROR_EINRICHTUNG_TRAINING_NICHT_EINDEUTIG);
                }
                if (Objects.nonNull(antrag.getEinrichtungTrainingObjekt())) {
                    einrichtungRepository.delete(antrag.getEinrichtungTrainingObjekt());
                }
                antrag.setEinrichtungTrainingObjekt(neueEinrichtung);
                antrag.setLastModifiedTraining(LocalDateTime.now());

                LOG.atDebug().addArgument(antrag.getUuid()).addArgument("Trainingsphase")
                        .addArgument(neueEinrichtung.getName())
                        .log("Antrag UUID [{}]: [{}] Einrichtung fuer den Antrag wurde auf [{}] geaendert");
            }
        } catch (final NotFoundException e) {
            LOG.atWarn().addArgument("(NotFoundException)").addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                    .addArgument(antrag.getUuid()).addArgument(antrag.getVsnr())
                    .log(ERROR_EINRICHTUNG_TRAINING_NICHT_EINDEUTIG.concat(LOG_TEXT_WITH_KEY));
            throw new EingabevalidierungException(RESOURCE_NAME, GET_DRV_ID_AUS_JWT.apply(jwt),
                    ERROR_EINRICHTUNG_TRAINING_NICHT_EINDEUTIG);
        }

    }

    /**
     * Gibt zurück, ob es sich beim Update um eine neue Einrichtung oder eine andere Durchführungsart handelt.
     *
     * @param aktuelleEinrichtung the aktuelle Einrichtung
     * @param angebotId           the angebot id
     * @param durchfuehrungsart   the durchfuehrungsart
     * @return true, falls die Einrichtung neu ist und andernfalls false
     */
    private boolean isNeueEinrichtungWerte(final RehaEinrichtung aktuelleEinrichtung,
            final Long angebotId, final String durchfuehrungsart) {
        return Objects.isNull(aktuelleEinrichtung) || aktuelleEinrichtung.getAngebote().isEmpty()
                || !angebotId.equals(aktuelleEinrichtung.getAngebote().getFirst().getSmpAngebotId())
                || (angebotId.equals(aktuelleEinrichtung.getAngebote().getFirst().getSmpAngebotId())
                && !durchfuehrungsart
                .equals(aktuelleEinrichtung.getAngebote().getFirst().getDurchfuehrungsart()));
    }
}
