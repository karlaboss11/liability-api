package de.deutscherv.rvsm.fa.fit.aufgaben.service;

import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCompleteDTO;
import de.deutscherv.rvsm.qs.arv.async.model.AufgabeCreateDTO;

/**
 * Interface für die Implementierung der asynchronen Schnittstelle zum Erzeugen und Schließen von Aufgaben in RV PuR.
 */
public interface PurAufgabenProducer {

    /**
     * Sendet eine asynchrone Nachricht für die Aufgabenerstellung an das rvPuR-Aufgaben-Gateway und speichert die Aufgaben-ID in der
     * Datenbank.
     *
     * @param aufgabeCreateDTO das Objekt mit Informationen zur Aufgabenerzeugung
     */
    void createAufgabe(final AufgabeCreateDTO aufgabeCreateDTO);

    /**
     * Sendet eine asynchrone Nachricht für die Aufgabenschließung an das rvPuR-Aufgaben-Gateway.
     *
     * @param aufgabeCompleteDTO das Objekt mit Informationen zur Aufgabenschließung
     */
    void completeAufgabe(final AufgabeCompleteDTO aufgabeCompleteDTO);

}
