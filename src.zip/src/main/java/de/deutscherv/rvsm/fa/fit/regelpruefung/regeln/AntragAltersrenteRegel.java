package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;

/**
 * Regelpruefung - Altersrente.
 */
@Singleton
public class AntragAltersrenteRegel extends BasisRegel {

    // 65= Altersrente für besonders langjährig Versicherte
    // 18= Altersrente für Frauen - §237a SGB VI
    // 63= Altersrente für langjährig Versicherte
    // 62= Altersrente für schwerbehinderte Menschen
    // 17= Altersrente wegen Arbeitslosigkeit - §237 SGB VI
    // 16= Regelaltersrente - §35 SGB VI
    // 10= Knappschaftsausgleichsleistung - §239 SGB VI
    // 19= Altersrente für langjährig unter Tage beschäftigte Bergleute - §40 SGB V
    private static final List<String> ALTERSRENTENGRUPPEN =
        List.of("65", "18", "63", "62", "17", "16", "10", "19");

    // 0= Vollrente
    // 9= Beantragte Teilrente - §42 Abs. 1 SGB VI
    private static final List<String> TEILRENTENGRUPPEN = List.of("0", "9");

    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(RegelUtils.ERFUELLT, "Es wurde kein Antrag auf Altersente gestellt",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.NICHT_ERFUELLT_ABLEHNEN, "Es wurde ein Antrag auf Altersente gestellt",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es wurde ein Antrag auf Altersente gestellt");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_ANTRAGALTERSRENTE;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!RegelUtils.kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String antragRenteLeat = kontoinformation.getAntragRenteLeat();
        final String antragRenteTlrt = kontoinformation.getAntragRenteTlrt();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(antragRenteLeat).firstExpected("??")
                .secondValue(antragRenteTlrt).secondExpected("?").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (!StringUtils.isBlank(antragRenteLeat)
            && !ALTERSRENTENGRUPPEN.contains(antragRenteLeat.trim())
                || Objects.isNull(antragRenteTlrt)) {
            return ergebnisErfuellt(this);
        }
        if (!StringUtils.isBlank(antragRenteLeat)
            && ALTERSRENTENGRUPPEN.contains(antragRenteLeat.trim())
                && !StringUtils.isBlank(antragRenteTlrt)
            && TEILRENTENGRUPPEN.contains(antragRenteTlrt.trim())) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        return ergebnisAussteuernKeineDaten(this);

    }

}
