package de.deutscherv.rvsm.fa.fit.antraege.model;

/**
 * 
 * Enum für den Satus der Doppelvergabe in einem Antrag.
 *
 */
public enum DoppelvergabeStatus {

    /**
     * Es liegt keine Doppelvergabe vor.
     */
    KEINE_DOPPELVERGABE,
    
    /**
     * Die Doppelvergabe muss geprüft werden.
     */
    PRUEFEN,
    
    /**
     * Der Antrag wird nach der Prüfung in RV Fit Modern weiterverarbeitet.
     */
    WEITERVERARBEITEN,
    
    /**
     * Der Antrag wird nach der Prüfung storniert.
     */
    STORNIEREN
    
}
