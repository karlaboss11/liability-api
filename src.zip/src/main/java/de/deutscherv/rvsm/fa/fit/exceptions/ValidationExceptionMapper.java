package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import jakarta.validation.ValidationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import lombok.extern.slf4j.Slf4j;

/**
 * ValidationExceptionMapper.
 */
@Provider
@Slf4j
public class ValidationExceptionMapper implements ExceptionMapper<ValidationException> {

    /**
     * Nachricht wenn Validierung ist fehlgeschlagen.
     */
    public static final String VALIDATION_FEHLGESCHLAGEN_NACHRICHT =
        "Die Validierung ist fehlgeschlagen";

    @Override
    public Response toResponse(final ValidationException ve) {
        LOG.atWarn().setCause(ve).log(VALIDATION_FEHLGESCHLAGEN_NACHRICHT);
        MDCUtils.setFailed();
        return Response.status(Status.BAD_REQUEST)
            .entity(new AntwortDto().code(Status.BAD_REQUEST.getStatusCode())
                .nachricht(VALIDATION_FEHLGESCHLAGEN_NACHRICHT))
            .build();
    }

}