package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * Standardisierte Log-Meldungen werden zur Verfuegung gestellt.
 */
@UtilityClass
@Slf4j
public class LoggingUtils {

    /**
     * Standardisierte Log-Meldung für einen Processor.
     *
     * @param route     Route über die die Nachricht verarbeitet wird.
     * @param className Name der Processor-Klasse.
     * @param antrag    dessen Schluesslewerte geloggt werden.
     */
    public static void logProcessorAntrag(final String route, final String className, final Antrag antrag) {
        LOG.atInfo()
            .addArgument(route)
            .addArgument(className)
            .addArgument(antrag.getUuid())
            .addArgument(antrag.getKtan())
            .addArgument(antrag.getVsnr())
            .log("Route [{}] Processor [{}] UUID [{}] KTAN [{}] VSNR [{}]");
    }

    /**
     * Standardisierte Log-Meldung für einen Processor.
     *
     * @param route      Route über die die Nachricht verarbeitet wird.
     * @param className  Name der Processor-Klasse.
     * @param antragUuid die geloggt wird.
     */
    public static void logProcessorUuid(final String route, final String className, final UUID antragUuid) {
        LOG.atInfo()
            .addArgument(route)
            .addArgument(className)
            .addArgument(antragUuid)
            .log("Route [{}] Processor [{}] UUID [{}]");
    }

    /**
     * Standardisierte Log-Meldung für einen Processor.
     *
     * @param route           Route über die die Nachricht verarbeitet wird.
     * @param className       Name der Processor-Klasse.
     * @param papierantragDto deren Schluesslewerte geloggt werden.
     */
    public static void logProcessorPapierantrag(final String route, final String className, final PapierantragDto papierantragDto) {
        LOG.atInfo()
            .addArgument(route)
            .addArgument(className)
            .addArgument(papierantragDto.getVorgangsId())
            .addArgument(papierantragDto.getAufgabenId())
            .addArgument(papierantragDto.getVersicherter().getVsnr())
            .log("Route [{}] Processor [{}] VOG-ID: [{}], AUFG-ID [{}] VSNR [{}]");
    }

    /**
     * Standardisierte Log-Meldung für einen Processor.
     *
     * @param route        Route über die die Nachricht verarbeitet wird.
     * @param className    Name der Processor-Klasse.
     * @param antragsdaten deren Schluesselwerte gelogt werden
     */
    public static void logProcessorAntragsdaten(final String route, final String className, final Antragsdaten antragsdaten) {
        LOG.atInfo()
            .addArgument(route)
            .addArgument(className)
            .addArgument(antragsdaten.getSteuerdaten().getVsnr())
            .log("Route [{}] Processor [{}] VSNR [{}]");
    }

}
