package de.deutscherv.rvsm.fa.fit.health;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.Date;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Readiness;

/**
 * ReadinessCheck.
 */
@Readiness
@ApplicationScoped
public class ReadinessCheck implements HealthCheck {

    @Override
    public HealthCheckResponse call() {
        return HealthCheckResponse.named("rvFit Service Readiness Check")
                .withData("time", String.valueOf(new Date())).up().build();
    }

}
