package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SMP-Model: Adresse extended.
 */
@Data
@SuppressWarnings("java:S1068")
public class AngebotExtended extends Angebot {

    private String freiePlaetze;
    private Long freiePlaetzeWert;
    private String durchfuehrungsart;
    private Long dauer;
    private Long anzahlTrainingseinheiten;
    private Long dauerTrainingseinheiten;
    private Long distanz;
    private Long distanzVersicherter;
    private Geokoordinaten standort;
    private Adresse adresse;
    private Adresse postanschrift;
}
