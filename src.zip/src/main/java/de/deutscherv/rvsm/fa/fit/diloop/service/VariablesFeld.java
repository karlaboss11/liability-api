package de.deutscherv.rvsm.fa.fit.diloop.service;

/**
 * Auflistung variabler Felder.
 */
public enum VariablesFeld {

    /**
     * Freitext Versicherter.
     */
    FREITEXT_VERSICHERTER,
    /**
     * Freitext Einrichtung.
     */
    FREITEXT_EINRICHTUNG
}
