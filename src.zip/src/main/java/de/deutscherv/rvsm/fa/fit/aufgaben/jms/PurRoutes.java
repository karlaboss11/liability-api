package de.deutscherv.rvsm.fa.fit.aufgaben.jms;

import de.deutscherv.rvsm.fa.fit.util.Json;
import jakarta.enterprise.context.ApplicationScoped;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.eclipse.microprofile.config.ConfigProvider;

import static de.deutscherv.rvsm.fa.fit.util.MessagingUtils.getJmsRouteForTextMessageType;

/**
 * Routen rvPuR.
 */
@ApplicationScoped
public class PurRoutes extends RouteBuilder  {

    /**
     * Routenname: Erstelle rvPuR Aufgabe.
     */
    public static final String DIRECT_ERSTELLE_PUR_AUFGABE = "direct:erstellePurAufgabe";
    /**
     * Routenname: Schliesse rvPuR Aufgabe.
     */
    public static final String DIRECT_SCHLIESSE_PUR_AUFGABE = "direct:schliessePurAufgabe";
    private static final Processor MAP_TO_JSON_STRING = exchange ->
            exchange.getMessage().setBody(Json.objectToJson(exchange.getMessage().getBody()));
    @Override
    public void configure() throws Exception {
        // @formatter:off
        from(DIRECT_ERSTELLE_PUR_AUFGABE)
                .transacted()
                .process(MAP_TO_JSON_STRING)
                .to(getJmsRouteForTextMessageType(ConfigProvider.getConfig()
                        .getValue("vom.queue.outgoing.request.create.aufgabe", String.class)));

        from(DIRECT_SCHLIESSE_PUR_AUFGABE)
                .transacted()
                .process(MAP_TO_JSON_STRING)
                .to(getJmsRouteForTextMessageType(ConfigProvider.getConfig()
                        .getValue("vom.queue.outgoing.aufgabe.completed", String.class)));
        // @formatter:on
    }


}
