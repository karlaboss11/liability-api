package de.deutscherv.rvsm.fa.fit.regelpruefung.model;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Regel.
 */
@Entity
@Table(name = "regel")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)

public class Regel {

    /** technische id der Regel. */
    @Id
    @Column
    private UUID uuid;

    @Column
    @Enumerated(EnumType.STRING)
    private RegelName name;

    @Column
    private String ktan;

    @Column
    private String parameter;

    @Column
    private boolean aktiv;

    @Column
    private Long prioritaet;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;
}
