package de.deutscherv.rvsm.fa.fit.antraege;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * NamespaceFilter der das Hinzufuegen einer Namespace-URI ermoeglicht.
 */
public final class NamespaceFilter extends XMLFilterImpl {

    private final String usedNamespaceUri;
    private final boolean addNamespace;
    private boolean addedNamespace = false;

    /**
     * Konstruktor.
     *
     * @param namespaceUri Das URI des Namespace
     * @param addNamespace true - wenn die URI hinzugefuegt werden soll.
     */
    public NamespaceFilter(final String namespaceUri, final boolean addNamespace) {
        super();
        if (addNamespace) {
            this.usedNamespaceUri = namespaceUri;
        } else {
            this.usedNamespaceUri = "";
        }
        this.addNamespace = addNamespace;
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        if (addNamespace) {
            startControlledPrefixMapping();
        }
    }

    @Override
    public void startElement(final String arg0, final String arg1, final String arg2,
            final Attributes arg3) throws SAXException {
        super.startElement(this.usedNamespaceUri, arg1, arg2, arg3);
    }

    @Override
    public void endElement(final String arg0, final String arg1, final String arg2)
            throws SAXException {
        super.endElement(this.usedNamespaceUri, arg1, arg2);
    }

    /**
     * Startet das Prefix-Mapping.
     *
     * @throws SAXException Fehler beim Lesen der XML.
     */
    private void startControlledPrefixMapping() throws SAXException {
        if (this.addNamespace && !this.addedNamespace) {
            super.startPrefixMapping("", this.usedNamespaceUri);
            this.addedNamespace = true;
        }
    }

}
