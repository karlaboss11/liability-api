/**
 * Beinhaltet Klassen, die sich mit der Anbindung an rvPuR beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.rvpur;
