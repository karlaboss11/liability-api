package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.util.ValueMatcher;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Erwerbsminderungsrente.
 */
@Singleton
public class AntragEMRenteRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(
                    RegelUtils.ERFUELLT, "Ein wurde kein Antrag auf EM Rente gestellt",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Ein wurde ein Antrag auf EM Rente gestellt");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_ANTRAGEMRENTE;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation = kontext.getAntrag().getKontoinformationen().getFirst();
        final String antragRenteLeat = kontoinformation.getAntragRenteLeat();

        final boolean hasQuestionMark = ValueMatcher.builder().firstValue(antragRenteLeat).firstExpected("??").build().matches();

        if (hasQuestionMark) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (!StringUtils.isBlank(antragRenteLeat)
                && List.of("74", "14", "75", "76", "43", "15").contains(antragRenteLeat.trim())) {
            return ergebnisNichtErfuelltAussteuern(this);
        }
        if (Objects.isNull(antragRenteLeat) || !antragRenteLeat.isEmpty() && !List
                .of("74", "14", "75", "76", "43", "15").contains(antragRenteLeat.trim())) {
            return ergebnisErfuellt(this);
        }
        return ergebnisAussteuernKeineDaten(this);
    }
}
