package de.deutscherv.rvsm.fa.fit.aufgaben.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

/**
 * Klasse für Aufgaben im Vorgansmanagement.
 *
 * @author U38322
 */
@Entity
@Table(name = "aufgabe")
@NamedQuery(name = "Aufgabe.findAll", query = "SELECT a FROM Aufgabe a")
@Cacheable
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Aufgabe {

    /** technische id der Aufgabe. */
    @Id
    @Column
    @Builder.Default
    private UUID uuid = UUID.randomUUID();

    @Column(name = "transaktion_id")
    private UUID transaktionId;

    @Column(name = "vom_aufgaben_id")
    private String vomAufgabenId;

    @CreationTimestamp
    @Column(name = "datum_erstellung", updatable = false)
    private LocalDateTime datumErstellung;

    @Column(name = "datum_erledigt")
    private LocalDateTime datumErledigt;

    @Column(name = "aufgaben_art")
    private AufgabenArt aufgabenArt;

}
