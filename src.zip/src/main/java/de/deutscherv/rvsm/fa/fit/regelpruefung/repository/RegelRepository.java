package de.deutscherv.rvsm.fa.fit.regelpruefung.repository;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.model.Regel;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * Regel Repository.
 */
@RequiredArgsConstructor
@ApplicationScoped
public class RegelRepository {

    private static final String KTAN_NULL_UND_AKTIV_QUERY = "ktan is null and aktiv = ?1";
    private static final String AKTIV_QUERY = "ktan = ?1 and aktiv = ?2";

    private final EntityManager entityManager;

    /**
     * Persistiere Regel.
     *
     * @param regel die persistiert wird
     */
    public void persist(final Regel regel) {
        entityManager.persist(regel);
    }

    /**
     * Suche Regeln nach dem Regelname.
     *
     * @param name nach dem selektiert wird
     * @return Liste der gefundenen Regeln
     */
    public List<Regel> findByRegelName(final RegelName name) {
        return entityManager.createQuery("select r from Regel r where name = :name", Regel.class)
                .setParameter("name", name).getResultList();
    }

    /**
     * Suche Regeln mit KTAN und Aktiv-Status.
     *
     * @param ktan nach der selektiert wird
     * @param aktiv Aktiv-Status nach dem selektiert wird
     * @return Liste der gefundenen Regeln
     */
    public List<Regel> findByKtanAndAktiv(final String ktan, final boolean aktiv) {
        if (StringUtils.isEmpty(ktan)) {
            return list(KTAN_NULL_UND_AKTIV_QUERY, aktiv);
        }
        return list(AKTIV_QUERY, ktan, aktiv);
    }

    /**
     * Liefert eine Liste von Regeln die über die Query gefunden wurde.
     *
     * @param query  Bedingungen fuer die Query
     * @param params fuer die Query
     * @return Liste der gefundenen Regeln
     */
    public List<Regel> list(final String query, final Object... params) {
        String queryStr = "select r from Regel r";
        if (params.length > 0) {
            queryStr += " where " + query;
        }
        final TypedQuery<Regel> typedQuery = entityManager.createQuery(queryStr, Regel.class);
        IntStream.range(0, params.length)
                .forEach(idx -> typedQuery.setParameter(idx + 1, params[idx]));

        return typedQuery.getResultList();
    }
}
