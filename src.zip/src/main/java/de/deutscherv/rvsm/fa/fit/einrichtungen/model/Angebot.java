package de.deutscherv.rvsm.fa.fit.einrichtungen.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity: Angebot.
 */
@Entity
@Table(name = "angebot")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Angebot {

    /** technische id des Angebots. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column
    private UUID uuid;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "adresse_uuid", referencedColumnName = "uuid")
    private EinrichtungAnschrift adresse;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "postanschrift_uuid", referencedColumnName = "uuid")
    private EinrichtungAnschrift postanschrift;

    @Column(name = "smp_angebot_id")
    private Long smpAngebotId;

    @Column
    private String phase;

    @Column(name = "freie_plaetze_wert")
    private Integer freiePlaetzeWert;

    @Column
    private String durchfuehrungsart;

    @Column
    private Integer dauer;

    @Column(name = "anzahl_trainingseinheiten")
    private Integer anzahlTrainingseinheiten;

    @Column(name = "dauer_trainingseinheiten")
    private Integer dauerTrainingseinheiten;

    @Column
    private Integer distanz;

    @Column(name = "distanz_versicherter")
    private Integer distanzVersicherter;

    @Column(name = "ktan")
    private String ktan;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;
}
