/**
 * Beinhaltet die Regelengine.
 */
package de.deutscherv.rvsm.fa.fit.regelpruefung;
