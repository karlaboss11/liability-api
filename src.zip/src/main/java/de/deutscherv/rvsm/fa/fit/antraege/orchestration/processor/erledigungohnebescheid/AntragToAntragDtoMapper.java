package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor um einen Antrag in ein AntragDto zu mappen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class AntragToAntragDtoMapper implements Processor {

    private final AntragMapper antragMapper;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        exchange.getMessage().setBody(antragMapper.toDto(antrag));
    }
}
