package de.deutscherv.rvsm.fa.fit.diloop.service;

import lombok.Builder;
import lombok.Getter;

/**
 * Allgemeine Dokumentendaten zur Dokumentenerzeugung.
 */
@Getter
@Builder
public final class AllgemeineDokumentenDaten {
    private String fall;
    private String ktan;
    private String aigr;
    private boolean doReview;
    private boolean isBatchPrint;
}
