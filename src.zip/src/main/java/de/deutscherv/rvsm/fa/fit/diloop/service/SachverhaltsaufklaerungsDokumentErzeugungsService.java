package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentenErzeugungConfig;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.MSNR;

/**
 * Implementierung des DokumentErzeugungsService für Sachverhaltsaufklärungen.
 */
@ApplicationScoped
public final class SachverhaltsaufklaerungsDokumentErzeugungsService extends DokumentErzeugungsService {

    private static final String FALSE = "FALSE";

    private final DokumentenErzeugungConfig dokumentenErzeugungConfig;

    /**
     * Konstruktor.
     *
     * @param dokumentenErzeugungConfig Konfiguration zur Dokumentenerzeugung
     */
    public SachverhaltsaufklaerungsDokumentErzeugungsService(final DokumentenErzeugungConfig dokumentenErzeugungConfig) {
        this.dokumentenErzeugungConfig = dokumentenErzeugungConfig;
    }

    @Override
    protected UUID getTemplateId(DokumentenErstellungsDaten dokumentenErstellungsDaten) {
        return UUID.fromString(dokumentenErzeugungConfig.getVorlagenIdSachverhaltsaufklaerung());
    }

    @Override
    protected AllgemeineDokumentenDaten getAllgemeineDokumentenDaten(@Nonnull final DokumentenErstellungsDaten daten) {
        final KontoDto konto = daten.konto();
        final Antrag antrag = daten.antrag();
        return AllgemeineDokumentenDaten.builder()
                .fall(konto.getVersicherungsnummer())
                .ktan(konto.getKtan())
                .aigr(getAigr(antrag))
                .doReview(true)
                .isBatchPrint(false)
                .build();
    }

    @Override
    protected Map<String, String> getVariablen(@Nonnull final DokumentenErstellungsDaten daten) {
        final Map<String, String> variablen = new HashMap<>();
        variablen.put("rvEvolution", "1");
        variablen.putAll(getVariablenZurBefuellungDerKonkretenVorlage());
        variablen.putAll(getVariablenZurKommunikationMitRvPur(daten));
        return variablen;
    }

    /**
     * Daten für die Kommunikation mit rvPuR.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return Variablen für die Kommunikation mit rvPur
     */
    private Map<String, String> getVariablenZurKommunikationMitRvPur(@Nonnull final DokumentenErstellungsDaten daten) {
        final Antrag antrag = daten.antrag();
        final Map<String, String> bescheid = new HashMap<>();
        bescheid.put("vorgangsID", antrag.getVorgangskennung());
        bescheid.put("aktenart", "03");
        bescheid.put("aktenteil", "25");
        bescheid.put("dokumenttyp", "19");
        bescheid.put("teilprozess", "08");
        bescheid.put("terminUebergeben", "1");
        bescheid.put("terminDatum", LocalDate.now().plusDays(28).format(
                DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        bescheid.put("terminBemerkung", "RV Fit: Posteingang zur Klärung des Sachverhalts?");
        bescheid.put("inWiedervorlageSchieben", "1");
        bescheid.put("massnahmeArtNummer", "8".concat(MSNR.format(antrag.getMsnr())));

        return bescheid;
    }

    /**
     * Daten zur Befüllung der konkreten Vorlage.
     *
     * @return die Variablen zur Befüllung der konkreten Vorlage
     */
    private Map<String, String> getVariablenZurBefuellungDerKonkretenVorlage() {
        final Map<String, String> map = new HashMap<>();
        map.put("bankverbindung", "ohne Bankverbindung");
        map.put("personenstandsdaten", "keine Personenstandsdaten");
        map.put("ueberschrift", "Rückfrage zu Ihrem RV Fit Antrag");
        map.put("datenschutzText", "versicherte / berechtigte Person");
        map.put("datenschutzAllgemein", FALSE);
        map.put("anlage", FALSE);
        map.put("freiesAntwortschreiben", FALSE);
        map.put("sv_kk_maschineller_Aufruf", "true");
        return map;
    }
}
