package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.LaenderUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.util.LandIsoCodes;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;

/**
 * Regelpruefung - Aufenthalt.
 */
@Singleton
public class AufenthaltRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "Es liegt kein Aufenthalt außerhalb von Deutschland vor.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.AUSSTEUERN,
            "Es konnte nicht ermittelt werden, ob ein Aufenthalt außerhalb von Deutschland vorliegt. Bitte manuell prüfen.",
            RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es liegt ein Aufenthalt außerhalb von Deutschland vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_AUFENTHALT;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (Objects.isNull(kontext.getAntrag()) || Objects.isNull(kontext.getStammdaten())
                || Objects.isNull(kontext.getStammdaten().getLand())) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final LandIsoCodes landAusAntrag = LandIsoCodes.findeLandFuerCode(kontext.getAntrag().getLand(),
                LandIsoCodes.Typ.NTSC).orElse(LandIsoCodes.DEUTSCHLAND);
        final boolean keinLandInStammdaten = kontext.getStammdaten().getLand() == null
                || kontext.getStammdaten().getLand().isEmpty();

        if (landAusAntrag == LandIsoCodes.DEUTSCHLAND && keinLandInStammdaten) {
            return ergebnisErfuellt(this);
        }

        final var land = kontext.getStammdaten().getLand();
        if (LaenderUtils.isAussteuern(land)) {
            return ergebnisAussteuern(this);
        }

        if (LaenderUtils.isDeutschland(land)) {
            return ergebnisErfuellt(this);

        }

        return ergebnisNichtErfuelltAussteuern(this);

    }
}
