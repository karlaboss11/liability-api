package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.azk.AzkService;
import de.deutscherv.rvsm.fa.fit.exceptions.BestandsfehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.KeinAntragInBearbeitungException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragArchivPdfDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.rvpur.util.PDFUtil;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikUtil;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import io.quarkus.cache.CacheInvalidateAll;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.eclipse.microprofile.jwt.JsonWebToken;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.AUFGABE_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.AUFGABE_SCHLIESSEN_OHNE_STATISTIK;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.AUTOMATISCH;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.DOPPELVERGABE_PRUEFUNG_OK;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.ENTWURF;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.KONTOINFORMATION_ABGEFRAGT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.RVPUR_AUFGABE_GESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIK_ERFASST;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.VORGANG_ERZEUGT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.VerarbeitungsService.automatischeAblehnung;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.VerarbeitungsService.automatischeBewilligung;
import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * The Class AntragService.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
@SuppressWarnings("javaarchitecture:S7091")
public class AntragService {

    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;
    private final AntragRepository antragRepository;
    private final AntragStatusService antragStatusService;
    private final AufgabeService aufgabeService;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final StammdatenService stammdatenService;
    private final AntragMapper antragMapper;
    private final FluentProducerTemplate producerTemplate;
    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final StatistikService statistikService;
    private final AzkService azkService;


    /**
     * Archiviere PDF.
     *
     * @param antrag    Antrag
     * @param pdfStream Stream mit den PDF-Daten
     * @return true falls erfolgreich
     */
    static boolean archivePdf(final Antrag antrag, final byte[] pdfStream) {
        final AntragArchivPdfDto archivPdfDto = new AntragArchivPdfDto();
        archivPdfDto.setVsnr(antrag.getVsnr());
        archivPdfDto.setAntragsdatum(antrag.getAntragsDatum());
        archivPdfDto.setPdf(Base64.getEncoder().encodeToString(pdfStream));
        return true;
    }

    /**
     * Mappt den Antrag zu einem DTO und prüft auf Schutzbedarf.
     *
     * @param antrag der Antrag
     * @return den AntragDto des Antrags zur übergebenen UUID
     */
    @Transactional
    public AntragDto mapToAntragDto(final Antrag antrag) {
        final AntragDto antragDto = antragMapper.toDto(antrag);

        // Prüfen ob ein Schutzbedarf vorliegt
        stammdatenService.getKontoDto(antragMapper.toEntity(antragDto));

        return antragDto;
    }

    /**
     * Sucht einen Antrag mit der übergebenen UUID. Falls keiner gefunden wird, wird eine NotFoundException geworfen.
     *
     * @param uuid die UUID zum Antrag
     * @return den Antrag zur übergebenen UUID
     */
    public Antrag getAntragByUuid(final UUID uuid) {

        LOG.atDebug().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid)
                .log("Lies Antrag anhand der UUID aus dem Repository. Ktan [{}], UUID:[{}]: ");
        final Antrag antrag = antragRepository.findByUuid(uuid)
                .filter(a -> a.getKtan().equals(JwtUtils.GET_KTAN.apply(jwt, drvMandant)))
                .orElseThrow(NotFoundException::new);

        MDCUtils.setVsnr(antrag.getVsnr());
        return antrag;
    }

    /**
     * Sucht einen Antrag mit der übergebenen Vorgangskennung. Falls keiner gefunden wird, wird eine NotFoundException geworfen.
     *
     * @param vorgangskennung die Vorgangskennung zum Antrag
     * @return den Antrag zur übergebenen Vorgangskennung
     */
    public Antrag getAntragByVorgangskennung(final String vorgangskennung) {

        LOG.atDebug().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vorgangskennung)
                .log("Lies Antrag anhand der UUID aus dem Repository. Ktan [{}], UUID:[{}]: ");
        final Antrag antrag = antragRepository.findByVorgangskennung(vorgangskennung);
        if (Objects.isNull(antrag)) {
            LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vorgangskennung)
                    .log("Keinen Antrag zur Vorgangskennung gefunden. DrvId [{}] Vsnr [{}]");
            return null;
        }

        MDCUtils.setVsnr(antrag.getVsnr());
        return antrag;
    }

    /**
     * Ermittle Antraege mit Status {@code VORGANG_ERZEUGT}.
     * @param limit maximale Anzahl
     * @return Liste der gefundenen Antraege
     */
    public List<Antrag> getAntraegeMitMitStatusVorgangErzeugt(final int limit) {
        LOG.atDebug().addArgument(drvMandant.getOrThrow())
                .log("Suche Anträge mit offener Vorgangserzeugung. Ktan [{}]: ");
        return antragRepository.findAntraegeimStatus(AntragStatus.VORGANG_ERZEUGT, limit);
    }

    /**
     * Setzen des Antragsstatus von {@code VORGANG_WIRD_ERSTELLT} nach {@code VORGANG_ERSTELLT}.
     * @param antragUuids UUID-Liste von Antraegen
     */
    public void setzeStatusVonVorgangWirdErstelltAufVorgangErzeugt(final List<String> antragUuids) {
        LOG.atDebug().addArgument(drvMandant.getOrThrow())
                .addArgument(StringUtils.join(",", antragUuids)).log(
                        "Setze Anträge mit offener Vorgangserzeugung auf In Bearbeitung. Ktan [{}]: UUIDs [{}]");
        final int anzahlAktualisiert = antragRepository.setzeStatusVonVorgangWirdErstelltAufVorgangErzeugt(antragUuids);
        LOG.atDebug().addArgument(antragUuids).log("Persistiere Anträge Uuids [{}] in DB");

        LOG.atDebug().addArgument(anzahlAktualisiert).addArgument(drvMandant.getOrThrow())
                .addArgument(StringUtils.join(",", antragUuids))
                .log("Es wurden {} Anträge aktualisiert. Ktan [{}]: UUIDs [{}]");
    }

    /**
     * Liefert eine Liste von Antraegen zu bestimmten Vorgangskennung.
     * @param vorgangsKennungen Liste von Vorgangskennungen nach denen selektiert wird
     * @return List der gefundenen Antraege.
     */
    public List<Antrag> getAntraegeFuerVorgangsKennungen(final List<String> vorgangsKennungen) {
        LOG.atDebug().addArgument(drvMandant.getOrThrow())
                .addArgument(StringUtils.join(",", vorgangsKennungen))
                .log("Suche Anträge anhand Vorgangskennungen. Ktan [{}]: VorgangsKennungen [{}]");
        return antragRepository
                .getAntraegeFuerVorgangsKennungenMitStatusVorgangErstellt(vorgangsKennungen);
    }

    /**
     * Erstellt ein PDF-Archiv.
     *
     * @param antrag der Antrag
     * @return true im Erfolgsfall
     */
    @CacheInvalidateAll(cacheName = "pdf")
    public boolean createPdfArchiv(final Antrag antrag) {
        LOG.atDebug().addArgument(antrag.getUuid()).log("PDF fuer Archiv wird erzeugt: UUID [{}]");

        if (StringUtils.isEmpty(antrag.getXml())) {
            LOG.atDebug().addArgument(antrag.getUuid()).log(
                    "Antrag nicht Archivierungs-Relevant (kein XML vorhanden). Antrag uuid [{}]: ");
            return false;
        }

        final byte [] pdf = PDFUtil.createPdf(antrag);
        if (pdf.length > 0) {
            return archivePdf(antrag, pdf);
        }

        return false;
    }

    /**
     * Sucht einen Antrag mit der übergebenen UUID. Falls kein Antrag gefunden wird, wird eine KeinAntragInBearbeitungException geworfen.
     *
     * @param uuid die UUID des Antrags
     * @return den gefunden Antrag
     */
    public Antrag sucheAntragInBearbeitungMitUuid(final UUID uuid) {
        final Antrag antrag = getAntragByUuid(uuid);

        if (!List.of(STATISTIK_ERFASST,
                        PERSONENDATEN_AUFGABE_ERSTELLT, ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
                        DOPPELVERGABE_AUFGABE_ERSTELLT, DOPPELVERGABE_PRUEFUNG_OK, BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT, AUTOMATISCH,
                        STAMMDATEN_FEHLER_AUFGABE_ERSTELLT, KONTOINFORMATION_ABGEFRAGT, AUFGABE_ABGESCHLOSSEN,
                        STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT, STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT,
                        KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT, VORGANG_ERZEUGT, ENTWURF)
                .contains(antrag.getStatus())) {
            LOG.atWarn().addArgument(uuid).addArgument(antrag.getStatus())
                    .log("Keinen aktiven Antrag zur UUID [{}] gefunden, Status [{}]");
            throw new KeinAntragInBearbeitungException(uuid.toString());
        }
        return antrag;
    }

    /**
     * Verarbeitet einen Antrag nach dem Versand von Dokumenten, d.h. für Bewilligungen, Ablehnungen oder Sachverhaltsaufklärungen.
     * Dabei wird:
     * <ul>
     *     <li>der Antrgsstatus gesetzt</li>
     *     <li>der Verarbeitungsstatus gesetzt</li>
     *     <li>das Bescheiddatum eingetragen</li>
     *     <li>die Aenderung an rvDialog kommuniziert</li>
     *     <li>die Aufgabe in rvPuR geschlossen</li>
     * </ul>
     * Im Fehlerfall wird ein entsprechender Status in die Datenbank geschrieben.
     * @param uuid               die UUID eines AntragsWas
     * @param versandErgebnisDto das Ergebnis aus dem Versand von Dokumenten
     * @param erledigungsArt     die Erledigungsart für diesen Antrag
     * @return der aktualisierte Antrag
     */
    @Transactional
    @RequiresMandant
    public Antrag verarbeiteMitVersandergebnis(final UUID uuid,
            final VersandErgebnisDto versandErgebnisDto, final Art erledigungsArt) {
        sensitiveCreateLog(uuid);

        Antrag antrag = sucheAntragInBearbeitungMitUuid(uuid);
        antrag = antragStatusService.setAntragStatus(antrag, AntragStatus.BESCHEID_ABGESCHLOSSEN);
        verarbeitungsstatusService.saveVerarbeitungsstatus(uuid, versandErgebnisDto,
                erledigungsArt);

        if (Objects.requireNonNull(erledigungsArt) == Art.ABLEHNUNG) {
            rvfitLogger.sendeFachprotokollEreignis(
                    LogUtils.getFachereignis(
                            EreignisTyp.ZWISCHENEREIGNIS_USER,
                            Ereignistext.ANSPRUCHS_PRUEFUNG_DURCHGEFUEHRT,
                            EreignisFreitext.ANSPRUCHS_PRUEFUNG_ABLEHNEN_USER,
                            null, antrag, null, jwt, drvMandant
                    )
            );
        } else if (erledigungsArt == Art.BEWILLIGUNG) {
            if (PruefergebnisUtils.anspruchsvorausetzungFailed(antrag)) {
                rvfitLogger.sendeFachprotokollEreignis(
                        LogUtils.getFachereignis(
                                EreignisTyp.ZWISCHENEREIGNIS_USER,
                                Ereignistext.ANSPRUCHS_PRUEFUNG_DURCHGEFUEHRT,
                                EreignisFreitext.ANSPRUCHS_PRUEFUNG_ERFUELLT_USER,
                                null, antrag, null, jwt, drvMandant
                        )
                );
            } else if (PruefergebnisUtils.einrichtungspruefungFailed(antrag)) {
                rvfitLogger.sendeFachprotokollEreignis(
                        LogUtils.getFachereignis(
                                EreignisTyp.ZWISCHENEREIGNIS_USER,
                                Ereignistext.EINRICHTUNGS_PRUEFUNG_DURCHGEFUEHRT,
                                EreignisFreitext.EINRICHTUNGS_PRUEFUNG_ERFUELLT_USER,
                                null, antrag, null, jwt, drvMandant
                        )
                );
            }
        }

        antrag.setBescheiddatum(LocalDate.now());
        final Antrag updatedAntrag = antragRepository.merge(antrag);
        antragRepository.flush();

        return updatedAntrag;
    }

    /**
     * Protokolliert das Fachereignis nach Bescheiderstellung.
     *
     * @param antrag der Antrag
     */
    public void protokolliereFachereignisAntragBeschieden(final Antrag antrag) {
        final EreignisTyp ereignisTyp = (automatischeBewilligung(antrag) || automatischeAblehnung(antrag))
                ? EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL
                : EreignisTyp.NACHRICHTEN_AUSGANG_USER;

        final Ereignistext ereignisText = Ereignistext.ANTRAG_BESCHIEDEN;
        final EreignisFreitext ereignisFreiText = EreignisFreitext.ANTRAG_BESCHIEDEN;

        LOG.atInfo()
                .addArgument(ereignisTyp)
                .addArgument(ereignisText)
                .addArgument(ereignisFreiText)
                .addArgument(antrag.getUuid())
                .addArgument(antrag.getVorgangskennung())
                .addArgument(antrag.getVsnr())
                .log("Sende ans Ereignis ans Fachprotokoll. Typ [{}] Text [{}] Freitext [{}] VOG-ID: [{}], UUID [{}], VSNR [{}]");

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                ereignisTyp, ereignisText, ereignisFreiText, null, antrag, null, jwt, drvMandant)
        );
    }

    /**
     * Verarbeitet einen Antrag ohne Versand von Dokumenten, d.h. für Erledigung auf andere Art und Weise, Storno, oder Rücknahme.
     * Dabei wird:
     * <ul>
     *     <li>der Antrgsstatus gesetzt</li>
     *     <li>der Verarbeitungsstatus gesetzt</li>
     *     <li>das Bescheiddatum eingetragen</li>
     *     <li>die Aenderung an rvDialog kommuniziert</li>
     *     <li>die Aufgabe in rvPuR geschlossen</li>
     * </ul>
     * Im Fehlerfall wird ein entsprechender Status in die Datenbank geschrieben.
     *
     * @param uuid           die UUID eines Antrags
     * @param erledigungsArt die Erledigungsart für diesen Antrag
     * @return der aktualisierte Antrag
     */
    @Transactional
    public AntragDto verarbeiteErledigungOhneBescheid(final UUID uuid, final Art erledigungsArt) {
        sensitiveCreateLog(uuid);
        final Antrag antrag = sucheAntragInBearbeitungMitUuid(uuid);

        final boolean vorRegelpruefung;
        if (antrag.getStatus() == DOPPELVERGABE_AUFGABE_ERSTELLT && erledigungsArt == Art.STORNO) {
            antrag.setDoppelvergabe(DoppelvergabeStatus.STORNIEREN);
            vorRegelpruefung = true;
        } else {
            vorRegelpruefung = false;
        }

        return erledigungOhneBescheid(antrag, erledigungsArt, vorRegelpruefung);
    }

    /**
     * Verarbeitet einen Antrag ohne Versand von Dokumenten bei der Erfassung, d.h. für Erledigung auf andere Art und Weise oder Rücknahme.
     * Dabei wird:
     * <ul>
     *     <li>der Antrgsstatus gesetzt</li>
     *     <li>der Verarbeitungsstatus gesetzt</li>
     *     <li>das Bescheiddatum eingetragen</li>
     *     <li>die Aenderung an rvDialog kommuniziert</li>
     *     <li>die Aufgabe in rvPuR geschlossen</li>
     * </ul>
     * Im Fehlerfall wird ein entsprechender Status in die Datenbank geschrieben.
     *
     * @param uuid           die UUID eines Antrags
     * @param erledigungsArt die Erledigungsart für diesen Antrag
     * @return der aktualisierte Antrag
     */
    @Transactional
    public AntragDto verarbeiteErledigungOhneBescheidErfassung(final UUID uuid, final Art erledigungsArt) {
        sensitiveCreateLog(uuid);
        final Antrag antrag = getAntragByUuid(uuid);
        return erledigungOhneBescheid(antrag, erledigungsArt, true);
    }

    private AntragDto erledigungOhneBescheid(final Antrag antrag, final Art erledigungsArt,
            final boolean erledigungVorRegelPruefung) {
        if (antrag.getStatus() == PERSONENDATEN_AUFGABE_ERSTELLT) {
            antrag.setStatus(RVPUR_AUFGABE_GESCHLOSSEN);
        }
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);

        EreignisFreitext ereignisFreitext = EreignisFreitext.BEARBEITUNG_ABGESCHLOSSEN;
        if (antrag.getAntragsart() == AntragsArt.PAPIERANTRAG) {
            ereignisFreitext = EreignisFreitext.BEARBEITUNG_ABGESCHLOSSEN_PAPIER;
        }
        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.ENDEREIGNIS_USER,
                Ereignistext.BEARBEITUNG_ABGESCHLOSSEN, ereignisFreitext,
                erledigungsArt.name(), antrag, null, jwt, drvMandant));

        verarbeitungsstatusService.saveVerarbeitungsstatusOhneVersand(antrag.getUuid(), erledigungsArt);
        antrag.setBescheiddatum(LocalDate.now());
        aufgabeService.purAufgabeSchliessen(antrag);

        statistikService.createStatistik(antrag, erledigungVorRegelPruefung);
        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                Ereignistext.STATISTIK_GEBILDET, EreignisFreitext.STATISTIK_GEBILDET_ERLEDIGUNG,
                null, antrag, null, jwt, drvMandant));



        return antragMapper.toDto(antrag);
    }

    /**
     * Verarbeitet einen Antrags ohne Versand von Dokumenten.
     * Dabei wird:
     * <ul>
     *     <li>der Antrgsstatus gesetzt</li>
     *     <li>der Verarbeitungsstatus gesetzt</li>
     *     <li>das Bescheiddatum eingetragen</li>
     *     <li>die Aufgabe in rvPuR geschlossen</li>
     * </ul>
     *
     * @param uuid           die UUID eines Antrags
     * @param erledigungsArt die Erledigungsart für diesen Antrag
     * @return der aktualiserte Antrag
     */
    @Transactional
    public AntragDto verarbeiteWeiterleitungOhneBescheid(final UUID uuid,
            final Art erledigungsArt) {
        sensitiveCreateLog(uuid);
        final Antrag antrag = sucheAntragInBearbeitungMitUuid(uuid);
        antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        verarbeitungsstatusService.saveVerarbeitungsstatusOhneVersand(uuid, erledigungsArt);
        antrag.setBescheiddatum(LocalDate.now());

        aufgabeService.purAufgabeSchliessen(antrag);
        return antragMapper.toDto(antrag);
    }

    /**
     * Verarbeitet einen Antrag zur Weiterverarbeitung in rvDialog. Dabei wird:
     * <ul>
     *     <li>der Antrgsstatus gesetzt</li>
     *     <li>der Verarbeitungsstatus gesetzt</li>
     *     <li>das Antragsdatum eingetragen</li>
     *     <li>das Bescheiddatum eingetragen</li>
     *     <li>die Aufgabe in rvPuR geschlossen</li>
     * </ul>
     * Im Fehlerfall wird ein entsprechender Status in die Datenbank geschrieben.
     *
     * @param uuid die UUID eines Antrags
     * @return der aktualiserte Antrag
     */
    @Transactional
    public AntragDto verarbeiteWeiterbearbeitungInRvDialog(final UUID uuid) {
        final Antrag antrag = getAntragByUuid(uuid);
        sensitiveCreateLog(uuid);
        switch (antrag.getStatus()) {
            case PERSONENDATEN_AUFGABE_ERSTELLT -> antrag.setStatus(RVPUR_AUFGABE_GESCHLOSSEN);
            case ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT -> antrag.setStatus(AUFGABE_SCHLIESSEN_OHNE_STATISTIK);
            default -> {
                /* Der Status wird nicht geaendert. */
            }
        }

        aufgabeService.purAufgabeSchliessen(antrag);
        verarbeitungsstatusService.saveVerarbeitungsstatusOhneVersand(uuid, Art.WEITERBEARBEITUNG_IN_RVDIALOG);
        antrag.setBescheiddatum(LocalDate.now());
        antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        antragRepository.persistAndFlush(antrag);

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                EreignisTyp.ENDEREIGNIS_USER,
                Ereignistext.BEARBEITUNG_ABGESCHLOSSEN,
                EreignisFreitext.BEARBEITUNG_ABGESCHLOSSEN_PAPIER,
                Art.WEITERBEARBEITUNG_IN_RVDIALOG.name(),
                antrag,
                null,
                jwt,
                drvMandant
        ));

        return antragMapper.toDto(antrag);
    }

    /**
     * Methode zum Schreiben einer Lognachricht zur Aktualisieung des Verarbeitungsstatus.
     *
     * @param uuid die UUID eines Antrags
     */
    public void sensitiveCreateLog(final UUID uuid) {
        LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid).log(
                "Aktualisiert den Verarbeitungsstatus anhand der Antrags UUID. KTAN [{}], Antrag UUID [{}]");
    }


    /**
     * Verarbeitet einen Antrag nach der Prüfung auf Doppelvergabe in RV Fit Modern weiter.
     *
     * @param uuid die UUID zur identifizierung des Antrags.
     */
    @Transactional
    public void verarbeiteDoppelvergabe(final UUID uuid) {
        Antrag antrag = getAntragByUuid(uuid);

        if (antrag.getStatus() != DOPPELVERGABE_AUFGABE_ERSTELLT) {
            LOG.atWarn().addArgument(uuid).addArgument(antrag.getStatus())
                    .log("Keinen Antrag mit Doppelvergabe zur UUID [{}] gefunden, Status [{}]");
            throw new KeinAntragInBearbeitungException(uuid.toString());
        }

        antrag.setDoppelvergabe(DoppelvergabeStatus.WEITERVERARBEITEN);
        antrag.setStatus(AntragStatus.DOPPELVERGABE_AUFGABE_SCHLIESSEN);

        antrag = antragRepository.merge(antrag);
        antragRepository.flush();

        producerTemplate.withBody(antrag).to(RouteNames.DIRECT_CONTINUE_DOPPELVERGABE).send();

        rvfitLogger.sendeFachprotokollEreignis(
                LogUtils.getFachereignis(
                        EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                        Ereignistext.DOPPELVERGABE_PRUEFUNG_DURCHGEFUEHRT,
                        EreignisFreitext.DOPPELVERGABE_PRUEFUNG_ERFUELLT_USER,
                        null,
                        antrag,
                        null,
                        jwt,
                        drvMandant));
    }

    /**
     * Ermittelt die Bestandsfehler zu einem Antrag.
     * @param antrag der Antrag
     * @return Dto mit den ermittelten Fehlern
     */
    @RequiresMandant
    public BestandsfehlerDto getBestandsfehlerDto(final Antrag antrag) {
        List<Bestandsfehler> bestandsfehlerList = bestandsfehlerRepository.findByAntragUuidNotDeleted(antrag.getUuid());
        return erstelleBestandsfehlerDto(antrag, bestandsfehlerList);
    }

    /**
     * Erstellt ein BestandsfehlerDTO aus der Liste der Bestandsfehler.
     * @param antrag betroffener Antrag
     * @param bestandsfehlerListe Liste der Bestandsfehler
     * @return erstelltes BestandsfehlerDto
     */
    BestandsfehlerDto erstelleBestandsfehlerDto(final Antrag antrag, final List<Bestandsfehler> bestandsfehlerListe) {
        final BestandsfehlerDto bestandsfehlerDto = new BestandsfehlerDto();

        List<String> rvSystemFehlerCodes = null;
        for (Bestandsfehler bestandsfehler : bestandsfehlerListe) {
            if (istRvSystemFehler(bestandsfehler)) {
                if (rvSystemFehlerCodes == null) {
                    rvSystemFehlerCodes = new ArrayList<>();
                }
                rvSystemFehlerCodes.add(String.format("FE%s", bestandsfehler.getBestandsfehlercode()));
            } else {
                final UnerwartererFehlerDto unerwartererFehler = new UnerwartererFehlerDto();
                unerwartererFehler.setFehlercode(bestandsfehler.getBestandsfehlercode());
                bestandsfehlerDto.setUnerwartererFehler(unerwartererFehler);
            }
        }
        bestandsfehlerDto.setRvSystemFehlerCodes(rvSystemFehlerCodes);
        bestandsfehlerDto.setVsnr(antrag.getVsnr());
        bestandsfehlerDto.setVorname(antrag.getVorname());
        bestandsfehlerDto.setName(antrag.getNachname());
        return bestandsfehlerDto;
    }

    private static boolean istRvSystemFehler(final Bestandsfehler bestandsfehler) {
        return NumberUtils.isDigits(bestandsfehler.getBestandsfehlercode());
    }

    /**
     * Erstellt eine Map mit spezifischen Properties für die Camel Route, die beim erneuten Versuch nach einem Bestandsfehler hinterlegt
     * werden müssen.
     *
     * @param antrag der Antrag
     * @return eine Map mit Properties, die für die erneute Vearbeitung nach einem Bestandsfehler auf dem AntragStatus basierend gesetzt
     * werden müssen
     */
    public Map<String, Object> getErneutVearbeitenStatusSpezifischeProperties(final Antrag antrag) {
        final Map<String, Object> map = new HashMap<>();
        // Für StatistikAbschlus muss die Vearbeitungsart übergeben werden,
        // damit der richtige Wert an den Dialog gesendet wird
        if (antrag.getStatus() == STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT) {
            verarbeitungsstatusService.getVerarbeitungsstatus(antrag.getUuid()).ifPresent(verarbeitungsstatus -> {
                Art art = verarbeitungsstatus.getArt();
                map.put(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, art);
                map.put(RVFitCamelHeader.PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG, erledigeVorRegelpruefung(antrag));
            });
        }
        return map;
    }

    private static boolean erledigeVorRegelpruefung(final Antrag antrag) {
        return antrag.getAntragPruefergebnisse() == null || antrag.getAntragPruefergebnisse().isEmpty();
    }

    /**
     * Es wird ein neuer Versuch gestartet um die Bestandsdaten zu pruefen.
     * @param uuid des Antrags.
     */
    public void starteErneutenVersuch(final UUID uuid) {
        checkKontoGesperrt(uuid, true);

        final Antrag antrag = sucheAntragInBearbeitungMitUuid(uuid);
        azkService.pruefeZugriff(uuid);

        final String route = getRouteFuerErneutenVersuch(antrag);
        final Exchange exchange = producerTemplate
                .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString())
                .withExchangeProperties(getErneutVearbeitenStatusSpezifischeProperties(antrag))
                .withBody(antrag)
                .to(route)
                .send();

        Exception exception = Optional.of(exchange)
                .map(ex -> ex.getProperty(Exchange.EXCEPTION_CAUGHT))
                .map(Exception.class::cast).orElse(null);
        if (exception instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }

        verarbeiteAsynchronWeiter(exchange);

        try {
            if (getBestandsfehlerException(exchange) instanceof BestandsfehlerException bestandsfehlerException) {
                if (StatistikUtil.istKontoSchutzbeduerftig(bestandsfehlerException)) {
                    throw new KontoGesperrtException(antrag.getVsnr(), antrag.getKtan());
                }
                throw bestandsfehlerException;
            }
        } catch (final KontoGesperrtException kontoGesperrtException) {
            sendeWeiterbearbeitungInDialog(uuid);
            throw kontoGesperrtException;
        }
    }

    private void verarbeiteAsynchronWeiter(Exchange exchange) {
        final Antrag updatedAntrag = exchange.getMessage().getBody(Antrag.class);
        producerTemplate
                .withHeader(RVFitCamelHeader.ANTRAG_UUID, updatedAntrag.getUuid().toString())
                .withHeaders(getBestandsfehlerHeader(exchange))
                .withBody(updatedAntrag)
                .to(EingangEAntragRoutes.DIRECT_VOLLVERARBEITUNG).asyncSend();
    }

    private static String getRouteFuerErneutenVersuch(Antrag antrag) {
        return switch (antrag.getStatus()) {
            case STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT -> RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB;
            case STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT -> RouteNames.DIRECT_ERFASSE_STATISTIK;
            case STAMMDATEN_FEHLER_AUFGABE_ERSTELLT -> RouteNames.DIRECT_GET_METADATA;
            case KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT -> RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN;
            default -> throw new NotImplementedException(
                    String.format("Keine Route für Status %s zur erneuten Verarbeitung implementiert.",
                            antrag.getStatus()));
        };
    }

    /**
     * Prüft, ob Schutzbedarf vorliegt und wirft ggf. eine passende Exception.
     *
     * @param antragUuid               die UUID des Antrags
     * @param wirfBestandsfehlerWeiter <code>true</code>, falls ein ggf. aufgetretener Bestandsfehler weitergeworfen
     *                                 werden soll und <code>false</code>, falls der Fehler nur abgefangen werden soll
     */
    public void checkKontoGesperrt(final UUID antragUuid, final boolean wirfBestandsfehlerWeiter) {
        try {
            final Antrag antrag = getAntragByUuid(antragUuid);
            // Prueft, ob bei Personendaten-Schnittstelle ein EA-KTO-025 oder -026 vorliegt
            final AntragDto antragDto = mapToAntragDto(antrag);
            // Prueft, ob ein Bestandsfehler mit Schutzbedarfs-AF-Code vorliegt
            if (StatistikUtil.istKontoSchutzbeduerftig(getBestandsfehlerDto(antrag))) {
                throw new KontoGesperrtException(antragDto.getVsnr(), antragDto.getKtan());
            }
        } catch (final KontoGesperrtException kontoGesperrtException) {
            sendeWeiterbearbeitungInDialog(antragUuid);
            throw kontoGesperrtException;
        } catch (final BestandsfehlerException bestandsFehlerException) {
            if (wirfBestandsfehlerWeiter) {
                throw bestandsFehlerException;
            }
            LOG.atDebug().addArgument(antragUuid).log("Bestandsfehlerexception gefangen. UUID [{}]");
        }
    }

    /**
     * Erledigt den Antrag zur übergebenen UUID zur Weiterbearbeitung in RV Dialog.
     *
     * @param uuid die UUID des Antrags
     * @return das Exchange-Objekt nach Beendigung der Weiterbearbeitungs-Route
     */
    public Exchange sendeWeiterbearbeitungInDialog(final UUID uuid) {
        Exchange send = producerTemplate
                .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString())
                .withExchangeProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, Art.WEITERBEARBEITUNG_IN_RVDIALOG)
                .to(RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID_WEITERBEARBEITUNG_IN_RV_DIALOG).send();

        if (send.isFailed() && send.getException() instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }
        return send;
    }

    /**
     * Sucht in einem Exchange-Objekt nach Bestandsfehler-Headern und gibt diese als Map zurück.
     *
     * @param exchange das Exchange-Objekt
     * @return eine Map mit Bestandsfehlern aus dem Exchange
     */
    private static Map<String, Object> getBestandsfehlerHeader(final Exchange exchange) {
        return exchange.getMessage()
                .getHeaders()
                .entrySet()
                .stream()
                .filter(e -> RVFitCamelHeader.BESTANDSFEHLER_HEADER.contains(e.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    /**
     * Extrahiert BestandsfehlerExceptions aus dem übergebenen Exchange, falls vorhanden.
     * @param exchange das Exchange-Objekt
     * @return eine BestandsfehlerExpception, falls vorhanden, ansonsten null
     */
    private static BestandsfehlerException getBestandsfehlerException(final Exchange exchange) {
        return exchange.getMessage()
                .getHeaders()
                .entrySet()
                .stream()
                .filter(e -> RVFitCamelHeader.BESTANDSFEHLER_HEADER.contains(e.getKey()))
                .filter(e -> e.getValue() instanceof BestandsfehlerException)
                .map(Map.Entry::getValue)
                .map(BestandsfehlerException.class::cast)
                .findFirst()
                .orElse(null);
    }
}
