package de.deutscherv.rvsm.fa.fit.kontoinformation;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.FehlerEintrag;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationRequest;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationException;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.WebApplicationException;
import java.time.LocalDate;
import java.util.Objects;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 * KontoinformationService bietet Service Methoden für das Abrufen von Kontoinformationsdaten an.
 *
 * @author V215169
 */
@ApplicationScoped
@Slf4j
public class KontoinformationService {

    // kein AF oder nicht exakt 6 Ziffern
    private static final Pattern KEIN_AF_FEHLER = Pattern.compile("^(?!.*AF)(?!.*\\b\\d{6}\\b).+$");
    private final KontoinformationClient kontoinformationClient;
    private final JsonWebToken jwt;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final AntragMapper antragMapper;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;

    /**
     * Konstruktor.
     *
     * @param kontoinformationClient   Kontoinformation-Client
     * @param jwt                      JSON-Web-Client
     * @param rVFitJsonSchemaValidator rvFit-JSON-Schemavalidator
     * @param antragMapper             Antrag-Mapper
     * @param drvMandant               DRV-Mandant
     * @param rvfitLogger              rvFit-Logger
     */
    @Inject
    public KontoinformationService(@RestClient final KontoinformationClient kontoinformationClient,
            final JsonWebToken jwt,
            final RVFitJsonSchemaValidator rVFitJsonSchemaValidator,
            final AntragMapper antragMapper,
            final DrvMandant drvMandant, RvfitLogger rvfitLogger) {
        this.kontoinformationClient = kontoinformationClient;
        this.jwt = jwt;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.antragMapper = antragMapper;
        this.drvMandant = drvMandant;
        this.rvfitLogger = rvfitLogger;
    }

    /**
     * Kontoinformationen werde gempappt von der Response zu Kontoinforamtion.
     * @param response Response
     * @param antrag betroffener Antrag
     * @return Kontoinformationen
     */
    private Kontoinformation mapKontoinformation(final KontoinformationResponse response, final Antrag antrag) {
        boolean keinUnerwarteterFehler = StringUtils.isBlank(response.getUnerwarteterFehler());

        if (keinUnerwarteterFehler) {
            return antragMapper.toKontoinformationEntity(response);
        } else {
            LOG.atWarn().addArgument(response.getRvSystemFehler()).addArgument(response.getUnerwarteterFehler()).log(
                    "Fehler in RVDialog Kontoinformation Wartezeiten Response:" +
                            " RVsystemFehler:[{}], UnerwarteterFehler: [{}]");
            FehlerEintragDto fehlerEintragDto = new FehlerEintragDto().statuscode(response.getUnerwarteterFehler());
            throw new KontoinformationBestandsFehlerException("Es sind Bestandsfehler aufgetreten",
                    antrag, fehlerEintragDto);
        }
    }

    /**
     * Kontoinformationen werden ermittelt.
     *
     * @param kontoinformationRequest Anfragedaten
     * @return ermittelte Kontoinformationen
     */
    public KontoinformationResponse rufeKontoinformationAb(
            final KontoinformationRequest kontoinformationRequest) {
        final String ktan = JwtUtils.GET_KTAN.apply(jwt, drvMandant);
        final KontoinformationResponse kontoinformationResponse =
                kontoinformationClient.getKontoinformationen(ktan, kontoinformationRequest);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.KONTOINFORMATION,
                kontoinformationResponse)) {
            throw new IllegalArgumentException(
                    "Keine valide Kontoinformation angegeben: " + kontoinformationResponse);
        }

        String vsnr = kontoinformationResponse.getVsnr();
        EreignisTyp ereignisTyp = EreignisTyp.NACHRICHTEN_EINGANG_MASCHINELL;
        if (JwtUtils.isJwtVonUser(jwt)) {
            ereignisTyp = EreignisTyp.NACHRICHTEN_EINGANG_USER;
        }
        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignisOhneAntrag(
                ereignisTyp,
                Ereignistext.KONTOINFORMATION_EINGEGANGEN,
                EreignisFreitext.KONTOINFORMATIONEN_EINGEGANGEN,
                vsnr,
                jwt,
                drvMandant
        ));

        return kontoinformationResponse;
    }

    /**
     * Ruft das Bestandgateway auf und gibt eine KontoinformationEntity zurück.
     *
     * @param antrag         Der Antrag
     * @param antragsDatum Antragsdatum
     * @return Kontoinformationen
     */
    public Kontoinformation getKontoinformationEntity(final Antrag antrag,
            final LocalDate antragsDatum) {
        final String vsnr = antrag.getVsnr();
        final KontoinformationRequest req = KontoinformationRequest
                .builder()
                .vsnr(vsnr)
                .aktuellesDatum(antragsDatum).build();
        try {
            final KontoinformationResponse response = rufeKontoinformationAb(req);
            return mapKontoinformation(response, antrag);
        } catch (final WebApplicationException webApplicationException) {
            final String ktan = drvMandant.getOrElse("");
            switch (webApplicationException.getResponse().getStatus()) {
                case 404 -> kontoinformationNichtGefunden(ktan, vsnr);
                case 500 -> bestandsfehlerAufgetreten(antrag, webApplicationException);
                default -> allgemeinerKontoinformationFehler(ktan, vsnr, webApplicationException);
            }
        } catch (final Exception e) {
            if (!(e instanceof KontoinformationBestandsFehlerException)) {
                allgemeinerKontoinformationFehler(drvMandant.getOrElse(""), vsnr, e);
            }
            throw e;
        }
        return null;
    }

    /**
     * Bearbeitung wenn ein Bestandsfehler aufgetreten ist.
     *
     * @param antrag der Antrag
     * @param webApplicationException aufgetretene Exception
     */
    public void bestandsfehlerAufgetreten(final Antrag antrag, final WebApplicationException webApplicationException) {
        final String ktan = antrag.getKtan();
        final String vsnr = antrag.getVsnr();
        if (webApplicationException.getResponse().hasEntity()) {
            KontoinformationResponse response = webApplicationException.getResponse().readEntity(
                    KontoinformationResponse.class);
            final String statuscode = response.getRvSystemFehler().stream()
                    .map(FehlerEintrag::getStatuscode)
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElse("");

            final FehlerEintragDto fehlerEintragDto = new FehlerEintragDto().statuscode(statuscode);

            LOG.atWarn().addArgument(ktan).addArgument(vsnr).addArgument(statuscode)
                    .log("Ein Bestandsfehler ist aufgetreten KTAN [{}], VSNR [{}], STATUSCODE [{}]");

            // nicht-AF-Fehler
            if (KEIN_AF_FEHLER.matcher(statuscode).matches()) {
                throw new KontoinformationException("Kontoinformationen konnten nicht eingeholt werden");
            }

            throw new KontoinformationBestandsFehlerException("Es sind Bestandsfehler aufgetreten",
                    antrag, fehlerEintragDto);
        }

        allgemeinerKontoinformationFehler(ktan, vsnr, webApplicationException);
    }

    /**
     * Wirft eine NotFoundException, wenn Kontoinformationen nicht gefunden wurden.
     *
     * @param ktan KTAN des Traegers
     * @param vsnr Versicherungsnr.
     */
    private void kontoinformationNichtGefunden(final String ktan, final String vsnr) {
        LOG.atWarn().addArgument(ktan).addArgument(vsnr)
                .log("Stammdaten wurde nicht gefunden KTAN [{}], VSNR [{}]");
        throw new NotFoundException("Kontoinformationen konnten nicht gefunden werden.");
    }

    /**
     * Bearbeitung wenn ein sonstiger Fehler aufgetreten ist.
     *
     * @param ktan                    KTAN des Traegers
     * @param vsnr                    Versicherungsnr.
     * @param webApplicationException aufgetretene Exception
     */
    private void allgemeinerKontoinformationFehler(final String ktan, final String vsnr,
            final WebApplicationException webApplicationException) {
        LOG.atWarn().addArgument(webApplicationException.getResponse().getStatus())
                .addArgument(ktan)
                .addArgument(vsnr).log(
                        "Kontoinformationen konnten nicht ermittelt werden. StatusCode [{}], KTAN [{}], VSNR [{}]");
        throw new KontoinformationException("Kontoinformationen konnten nicht eingeholt werden", webApplicationException);
    }

    /**
     * Bearbeitung wenn ein sonstiger Fehler aufgetreten ist.
     *
     * @param ktan KTAN des Traegers
     * @param vsnr Versicherungsnr.
     * @param e Exception
     */
    private void allgemeinerKontoinformationFehler(final String ktan, final String vsnr, final Exception e) {
        LOG.atWarn()
                .addArgument(ktan)
                .addArgument(vsnr).log(
                        "Kontoinformationen konnten nicht ermittelt werden. KTAN [{}], VSNR [{}]");
        throw new KontoinformationException("Kontoinformationen konnten nicht eingeholt werden", e);
    }
}
