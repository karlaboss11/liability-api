-- Script zur Anlage der initialen Daten bank für RVFit und des admin users

-- ACHTUNG: Passwort ändern vor der Ausführung

create database rvfit;

create user rvfitadmin with password 'rvfitadmin';

GRANT all privileges on DATABASE rvfit to rvfitadmin;

ALTER DATABASE rvfit OWNER TO rvfitadmin;

GRANT ALL ON SCHEMA public TO rvfitadmin;

