package de.deutscherv.rvsm.fa.fit.papierantraege;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.StammdatenMockTransformer;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.VerarbeitungsService;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.exceptions.PapierantragValidierungException;
import de.deutscherv.rvsm.fa.fit.integrationtests.regression.template.EAntragRegressionsTestTemplate;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlercodeDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto.PersonentypEnum;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenApiImpl;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.StammdatenMapper;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.KontoTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragCreator;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import io.quarkus.artemis.test.ArtemisTestResource;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.spi.RouteController;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.util.JSONTestUtils.jsonToString;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test PapierAntrageApiImpl.
 */
@Slf4j
@QuarkusTest
@QuarkusTestResource(ArtemisTestResource.class)
class PapierAntraegeApiImplTest {

    private static WireMockServer wireMockServer;
    private static final String AUFGABEN_ID = "AUID0123456789";

    private static int iVorgangsnummer = 0;

    private PapierantragCreator papierantragCreator;
    @Inject
    private FluentProducerTemplate producerTemplate;
    @Inject
    private AntragMapper antragMapper;
    @Inject
    private StammdatenMapper stammdatenMapper;
    @Inject
    private PapierAntraegeApiImpl papierAntraegeApi;
    @Inject
    private AntragRepository antragRepository;

    @Inject
    private EntityManager entityManager;

    @Inject
    private StammdatenApiImpl stammdatenApi;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private CamelContext camelContext;

    private CountDownLatch latch;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void setUpBeforeClass() {
        Mockito.reset();
        wireMockServer = new WireMockServer(WireMockStub.PORT);
        wireMockServer.start();
        configureFor("localhost", wireMockServer.port());

        createStubMappings();
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDown() {
        wireMockServer.stop();
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setup() {
        latch = new CountDownLatch(1);
        final RouteController routeController = camelContext.getRouteController();

        final Set<String> countdownRoutes = Set.of(
            DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS,
            DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS,
            DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS
        );
        for (final String route : countdownRoutes) {
            routeController.stopRoute(route);
            AdviceWith.adviceWith(route, camelContext,
                new AdviceWithRouteBuilder() {
                    @Override
                    public void configure() {
                        weaveAddLast().process(exchange -> latch.countDown());
                    }
                });
            routeController.startRoute(route);
        }
    }

    private static String createKontoJson() {
        // Stub getStammdatenByVsnr Methode um Testdaten zurückzugeben
        final KontoDto konto = new KontoDto();
        konto.setKtan("70");
        konto.setKontoId(UUID.fromString("3c684ca0-c002-49d7-aab0-cb3c411be0de"));
        konto.setVersicherungsnummer("23270152B506");

        final PersonDto person = new PersonDto();
        person.setPersonentyp(PersonentypEnum.BETEILIGTER);
        person.setName("Pan");
        person.setVorname("Peter");
        person.setGeschlecht(PersonDto.GeschlechtEnum.MAENNLICH);
        person.setGeburtsdatum("2000-08-08");

        final PersonAnschriftDto anschrift = new PersonAnschriftDto();
        anschrift.setStrasseHausnummer("Martin-Luther-Str. 2-4");
        anschrift.setPostleitzahl("66121");
        anschrift.setWohnort("Saarbrücken");

        person.setAnschrift(anschrift);
        konto.setPersonen(List.of(person));
        final Jsonb jsonb = JsonbBuilder.create();

        return jsonb.toJson(konto);
    }

    /**
     * TEST - Erstellt einen Papierantrag als ENTWURF (mit übergebenener Aufgaben-&Vorgangsid) lädt diesen im Anschluss wieder und
     * verarbeitet ihn.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testCreatePapierantragEntwurfUndAbschliessenMitVogidAuID() {
        drvMandant.setInScope("17");

        PapierantragDto papierantragDto = erstellePapierantrag("13160774D464");
        final String vorgangsId = papierantragDto.getVorgangsId();
        final String aufgabenId = papierantragDto.getAufgabenId();

        // CreatePapierantragEntwurf speichern
        final Response response = papierAntraegeApi.createPapierantragEntwurf(papierantragDto);
        assertEquals(201, response.getStatus());

        // Aufgabe aus Auftrag auslesen und Werte vergleichen
        final Antrag antrag = entityManager.createQuery(
                "select a from Antrag a where vorgangskennung = :void and vsnr = :vsnr and status = :status",
                Antrag.class).setParameter("void", vorgangsId)
            .setParameter("status", AntragStatus.ENTWURF)
            .setParameter("vsnr", papierantragDto.getVersicherter().getVsnr()).getSingleResult();

        final Aufgabe aufgabe = antrag.getAufgaben().stream()
            .filter(a -> a.getVomAufgabenId().equals(aufgabenId))
            .filter(a -> a.getAufgabenArt().equals(AufgabenArt.ANTRAGSERFASSUNG)).findFirst()
            .orElseThrow();

        assertEquals(AufgabenArt.ANTRAGSERFASSUNG, aufgabe.getAufgabenArt());
        assertEquals(AUFGABEN_ID, aufgabe.getVomAufgabenId());
        assertNotNull(aufgabe.getDatumErstellung());
        assertNull(aufgabe.getDatumErledigt()); // Muss leer sein, da Antrag in Entwurf noch nicht abgeschlossen

        drvMandant.setInScope("17");
        // Erstellten Entwurf Laden
        final Response papierantragEntwurfByVsnr =
            papierAntraegeApi.getPapierantragEntwurfByVsnr(papierantragDto.getAntrag().getVsnr());
        papierantragDto =
            papierantragEntwurfByVsnr.readEntity(PapierantragDto.class);

        final StammdatenDto stammdatenDto =
            stammdatenApi.getStammdatenByVsnr(papierantragDto.getAntrag().getVsnr())
                .readEntity(StammdatenDto.class);
        papierantragDto.setVersicherter(stammdatenDto);
        papierantragDto.setVorgangsId(vorgangsId);
        papierantragDto.setAufgabenId(aufgabenId);

        // Papierantrag erstellen
        final Response responseEntwurf = papierAntraegeApi.createPapierantrag(papierantragDto);
        assertEquals(201, responseEntwurf.getStatus());

        final Aufgabe aufgabeEntwurf = antrag.getAufgaben().stream()
            .filter(a -> a.getVomAufgabenId().equals(aufgabenId))
            .filter(a -> a.getAufgabenArt().equals(AufgabenArt.ANTRAGSERFASSUNG)).findFirst()
            .orElseThrow();

        assertNotNull(aufgabeEntwurf.getDatumErstellung());

        cleanDatabaseAntragWithUUID(response.readEntity(PapierantragDto.class).getAntrag().getUuid());
    }

    /**
     * TEST - Erstellt einen Papierantrag.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testCreatePapierantrag() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("03080800B018");

        final StatistikService statistikServiceMock = Mockito.mock(StatistikService.class);
        Mockito.when(statistikServiceMock.createStatistikAntragserfassung(any())).thenReturn(true);
        QuarkusMock.installMockForType(statistikServiceMock, StatistikService.class);

        final VerarbeitungsService verarbeitungsServiceMock =
            Mockito.mock(VerarbeitungsService.class);
        QuarkusMock.installMockForType(verarbeitungsServiceMock, VerarbeitungsService.class);

        final PapierantragDto papierantragDto = given().contentType(ContentType.JSON)
            .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
            .statusCode(201).extract().as(PapierantragDto.class);

        cleanDatabaseAntragWithVSNR(papierantragDto.getAntrag().getVsnr());
        Mockito.reset(statistikServiceMock);
        Mockito.reset(verarbeitungsServiceMock);
    }

    /**
     * TEST - Papierantrag mit Antrags UUID NULL.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    void testCreatePapierantragWithUuidNull() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("03080800B018");

        final StatistikService statistikServiceMock = Mockito.mock(StatistikService.class);
        Mockito.when(statistikServiceMock.createStatistikAntragserfassung(any())).thenReturn(true);
        QuarkusMock.installMockForType(statistikServiceMock, StatistikService.class);

        final VerarbeitungsService verarbeitungsServiceMock =
            Mockito.mock(VerarbeitungsService.class);
        QuarkusMock.installMockForType(verarbeitungsServiceMock, VerarbeitungsService.class);

        papierantragsDto.getAntrag().setUuid(null);
        final Response resp = papierAntraegeApi.createPapierantrag(papierantragsDto);
        assertEquals(Response.Status.CREATED.getStatusCode(), resp.getStatus());

        cleanDatabaseAntragWithVSNR(resp.readEntity(PapierantragDto.class).getAntrag().getVsnr());
        Mockito.reset(statistikServiceMock);
        Mockito.reset(verarbeitungsServiceMock);
    }

    /**
     * Test create papierantrag error weil VNSR leerer/ungültig.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    void testCreatePapierantragErrorVSNRleer() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("");

        papierantragsDto.getVersicherter().setVsnr("");
        assertThrows(PapierantragValidierungException.class, () ->
            papierAntraegeApi.createPapierantrag(papierantragsDto));
    }

    /**
     * Test create Papierantrag Bad Request weil VOGID Null ist.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennVogidIstNull() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    null, AUFGABEN_ID));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("vogid");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_LEER);
        }
    }

    /**
     * Test create Papierantrag Bad Request weil AufgID  Null ist.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennAufgidIstNull() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), null));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("aufgid");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_LEER);
        }
    }

    /**
     * Test createPapierantragEntwurf.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testCreatePapierantragEntwurf() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("");

        Response resp = papierAntraegeApi.createPapierantragEntwurf(papierantragsDto);
        drvMandant.setInScope("17");
        antragRepository.flush();
        assertEquals(201, resp.getStatus());

        papierantragsDto.getAntrag()
            .setUuid(((PapierantragDto) resp.getEntity()).getAntrag().getUuid());
        try (AutoCloseable ignore = drvMandant.setInScope("17")) {
            resp = papierAntraegeApi.createPapierantragEntwurf(papierantragsDto);
            drvMandant.setInScope("17");
            antragRepository.flush();
            assertEquals(201, resp.getStatus());
            cleanDatabaseAntragWithVSNR(resp.readEntity(PapierantragDto.class).getAntrag().getUuid());
        }
    }

    /**
     * Test getPapierantragEntwurfByVsnr.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testgetPapierantragEntwurfByVsnr() {
        drvMandant.setInScope("70");

        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            deleteFromAntragForTestPerson(TestPerson.MICKEY_MOUSE.VSNR);
            createAntrag(TestPerson.MICKEY_MOUSE);
        }
        given().pathParam("vsnr", TestPerson.MICKEY_MOUSE.VSNR)
            .get("/papierantraege/{vsnr}")
            .then()
            .statusCode(404);

        WireMockStub.stubForStammdaten(TestPerson.MARGE_SIMPSON);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            deleteFromAntragForTestPerson(TestPerson.MARGE_SIMPSON.VSNR);
            createEAntrag(TestPerson.MARGE_SIMPSON);
        }
        // Antrag vorhanden ABER eAntrag kein Papierantrag -> (404)
        given().pathParam("vsnr", TestPerson.MARGE_SIMPSON.VSNR)
            .get("/papierantraege/entwurf/{vsnr}")
            .then()
            .statusCode(404);

        WireMockStub.stubForStammdaten(TestPerson.ERIC_CARTMANN);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            deleteFromAntragForTestPerson(TestPerson.ERIC_CARTMANN.VSNR);
            createAntragEntwurf(TestPerson.ERIC_CARTMANN);
        }
        // antrag in Status ENTWURF (200)
        given().pathParam("vsnr", TestPerson.ERIC_CARTMANN.VSNR)
            .get("/papierantraege/entwurf/{vsnr}")
            .then()
            .statusCode(200);

        // Negativtest Mandant VSRN - VSNR 18010160T012 <- nicht im Bestand des Mandanten vorhanden
        given().pathParam("vsnr", "18010160T012")
            .get("/papierantraege/entwurf/{vsnr}")
            .then()
            .statusCode(404);

    }

    /**
     * Loesche Antrag der Testperson.
     *
     * @param vsnr Versicherungsnr.
     */
    @Transactional
    void deleteFromAntragForTestPerson(final String vsnr) {
        entityManager.createQuery("DELETE FROM Bestandsfehler").executeUpdate();
        entityManager.createQuery("DELETE FROM Fehler").executeUpdate();
        final List<Antrag> resultList = entityManager.createQuery(
                "select an from Antrag an where an.vsnr = :vsnr",
                Antrag.class)
            .setParameter("vsnr", vsnr)
            .getResultList();
        resultList.forEach(entityManager::remove);
    }

    /**
     * Test getPapierantragEntwurfByUUID.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testgetPapierantragEntwurfByUUID() {
        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            // antrag in Status != Entwurf -> (404)
            final UUID antragKeinEntwurf = createAntrag(TestPerson.MICKEY_MOUSE).getUuid();
            final Response resp = papierAntraegeApi.getPapierantragEntwurfByUuid(antragKeinEntwurf.toString());
            assertEquals(404, resp.getStatus());
        }

        // Nicht in DB für Mandant 70 vorhanden -> (404)
        WireMockStub.stubForStammdaten(TestPerson.KYLE_BROFLOVSKI);
        final UUID antragAndererMandant;
        try (AutoCloseable ignore = drvMandant.setInScope("17")) {
            antragAndererMandant = createAntrag(TestPerson.KYLE_BROFLOVSKI).getUuid();
        }
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Response resp = papierAntraegeApi.getPapierantragEntwurfByUuid(antragAndererMandant.toString());
            assertEquals(404, resp.getStatus());
        }

        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        // Antrag vorhanden ABER eAntrag kein Papierantrag -> (404)
        final UUID eantragUuid = createEAntrag(TestPerson.MICKEY_MOUSE);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Response resp = papierAntraegeApi.getPapierantragEntwurfByUuid(eantragUuid.toString());
            assertEquals(404, resp.getStatus());
        }

        WireMockStub.stubForStammdaten(TestPerson.HARVEY_DENT);
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            // antrag vorhanden + Status IN_BERARBEITUNG --> (200)
            final UUID antragEntwurf = createAntragEntwurf(TestPerson.HARVEY_DENT).getUuid();
            final Response resp = papierAntraegeApi.getPapierantragEntwurfByUuid(antragEntwurf.toString());
            assertEquals(200, resp.getStatus());
        }

    }

    /**
     * Test createPapierantragEntwurf Error (VSNR null/leer).
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    void testCreatePapierantragEntwurfError() {
        drvMandant.setInScope("17");

        final PapierantragDto papierantragsDto = erstellePapierantrag("");

        papierantragsDto.getVersicherter().setVsnr("");
        assertThrows(PapierantragValidierungException.class, () -> papierAntraegeApi.createPapierantragEntwurf(papierantragsDto));
    }

    /**
     * Test CreatePapierantragEntwurf mit Mandanten für die es keine Datenbank gibt Erwarte IllegalStateException - NoInstance of
     * Datasource.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "99") })
    @Transactional
    void testCreatePapierantragEntwurfErrorNoDBInstance() {
        drvMandant.setInScope("99");

        final PapierantragDto papierantragsDto = erstellePapierantrag("");

        assertThrows(IllegalStateException.class,
            () -> papierAntraegeApi.createPapierantragEntwurf(papierantragsDto));

    }

    /**
     * Test create Papierantrag wenn die UUID nicht null ist.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    void testCreatePapierantragWithUuidNotNull() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("03080800B018");

        final StatistikService statistikServiceMock = Mockito.mock(StatistikService.class);
        Mockito.when(statistikServiceMock.createStatistikAntragserfassung(any())).thenReturn(true);

        QuarkusMock.installMockForType(statistikServiceMock, StatistikService.class);

        final VerarbeitungsService verarbeitungsServiceMock =
            Mockito.mock(VerarbeitungsService.class);
        QuarkusMock.installMockForType(verarbeitungsServiceMock, VerarbeitungsService.class);

        papierantragsDto.getAntrag().setUuid(UUID.randomUUID().toString());
        final Response resp = papierAntraegeApi.createPapierantrag(papierantragsDto);
        assertEquals(Response.Status.CREATED.getStatusCode(), resp.getStatus());

        cleanDatabaseAntragWithVSNR(resp.readEntity(PapierantragDto.class).getAntrag().getVsnr());
        Mockito.reset(statistikServiceMock);
        Mockito.reset(verarbeitungsServiceMock);
    }

    /**
     * Test verabeite Papierantrag Erledigung auf andere Art und Weise ohne ausreichende Rollenrechte.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testVerarbeitePapierantragErledigungAufAndereArtUndWeiseKeinZugriff() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("");
        given().contentType(ContentType.JSON).body(papierantragsDto).when()
            .post("/papierantraege/erledigung-auf-andere-art-und-weise").then().statusCode(403);
    }

    /**
     * Test verarbeite Papierantrat Erledigung auf andere Art und Weise.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testVerarbeitePapierantragErledigungAufAndereArtUndWeise() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("03080800B018");
        final Response response = papierAntraegeApi.verarbeitePapierantragErledigungAufAndereArtUndWeise(papierantragsDto);
        assertEquals(201, response.getStatus());
    }

    /**
     * Test verarbeite Papierantrat Ruecknahme ohne ausreichende Rollenrechte.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testVerarbeitePapierantragRuecknahmeKeinZugriff() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("");
        given().contentType(ContentType.JSON).body(papierantragsDto).when()
            .post("/papierantraege/ruecknahme").then().statusCode(403);
    }

    /**
     * Test VerarbeitePapierantragWeiterbearbeitungInRvDialog.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testVerarbeitePapierantragWeiterbearbeitungInRvDialog() {
        final String uuid;
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final PapierantragDto papierantragDto = PapierantragTestDaten.getPapierantrag(TestPerson.PETER_PAN);

            final Response resp = papierAntraegeApi.verarbeitePapierantragWeiterbearbeitungInRvDialog(papierantragDto);
            assertThat(resp.getStatus()).isEqualTo(201);

            final PapierantragDto ergebnis = (PapierantragDto) resp.getEntity();
            uuid = ergebnis.getAntrag().getUuid();
        }

        boolean await = latch.await(30, TimeUnit.SECONDS);
        assertThat(await).isTrue();

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Optional<Antrag> antrag = antragRepository.findByUuid(UUID.fromString(uuid));
            assertThat(antrag).isPresent();
            assertThat(antrag.get().getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        }
    }

    /**
     * Test VerarbeitePapierantragWeiterbearbeitungInRvDialog.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testVerarbeitePapierantragOhneErfassungWeiterbearbeitungInRvDialog() {
        final String uuid;
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final PapierantragDto papierantragDto = PapierantragTestDaten.getPapierantrag(TestPerson.PETER_PAN);

            final Response resp = papierAntraegeApi.verarbeitePapierantragOhneErfassungWeiterbearbeitungInRvDialog(papierantragDto);
            assertThat(resp.getStatus()).isEqualTo(201);

            final PapierantragDto ergebnis = (PapierantragDto) resp.getEntity();
            uuid = ergebnis.getAntrag().getUuid();
        }

        final boolean await = latch.await(30, TimeUnit.SECONDS);
        assertThat(await).isTrue();

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Optional<Antrag> antrag = antragRepository.findByUuid(UUID.fromString(uuid));
            assertThat(antrag).isPresent();
            assertThat(antrag.get().getStatus()).isEqualTo(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        }
    }

    /***
     * Löscht den angelegte Antrag mit der UUID aus der Datenbank.
     *
     * @param uuid UUID des zu löschenden Antrages
     */
    @Transactional
    void cleanDatabaseAntragWithUUID(final String uuid) {
        try {
            final Antrag neuesterAntrag =
                entityManager.createQuery("select a from Antrag a where uuid = :uuid", Antrag.class)
                    .setParameter("uuid", UUID.fromString(uuid)).getSingleResult();
            entityManager.remove(neuesterAntrag);
        } catch (final NoResultException e) {
            LOG.atWarn().addArgument(uuid).log("Kein Antrag mit id {} gefunden");
        }
    }

    /***
     * Löscht den angelegte Antrag mit der VSNR aus der Datenbank.
     *
     * @param vsnr VSNR des zu löschenden Antrages
     */
    @Transactional
    void cleanDatabaseAntragWithVSNR(final String vsnr) {
        try {
            final Antrag neuesterAntrag = entityManager.createQuery(
                "select a from Antrag a where vsnr = :vsnr order by created desc limit 1",
                Antrag.class).setParameter("vsnr", vsnr).getSingleResult();
            entityManager.remove(neuesterAntrag);
        } catch (final Exception e) {
            LOG.atWarn().addArgument(vsnr).log("Kein Antrag für vsnr {} gefunden");
        }
    }

    /**
     * Test verarbeite Papierantrag Ruecknahme.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testVerarbeitePapierantragRuecknahme() {
        drvMandant.setInScope("17");
        final PapierantragDto papierantragsDto = erstellePapierantrag("03080800B018");
        final Response response = papierAntraegeApi.verarbeitePapierantragRuecknahme(papierantragsDto);
        assertEquals(201, response.getStatus());
    }

    private static void createStubMappings() {

        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);

        wireMockServer.stubFor(get(urlPathTemplate("/konten/{vsnr}"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(aResponse().withTransformers(StammdatenMockTransformer.NAME)
                .withFixedDelay(200).withBody(createKontoJson())
                .withHeader("Content-Type", "application/json")));

        wireMockServer.stubFor(get(urlPathMatching(
            "/nachderreha-api/rvfit/v2/einrichtungen(\\?plz=[^&]*)?(\\&umkreis=[^&]*)?"))
            .willReturn(
                aResponse().withStatus(Response.Status.OK.getStatusCode()).withFixedDelay(200)
                    .withBody(jsonToString("einrichtung/einrichtungen_all.json"))
                    .withHeader("Content-Type", "application/json")));

        stubFor(post(urlPathTemplate("/rvdialog-wartezeitabfrage"))
            .withHeader("Content-Type", new EqualToPattern("application/json", false))
            .willReturn(aResponse().withBody("""
                {
                  "vsnr": "23270152B506",
                  "wartezeit6in24m": 7,
                  "wartezeit180m": 181,
                  "wartezeitfehler": false,
                  "antragRehaMsat": "6",
                  "antragRehaArt": "21",
                  "massnahmeRehaElat": "",
                  "massnahmeRehaKobs": null,
                  "antragRenteLeat": "45",
                  "bezugRenteLeat": "45",
                  "antragRenteTlrt": "0",
                  "bezugRenteTlrt": "0",
                  "bezugRenteProzent": "",
                  "beamteneigenschaft": false,
                  "rechtsbehelfRente": false,
                  "rechtsbehelfReha": false,
                  "beschaeftigungGruppe": "110",
                  "beschaeftigungGrund": "10",
                  "beschaeftigungKobs": "2024-02-13",
                  "altersteilzeitGruppe": "113",
                  "altersteilzeitGrund": "52",
                  "altersteilzeitKobs": "2024-02-13",
                  "selbstaendigkeit": false,
                   "rvSystemFehler": [
                    {
                      "statuscode": "",
                      "message": ""
                    }
                  ],
                  "unerwarteterFehler": ""
                }
                """).withFixedDelay(200).withStatus(200).withHeader("Content-Type",
                "application/json")));
    }

    /**
     * Test GeburtsdatumStatusMapping.
     */
    @Test
    void testGeburtsdatumStatusMapping() {
        final PapierantragDto dto = erstellePapierantrag("");
        dto.getVersicherter().setGeburtsdatum("2000-00-00");

        final AntragDto antragDto = new AntragDto();
        antragDto.setGeburtsdatum("2000-00-00");
        dto.setAntrag(antragDto);

        final Antrag entity = antragMapper.toEntity(dto);
        assertThat(entity.getGeburtsdatum()).isEqualTo(LocalDate.of(2000, 1, 1));
        assertThat(entity.getGeburtsdatumStatus()).isEqualTo(GeburtsdatumStatus.MONAT_TAG_NULL);
    }

    /**
     * Test create Papierantrag Validerung, Fehler VorgangsId ist vorhanden.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    void testCreatePapierantragValidierungsFehlerVorgangsIdVorhanden() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final String vorgangsKennung = generiereNeueVogID();
            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    vorgangsKennung, AUFGABEN_ID));

            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final StatistikService statistikServiceMock = Mockito.mock(StatistikService.class);
            Mockito.when(statistikServiceMock.createStatistikAntragserfassung(any())).thenReturn(true);
            QuarkusMock.installMockForType(statistikServiceMock, StatistikService.class);

            final VerarbeitungsService verarbeitungsServiceMock = Mockito.mock(VerarbeitungsService.class);
            QuarkusMock.installMockForType(verarbeitungsServiceMock, VerarbeitungsService.class);

            // Erster Antrag wird erfolgreich gestellt
            final PapierantragDto papierantragDto =
                given().contentType(ContentType.JSON).body(papierantragsDto)
                    .post("/papierantraege").then().contentType(ContentType.JSON)
                    .statusCode(201).extract().as(PapierantragDto.class);

            // Zweiter Antrag hat die gleiche Vorgangskennung muss deswegen eine Fehlermeldung liefern
            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);
            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("vogid");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_UNGUELTIG);

            cleanDatabaseAntragWithVSNR(papierantragDto.getAntrag().getVsnr());
            Mockito.reset(stammdatenServiceMock);
            Mockito.reset(statistikServiceMock);
            Mockito.reset(verarbeitungsServiceMock);
        }
    }

    /**
     * Test create Papierantrag Validerung, Bad Request wenn Eingangsdatum vor Antragsdatum liegt.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennEingangsDatumVorAntragsDatumLiegt() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), AUFGABEN_ID));
            papierantragsDto.getAntrag().setEingangsdatum(LocalDate.now().minusDays(7));
            papierantragsDto.getAntrag().setAntragsdatum(LocalDate.now().minusDays(5));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then()
                .contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("antragsdatum");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_UNGUELTIG);
        }
    }

    /**
     * Test create Papierantrag Validerung, Bad Request wenn Eingangsdatum in der Zukunft liegt.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennEingangsDatumInZukunftLiegt() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), AUFGABEN_ID));
            papierantragsDto.getAntrag().setEingangsdatum(LocalDate.now().plusDays(7));
            papierantragsDto.getAntrag().setAntragsdatum(LocalDate.now());

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then()
                .contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("eingangsdatum");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_UNGUELTIG);
        }
    }

    /**
     * Test create Papierantrag Validerung, Bad Request wenn Antragsdatum mehr als 10 Jahre zurueckliegt.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennAntragsDatumMehrAls10JahreZurueckLiegt() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), AUFGABEN_ID));
            papierantragsDto.getAntrag().setEingangsdatum(LocalDate.now());
            papierantragsDto.getAntrag().setAntragsdatum(LocalDate.now().minusYears(10)
                .minusDays(1));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then()
                .contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(1);
            assertThat(fehlerDtos[0].getFeld()).isEqualTo("antragsdatum");
            assertThat(fehlerDtos[0].getCode()).isEqualTo(FehlercodeDto.FELD_UNGUELTIG);
        }
    }

    /**
     * Test create Papierantrag Validerung, Bad Request wenn Eingangsdatum und Antragsdatum in der Zukunft liegen.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennAntragsDatumUndEingangsDatumInZukunftLiegen() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), AUFGABEN_ID));
            papierantragsDto.getAntrag().setEingangsdatum(LocalDate.now().plusDays(2));
            papierantragsDto.getAntrag().setAntragsdatum(LocalDate.now().plusDays(2));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(2);
            assertThat(Arrays.stream(fehlerDtos).map(FehlerDto::getFeld))
                .containsAll(List.of("eingangsdatum", "antragsdatum"));
            assertThat(Arrays.stream(fehlerDtos).map(FehlerDto::getCode))
                .allMatch(code -> code.equals(FehlercodeDto.FELD_UNGUELTIG));
        }
    }

    /**
     * Test create Papierantrag Validerung, Bad Request wenn Eingangsdatum vor Antragsdatum mehr als 10 Jahre zurueckliegen.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testCreatePapierantragBadRequestWennAntragsDatumUndEingangsDatumMehrAls10JahreZurueckLiegen() {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final StammdatenService stammdatenServiceMock = Mockito.mock(StammdatenService.class);
            final KontoDto kontoDto = KontoTestDaten.getKontoDaten(TestPerson.PETER_PAN);
            Mockito.when(stammdatenServiceMock.getStammdatenDtoByVsnr(any()))
                .thenReturn(stammdatenMapper.toStammdatenDtoFromKontoDto(kontoDto));
            QuarkusMock.installMockForType(stammdatenServiceMock, StammdatenService.class);

            final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    generiereNeueVogID(), AUFGABEN_ID));
            papierantragsDto.getAntrag().setEingangsdatum(LocalDate.now().minusYears(10)
                .minusDays(1));
            papierantragsDto.getAntrag().setAntragsdatum(LocalDate.now().minusYears(10)
                .minusDays(1));

            final FehlerDto[] fehlerDtos = given().contentType(ContentType.JSON)
                .body(papierantragsDto).post("/papierantraege").then().contentType(ContentType.JSON)
                .statusCode(400).extract().as(FehlerDto[].class);

            assertThat(fehlerDtos).isNotEmpty().hasSize(2);
            assertThat(Arrays.stream(fehlerDtos).map(FehlerDto::getFeld))
                .containsAll(List.of("eingangsdatum", "antragsdatum"));
            assertThat(Arrays.stream(fehlerDtos).map(FehlerDto::getCode))
                .allMatch(code -> code.equals(FehlercodeDto.FELD_UNGUELTIG));
        }
    }

    /***
     * Testet getVerarbeitungsartByVorgangsId.
     *
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testGetVerarbeitungsartByVorgangsId() {
        drvMandant.setInScope("70");
        final String vorgangsId = generiereNeueVogID();

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            PapierantragTestDatenHelper.erstellePapierantrag(
                new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                    vorgangsId, null));
        }
        // Keine Verarbeitung zur vorgangsId gefunden
        given().pathParam("vorgangsId", vorgangsId)
            .get("/antraege/{vorgangsId}/verarbeitungsart")
            .then()
            .statusCode(404);
    }

    /**
     * Test Rolle Erfasser.
     */
    @Test
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_EF")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "17") })
    @Transactional
    void testRolleErfasser() {
        assertDoesNotThrow(this::testCreatePapierantrag);
    }

    /***
     * Erstellt eine Test PapierantragDTO.
     *
     * @param versnr Versicherungsnr.
     * @return PapierantragsDto - BeispielPapierantrag für Test
     */
    private PapierantragDto erstellePapierantrag(final String versnr) {
        final String vsnr;
        if (versnr.isEmpty()) {
            vsnr = "23270152B506";
        } else {
            vsnr = versnr;
        }

        final PapierantragDto papierAntrag = new PapierantragDto();
        final AntragDto antragDto = new AntragDto();

        final StammdatenDto myStamm = new StammdatenDto();
        myStamm.setVsnr(vsnr);
        myStamm.setVorname("Peter");
        myStamm.setNachname("Pan");
        myStamm.setGeburtsdatum("2000-08-08");
        myStamm.setStaatsangehoerigkeit("151");

        myStamm.setWohnort("Wohnort");
        myStamm.setPlz("12345");
        myStamm.setStrasse("Musterstraße");
        myStamm.setHausnummer("123");

        antragDto.setTelefon("0921123456");
        antragDto.setFax("0921987654");
        antragDto.setAntragsdatum(LocalDate.now());
        antragDto.setEingangsdatum(LocalDate.now());
        antragDto.setUuid(UUID.randomUUID().toString());

        antragDto.setWohnort("Wohnort");
        antragDto.setPlz("12345");
        antragDto.setStrasse("Musterstraße");
        antragDto.setHausnummer("123");

        antragDto.setVsnr(vsnr);
        antragDto.setVorname("Peter");
        antragDto.setNachname("Pan");
        antragDto.setGeburtsdatum("2000-08-08");
        antragDto.setStaatsangehoerigkeit("151");
        antragDto.setKtan("17");

        papierAntrag.setAntrag(antragDto);
        papierAntrag.setVersicherter(myStamm);
        papierAntrag.setAufgabenId(AUFGABEN_ID);
        papierAntrag.setVorgangsId(generiereNeueVogID());

        return papierAntrag;
    }

    /**
     * Erzeugt neue Vorgangsid (14Stellig) Prefix + fortlaufendeNummer + Suffix.
     *
     * @return vorgangsID 14stellige VorgangsID
     */
    private String generiereNeueVogID() {
        iVorgangsnummer++;
        return "V24" + String.format("%07d", iVorgangsnummer) + "RV32";
    }

    @SneakyThrows
    private Antrag createAntrag(final TestPerson testPerson) {
        if (papierantragCreator == null) {
            papierantragCreator = new PapierantragCreator(wireMockServer, entityManager, drvMandant, latch);
        }
        return papierantragCreator.createAntrag(testPerson);
    }

    @SneakyThrows
    private Antrag createAntragEntwurf(final TestPerson testPerson) {
        if (papierantragCreator == null) {
            papierantragCreator = new PapierantragCreator(wireMockServer, entityManager, drvMandant, latch);
        }
        return papierantragCreator.createAntragEntwurf(testPerson);
    }

    private UUID createEAntrag(final TestPerson testPerson) {
        EAntragRegressionsTestTemplate testTemplate = new EAntragRegressionsTestTemplate(testPerson,
            producerTemplate) {
            @Override
            public boolean fuehreAus() {
                return true;
            }
        };
        return testTemplate.getAntragUuid();
    }

}
