package de.deutscherv.rvsm.fa.fit.papierantraege;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.inject.Inject;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static io.restassured.RestAssured.given;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
@ActivateRequestContext
@QuarkusTest
class ErstellePapierAntraegeTest {

    @Inject
    private DrvMandant drvMandant;
    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    private CountDownLatch latch;

    private static final String JSON_BODY = """
                    {
                        "antrag": {
                            "vsnr": "03080800B018",
                            "eingangsdatum": "2025-02-28",
                            "antragsdatum": "2025-02-28",
                            "antragsart": "PAPIERANTRAG",
                            "strasse": "Paracelsusstr.",
                            "hausnummer": "21",
                            "plz": "06114",
                            "wohnort": "Halle (Saale)",
                            "land": "000",
                            "vorname": "Peter",
                            "nachname": "Pan",
                            "geburtsdatum": "2000-08-08",
                            "geburtsort": "Köln",
                            "staatsangehoerigkeit": "000",
                            "telefon": "017610323499",
                            "fax": "0345 213-2022694",
                            "freitext": "",
                            "einrichtungStartAuf": null,
                            "einrichtungTraining": null,
                            "fruehererName": null,
                            "vorsatzwort": null,
                            "namenszusatz": null,
                            "titel": "Dr.",
                            "geburtsname": "Barrie",
                            "geschlecht": "M",
                            "bemerkungen": "Yaay"
                        },
                        "versicherter": {
                            "id": null,
                            "vsnr": "03080800B018",
                            "vorname": "Peter",
                            "nachname": "Pan",
                            "geburtsdatum": "2000-08-08",
                            "geburtsdatumStatus": "OK",
                            "geburtsort": "Köln",
                            "geburtsland": "000",
                            "strasse": "Paracelsusstr.",
                            "hausnummer": "21",
                            "plz": "06114",
                            "wohnort": "Halle (Saale)",
                            "land": "000",
                            "staatsangehoerigkeit": "000",
                            "vorsatzwort": "",
                            "namenszusatz": "",
                            "titel": "Dr.",
                            "telefon": "017610323499",
                            "telefax": "0345 213-2022694",
                            "geschlecht": "M",
                            "geburtsname": "Barrie",
                            "fruehererName": null,
                            "grossdruck": false,
                            "kurzschrift": false,
                            "vollschrift": false,
                            "cd": false,
                            "hoermedium": false
                        },
                        "einrichtung1": null,
                        "einrichtung2": null,
                        "aufgabenId": "H340000540RVX1",
                        "vorgangsId": "B1400001D2RVZ1"
                    }
            """;

    private static WireMockServer wireMockServer;
    @Inject
    private CamelContext camelContext;

    /**
     * Globale Testvorbereitungen.
     *
     * @throws JsonProcessingException Json-Fehler
     */
    @BeforeAll
    public static void setup() throws JsonProcessingException {
        wireMockServer = WireMockStub.connect(WireMockStub.PORT);

        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForStammdaten(TestPerson.PETER_PAN);
        WireMockStub.stubForKontoinformation(TestPerson.PETER_PAN);
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    void setUp() {
        latch = new CountDownLatch(1);
        camelContext.getRouteController().stopRoute(RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB);
        AdviceWith.adviceWith(RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB, camelContext,
                new AdviceWithRouteBuilder() {
                    @Override
                    public void configure() {
                        weaveAddLast().process(exchange -> latch.countDown());
                    }
                });
        camelContext.getRouteController().startRoute(RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB);
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    public static void tearDown() {
        WireMockStub.disconnect(wireMockServer);
    }

    /**
     * Test - Papierantrag soll hochgeladen werden.
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void papierAntragSollteErfolgreichHochgeladenWerden() {
        drvMandant.setInScope("70");
        stubFor(post(urlPathMatching("/auftraege"))
                .withHeader("Content-Type", new EqualToPattern("application/json", false)).willReturn(
                        aResponse().withStatus(202).withBody(WireMockStub.getDokumentenErzeugungAuftragAntwort())));
        given().contentType(ContentType.JSON).body(JSON_BODY).post("/papierantraege").then()
                .contentType(ContentType.JSON).statusCode(201).extract().as(PapierantragDto.class);
    }

    /**
     * Test - Papierantrag soll abgelehnt werden.
     */
    @SneakyThrows
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void papierAntragSollteAbgelehntWerden() {
        drvMandant.setInScope("70");
        WireMockStub.stubForStammdaten(TestPerson.BEZUGRENTE_ABLEHNEN_PD_AUSSTEUERN);
        WireMockStub.stubForKontoinformation(TestPerson.BEZUGRENTE_ABLEHNEN_PD_AUSSTEUERN);
        WireMockStub.stubForAzk();
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
        stubFor(post(urlPathMatching("/auftraege"))
                .withHeader("Content-Type", new EqualToPattern("application/json", false)).willReturn(
                        aResponse().withStatus(202).withBody(WireMockStub.getDokumentenErzeugungAuftragAntwort())));
        final String body = """
                        {
                            "antrag": {
                                "vsnr": "04121282P014",
                                "eingangsdatum": "2025-02-28",
                                "antragsdatum": "2025-02-28",
                                "antragsart": "PAPIERANTRAG",
                                "strasse": "Platz der Republik.",
                                "hausnummer": "1",
                                "plz": "10557",
                                "wohnort": "Berlin",
                                "land": "000",
                                "vorname": "Bezugrente-Ablehnen",
                                "nachname": "Pd-Aussteuern",
                                "geburtsdatum": "1982-12-12",
                                "geburtsort": "München",
                                "staatsangehoerigkeit": "000",
                                "telefon": "017610323499",
                                "fax": "",
                                "freitext": "",
                                "einrichtungStartAuf": null,
                                "einrichtungTraining": null,
                                "fruehererName": null,
                                "vorsatzwort": null,
                                "namenszusatz": null,
                                "titel": "",
                                "geburtsname": "",
                                "geschlecht": "M",
                                "bemerkungen": ""
                            },
                            "versicherter": {
                                "id": null,
                                "vsnr": "04121282P014",
                                "vorname": "Bezugrente-Ablehnen",
                                "nachname": "Pd-Aussteuern",
                                "geburtsdatum": "1982-12-12",
                                "geburtsdatumStatus": "OK",
                                "geburtsort": "München",
                                "geburtsland": "000",
                                "strasse": "Platz der Republik",
                                "hausnummer": "1",
                                "plz": "10557",
                                "wohnort": "Berlin",
                                "land": "000",
                                "staatsangehoerigkeit": "000",
                                "vorsatzwort": "",
                                "namenszusatz": "",
                                "titel": ".",
                                "telefon": "017610323499",
                                "telefax": "",
                                "geschlecht": "M",
                                "geburtsname": "",
                                "fruehererName": null,
                                "grossdruck": false,
                                "kurzschrift": false,
                                "vollschrift": false,
                                "cd": false,
                                "hoermedium": false
                            },
                            "einrichtung1": null,
                            "einrichtung2": null,
                            "aufgabenId": "H340000540RVK1",
                            "vorgangsId": "B1400001D2RVK1"
                        }
                """;
        final var antrag = given().contentType(ContentType.JSON).body(body).post("/papierantraege").then()
                .contentType(ContentType.JSON).statusCode(201).extract().as(PapierantragDto.class);
        var await = latch.await(4, TimeUnit.SECONDS);
        Assertions.assertTrue(await);
        final var status = verarbeitungsstatusRepository.findByAntragId(UUID.fromString(antrag.getAntrag().getUuid()))
                .orElseThrow();
        Assertions.assertEquals(Art.ABLEHNUNG, status.getArt());
    }
}
