package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static de.deutscherv.rvsm.fa.fit.testdaten.TestPerson.PETER_PAN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BewilligungsDokumentErzeugungsServiceTest
    extends DokumentenErzeugungsServiceTestParent {

    private static BewilligungsDokumentErzeugungsService bewilligungsDoeService;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void setup() {
        bewilligungsDoeService = new BewilligungsDokumentErzeugungsService(new DokumentenErzeugungTestConfig());
    }

    /**
     * Vorbereitung vor jedem Test.
     */
    @BeforeEach
    void reset() {
        this.dto = null;
    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @SneakyThrows
    @AfterEach
    void afterEach() {
        printResult();
    }

    /**
     * Test Dokumenterzeugung fuer Bweilligung.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungFuerBewilligung() {
        final var freitext = Map.of(
            VariablesFeld.FREITEXT_EINRICHTUNG, "Freitext für die Einrichtung",
            VariablesFeld.FREITEXT_VERSICHERTER, "Freitext für die versicherte Person"
        );

        final DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(PETER_PAN, freitext);
        //EinrichtungTrainingObjekt gleich StartObjekt setzen
        daten.antrag().setEinrichtungTrainingObjekt(daten.antrag().getEinrichtungStartObjekt());

        this.dto = bewilligungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(PETER_PAN.VSNR);
        final Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen).isNotNull()
            .isNotEmpty()
            .containsEntry("rvEvolution", "1")
            .containsEntry("dd_Bk_Bezugszeichenzeile", "Datum Ihres Antrags:")
            .containsEntry("t_Bezugszeichenzeile",
                daten.antrag().getAntragsDatum().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")))
            .containsEntry("USEQ_RBH_11_op_Bekanntg_SGG", "Bekanntgabe")
            .containsEntry("terminUebergeben", "1")
            .containsEntry("terminDatum", LocalDate.now().plusDays(300).format(
                DateTimeFormatter.ofPattern("dd.MM.yyyy")))
            .containsEntry("terminBemerkung", "Aufnahme oder Abschluss RV Fit")
            .containsEntry("inWiedervorlageSchieben", "0")
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()))
            .containsEntry("sv_kk_maschineller_Aufruf", "true")
            .containsEntry("sv_tm_G9582_00_Freie_Eingabe_Versicherte", "Freitext für die versicherte Person")
            .containsEntry("sv_tm_G9582_00_Freie_Eingabe_Einrichtung", "Freitext für die Einrichtung");

        assertThat(variablen.get("sv_kk_G9582_00_Hinweis_Ausschlussgrund")).matches("^(true|false)$");
        assertThat(variablen.get("sv_op_G9582_00_Durchführungsart_Phase_1")).matches("^([01])$");
        assertThat(variablen.get("sv_gz_G9582_00_Dauer_Phase_1")).matches("^([1-9])$");
        assertThat(variablen.get("sv_op_G9582_00_Durchführungsart_Phase_2")).matches("^([01])$");
        assertThat(variablen.get("sv_gz_G9582_00_Einheiten")).matches("^([1-9][0-9]?)$");
        assertThat(variablen.get("sv_gz_G9582_00_Wochen")).matches("^([1-9][0-9]?)$");
        assertThat(variablen.get("sv_op_G9582_00_Durchführungsart_Phase_4")).matches("^([012])$");
        assertThat(variablen.get("sv_gz_G9582_00_Dauer_Phase_4")).matches("^([1-9])$");
        assertThat(variablen.get("sv_tm_G9582_00_Name_und_Anschrift_der_Ei")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9582_00_Telefon")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9582_00_E_Mail")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("USEQ_RBH_22_op_Inland_Ausland_EU")).matches("^([12])$");
        // Daten für die Kommunikation mit RV PuR

    }

    /**
     * Test Dokumentenerzeugung fuer Bewilligung mit unterschiedlichen Einrichtungen für die Start- und Trainingsphase.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungFuerBewilligungUnterschiedlicheStartTrainingsEinrichtung() {
        final var freitext = Map.of(
            VariablesFeld.FREITEXT_EINRICHTUNG, "Freitext für die Einrichtung",
            VariablesFeld.FREITEXT_VERSICHERTER, "Freitext für die versicherte Person"
        );

        final DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(PETER_PAN, freitext);

        this.dto = bewilligungsDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(PETER_PAN.VSNR);
        Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen).isNotNull().isNotEmpty();

        assertThat(variablen.get("rvEvolution")).isEqualTo("1");

        // Datenbedarf DiLooP (NEU) für die Konstellation: eine beteiligte Reha-Einrichtung (G9852-00)
        assertThat(variablen).containsEntry("dd_Bk_Bezugszeichenzeile", "Datum Ihres Antrags:")
            .containsEntry("t_Bezugszeichenzeile",
                daten.antrag().getAntragsDatum().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")))
            .containsEntry("sv_tm_G9583_00_Freie_Eingabe_Versicherte", "Freitext für die versicherte Person")
            .containsEntry("sv_tm_G9583_00_Freie_Eing_Einr_Phase_1_4", "Freitext für die Einrichtung")
            .containsEntry("USEQ_RBH_11_op_Bekanntg_SGG", "Bekanntgabe")
            .containsEntry("terminUebergeben", "1")
            .containsEntry("terminDatum", LocalDate.now().plusDays(300).format(
                DateTimeFormatter.ofPattern("dd.MM.yyyy")))
            .containsEntry("terminBemerkung", "Aufnahme oder Abschluss RV Fit")
            .containsEntry("inWiedervorlageSchieben", "0")
            .containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()))
            .containsEntry("sv_kk_maschineller_Aufruf", "true");

        assertThat(variablen.get("sv_kk_G9583_00_Hinweis_Ausschlussgrund")).matches("^(true|false)$");
        assertThat(variablen.get("sv_op_G9583_00_Durchführungsart_Phase_1")).matches("^([01])$");
        assertThat(variablen.get("sv_gz_G9583_00_Dauer_Phase_1")).matches("^([1-9])$");
        assertThat(variablen.get("sv_op_G9583_00_Durchführungsart_Phase_2")).matches("^([01])$");
        assertThat(variablen.get("sv_gz_G9583_00_Einheiten")).matches("^([1-9][0-9]?)$");
        assertThat(variablen.get("sv_gz_G9583_00_Wochen")).matches("^([1-9][0-9]?)$");
        assertThat(variablen.get("sv_op_G9583_00_Durchführungsart_Phase_4")).matches("^([012])$");
        assertThat(variablen.get("sv_gz_G9583_00_Dauer_Phase_4")).matches("^([1-9])$");
        assertThat(variablen.get("sv_tm_G9583_00_Name_Anschr_Einrichtung")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9583_00_Telefon")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9583_00_E_Mail")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_tm_G9583_00_Name_Anschr_Einr_Phase_2")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9583_00_Telefon_Phase_2")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("sv_t_G9583_00_E_Mail_Phase_2")).isNotNull().hasSizeGreaterThan(1);
        assertThat(variablen.get("USEQ_RBH_22_op_Inland_Ausland_EU")).matches("^([12])$");
        // Daten für die Kommunikation mit RV PuR

    }

    /**
     * Test der Durchfuehrungsarg für Name und Phase.
     *
     * @param durchfuehrungsArtName Bezeichnung der Durchfuehrungsart
     * @param phase                 Phase
     * @param expected              zu erwartender Wert
     */
    @ParameterizedTest
    @CsvSource({
        // Parameter 1: Bezeichnung/Name der Durchführungsart
        // Parameter 2: Phase (1 Start, 2 Training, 4 Auffrischung)
        // Parameter 3: erwarteter Wert
        "'AMBULANT', 1, '0'",       // Testfall 1: AMBULANT
        "'AmBulant (ganztägig)', 1, '0'",       // Testfall 2: AMBULANT
        "'STATIONÄR', 1, '1'",      // Testfall 3: STATIONAER
        "'online', 2, '1'",         // Testfall 4: ONLINE mit Phase 2
        "'ONLINE', 4, '2'",         // Testfall 5: ONLINE mit Phase 4
        "'UNBEKANNT', 1, ''"        // Testfall 6: ungültige Eingabe
    })
    void testGetDurchfuehrungsArtFuerNameUndPhase(final String durchfuehrungsArtName, final int phase, final String expected) {
        assertEquals(expected, bewilligungsDoeService.getDurchfuehrungsArtFuerNameUndPhase(durchfuehrungsArtName, phase));
    }

    /**
     * Test AGIR aus Antrag.
     *
     * @param atad         ATAD
     * @param expectedAigr erwartetet AGIR
     */
    @ParameterizedTest
    @CsvSource({
        "0, 0000",
        "1, 0001",
        "20, 0020",
        "300, 0300",
        "4000, 4000"
    })
    void testeAigrAusAntrag(final int atad, final String expectedAigr) {
        final Antrag antrag = new Antrag();
        antrag.setAtad(atad);

        final String aigr = bewilligungsDoeService.getAigr(antrag);

        assertThat(aigr).isEqualTo(expectedAigr);
    }

    /**
     * Test AGIR aus Antrag.
     */
    @Test
    void testeAigrAusAntrag() {
        final Antrag antrag = new Antrag();
        antrag.setAtad(null);

        final String aigr = bewilligungsDoeService.getAigr(antrag);

        assertThat(aigr).isEqualTo(null);
    }

}
