package de.deutscherv.rvsm.fa.fit.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierAntragEinrichtungUtil;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalClient;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test PapierAntragEinrichtungUtil.
 */
@QuarkusTest
class PapierAntragEinrichtungUtilTest {

    @Inject
    private PapierAntragEinrichtungUtil papierAntragEinrichtungUtil;

    @InjectMock
    @RestClient
    private SelbstmeldeportalClient client;
    private PapierantragDto myPapierAntrag;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeEach
    void setUp() {
        myPapierAntrag = new PapierantragDto();
        final AntragDto antragDto = new AntragDto();

        final StammdatenDto myStamm = new StammdatenDto();
        myStamm.setVsnr("12345678B123");
        myStamm.setVorname("Max");
        myStamm.setNachname("Mustermann");
        myStamm.setGeburtsdatum(LocalDate.now().toString());
        myStamm.setStaatsangehoerigkeit("151");

        myStamm.setWohnort("Wohnort");
        myStamm.setPlz("12345");
        myStamm.setStrasse("Musterstraße");
        myStamm.setHausnummer("123");

        antragDto.setTelefon("0921123456");
        antragDto.setFax("0921987654");
        antragDto.setAntragsdatum(LocalDate.now());
        antragDto.setEingangsdatum(LocalDate.now());

        antragDto.setWohnort("Wohnort");
        antragDto.setPlz("12345");
        antragDto.setStrasse("Musterstraße");
        antragDto.setHausnummer("123");

        antragDto.setVsnr("12345678B123");
        antragDto.setVorname("Max");
        antragDto.setNachname("Mustermann");
        antragDto.setGeburtsdatum(LocalDate.now().toString());
        antragDto.setStaatsangehoerigkeit("151");

        myPapierAntrag.setAntrag(antragDto);
        myPapierAntrag.setVersicherter(myStamm);

        final RehaEinrichtungDto reha1 = new RehaEinrichtungDto();
        reha1.setSelbstmeldeportalId(10015L);

        final RehaEinrichtungDto reha2 = new RehaEinrichtungDto();
        reha2.selbstmeldeportalId(10023L);

        myPapierAntrag.setEinrichtung1(reha1);
        myPapierAntrag.setEinrichtung2(reha2);
    }

    /**
     * Test, Setzen von Reha-Einrichtungen.
     */
    @SneakyThrows
    @Test
    void testeSetzenVonRehaEinrichtung() {
        Mockito.when(client.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response
                .ok(new ObjectMapper().readValue(JSONTestUtils.jsonToString("einrichtung/einrichtungen_all_extended.json"),
                    new TypeReference<List<EinrichtungResponseExtended>>() {

                    }), MediaType.APPLICATION_JSON_TYPE)
                .build());
        final Antrag antragMitEinrichtung =
            papierAntragEinrichtungUtil.getAntragMitEinrichtung(myPapierAntrag, new Antrag());

        final Long einrichtungId = 10015L;

        assertEquals(einrichtungId, antragMitEinrichtung.getEinrichtungStartObjekt().getSmpEinrichtungsId());
        assertEquals(einrichtungId, antragMitEinrichtung.getEinrichtungAufObjekt().getSmpEinrichtungsId());
    }

    /**
     * Test, Exception bei ungueltiger StartID.
     */
    @Test
    void testeExceptionBeiUngueltigerStartId() {

        final Long ungueltigeId = 123L;

        myPapierAntrag.getEinrichtung1().setSelbstmeldeportalId(ungueltigeId);
        final Antrag antrag = new Antrag();
        assertThrows(RuntimeException.class, () -> papierAntragEinrichtungUtil
            .getAntragMitEinrichtung(myPapierAntrag, antrag));
    }

    /**
     * Test, Exception bei ungueltiger TrainingID.
     */
    @Test
    void testeExceptionBeiUngueltigerTrainingId() {

        final Long ungueltigeId = 123L;

        myPapierAntrag.getEinrichtung2().setSelbstmeldeportalId(ungueltigeId);
        final Antrag antrag = new Antrag();
        assertThrows(RuntimeException.class, () -> papierAntragEinrichtungUtil
            .getAntragMitEinrichtung(myPapierAntrag, antrag));
    }

    /**
     * Test, Papierantrag zurückgegebene bei fehlenden Angaben.
     */
    @SneakyThrows
    @Test
    void testPapierAntragZurueckGegebenBeiFehlendenAngaben() {

        final Antrag antrag = new Antrag();
        antrag.setUuid(UUID.fromString("FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"));
        Mockito.when(client.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response
                .ok(new ObjectMapper().readValue(JSONTestUtils.jsonToString("einrichtung/einrichtungen_all.json"),
                    new TypeReference<List<EinrichtungResponseExtended>>() {

                    }), MediaType.APPLICATION_JSON_TYPE)
                .build());

        final Antrag antragMitEinrichtung =
            papierAntragEinrichtungUtil.getAntragMitEinrichtung(myPapierAntrag, antrag);

        assertEquals(UUID.fromString("FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"), antragMitEinrichtung.getUuid());
    }

    /**
     * Test, sichere SmpID für selektierte Einrichtungen für Antrag in Enwurf.
     */
    @SneakyThrows
    @Test
    void testEnsureSmpIdForSelectedEinrichtungenForAntragInEntwurf() {

        final Antrag antrag = new Antrag();
        antrag.setUuid(UUID.randomUUID());
        antrag.setAngebotStartName("Beispielklinik Haidhausen");

        antrag.setAngebotTrainingName("ZAR im Mineralbad Bad Cannstatt");
        Mockito.when(client.getEinrichtungen(any(), any(), any(), any(), any(), any()))
            .thenReturn(Response
                .ok(new ObjectMapper().readValue(JSONTestUtils.jsonToString("einrichtung/einrichtungen_all.json"),
                    new TypeReference<List<EinrichtungResponseExtended>>() {

                    }), MediaType.APPLICATION_JSON_TYPE)
                .build());

        final Antrag antragMitSmpid = papierAntragEinrichtungUtil.ensureSmpIdForSelectedEinrichtungenForAntragInEntwurf(antrag, 10001L,
            10019L);

        assertNotNull(antragMitSmpid.getEinrichtungStartObjekt());
        assertNotNull(antragMitSmpid.getAngebotStartSmpId());

        assertNotNull(antragMitSmpid.getEinrichtungTrainingObjekt());
        assertNotNull(antragMitSmpid.getAngebotTrainingSmpId());
    }

}
