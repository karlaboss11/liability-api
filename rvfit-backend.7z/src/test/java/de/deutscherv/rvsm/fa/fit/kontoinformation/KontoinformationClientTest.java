package de.deutscherv.rvsm.fa.fit.kontoinformation;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.FehlerEintrag;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationRequest;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import java.time.LocalDate;
import java.util.List;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Test Kontoinformation Client.
 */
@QuarkusTest
public class KontoinformationClientTest {

    private static final String KTAN_BUND = "70";

    @InjectMock
    @RestClient
    private KontoinformationClient kontoinformationClient;

    @Inject
    private KontoinformationService kontoinformationService;

    @Inject
    private DrvMandant drvMandant;

    private static KontoinformationRequest kontoinformationRequest;
    private static KontoinformationResponse vergleichsResponse;
    private static KontoinformationResponse fehlerResponse;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void setup() {
        kontoinformationRequest = KontoinformationRequest.builder().vsnr("24200202S483")
                .aktuellesDatum(LocalDate.now()).build();
        vergleichsResponse = KontoinformationResponse.builder().vsnr("24200202S483")
                .wartezeit6in24m(6).wartezeit180m(6).wartezeitfehler(false).antragRehaMsat("6")
                .antragRehaArt("21").massnahmeRehaElat("").massnahmeRehaKobs(LocalDate.now())
                .antragRenteLeat("45").bezugRenteLeat("45").antragRenteTlrt("0").bezugRenteTlrt("0")
                .bezugRenteProzent("").beamteneigenschaft(false).rechtsbehelfRente(false)
                .rechtsbehelfReha(false).beschaeftigungGruppe("110").beschaeftigungGrund("10")
                .beschaeftigungKobs(LocalDate.parse("2024-02-13")).altersteilzeitGruppe("113")
                .altersteilzeitGrund("52").altersteilzeitKobs(LocalDate.parse("2024-02-13"))
                .selbstaendigkeit(false).rvSystemFehler(null).unerwarteterFehler("").build();
        fehlerResponse = KontoinformationResponse.builder().vsnr("23270152B506").wartezeit6in24m(42)
                .wartezeit180m(180).wartezeitfehler(true).beamteneigenschaft(true)
                .rvSystemFehler(List.of(FehlerEintrag.builder().statuscode("091118").message("Ein rvSystem Fehler").build()))
                .unerwarteterFehler("Ein unerwarteter Fehler")
                .build();

    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @BeforeEach
    void beforeEach() {
        drvMandant.setInScope(KTAN_BUND);
    }

    /**
     * Test Frage Kontoinformationen ab.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = KTAN_BUND) })
    void frageKontoinformationenAb() {
        when(kontoinformationClient.getKontoinformationen(any(), any()))
                .thenReturn(vergleichsResponse);
        final KontoinformationResponse kontoinformationResponse =
                kontoinformationClient.getKontoinformationen(KTAN_BUND, kontoinformationRequest);
        assertEquals(vergleichsResponse, kontoinformationResponse);
    }



    /**
     * Test aktuelles Datum.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = KTAN_BUND) })
    void testGetAktuellesDatum() {
        final LocalDate aktuellesDatum = assertDoesNotThrow(() -> kontoinformationRequest.getAktuellesDatum());
    }
    /**
     * Test Client wirft Exception.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = KTAN_BUND) })
    void clientThrowException() {
        when(kontoinformationClient.getKontoinformationen(any(), any()))
                .thenReturn(fehlerResponse);

        Antrag antrag = Antrag.builder().vorname("Vorname").nachname("Nachname")
                .vsnr(kontoinformationRequest.getVsnr()).build();

        final LocalDate aktuellesDatum = assertDoesNotThrow(() -> kontoinformationRequest.getAktuellesDatum());

        assertThrows(KontoinformationBestandsFehlerException.class,
                () -> kontoinformationService.getKontoinformationEntity(
                        antrag, aktuellesDatum));
    }
}
