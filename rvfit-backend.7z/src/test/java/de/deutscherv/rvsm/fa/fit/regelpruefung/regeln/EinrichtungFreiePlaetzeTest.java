package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test EinrichtungFreiePlaetze.
 */
class EinrichtungFreiePlaetzeTest {


    private static RehaEinrichtung einrichtungRegensburg;
    private static RehaEinrichtung einrichtungBremen;
    private static RehaEinrichtung einrichtungStuttgart;
    private static RehaEinrichtung einrichtungMuenchen;
    private final EinrichtungFreiePlaetze einrichtungFreiePlaetze = new EinrichtungFreiePlaetze();

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void set() {
        einrichtungRegensburg =
            RehaEinrichtung.builder().smpEinrichtungsId(10018L).name("Testklinik_Dauer")
                .adresse(EinrichtungAnschrift.builder().plz("93053").ort("Regensburg").build())
                .angebote(List.of(
                    Angebot.builder().smpAngebotId(17625L).phase("Startphase").freiePlaetzeWert(4)
                        .durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(17626L).phase("Startphase").freiePlaetzeWert(4)
                        .durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(17625L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(17626L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(17627L).phase("Trainingsphase")
                        .freiePlaetzeWert(0).durchfuehrungsart("Ambulant").build()))
                .build();
        einrichtungBremen =
            RehaEinrichtung.builder().smpEinrichtungsId(10016L).name("Reha-Einrichtung Flughafen")
                .adresse(EinrichtungAnschrift.builder().plz("28199").ort("Bremen").build())
                .angebote(List.of(
                    Angebot.builder().smpAngebotId(17621L).phase("Startphase").freiePlaetzeWert(4)
                        .durchfuehrungsart("stationär").build(),
                    Angebot.builder().smpAngebotId(17621L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("stationär").build(),
                    Angebot.builder().smpAngebotId(17622L).phase("Trainingsphase")
                        .freiePlaetzeWert(-1).durchfuehrungsart("Ambulant").build()))
                .build();
        einrichtungStuttgart =
            RehaEinrichtung.builder().smpEinrichtungsId(10000L).name("Testklinik_DF")
                .adresse(EinrichtungAnschrift.builder().plz("70469").ort("Stuttgart").build())
                .angebote(List.of(
                    Angebot.builder().smpAngebotId(11112L).phase("Startphase").freiePlaetzeWert(-2)
                        .durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11112L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(-2).durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("Ambulant").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("online").build()))
                .build();

        einrichtungMuenchen = RehaEinrichtung.builder().smpEinrichtungsId(10006L)
            .name("Testklinik Milbertshofen am Hart")
            .adresse(EinrichtungAnschrift.builder().plz("80937").ort("München").build())
            .angebote(List.of(
                Angebot.builder().smpAngebotId(17601L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17601L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17602L).phase("Trainingsphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant").build()))
            .build();
    }

    private RehaEinrichtung createRehaEinrichtung(final String phase, final int freiePlaetze) {
        return RehaEinrichtung.builder().name("Testklinik " + phase)
            .angebote(
                List.of(Angebot.builder().phase(phase).freiePlaetzeWert(freiePlaetze).build()))
            .build();
    }

    /**
     * Test Einrichtung freie Plätze, Aussteuern leer.
     */
    @Test
    void einrichtungFreiePlaetzeAussteuernLeerTest() {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().build(), null, null, null, null);
        final List<RegelErgebnis> regelErgebnisse =
            einrichtungFreiePlaetze.pruefeRegel(regelKontext);

        assertTrue(regelErgebnisse.isEmpty());
    }

    /**
     * Test, Einrichtung freie Plätze, Aussteuern keine freie Plätze.
     */
    @Test
    void einrichtungFreiePlaetzeAussteuernKeineFreiePlaetzeTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik_Dauer")
            .angebotStartOrt("Regensburg")
            .angebotStartPlz("93053")
            .angebotStartStrasse("Bajuwarenstraße 11")

            .angebotAufName("Testklinik_Dauer")
            .angebotAufOrt("Regensburg")
            .angebotAufPlz("93053")
            .angebotAufStrasse("Bajuwarenstraße 11")

            .angebotTrainingName("Testklinik_Dauer")
            .angebotTrainingOrt("Regensburg")
            .angebotTrainingPlz("93053")
            .angebotTrainingStrasse("Bajuwarenstraße 11")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungRegensburg),
                List.of(einrichtungRegensburg), List.of(einrichtungRegensburg));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungFreiePlaetze
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE).get());
    }

    /**
     * Test, Einrichtung freie Plätze, Aussteuern auf Anfrage.
     */
    @Test
    void einrichtungFreiePlaetzeAussteuernAufAnfrageTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Reha-Einrichtung Flughafen")
            .angebotStartOrt("Bremen")
            .angebotStartPlz("28199")
            .angebotStartStrasse("Hanna-Kunath-Straße 5")

            .angebotAufName("Reha-Einrichtung Flughafen")
            .angebotAufOrt("Bremen")
            .angebotAufPlz("28199")
            .angebotAufStrasse("Hanna-Kunath-Straße 5")

            .angebotTrainingName("Reha-Einrichtung Flughafen")
            .angebotTrainingOrt("Bremen")
            .angebotTrainingPlz("28199")
            .angebotTrainingStrasse("Hanna-Kunath-Straße 5")
            .build();

        final RegelKontext regelKontext = new RegelKontext(antrag, null, List.of(einrichtungBremen),
            List.of(einrichtungBremen), List.of(einrichtungBremen));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_AUF_ANFRAGE).get());
    }

    /**
     * Test, Einrichtung freie Plätze, Aussteuern auf Angebot pausiert.
     */
    @Test
    void einrichtungFreiePlaetzeAussteuernAufAngebotPausiertTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik_DF")
            .angebotStartOrt("Stuttgart")
            .angebotStartPlz("70469")
            .angebotStartStrasse("Stuttgarter Str. 33")

            .angebotAufName("Testklinik_DF")
            .angebotAufOrt("Stuttgart")
            .angebotAufPlz("70469")
            .angebotAufStrasse("Stuttgarter Str. 33")

            .angebotTrainingName("Testklinik_DF")
            .angebotTrainingOrt("Stuttgart")
            .angebotTrainingPlz("70469")
            .angebotTrainingStrasse("Stuttgarter Str. 33")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungStuttgart),
                List.of(einrichtungStuttgart), List.of(einrichtungStuttgart));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT).get());
    }

    @Test
    void einrichtungFreiePlaetzeErfuelltTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik Milbertshofen am Hart")
            .angebotStartOrt("München")
            .angebotStartPlz("80937")
            .angebotStartStrasse("Neuherbergstraße 114")

            .angebotAufName("Testklinik Milbertshofen am Hart")
            .angebotAufOrt("München")
            .angebotAufPlz("80937")
            .angebotAufStrasse("Neuherbergstraße 114")

            .angebotTrainingName("Testklinik Milbertshofen am Hart")
            .angebotTrainingOrt("München")
            .angebotTrainingPlz("80937")
            .angebotTrainingStrasse("Neuherbergstraße 114")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungMuenchen),
                List.of(einrichtungMuenchen), List.of(einrichtungMuenchen));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    /**
     * Test, nur Training.
     */
    @Test
    void nurTrainingTest() {
        final Antrag antrag = Antrag.builder()
            .angebotTrainingName("Training Name")
            .angebotTrainingOrt("Training Ort")
            .angebotTrainingPlz("Training Plz")
            .angebotTrainingStrasse("Training Str")
            .build();
        // Training erfüllt
        RegelKontext regelKontext = new RegelKontext(antrag, null, null, null, null);
        List<RegelErgebnis> regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());
        regelKontext = new RegelKontext(antrag, null, null, null,
            List.of(createRehaEinrichtung("Trainingsphase", 4)));
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());

        // auf anfrage
        regelKontext = new RegelKontext(antrag, null, null, null,
            List.of(createRehaEinrichtung("Trainingsphase", -1)));
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_AUF_ANFRAGE).get());

        regelKontext = new RegelKontext(antrag, null, null, null,
            List.of(createRehaEinrichtung("Trainingsphase", 0)));
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungFreiePlaetze
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE).get());
        regelKontext = new RegelKontext(antrag, null, null, null,
            List.of(createRehaEinrichtung("Trainingsphase", -2)));
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT).get());
    }

    /**
     * Test, nur Auffrischung.
     */
    @Test
    void nurAuffrischungTest() {
        final Antrag antrag = Antrag.builder()
            .angebotAufName("Auffrischung Name")
            .angebotAufOrt("Auffrischung Ort")
            .angebotAufPlz("Auffrischung Plz")
            .angebotAufStrasse("Auffrischung Str")
            .build();
        // Training erfüllt
        RegelKontext regelKontext = new RegelKontext(antrag, null, null, null, null);
        List<RegelErgebnis> regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        RegelErgebnis ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);

        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());
        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());

        // auf anfrage
        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -1)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_AUF_ANFRAGE).get());

        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -0)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungFreiePlaetze
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE).get());
        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -2)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT).get());
    }

    /**
     * Test, Auffrischung und Training.
     */
    @Test
    void auffrischungUndTrainingTest() {
        final Antrag antrag = Antrag.builder()
            .angebotAufName("Auffrischung Name")
            .angebotAufOrt("Auffrischung Ort")
            .angebotAufPlz("Auffrischung Plz")
            .angebotAufStrasse("Auffrischung Str")

            .angebotTrainingName("Training Name")
            .angebotTrainingOrt("Training Ort")
            .angebotTrainingPlz("Training Plz")
            .angebotTrainingStrasse("Training Str")
            .build();
        // Training erfüllt
        RegelKontext regelKontext = new RegelKontext(antrag, null, null, null, null);
        List<RegelErgebnis> regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        RegelErgebnis ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);

        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());
        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungFreiePlaetze.getRegelDetail(RegelUtils.ERFUELLT).get());

        // auf anfrage
        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -1)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_AUF_ANFRAGE).get());

        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -0)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungFreiePlaetze
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE).get());
        regelKontext = new RegelKontext(antrag, null, null,
            List.of(createRehaEinrichtung("Auffrischungsphase", -2)), null);
        regelErgebnisse = einrichtungFreiePlaetze.pruefeRegel(regelKontext);
        ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(
            einrichtungFreiePlaetze.getRegelDetail(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT).get());
    }
}
