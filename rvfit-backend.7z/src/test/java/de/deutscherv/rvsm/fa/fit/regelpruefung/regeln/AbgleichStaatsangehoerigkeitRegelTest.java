package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AbgleichStaatsangehoerigkeitRegelTest {

    private final AbgleichStaatsangehoerigkeitRegel regel = new AbgleichStaatsangehoerigkeitRegel();

    @Test
    void keineDatenTest() {
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).as("Die Nachricht sollte entsprechend AUSSTEUERN_KEINE_DATEN sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    @Test
    void positivTest() {

        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().staatsangehoerigkeit("keine").build(), Stammdaten.builder().staatsangehoerigkeit("keine").build(), null,
                null,
                null);
        final List<RegelErgebnis> pruefeRegel = regel
                .pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Erfüllt sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).as("Die Nachricht sollte \"Antragsdaten und Stammdaten stimmen nicht überein\"")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    @Test
    void negativTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().staatsangehoerigkeit("keine").build(), Stammdaten.builder().staatsangehoerigkeit("alle").build(), null,
                null,
                null);
        final List<RegelErgebnis> pruefeRegel = regel
                .pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);

        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.AUSSTEUERN);

        assertThat(pruefeRegel).as("Die Nachricht sollte AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT).get());

    }
}
