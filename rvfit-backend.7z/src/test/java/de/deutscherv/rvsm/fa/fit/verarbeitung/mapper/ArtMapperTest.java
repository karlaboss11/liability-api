package de.deutscherv.rvsm.fa.fit.verarbeitung.mapper;

import de.deutscherv.rvsm.fa.fit.openapi.model.VerarbeitungsartDto;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ArtMapperTest {

    private ArtMapper artMapper;

    /**
     * Test ob im Mapping die Source- und Target-Werte korrekt zugeordnet sind.
     */
    @Test
    void testToDtoAllValidValues() {
        artMapper = new ArtMapperImpl();
        Arrays.stream(Art.values()).toList().forEach(art -> {
            final VerarbeitungsartDto verarbeitungsartDto = artMapper.toDto(art);
            assertEquals(verarbeitungsartDto.getArt().name(), art.name());
        });
    }

}
