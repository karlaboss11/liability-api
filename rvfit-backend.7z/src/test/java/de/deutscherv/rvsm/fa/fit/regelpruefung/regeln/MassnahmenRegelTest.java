package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

class MassnahmenRegelTest {

    private static final String ERFUELLT =
            "In den letzten 12 Monaten wurde keine Rehabilitations-Maßnahme abgeschlossen.";
    private static final String NICHT_ERFUELLT_AUSSTEUERN =
            "In den letzten 12 Monaten wurde eine Rehabilitations-Maßnahme abgeschlossen.";

    private final MassnahmenRegel regel = new MassnahmenRegel();

    /**
     * Testet auf Erfüllt bei keiner Maßnahme.
     */
    @Test
    void keineMassnahmeTest() {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    /**
     * Testet auf Aussteuern bei keinen Antragsdaten.
     */
    @Test
    void keineAntragsdatenTest() {
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(null, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo("Es liegen keine vollstaendigen Daten vor");
    }

    @Test
    void massnahmeErfuelltTest() {

        List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder()
                        .massnahmeRehaElat("11")// nicht in der ELAT Liste
                        .build()).toList();

        RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);

        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
        kontoinformationen =
                Stream.of(Kontoinformation.builder()
                        .massnahmeRehaElat("10")// in der ELAT Liste
                        .massnahmeRehaKobs(LocalDate.now().minusMonths(13))
                        .build()).toList();

        teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    @Test
    void aussteuernTest() {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder()
                        .massnahmeRehaElat("10")// in der ELAT Liste
                        // .massnahmeRehaKobs(LocalDate.now().minusMonths(1))
                        .build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(NICHT_ERFUELLT_AUSSTEUERN);
    }

    @ParameterizedTest
    @ValueSource(ints = { 1, 12 })
    void aussteuernTest2(int massnahmeRehaKobsMonthsBeforeNow) {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().massnahmeRehaElat("10")// in der ELAT Liste
                                .massnahmeRehaKobs(LocalDate.now()
                                        .minusMonths(massnahmeRehaKobsMonthsBeforeNow)).build())
                        .toList();
        final RegelErgebnis teilErgebnis = getTeilErgebnis(kontoinformationen, LocalDate.now(),
                Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(
                PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(NICHT_ERFUELLT_AUSSTEUERN);
    }

    @Test
    void aussteuernWhenMassnahmeRehaElatHasQuestionMark() {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().massnahmeRehaElat("??").build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    @Test
    void erfuelltWhenMassnahmeRehaElatHas00() {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().massnahmeRehaElat("00").build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    private RegelErgebnis getTeilErgebnis(final List<Kontoinformation> kontoinformationen,
            final LocalDate antragsDatum, final Stammdaten stammdaten) {

        final RegelKontext regelKontext =
                new RegelKontext(Antrag.builder().kontoinformationen(kontoinformationen)
                        .antragsDatum(antragsDatum).build(), stammdaten, null, null, null);

        return regel.pruefeRegel(regelKontext).getFirst();
    }
}
