package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.StammdatenMapper;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
@Slf4j
class PapierAntraegeServiceTest {

    @Inject
    private AntragRepository antragRepository;
    @Inject
    private AntragMapper antragMapper;
    @Inject
    private StammdatenMapper stammdatenMapper;
    @Inject
    private RVFitJsonSchemaValidator rvFitJsonSchemaValidator;
    @Inject
    private JsonWebToken jwt;
    @Inject
    private PapierantragsPruefung papierantragsPruefung;
    @Inject
    private FluentProducerTemplate producerTemplate;
    @Inject
    private DrvMandant drvMandant;

    @Test
    void isPapierantragDtoValidTest() {
        final PapierantragDto papierantragDto = PapierantragTestDaten.getPapierantrag(TestPerson.PETER_PAN);
        final PapierAntraegeService papierAntraegeService = new PapierAntraegeService(antragRepository, antragMapper, stammdatenMapper,
                papierantragsPruefung,
                jwt, rvFitJsonSchemaValidator,
                producerTemplate, drvMandant);
        assertTrue(papierAntraegeService.isPapierantragDtoValid(papierantragDto));

    }

    @Test
    void isPapierantragDtoValidTestNull() {
        final PapierAntraegeService papierAntraegeService = new PapierAntraegeService(antragRepository, antragMapper, stammdatenMapper,
                papierantragsPruefung,
                jwt, rvFitJsonSchemaValidator,
                producerTemplate, drvMandant);
        assertFalse(papierAntraegeService.isPapierantragDtoValid(null));
    }

    @Test
    void isPapierantragDtoValidTestInvalidVsnr() {
        final PapierantragDto papierantragDto = PapierantragTestDaten.getPapierantrag(TestPerson.PETER_PAN);
        final PapierAntraegeService papierAntraegeService = new PapierAntraegeService(antragRepository, antragMapper, stammdatenMapper,
                papierantragsPruefung,
                jwt, rvFitJsonSchemaValidator,
                producerTemplate, drvMandant);
        papierantragDto.getVersicherter().setVsnr("XXXX");
        LOG.atInfo()
                .addArgument(papierantragDto.getAntrag().getVsnr())
                .log("Vsnr: [{}]");
        assertFalse(papierAntraegeService.isPapierantragDtoValid(papierantragDto));
    }

}
