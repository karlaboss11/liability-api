package de.deutscherv.rvsm.fa.fit.security;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TestRessource.
 */
@Path("/csrf-token-test")
public class TestRessource {

    /**
     * Get Test.
     * @return Antwort
     */
    @GET
    public Response getTest() {
        return Response.accepted().build();
    }

    /**
     * Post Test.
     * @param json JSON
     * @return Antwort
     */
    @POST
    @Consumes({ "application/json" })
    @Produces({ "application/json", "application/problem+json" })
    public Response postTest(@Valid @NotNull final MyClazz json) {
        return Response.accepted(json).build();
    }

    /**
     * Klasse mit Key :-).
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MyClazz {
        private String key;
    }
}
