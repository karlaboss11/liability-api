package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.response.ValidatableResponse;
import java.util.Map;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;

/**
 * Test CsrfCookieHeader.
 */
@QuarkusTest
@TestProfile(CsrfCookieHeaderTest.class)
public class CsrfCookieHeaderTest implements QuarkusTestProfile {

    @ConfigProperty(name = "quarkus.csrf-reactive.token-header-name")
    private String tokenHeaderName;

    @Override
    public Map<String, String> getConfigOverrides() {
        return Map.of(
                "quarkus.rest-csrf.enabled", "true",
                "quarkus.rest-csrf.require-form-url-encoded", "true",
                "quarkus.rest-csrf.token-signature-key", "SaOmNnzpzDwEnBjHoRPPxGtFUREAH4IH",
                "quarkus.rest-csrf.cookie-force-secure", "true"
        );
    }

    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testPostMitCsrfTokenBekommtAntwortOk200() {
        final ValidatableResponse validatableResponse = given()
                .when()
                .get("/ping")
                .then();
        final String csrfCookie = validatableResponse
                .extract()
                .cookie("csrf-token");
        final String header = validatableResponse.extract().header(tokenHeaderName);
        given()
                .when()
                .cookie("csrf-token", csrfCookie)
                .header(tokenHeaderName, header)
                .contentType("application/json")
                .body(new TestRessource.MyClazz("value"))
                .post("/csrf-token-test")
                .then()
                .statusCode(202);

    }

    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void testPostOhneCsrfTokenBekommtAntwortBadRequest400() {
        given()
                .when()
                .contentType("application/json")
                .body(new TestRessource.MyClazz("value"))
                .post("/csrf-token-test")
                .then()
                .statusCode(400);

    }

}
