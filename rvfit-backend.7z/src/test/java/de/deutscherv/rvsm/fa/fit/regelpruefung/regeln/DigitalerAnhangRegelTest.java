package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class DigitalerAnhangRegelTest {

    private final DigitalerAnhangRegel regel = new DigitalerAnhangRegel();

    @Test
    void keineDatenTest() {
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());

        assertThat(pruefeRegel.getFirst().getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel.getFirst().getDetail()).isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).orElseThrow());
    }

    @Test
    void positivTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().hatDigitalenAnhang(false).build(), null, null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel.getFirst().getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel.getFirst().getDetail()).isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).orElseThrow());
    }

    @Test
    void negativTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().hatDigitalenAnhang(true).build(),
                null,null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel.getFirst().getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel.getFirst().getDetail()).isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN).orElseThrow());

    }
}
