package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AbgleichAntragStammdatenRegelTest {

    private static final String ERFUELLT_ANTRAGSDATEN_STIMMT_STAMMDATEN =
            "Antragsdaten und Stammdaten stimmen überein";
    private static final String AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT_STAMMDATEN =
            "Antragsdaten und Stammdaten stimmen nicht überein";
    private static final String AUSSTEUERN_STAMMDATEN_NULL = "Stammdaten sind nicht vorhanden";

    private static final RegelEngine engine = new RegelEngine(List.of(new AbgleichPlzRegel()));

    /**
     * Testet den erfolgreichen Abgleich mit den Stammdaten.
     */
    @Test
    void abgleichAntragsdatenMitStammdatenErfolgreich() {
        final RegelErgebnis teilErgebnis = getTeilErgebnis(
                Antrag.builder().vsnr("55 270152 b 555").nachname("abweichenderNachname").vorname("vorname")
                        .geburtsdatum(LocalDate.of(1977, 1, 8)).strasse("Strasse1 ").hausnummer(" 12A   ")
                        .plz(" 1235 ").wohnort(" WOHNort2").land("000").build(),
                Stammdaten.builder().vsnr(" 55 270152 B 555 ").nachname(" NACHNAME1 ")
                        .vorname(" VORNAME2 ").geburtsdatum(LocalDate.of(1977, 1, 8)).strasse("strasse")
                        .hausnummer("12a").plz("12345").wohnort("wohnort").land("000").build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail())
                .isEqualTo(AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT_STAMMDATEN);
    }

    /**
     * Testet den nicht erfolgreichen Abgleich mit den Stammdaten.
     */
    @Test
    void abgleichAntragsdatenMitStammdatenNichtErfolgreich() {
        final RegelErgebnis teilErgebnis = getTeilErgebnis(
                Antrag.builder().vsnr("55 270152 B 554").nachname("abweichenderNachname").vorname("vorname")
                        .geburtsdatum(LocalDate.of(1977, 1, 8)).strasse("Strasse1 ").hausnummer(" 12A   ")
                        .plz(" 12357 ").wohnort(" WOHNort2").land("000").build(),
                Stammdaten.builder().vsnr("55 270152 B 553").nachname("abweichenderNachname").vorname("vorname")
                        .geburtsdatum(LocalDate.of(1977, 1, 8)).strasse("strasse").hausnummer("12a")
                        .plz("12345").wohnort("wohnort").land("000").build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail())
                .isEqualTo(AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT_STAMMDATEN);
    }

    /**
     * Testet den nicht erfolgreichen Abgleich mit den Stammdaten, da diese nicht vorhanden sind.
     */
    @Test
    void abgleichAntragsdatenMitStammdatenNichtVorhanden() {
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(
                        Antrag.builder().vsnr("55 270152 B 554").nachname("abweichenderNachname").vorname("vorname")
                                .geburtsdatum(LocalDate.of(1977, 1, 8)).strasse("Strasse1 ")
                                .hausnummer(" 12A   ").plz(" 1235 ").wohnort(" WOHNort2").land("000").build(),
                        null);

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_STAMMDATEN_NULL);
    }

    private RegelErgebnis getTeilErgebnis(final Antrag antrag, final Stammdaten stammdaten) {
        final RegelKontext regelKontext = new RegelKontext(antrag, stammdaten, null, null, null);
        final RegelErgebnis gesamtErgebnis =
                engine.check(List.of(RegelName.REGEL_ABGLEICH_PLZ), regelKontext);
        return gesamtErgebnis.getDetailErgebnisse().getFirst();
    }
}
