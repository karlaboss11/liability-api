package de.deutscherv.rvsm.fa.fit.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class JsonTest {

    @Test
    void jsonToStringTest() {
        final String jsonString = JSONTestUtils.jsonToString("psd.json");

        assertThat(jsonString).contains("70", "03080800B018", "VERSICHERTER");
    }

    @SneakyThrows
    @Test
    void testObjectToJsonShouldCreateJsonString() {
        final List<Angebot> angebote = createAngebote();
        final EinrichtungAnschrift adresse = createEinrichtungAnschrift();
        final RehaEinrichtung rehaEinrichtungInput = createRehaEinrichtung(angebote, adresse);

        final String jsonString = Json.objectToJson(rehaEinrichtungInput);
        assertThat(jsonString).isNotNull();

        final RehaEinrichtung rehaEinrichtungOutput =
            new ObjectMapper().reader().readValue(jsonString, RehaEinrichtung.class);
        assertThat(rehaEinrichtungOutput).isNotSameAs(rehaEinrichtungInput)
            .isEqualTo(rehaEinrichtungInput).hasFieldOrPropertyWithValue("angebote", angebote)
            .hasFieldOrPropertyWithValue("adresse", adresse)
            .hasFieldOrPropertyWithValue("ktan", "70");
    }

    @SneakyThrows
    @Test
    void testObjectToJsonShouldHandleExceptionAndReturnNullValue() {
        final Object value = new Object();
        assertThrows(RvfitException.class, () -> Json.objectToJson(value));
    }

    @SneakyThrows
    @Test
    void testAnonymizeJsonFields() {
        final ObjectMapper objectMapper = new ObjectMapper();

        final String jsonString = JSONTestUtils.jsonToString("dga.json");
        final JsonNode originalNode = objectMapper.readTree(jsonString);

        final Set<String> jsonFieldsToAnonymize = Set.of("templateUuid", "inputs");
        final String anonymizedJson = Json.anonymizeJsonFields(jsonString, jsonFieldsToAnonymize);
        final JsonNode anonymizedNode = objectMapper.readTree(anonymizedJson);

        assertThat(originalNode.get(0).get("templateUuid").textValue())
            .isEqualTo("9329a746-2e78-4b86-afa3-54d53773d15f");
        assertThat(anonymizedNode.get(0).get("templateUuid").textValue())
            .isEqualTo("*****");
        assertThat(anonymizedNode.get(0).get("inputs").get("natuerlichePersonen").get(0).get("titel"))
            .isEqualTo(originalNode.get(0).get("inputs").get("natuerlichePersonen").get(0).get("titel"));
        assertThat(originalNode.get(0).get("inputs").get("natuerlichePersonen").get(0).get("vorname").textValue())
            .isEqualTo("Wario");
        assertThat(anonymizedNode.get(0).get("inputs").get("natuerlichePersonen").get(0).get("vorname").textValue())
            .isEqualTo("*****");

    }

    private static EinrichtungAnschrift createEinrichtungAnschrift() {
        final EinrichtungAnschrift adresse = new EinrichtungAnschrift();
        adresse.setPlz("12345");
        adresse.setStrasse("Langestraße");
        adresse.setHausnummer("70b");
        return adresse;
    }

    private static List<Angebot> createAngebote() {
        return List.of(Angebot.builder().uuid(UUID.randomUUID()).smpAngebotId(1L).dauer(90).phase("NamePhase")
            .durchfuehrungsart("Stationaer").build());
    }

    private static RehaEinrichtung createRehaEinrichtung(final List<Angebot> angebote,
        final EinrichtungAnschrift adresse) {
        final RehaEinrichtung rehaEinrichtungInput = new RehaEinrichtung();
        rehaEinrichtungInput.setKtan("70");
        rehaEinrichtungInput.setName("Meine Reha");
        rehaEinrichtungInput.setEmail("test@test.test");
        rehaEinrichtungInput.setResc("001");
        rehaEinrichtungInput.setUuid(UUID.randomUUID());
        rehaEinrichtungInput.setSmpEinrichtungsId(1L);
        rehaEinrichtungInput.setTelefonnummer("123456");
        rehaEinrichtungInput.setAngebote(angebote);
        rehaEinrichtungInput.setAdresse(adresse);
        rehaEinrichtungInput.setPostanschrift(adresse);
        return rehaEinrichtungInput;
    }

}
