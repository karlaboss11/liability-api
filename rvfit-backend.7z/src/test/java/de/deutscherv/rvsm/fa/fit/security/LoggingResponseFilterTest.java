package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.fa.fit.log.CEFCommons;
import de.deutscherv.rvsm.fa.fit.log.CEFEventType;
import de.deutscherv.rvsm.fa.fit.log.CEFLogger;
import jakarta.ws.rs.HttpMethod;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import java.net.URI;
import java.time.Instant;
import java.util.Date;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;

import static org.mockito.ArgumentMatchers.any;

class LoggingResponseFilterTest {

    private LoggingResponseFilter responseFilter;
    private CEFLogger cefLogger;

    @BeforeEach
    void init() {
        final LoggingRequestFilter requestFilter = Mockito.mock(LoggingRequestFilter.class);
        Mockito.when(requestFilter.getUserId()).thenReturn("UserId");
        Mockito.when(requestFilter.getHostOrIpAddress(any())).thenReturn("rvfit-frontend.drv");
        Mockito.when(requestFilter.getDrvMandant()).thenReturn(70L);

        final CEFCommons cefCommons = Mockito.mock(CEFCommons.class);
        Mockito.when(cefCommons.getMessage(any())).thenCallRealMethod();

        cefLogger = Mockito.mock(CEFLogger.class, InvocationOnMock::callRealMethod);
        responseFilter = new LoggingResponseFilter(requestFilter, cefLogger, cefCommons);
    }

    @Test
    @SneakyThrows
    void testUnauthorized() {
        final UriInfo uriInfo = Mockito.mock(UriInfo.class);
        Mockito.when(uriInfo.getRequestUri()).thenReturn(URI.create("http://rvfit-backend.drv/antrag"));

        final ContainerRequestContext requestContext = Mockito.mock(ContainerRequestContext.class);
        Mockito.when(requestContext.getMethod()).thenReturn(HttpMethod.GET);
        Mockito.when(requestContext.getUriInfo()).thenReturn(uriInfo);
        Mockito.when(requestContext.getDate()).thenReturn(Date.from(Instant.now()));

        final ContainerResponseContext responseContext = Mockito.mock(ContainerResponseContext.class);
        Mockito.when(responseContext.getStatus()).thenReturn(401);
        final Response.StatusType statusType = Mockito.mock(Response.StatusType.class);
        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.CLIENT_ERROR);
        Mockito.when(responseContext.getStatusInfo()).thenReturn(statusType);

        responseFilter.filter(requestContext, responseContext);

        Mockito.verify(cefLogger).atMedium(CEFEventType.APPLICATION, 3030);
    }

    @Test
    @SneakyThrows
    void testForbidden() {
        final UriInfo uriInfo = Mockito.mock(UriInfo.class);
        Mockito.when(uriInfo.getRequestUri()).thenReturn(URI.create("http://rvfit-backend.drv/antrag"));

        final ContainerRequestContext requestContext = Mockito.mock(ContainerRequestContext.class);
        Mockito.when(requestContext.getMethod()).thenReturn(HttpMethod.GET);
        Mockito.when(requestContext.getUriInfo()).thenReturn(uriInfo);
        Mockito.when(requestContext.getDate()).thenReturn(Date.from(Instant.now()));

        final ContainerResponseContext responseContext = Mockito.mock(ContainerResponseContext.class);
        Mockito.when(responseContext.getStatus()).thenReturn(403);
        final Response.StatusType statusType = Mockito.mock(Response.StatusType.class);
        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.CLIENT_ERROR);
        Mockito.when(responseContext.getStatusInfo()).thenReturn(statusType);

        responseFilter.filter(requestContext, responseContext);

        Mockito.verify(cefLogger).unauthorized(any(), any(), any(), any(), any(), any(), any(), any(), any(), any());
        Mockito.verify(cefLogger).atMedium(CEFEventType.APPLICATION, 3030);
    }

}
