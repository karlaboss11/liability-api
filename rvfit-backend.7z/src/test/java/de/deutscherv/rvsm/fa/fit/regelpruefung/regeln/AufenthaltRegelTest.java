package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test Aufenthalt.
 */
public class AufenthaltRegelTest {
    private final AufenthaltRegel regel = new AufenthaltRegel();

    /**
     * Test keine Daten vorhanden.
     */
    @Test
    void keineDatenTest() {
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).as("Die Nachricht sollte entsprechend AUSSTEUERN_KEINE_DATEN sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    /**
     * Test positiver Fall.
     */
    @Test
    void positivTest() {

        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().build(), Stammdaten.builder().land("000").build(), null, null,
                null);
        final List<RegelErgebnis> pruefeRegel = regel
                .pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Erfüllt sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).as("Die Nachricht sollte \"Antragsdaten und Stammdaten stimmen nicht überein\"")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    /**
     * Test negativer Fall.
     */
    @Test
    void negativTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().build(), Stammdaten.builder().land("999").build(), null, null,
                null);
        final List<RegelErgebnis> pruefeRegel = regel
                .pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);

        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.AUSSTEUERN);

        assertThat(pruefeRegel).as("Die Nachricht sollte AUSSTEUERN sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN).get());

    }

    /**
     * Test nicht erfuellt - Aussteuern.
     */
    @Test
    void negativNichterfuelltAussteuernTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().build(), Stammdaten.builder().land("dis is no code").build(), null, null,
                null);
        final List<RegelErgebnis> pruefeRegel = regel
                .pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);

        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);

        assertThat(pruefeRegel).as("Die Nachricht sollte NICHT_ERFUELLT_AUSSTEUERN sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.NICHT_ERFUELLT_AUSSTEUERN).get());

    }
}
