package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service;

import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.kontoinformation.KontoinformationService;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PruefergebnisServiceTest {

    private static final Long ANGEBOT_ID = 1001L;

    @Mock
    private AntragRepository mockAntragRepository;

    @Mock
    private SelbstmeldeportalService mockSelbstmeldeportalService;

    @Mock
    private KontoinformationService mockKontoinformationService;

    private PruefergebnisService pruefergebnisService;

    @BeforeEach
    public void setUp() {
        pruefergebnisService =
                new PruefergebnisService(null, null, null, mockAntragRepository, null, null,
                        null, mockSelbstmeldeportalService, null, null, null, null, null);
    }

    @Test
    void testEinrichtungenBySnpAngebotId_ReturnsFilteredResults() {
        RehaEinrichtung einrichtung = RehaEinrichtung.builder()
                .angebote(new ArrayList<>(List.of(Angebot.builder().smpAngebotId(ANGEBOT_ID).build(),
                        Angebot.builder().smpAngebotId(9999L).build())))
                .build();
        when(mockSelbstmeldeportalService.getEinrichtungByAngebotId("80337", ANGEBOT_ID))
                .thenReturn(Optional.of(einrichtung));
        List<RehaEinrichtung> result = pruefergebnisService.einrichtungenBySmpAngebotId("80337", ANGEBOT_ID);

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testEinrichtungenBySnpAngebotId_ReturnsEmptyList_WhenNoMatchingEinrichtung() {
        when(mockSelbstmeldeportalService.getEinrichtungByAngebotId("80337", ANGEBOT_ID))
                .thenReturn(Optional.empty());
        List<RehaEinrichtung> result = pruefergebnisService.einrichtungenBySmpAngebotId("80337", ANGEBOT_ID);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
