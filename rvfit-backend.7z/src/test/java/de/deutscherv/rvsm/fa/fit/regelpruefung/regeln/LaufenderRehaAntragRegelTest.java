package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test laufenderRehaAntragRegel.
 */
class LaufenderRehaAntragRegelTest {

    public static final String AUSSTEUERN_KEINE_DATEN = "Es liegen keine vollstaendigen Daten vor.";
    public static final String ERFUELLT = "Es gibt keinen laufenden Reha-Antrag.";
    public static final String NICHT_ERFUELLT_AUSSTEUERN = "Es gibt einen laufenden Reha-Antrag.";

    private final LaufenderRehaAntragRegel regel = new LaufenderRehaAntragRegel();

    /**
     * Test, aussteuern wegen fehlender Daten.
     */
    @Test
    void testAusteuernWegenFehlenderDaten() {
        final RegelKontext regelKontext = new RegelKontext();

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);

        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.AUSSTEUERN, RegelName.REGEL_LAUFENDERREHAANTRAG,
                AUSSTEUERN_KEINE_DATEN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test, aussteuern wegen question mark.
     */
    @Test
    void austeuernWhenQuestionMark() {
        final RegelKontext regelKontext =
            getRegelKontext(Kontoinformation.builder().antragRehaMsat("?").antragRehaArt("??").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);

        final RegelErgebnis expectedRegelErgebnis = new RegelErgebnis(PruefErgebnis.AUSSTEUERN, RegelName.REGEL_LAUFENDERREHAANTRAG,
            AUSSTEUERN_KEINE_DATEN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test, Regel erfüllt Antragsrehan MSAT nicht leer und nicht 4 oder 8.
     */
    @Test
    void testRegelErfuelltAntragsRehaMsatNichtLeerUndNicht4oder8() {
        final RegelKontext regelKontext =
            getRegelKontext(Kontoinformation.builder().antragRehaMsat("3").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.ERFUELLT, RegelName.REGEL_LAUFENDERREHAANTRAG,
                ERFUELLT);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test erfüllt wenn Reha-MSAT 0 und Rehaart 00.
     */
    @Test
    void erfuelltWhen0And00() {
        final RegelKontext regelKontext =
            getRegelKontext(Kontoinformation.builder().antragRehaMsat("0").antragRehaArt("00").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.ERFUELLT, RegelName.REGEL_LAUFENDERREHAANTRAG,
                ERFUELLT);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test, regel erfüllt Antragsreha MSAT leer und Rehaart leer.
     */
    @Test
    void testRegelErfuelltAntragsRehaMsatLeerUndRehaArtLeer() {
        final RegelKontext regelKontext = getRegelKontext(Kontoinformation.builder().build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.ERFUELLT, RegelName.REGEL_LAUFENDERREHAANTRAG,
                ERFUELLT);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test, Regel nicht erfüllt Antragsreha MSAT nicht leer und AntragrehaMSAT 4 und Rehart 11.
     */
    @Test
    void testRegelNichtErfuelltAntragsRehaMsatNichtLeerUndAntragRehaMsat4UndRehaArt11() {
        final RegelKontext regelKontext = getRegelKontext(
            Kontoinformation.builder().antragRehaMsat("4").antragRehaArt("11").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_LAUFENDERREHAANTRAG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test, Regel nicht erfüllt Antragsreha MSAT nicht leer und AntragrehaMSAT 4 und Rehart null.
     */
    @Test
    void testRegelNichtErfuelltAntragsRehaMsatNichtLeerUndAntragRehaMsat4UndRehaArtNull() {
        final RegelKontext regelKontext = getRegelKontext(
            Kontoinformation.builder().antragRehaMsat("4").antragRehaArt(null).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.AUSSTEUERN, RegelName.REGEL_LAUFENDERREHAANTRAG,
                AUSSTEUERN_KEINE_DATEN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    private RegelKontext getRegelKontext(Kontoinformation kontoinformation) {
        final Antrag antrag = new Antrag();
        antrag.setKontoinformationen(List.of(kontoinformation));

        final RegelKontext regelKontext = new RegelKontext();
        regelKontext.setAntrag(antrag);

        return regelKontext;
    }
}