package de.deutscherv.rvsm.fa.fit.security;

import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

/**
 * Testet die Funktionalität des BasicAuthFilter's.
 */
class SecurityHeaderFilterTest {

    private SecurityHeaderFilter securityHeaderFilter;

    private ClientRequestContext clientRequestContext;

    /**
     * Init Tests.
     */
    @BeforeEach
    public void init() {
        securityHeaderFilter = new SecurityHeaderFilter();
        securityHeaderFilter.setDisableAuthorization(false);
        clientRequestContext = Mockito.mock(ClientRequestContext.class);
    }

    /**
     * Testet, ob die Abschaltung des Filter's funktioniert.
     */
    @Test
    void testAuthorizationDisabled() {
        final MultivaluedMap<String, Object> headers = Mockito.mock(MultivaluedHashMap.class);
        Mockito.doReturn(headers).when(clientRequestContext).getHeaders();
        securityHeaderFilter.setDisableAuthorization(true);

        assertDoesNotThrow(() -> securityHeaderFilter.filter(clientRequestContext));

        Mockito.verify(headers, Mockito.times(1)).add(HttpHeaders.CONTENT_TYPE,
            MediaType.APPLICATION_JSON);
        Mockito.verify(headers, Mockito.times(1)).add("Strict-Transport-Security",
            "max-age=31536000; includeSubDomains");
        Mockito.verify(headers, Mockito.times(1)).add("X-Content-Type-Options", "nosniff");
        Mockito.verify(headers, Mockito.times(1)).add("X-Frame-Options", "SAMEORIGIN");
        Mockito.verify(headers, Mockito.times(1)).add("Content-Security-Policy",
            "default-src 'self'");
        Mockito.verify(headers, Mockito.times(1)).add("X-XSS-Protection", "0");
        Mockito.verify(headers, Mockito.times(1)).add("Feature-Policy",
            "geolocation 'none'; midi 'none'; notifications 'none'; push 'none'; sync-xhr 'none'; microphone 'none'; camera 'none'; "
                + "magnetometer 'none'; gyroscope 'none'; speaker 'none'; vibrate 'none'; fullscreen 'self'; payment 'none';");
        Mockito.verify(headers, Mockito.times(1)).add("Cache-Control",
            "no-cache, no-store, must-revalidate");
        Mockito.verify(headers, Mockito.times(1)).add("Referrer-Policy",
            "same-origin");
    }

}
