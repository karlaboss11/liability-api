package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AltersteilzeitRegelTest {

    private static final List<String> AZ_GRUPPEN = List.of("103", "108", "142", "000");
    private static final List<String> AZ_GRUENDE = List.of("10", "50", "00");

    private final AltersteilzeitRegel regel = new AltersteilzeitRegel();

    @Test
    void testKeineDaten() {
        final RegelKontext kontext = new RegelKontext();
        final Antrag antr = new Antrag();
        final List<RegelErgebnis> ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).hasSize(1);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getDetail)
                .isEqualTo("Es konnte nicht ermittelt werden, ob Altersteilzeit vorliegt. Bitte manuell prüfen.");
    }

    @Test
    void testGruppe() {
        final RegelKontext kontext = new RegelKontext();
        final Antrag antr = new Antrag();
        final Kontoinformation ki = new Kontoinformation();
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        List<RegelErgebnis> ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);
        for (final String gruppe : AZ_GRUPPEN) {
            ki.setAltersteilzeitGruppe(gruppe);
            antr.setKontoinformationen(List.of(ki));
            kontext.setAntrag(antr);
            ergebnis = regel.pruefeRegel(kontext);
            assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);
        }
        ki.setAltersteilzeitGruppe("232");
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);

        ki.setAltersteilzeitGruppe("???");
        ki.setAltersteilzeitGrund("??");
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.AUSSTEUERN);

    }

    @Test
    void testGrund() {

        final RegelKontext kontext = new RegelKontext();
        final Antrag antr = new Antrag();
        final Kontoinformation ki = new Kontoinformation();
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        List<RegelErgebnis> ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);
        ki.setAltersteilzeitGruppe("108");
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);
        for (final String grund : AZ_GRUENDE) {
            ki.setAltersteilzeitGrund(grund);
            antr.setKontoinformationen(List.of(ki));
            kontext.setAntrag(antr);
            ergebnis = regel.pruefeRegel(kontext);
            assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);
        }
        ki.setAltersteilzeitGrund("111");
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);

    }

    @Test
    void testKobs() {

        final RegelKontext kontext = new RegelKontext();
        final Antrag antr = new Antrag();
        final Kontoinformation ki = new Kontoinformation();
        antr.setKontoinformationen(List.of(ki));
        kontext.setAntrag(antr);
        List<RegelErgebnis> ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.ERFUELLT);

        ki.setAltersteilzeitGruppe("108");
        ki.setAltersteilzeitGrund("10");
        ki.setAltersteilzeitKobs(LocalDate.now());
        antr.setKontoinformationen(List.of(ki));
        antr.setAntragsDatum(LocalDate.now().minusMonths(12));
        kontext.setAntrag(antr);
        ergebnis = regel.pruefeRegel(kontext);
        assertThat(ergebnis).first().extracting(RegelErgebnis::getPruefErgebnis).isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);

    }

}
