package de.deutscherv.rvsm.fa.fit.rest;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Tests von ClientErrorMessages.
 *
 * @author 007386
 */
@QuarkusTest
class HttpStatusCodeTest {

    @Test
    void nichtDefinierterEndpointReturns404() {
        RestAssured.given()
                .when()
                .get("/blub")
                .then()
                .statusCode(404);
    }

    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ParameterizedTest
    @ValueSource(strings = { "/antraege/eantrag", "/rehaeinrichtungen/autovervollstaendigungen", "/papierantraege" })
    void nichtDefinierteHttpMethodeReturns405(final String path) {
        RestAssured.given()
                .when()
                .delete(path)
                .then()
                .statusCode(405);
    }

    @ParameterizedTest
    @ValueSource(strings = { "/rehaeinrichtungen" })
    void nichtAuthentifizierteAnfrageReturns401(final String path) {
        RestAssured.given()
                .when()
                .get(path)
                .then()
                .statusCode(401);
    }

    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @ParameterizedTest
    @ValueSource(strings = { "/papierantraege" })
    void falscherContentTypReturns415(final String path) {
        String body = "<dto><name>test</name></dto>";

        RestAssured.given()
                .when()
                .header("Content-Type", "application/xml")
                .body(body)
                .post(path)
                .then()
                .statusCode(415);
    }
}