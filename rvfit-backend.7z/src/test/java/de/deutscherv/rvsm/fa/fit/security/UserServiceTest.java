package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.security.identity.SecurityIdentity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class UserServiceTest {

    private UserService userService;

    @BeforeEach
    void init() {
        SecurityIdentity securityIdentity = Mockito.mock(SecurityIdentity.class);
        Mockito.when(securityIdentity.getRoles()).thenReturn(Set.of("role1", "role2", "role3 "));
        this.userService = new UserService("drv-id", "client-id", "70", securityIdentity);
    }

    @Test
    void testGetCurrentRoles() {
        assertThat(userService.getCurrentDrvId()).isEqualTo(Optional.of("drv-id"));
        assertThat(userService.getCurrentClientId()).isEqualTo("client-id");
        assertThat(userService.getCurrentRoles()).isEqualTo("role1 role2 role3");
    }

}