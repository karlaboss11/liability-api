package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;

@QuarkusTest
class JwtUtilsTest {
    @Inject
    private DrvMandant drvMandant;
    @Inject
    JsonWebToken token;

    @BeforeEach
    public void setup() {
        final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        Mockito.doReturn("127.0.0.1").when(request).getRemoteAddr();
        QuarkusMock.installMockForType(request, HttpServletRequest.class);
    }

    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "24") })
    void pruefeReihenfolgevonKTanKontexten() {
        String ktan = JwtUtils.GET_KTAN.apply(token, drvMandant);
        assertEquals("24", ktan, "Ein leerer Ktankontext führt zum Auslesen des Json web tokens");
        drvMandant.setInScope("1234");
        ktan = JwtUtils.GET_KTAN.apply(token, drvMandant);
        assertEquals("1234", ktan, "Der KtanContext sollte vorrang vor dem Json Web token haben");
    }
}
