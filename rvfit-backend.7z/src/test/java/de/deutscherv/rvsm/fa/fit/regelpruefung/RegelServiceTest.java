package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.regelpruefung.model.Regel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.repository.RegelRepository;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@QuarkusTest
class RegelServiceTest {

    @Inject
    RegelRepository regelRepository;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    EntityManager em;

    /**
     * Testet, ob Regeln gefunden werden, wenn der KTAN Parameter ignoriert wird.
     */
    @Test
    @Transactional
    void findAllByKtanAndActiveTest() {

        drvMandant.setInScope("70");
        final Regel rTest = Regel.builder().uuid(UUID.randomUUID()).name(RegelName.REGEL_MASSNAHME).ktan("99")
                .parameter("70").aktiv(false).build();

        em.persist(rTest);

        final List<Regel> rFindAllByKtanAndActive =
                regelRepository.list("ktan = ?1 and aktiv = ?2", "99", false);

        assertNotNull(rFindAllByKtanAndActive);

        // rFindAllByKtanAndActive.stream().forEach(r -> Assertions.assertEquals(rTest, r));
    }
}
