package de.deutscherv.rvsm.fa.fit.azk;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.azk.openapi.model.PruefungResponseDto;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@ExtendWith(MockitoExtension.class)
class AzkServiceTest {

    private AzkClient azkClient;
    private RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private Response response;
    private AzkService azkService;

    @BeforeEach
    void setUp() {
        azkClient = Mockito.mock(AzkClient.class);
        JsonWebToken jwt = Mockito.mock(JsonWebToken.class);
        rVFitJsonSchemaValidator = Mockito.mock(RVFitJsonSchemaValidator.class);
        response = Mockito.mock(Response.class);

        Mockito.lenient().when(jwt.claim(Mockito.anyString())).thenReturn(Optional.of("drv_id"));
        Mockito.lenient().when(rVFitJsonSchemaValidator.isValid(Mockito.eq(RestServiceClient.AZK), Mockito.any(PruefungResponseDto.class)))
                .thenReturn(true);
        Mockito.lenient().when(azkClient.pruefeATAD(Mockito.anyString(), Mockito.any())).thenReturn(response);

        azkService = new AzkService(false, azkClient, rVFitJsonSchemaValidator, jwt, Mockito.mock(AntragRepository.class));
    }

    @Test
    void testPruefeZurgiffErlaubt() {
        final var azkResponse = new PruefungResponseDto().berechtigung(true);

        Mockito.when(response.getStatus()).thenReturn(Status.OK.getStatusCode());
        Mockito.when(response.readEntity(PruefungResponseDto.class)).thenReturn(azkResponse);

        final var antrag = Antrag.builder()
                .atad(1)
                .ktan("ktan")
                .build();

        assertThatNoException().isThrownBy(() -> azkService.pruefeZugriff(antrag));
    }

    @Test
    void testPruefeZugriffNichtErlaubt() {
        final var azkResponse = new PruefungResponseDto().berechtigung(false);

        Mockito.when(response.getStatus()).thenReturn(Status.OK.getStatusCode());
        Mockito.when(response.readEntity(PruefungResponseDto.class)).thenReturn(azkResponse);

        final var antrag = Antrag.builder()
                .atad(1)
                .ktan("ktan")
                .build();

        assertThatThrownBy(() -> azkService.pruefeZugriff(antrag))
                .isInstanceOf(AzkException.class)
                .hasMessage("Keine Zugriffsberechtigung vorhanden");
    }

    @Test
    void testPruefeZugriffStatusNichtOk() {
        Mockito.when(azkClient.pruefeATAD(Mockito.anyString(), Mockito.any())).thenReturn(response);
        Mockito.when(response.getStatus()).thenReturn(Status.INTERNAL_SERVER_ERROR.getStatusCode());

        final var antrag = Antrag.builder()
                .atad(1)
                .ktan("ktan")
                .build();

        assertThatThrownBy(() -> azkService.pruefeZugriff(antrag))
                .isInstanceOf(AzkException.class)
                .hasMessage("AZK - Serverfehler 500");
    }

    @Test
    void testPruefeZugriffWebError() {
        Mockito.when(azkClient.pruefeATAD(Mockito.anyString(), Mockito.any())).thenThrow(new WebApplicationException("web error"));

        final var antrag = Antrag.builder()
                .atad(1)
                .ktan("ktan")
                .build();

        assertThatThrownBy(() -> azkService.pruefeZugriff(antrag))
                .isInstanceOf(AzkException.class)
                .hasMessage("AZK - Serverfehler web error");
    }

    @Test
    void testPruefeZugriffSchemaError() {
        final var azkResponse = new PruefungResponseDto().berechtigung(true);

        Mockito.when(response.getStatus()).thenReturn(Status.OK.getStatusCode());
        Mockito.when(response.readEntity(PruefungResponseDto.class)).thenReturn(azkResponse);
        Mockito.lenient().when(rVFitJsonSchemaValidator.isValid(Mockito.eq(RestServiceClient.AZK), Mockito.any(PruefungResponseDto.class)))
                .thenReturn(false);

        final var antrag = Antrag.builder()
                .atad(1)
                .ktan("ktan")
                .build();

        assertThatThrownBy(() -> azkService.pruefeZugriff(antrag))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
