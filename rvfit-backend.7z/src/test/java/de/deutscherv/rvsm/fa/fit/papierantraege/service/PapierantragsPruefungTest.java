package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlercodeDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.testdaten.AntragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathTemplate;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

/**
 * Test PapierantragsPruefung.
 */
@QuarkusTest
class PapierantragsPruefungTest {

    @Inject
    private PapierantragsPruefung pPruefung;

    @Inject
    private AntragMapper antragMapper;

    private PapierantragDto myPapierAntrag;

    private WireMockServer wireMockServer;

    private StubMapping stubMappingKonten;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeEach
    void setUp() {
        myPapierAntrag = new PapierantragDto();
        final AntragDto antragDto = new AntragDto();

        final StammdatenDto myStamm = new StammdatenDto();
        myStamm.setVsnr("12345678B123");
        myStamm.setVorname("Max");
        myStamm.setNachname("Mustermann");
        myStamm.setGeburtsdatum(LocalDate.now().toString());
        myStamm.setStaatsangehoerigkeit("151");

        myStamm.setWohnort("Wohnort");
        myStamm.setPlz("12345");
        myStamm.setStrasse("Musterstraße");
        myStamm.setHausnummer("123");

        antragDto.setTelefon("0921123456");
        antragDto.setFax("0921987654");
        antragDto.setAntragsdatum(LocalDate.now());
        antragDto.setEingangsdatum(LocalDate.now());

        antragDto.setWohnort("Wohnort");
        antragDto.setPlz("12345");
        antragDto.setStrasse("Musterstraße");
        antragDto.setHausnummer("123");

        antragDto.setVsnr("12345678B123");
        antragDto.setVorname("Max");
        antragDto.setNachname("Mustermann");
        antragDto.setGeburtsdatum("1952-01-27");
        antragDto.setStaatsangehoerigkeit("151");
        antragDto.setNamenszusatz("");
        antragDto.setFruehererName("");

        myPapierAntrag.setAntrag(antragDto);
        myPapierAntrag.setVersicherter(myStamm);

        wireMockServer = new WireMockServer(WireMockStub.PORT);
        wireMockServer.start();
        configureFor("localhost", wireMockServer.port());

        stubFor(post(urlEqualTo("/statistik/ablehnung"))
            .willReturn(aResponse().withStatus(Status.CREATED.getStatusCode())));
        stubFor(post(urlEqualTo("/statistik/bewilligung"))
            .willReturn(aResponse().withStatus(Status.CREATED.getStatusCode())));
        stubFor(post(urlEqualTo("/statistik/antragserfassung"))
            .willReturn(aResponse().withStatus(Status.CREATED.getStatusCode())));

    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterEach
    void stopWiremock() {
        wireMockServer.stop();
    }

    /**
     * Prüfung auf fehlerfreien Papierantrag.
     *
     * @throws NoSuchFieldException Feld nicht gefunden
     * @throws StammdatenException  Fehler bei den Stammdaten
     * @throws SecurityException    Security-Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerfrei()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        assertEquals(0, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Werte für PLZ / VSNR zu kurz setzen, STAATSANGEHÖRIGKEIT zu lang Erwartung: Fehleranzahl: 3 Fehlerfeld: PLZ_VERSICHERTER &
     * STAATSANGEHÖRIGKEIT & VSNR.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaft()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        myPapierAntrag.getAntrag().setPlz("12345678910");
        // myPapierAntrag.getVersicherter().setVsnr("03151259T481");
        myPapierAntrag.getAntrag().setStaatsangehoerigkeit("12345");
        assertEquals(1, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "PLZ".equalsIgnoreCase(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_UNGUELTIG.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Werte für PLZ / STAATSANGEHÖRIGKEIT / Vorname / Geburtsdatum / Eingangsdatum leer bzw. null Erwartung: Fehleranzahl: 5 Fehlerfeld:
     * PLZ_VERSICHERTER & STAATSANGEHÖRIGKEIT & VORNAME & GEBURTSDATUM & EINGANGSDATUM.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaftBlanksNull()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        myPapierAntrag.getAntrag().setStaatsangehoerigkeit("");
        myPapierAntrag.getAntrag().setVorname("");
        myPapierAntrag.getAntrag().setGeburtsdatum("");
        myPapierAntrag.getAntrag().setEingangsdatum(null);

        assertEquals(3, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "EINGANGSDATUM".equalsIgnoreCase(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_LEER.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Werte für PLZ und STAATSANGEHÖRIGKEIT mit ungültige Werten (Buchstaben) setzen Erwartung: Fehleranzahl: 2 Fehlerfeld:
     * PLZ_VERSICHERTER & STAATSANGEHÖRIGKEIT.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaftNoDigitsPlzStaatsangehoerigkeit()
        throws NoSuchFieldException, SecurityException, StammdatenException {

        stubMappingKonten();

        myPapierAntrag.getAntrag().setPlz("abcdefghtlk");
        myPapierAntrag.getAntrag().setStaatsangehoerigkeit("abc");

        assertEquals(1, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "PLZ".equalsIgnoreCase(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_UNGUELTIG.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Wert für Geburstdatum auf NULL setzen Erwartung: Fehleranzahl: 1 Fehlerfeld: GEBURTSDATUM.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaftGeburstdatumNull()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        myPapierAntrag.getAntrag().setGeburtsdatum(null);

        // Prüfung erwartete Fehleranzahl gleich Fehleranzahl in Liste
        assertEquals(1, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "GEBURTSDATUM".equals(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_LEER.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Länge optionales Feld zu lange Erwartung: Fehleranzahl: 1 Fehlerfeld: BEMERKUNGEN.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaftBemerkungenLaenge()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        // Bemerkungsfeld auf > 10650 setzen
        myPapierAntrag.getAntrag().setBemerkungen(StringUtils.repeat("x", 10651));

        // Prüfung erwartete Fehleranzahl gleich Fehleranzahl in Liste
        assertEquals(1, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "BEMERKUNGEN".equals(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_LAENGE.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Prueft auf fehlerhafte VSNR-Pattern.
     *
     * @throws NoSuchFieldException Fehler
     * @throws SecurityException    Fehler
     * @throws StammdatenException  Fehler
     */
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    @Test
    void pruefePapierAntragFehlerhaftVsnrPattern()
        throws NoSuchFieldException, SecurityException, StammdatenException {
        stubMappingKonten();

        myPapierAntrag.getVersicherter().setVsnr("INVALID123");

        // Prüfung erwartete Fehleranzahl gleich Fehleranzahl in Liste
        assertEquals(1, pPruefung.pruefePapierAntrag(myPapierAntrag).size());

        // Prüfung Fehlerfeld(er) in Fehlerliste
        assertTrue(pPruefung.pruefePapierAntrag(myPapierAntrag).stream()
            .filter(e -> "VSNR".equals(e.getFeld()))
            .anyMatch(e -> FehlercodeDto.FELD_UNGUELTIG.equals(e.getCode())));

        wireMockServer.removeStubMapping(stubMappingKonten);
    }

    /**
     * Test setERfasstPapierantrag..
     *
     * @throws SecurityException   Fehler
     * @throws StammdatenException Fehler
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = {
        @Claim(key = "drv_mandant", value = "70")
    })
    void setErfasstPapierantrag()
        throws SecurityException, StammdatenException {

        final Antrag antrag = AntragTestDaten.getAntrag(TestPerson.PETER_PAN);
        final AntragRepository mock = Mockito.mock(AntragRepository.class);
        Mockito.when(mock.findByUuid(any())).thenReturn(Optional.of(antrag));
        QuarkusMock.installMockForType(mock, AntragRepository.class);
        myPapierAntrag.getAntrag().setUuid(UUID.randomUUID().toString());

        myPapierAntrag.getAntrag().setUuid(UUID.randomUUID().toString());

        Mockito.verify(mock, times(0)).delete(antrag);

    }

    /**
     * Prüfung auf valide VSNR.
     */
    @Test
    void isVsnrValid() {
        assertTrue(pPruefung.isVsnrValid("12345678B123"));
    }

    /**
     * VSNR ist blank Erwartung: Return false.
     */
    @Test
    void isVsnrValid_blank() {
        assertFalse(pPruefung.isVsnrValid(""));
    }

    /**
     * VSNR ist invalide falsches pattern Erwartung: Return false.
     */
    @Test
    void isVsnrValid_pattern() {
        assertFalse(pPruefung.isVsnrValid("123423"));
    }

    private void stubMappingKonten() {
        // Stub getStammdatenByVsnr Methode um Testdaten zurückzugeben
        final String responseBody = """
            {
                "kontoId": "57cc58ee-2531-42c3-9903-ed41ba6a7fd7",
                "ktan": "70",
                "versicherungsnummer": "12345678B123",
                "personen": [
                  {
                    "kontobeteiligteId": 181,
                    "personId": "57cc58ee-2531-42c3-9903-ed41ba6a7fd7",
                    "rolle": "Versicherter",
                    "personentyp": "BETEILIGTER",
                    "name": "Mustermann",
                    "vorname": "Max",
                    "anrede": "HERR",
                    "vorsatzwort": "",
                    "namensZusatz": "",
                    "titel": "",
                    "geburtsname": "",
                    "geburtsnamenVorsatzwort": "",
                    "geburtsnamenZusatz": "",
                    "geburtsort": "Köln",
                    "steuerId": 0,
                    "geburtsdatum": "1952-01-27",
                    "sterbeDatum": null,
                    "mehrling": false,
                    "geschlecht": "MAENNLICH",
                    "todesDatumVerschollenheit": null,
                    "transgender": false,
                    "anfrageStatusSteuerId": null,
                    "anfrageDatumSteuerId": null,
                    "bescheidNummerSteuerId": "02",
                    "steuerIdAbweichendesGebDatum": "2022-03-10",
                    "verfahrenNamensdaten": "15",
                    "herkunftNamensdaten": "13",
                    "verursacherNamensdaten": "FK583544",
                    "prozessdatumNamensdaten": "2022-03-10",
                    "verfahrenGeburtsname": "01",
                    "herkunftGeburtsname": "23",
                    "verursacherGeburtsname": "YM707513",
                    "prozessdatumGeburtsname": "2022-03-10",
                    "verfahrenGeburtsort": "52",
                    "herkunftGeburtsort": "00",
                    "verursacherGeburtsort": "QF054546",
                    "prozessdatumGeburtsort": "2022-03-10",
                    "verfahrenGeburtsdatum": "01",
                    "herkunftGeburtsdatum": "31",
                    "verursacherGeburtsdatum": "BS810143",
                    "prozessdatumGeburtsdatum": "5104-09-13",
                    "verfahrenGeschlecht": "01",
                    "herkunftGeschlecht": "41",
                    "verursacherGeschlecht": "OU744288",
                    "prozessdatumGeschlecht": "2022-03-10",
                    "anschrift": {
                      "anschriftId": "e88f6a7f-b2d1-4af3-9ef8-916acb73c042",
                      "postleitzahl": "12345",
                      "wohnort": "Wohnort",
                      "strasseHausnummer": "Musterstraße 123",
                      "istWohnortInAusland": false,
                      "anschriftenZusatz": null,
                      "laenderSchluessel": "550",
                      "anschriftenStatus": 4,
                      "gemeindeSchluessel": "43571408",
                      "verfahren": "51",
                      "herkunft": "32",
                      "verursacher": "ZG098403",
                      "prozessdatum": "2022-03-10"
                    }
                  }
                ]
              }
             """;
        stubMappingKonten = stubFor(get(urlPathTemplate("/konten/{versicherungsnummer}"))
            .withPathParam("versicherungsnummer", equalTo("12345678B123"))
            .willReturn(aResponse().withStatus(200).withBody(responseBody)
                .withHeader("Content-Type", "application/json")));
    }

}
