package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test EinrichtungsdatenUtils.
 */
class EinrichtungsdatenUtilsTest {

    /**
     * Test Einrichtung.
     *
     * @param name       name
     * @param strasse    straße
     * @param hausnummer hausnummer
     * @param plz        plz
     * @return Einrichtung
     */
    private RehaEinrichtung getNewRehaEinrichtung(final String name, final String strasse,
        final String hausnummer, final String plz) {
        final RehaEinrichtung einrichtung = new RehaEinrichtung();
        final EinrichtungAnschrift adresse = new EinrichtungAnschrift();
        adresse.setStrasse(strasse);
        adresse.setPlz(plz);
        adresse.setHausnummer(hausnummer);
        einrichtung.setAdresse(adresse);
        einrichtung.setName(name);

        return einrichtung;
    }

    /**
     * Testeinrichtungen.
     *
     * @return Einrichtungen
     */
    private List<RehaEinrichtung> getFilledListOfEinrichtungen() {
        final List<RehaEinrichtung> einrichtungen = new ArrayList<>();
        einrichtungen
            .add(getNewRehaEinrichtung("Reha-Klinik Glotterbad", "Gehrenstr.", "10", "79286"));
        einrichtungen.add(getNewRehaEinrichtung("ZAR im Mineralbad Bad Cannstatt", "Sulzerrainstr.",
            "2", "70372"));
        einrichtungen.add(getNewRehaEinrichtung("ZAR Mannheim", "Auf dem Sand", "75-77", "68309"));
        einrichtungen.add(getNewRehaEinrichtung("ZAR Göppingen", "Bahnhofsplatz", "2/1", "73033"));
        return einrichtungen;
    }

    /**
     * Testet, ob getUniqueEinrichtungFromFreitext die richtige Einrichtung findet.
     */
    @Test
    void testPreciseNamePlzEinrichtungsdatenEinrichtungWasFoundTest() {
        final String freitext = "Reha-Klinik Glotterbad\nStrasse\n79286 Glottertal";
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final RehaEinrichtung einrichtung =
            EinrichtungsdatenUtils.getUniqueEinrichtungFromFreitext(freitext, listOfEinrichtungen);

        assertNotNull(einrichtung);
        assertEquals("Reha-Klinik Glotterbad", einrichtung.getName());
        assertEquals("Gehrenstr.", einrichtung.getAdresse().getStrasse());
        assertEquals("10", einrichtung.getAdresse().getHausnummer());
        assertEquals("79286", einrichtung.getAdresse().getPlz());
    }

    /**
     * Testet, ob getUniqueEinrichtungFromFreitext die richtige Einrichtung findet.
     */
    @Test
    void testgetUniqueEinrichtungFromFreitextFreitextIsBlank() {
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungFromFreitext(null,
            getFilledListOfEinrichtungen()));
    }

    /**
     * Testet, ob getUniqueEinrichtungFromFreitext die richtige Einrichtung findet.
     */
    @Test
    void testPreciseAdresseEinrichtungsdatenEinrichtungWasFoundTest() {
        final String freitext = "Reha-Klinik\nGehrenstr. 10\n12345 Glottertal";
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final RehaEinrichtung einrichtung =
            EinrichtungsdatenUtils.getUniqueEinrichtungFromFreitext(freitext, listOfEinrichtungen);

        assertNotNull(einrichtung);
        assertEquals("Reha-Klinik Glotterbad", einrichtung.getName());
        assertEquals("Gehrenstr.", einrichtung.getAdresse().getStrasse());
        assertEquals("10", einrichtung.getAdresse().getHausnummer());
        assertEquals("79286", einrichtung.getAdresse().getPlz());
    }

    /**
     * Testet, ob getUniqueEinrichtungFromFreitext Freitexte richtig analysiert.
     *
     * @param freitext der Freitext
     */
    @ParameterizedTest
    @CsvSource(value = { "Reha-Klinik Glotterbad, 79286 Glottertal",
        "Reha-Klinik Glotterbad\\n79286",
        "Glottertal 79286, Reha klinik Glotterbad",
        "RehaKlinik Gloterbbad\\nGehrenstr. 10\\n79286 Glottertal",
        "Reha-Klinik Glotterbad\\nGehrenstr.  10\\nGlottertal",
        "Reha-Klinik Glotterbad\\nGehrenstrasse 10\\nGlottertal"
    }, delimiter = ':')
    void testNameAndPLZEinrichtungWasFoundTest(final String freitext) {
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final RehaEinrichtung einrichtung =
            EinrichtungsdatenUtils.getUniqueEinrichtungFromFreitext(freitext, listOfEinrichtungen);

        assertNotNull(einrichtung);
        assertEquals("Reha-Klinik Glotterbad", einrichtung.getName());
    }

    /**
     * Testet, ob getUniqueEinrichtungFromFreitext bei falscher Plz die Einrichtung nicht findet.
     *
     * @param freitext die Freitexte
     */
    @ParameterizedTest
    @CsvSource(value = { "Reha Glotterbad, 79286 Glottertal",
        "Reha-Klinik Glotterbad, 12345 Glottertal",
        "Reha-Klinik Glotterbad",
        "Glotterbad\\n79286",
        "Reha-Klinik, Gehrenstr., 79286",
        "Reha-Klinik, 79286",
        "Reha-Klinik, Morehnstrasse 10, 79286"
    }, delimiter = ':')
    void testNameAndPLZNotClearEinrichtungWasNotFoundTest(final String freitext) {
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final RehaEinrichtung einrichtung =
            EinrichtungsdatenUtils.getUniqueEinrichtungFromFreitext(freitext, listOfEinrichtungen);

        assertNull(einrichtung);
    }

    /**
     * Testet, ob die Einrichtung richtig vom Freitext gelesen werden kann.
     *
     * @param freitext der Freitext
     */
    @ParameterizedTest
    @CsvSource(value = { "RehaKlinik Gloterbbad\\nGehrenstr. 10\\n79286 Glottertal",
        "Reha-Klinik Glotterbad\\nGehrenstr.  10\\nGlottertal",
        "Reha-Klinik Glotterbad\\nGehrenstrasse 10\\nGlottertal" }, delimiter = ':')
    void getEinrichtungenFromFreitextTest(final String freitext) {
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final List<RehaEinrichtung> listOfResults =
            EinrichtungsdatenUtils.getEinrichtungenFromFreitext(freitext, listOfEinrichtungen);

        assertNotNull(listOfResults);
        assertEquals("Reha-Klinik Glotterbad", listOfResults.getFirst().getName());
    }

    /**
     * Testet, ob getEinrichtungenByStrasseAndHausnummer die richtigen Einrichtungen zurück gibt.
     */
    @Test
    void getEinrichtungenByStrasseAndHausnummerTest() {
        final List<RehaEinrichtung> listOfEinrichtungen = getFilledListOfEinrichtungen();

        final List<RehaEinrichtung> result = EinrichtungsdatenUtils
            .getEinrichtungenByStrasseAndHausnummer("Gehrenstr.", "10", listOfEinrichtungen);

        assertNotNull(result);
        assertEquals("Reha-Klinik Glotterbad", result.getFirst().getName());
    }

    /**
     * Test Phase Mapping.
     */
    @Test
    void testPhaseMapping() {
        assertEquals("Startphase",
            EinrichtungsdatenUtils.phaseEnumToSmpPhaseName(PhaseEnumDto.STARTPHASE));
        assertEquals("Trainingsphase",
            EinrichtungsdatenUtils.phaseEnumToSmpPhaseName(PhaseEnumDto.TRAININGSPHASE));
        assertEquals("Auffrischungsphase",
            EinrichtungsdatenUtils.phaseEnumToSmpPhaseName(PhaseEnumDto.AUFFRISCHUNG));
    }

    /**
     * Test Delete Doppelte.
     */
    @Test
    void testdeleteDoppelte() {
        final RehaEinrichtung einrichtung = new RehaEinrichtung();
        einrichtung.setUuid(UUID.randomUUID());
        einrichtung.setResc("A11111");
        einrichtung.setName("Testklinik_DF");
        einrichtung.addAngebot(Angebot.builder().durchfuehrungsart("Ambulant")
            .phase("TRAININGSPHASE").smpAngebotId(11111L).build());
        einrichtung.addAngebot(Angebot.builder().durchfuehrungsart("online").phase("TRAININGSPHASE")
            .smpAngebotId(11111L).build());
        einrichtung.addAngebot(Angebot.builder().durchfuehrungsart("Ambulant (ganztägig)")
            .phase("Startphase").smpAngebotId(10216L).build());

        EinrichtungsdatenUtils.deleteNichtEindeutigAngeboteFromEinrichtung(
            PhaseEnumDto.TRAININGSPHASE, 11111L, "Ambulant", einrichtung);
        assertEquals(1, einrichtung.getAngebote().size());
    }

    /**
     * Test getUniqueEinrichtungByNameAndPlz.
     */
    @Test
    void testGetUniqueEinrichtungByNameAndPlz() {
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByNameAndPlz(null, "11111",
            getFilledListOfEinrichtungen()));
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByNameAndPlz("test", null,
            getFilledListOfEinrichtungen()));
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByNameAndPlz("test", "11111",
            new ArrayList<>()));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils.getEinrichtungenByNameAndPlz(null,
            "11111", getFilledListOfEinrichtungen()));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils.getEinrichtungenByNameAndPlz("test",
            null, getFilledListOfEinrichtungen()));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils.getEinrichtungenByNameAndPlz("test",
            "11111", new ArrayList<>()));
    }

    /**
     * Test getUniqueEinrichtungByStrasseAndHausnummer wenn die Einrichtungsliste leer ist.
     */
    @Test
    void testgetUniqueEinrichtungByStrasseAndHausnummerEinrichtungslisteIsEmpty() {
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByStrasseAndHausnummer("test",
            "11111", new ArrayList<>()));

        List<RehaEinrichtung> einrichtungen = new ArrayList<>();
        einrichtungen
            .add(getNewRehaEinrichtung("Reha-Klinik Glotterbad", "Gehrenstr.", "10", "79286"));
        einrichtungen
            .add(getNewRehaEinrichtung("Reha-Klinik Glotterbad 2", "Gehrenstr.", "10", "79286"));
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByStrasseAndHausnummer("Gehrenstr.",
            "10", einrichtungen));

        einrichtungen = new ArrayList<>();
        einrichtungen
            .add(getNewRehaEinrichtung("Reha-Klinik Glotterbad", "Gehrenstr.", "10", "79286"));
        assertNull(EinrichtungsdatenUtils.getUniqueEinrichtungByStrasseAndHausnummer("Gehrenstr.",
            "11", einrichtungen));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils
            .getEinrichtungenByStrasseAndHausnummer(null, "1", getFilledListOfEinrichtungen()));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils
            .getEinrichtungenByStrasseAndHausnummer("test", null, getFilledListOfEinrichtungen()));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils
            .getEinrichtungenByStrasseAndHausnummer("test", "1", new ArrayList<>()));

        einrichtungen = new ArrayList<>();
        einrichtungen
            .add(getNewRehaEinrichtung("Reha-Klinik Glotterbad", "Gehrenstr.", "10", "79286"));
        assertEquals(new ArrayList<>(), EinrichtungsdatenUtils
            .getEinrichtungenByStrasseAndHausnummer("Gehrenstr.", "11", einrichtungen));
    }

    /**
     * Teste getDurchfuehrungsartId.
     */
    @Test
    void testGetDurchfuehrungsartId() {
        assertEquals(4, EinrichtungsdatenUtils.getDurchfuehrungsartId("Ambulant"));
        assertEquals(5, EinrichtungsdatenUtils.getDurchfuehrungsartId("Ambulant (ganztägig)"));
        assertEquals(6, EinrichtungsdatenUtils.getDurchfuehrungsartId("online"));
        assertEquals(7, EinrichtungsdatenUtils.getDurchfuehrungsartId("stationär"));
        assertNull(EinrichtungsdatenUtils.getDurchfuehrungsartId("test"));
    }

    /**
     * Test alleEinrichtungenVorhanden.
     */
    @Test
    void testAlleEinrichtungenVorhanden() {
        final Antrag antr = Antrag.builder().build();
        assertFalse(EinrichtungsdatenUtils.alleEinrichtungenVorhanden(antr));
        antr.setAngebotStartSmpId(1L);
        assertFalse(EinrichtungsdatenUtils.alleEinrichtungenVorhanden(antr));
        antr.setAngebotAufSmpId(2L);
        assertFalse(EinrichtungsdatenUtils.alleEinrichtungenVorhanden(antr));
        antr.setAngebotTrainingName("name");
        antr.setAngebotTrainingOrt("ort");
        antr.setAngebotTrainingPlz("plz");
        antr.setAngebotTrainingStrasse("str");
        assertTrue(EinrichtungsdatenUtils.alleEinrichtungenVorhanden(antr));
    }

    /**
     * Test keineEinrichtungenVorhanden.
     */
    @Test
    void testKeineEinrichtungenVorhanden() {
        final Antrag antr = Antrag.builder().build();
        assertTrue(EinrichtungsdatenUtils.keineEinrichtungenVorhanden(antr));
        antr.setAngebotAufSmpId(1L);
        assertFalse(EinrichtungsdatenUtils.keineEinrichtungenVorhanden(antr));

    }
}
