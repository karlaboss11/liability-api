package de.deutscherv.rvsm.fa.fit.security;

import com.google.common.net.HttpHeaders;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import jakarta.enterprise.inject.Instance;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.UriInfo;
import java.net.URI;
import java.security.Principal;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.MDC;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.when;

class LoggingRequestFilterTest {

    private LoggingRequestFilter loggingRequestFilter;
    private ContainerRequestContext containerRequestContext;

    @BeforeEach
    void init() {
        Principal principal = Mockito.mock(Principal.class);
        when(principal.getName()).thenReturn("PrincipalName");

        @SuppressWarnings("unchecked")
        Instance<Principal> instance = Mockito.mock(Instance.class);
        when(instance.get()).thenReturn(principal);
        when(instance.isResolvable()).thenReturn(true);

        UserService userService = Mockito.mock(UserService.class);
        Mockito.when(userService.getCurrentClientId()).thenReturn("ClientId");
        Mockito.when(userService.getCurrentRoles()).thenReturn("Bearberfasser");

        containerRequestContext = Mockito.mock(ContainerRequestContext.class);
        loggingRequestFilter = new LoggingRequestFilter(instance, userService);
    }

    @Test
    @SneakyThrows
    void testFilter() {
        UriInfo uriInfo = Mockito.mock(UriInfo.class);
        Mockito.when(uriInfo.getRequestUri()).thenReturn(URI.create("http://rvfit-frontend.drv"));
        Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);

        loggingRequestFilter.filter(containerRequestContext);

        assertThat(MDC.get(MDCKey.USER_ID.valueOf())).isEqualTo("PrincipalName");
        assertThat(MDC.get(MDCKey.CLIENT_ID.valueOf())).isEqualTo("ClientId");
        assertThat(MDC.get(MDCKey.SOURCE_IP.valueOf())).isEqualTo("rvfit-frontend.drv");
        assertThat(MDC.get(MDCKey.USER_ROLES.valueOf())).isEqualTo("Bearberfasser");
    }

    @Test
    void testGetUserId() {
        assertThat(loggingRequestFilter.getUserId()).isEqualTo("PrincipalName");
    }

    @Test
    void testGetHostOrIpAddressQuelleUnbekannt() {
        assertThat(loggingRequestFilter.getHostOrIpAddress(containerRequestContext)).isEqualTo("UNBEKANNT");
    }

    @Test
    void testGetHostOrIpAddressWithXForwardedForHeader() {
        Mockito.when(containerRequestContext.getHeaderString(HttpHeaders.X_FORWARDED_FOR)).thenReturn("rvfit-frontend.drv");
        assertThat(loggingRequestFilter.getHostOrIpAddress(containerRequestContext)).isEqualTo("rvfit-frontend.drv");
    }

    @Test
    void testGetHostOrIpAddressWithoutXForwardedForHeader() {
        UriInfo uriInfo = Mockito.mock(UriInfo.class);
        Mockito.when(uriInfo.getRequestUri()).thenReturn(URI.create("http://rvfit-frontend.drv"));
        Mockito.when(containerRequestContext.getUriInfo()).thenReturn(uriInfo);

        assertThat(loggingRequestFilter.getHostOrIpAddress(containerRequestContext)).isEqualTo("rvfit-frontend.drv");
    }
}