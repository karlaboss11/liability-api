package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.MockedStatic;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mockStatic;

@QuarkusTest
class RegelEngineTest {

    @Inject
    RegelEngine engine;

    /**
     * Liefert Parameter für gesamtErgebnisTestNichtErfuelltAblehnen(). NICHT_ERFUELLT_ABLEHNEN sollte alle anderen überschreiben
     *
     * @return die Test-Parameter
     */
    private static Stream<Arguments> gesamtErgebnisTestNichtErfuelltAblehnenArgs() {
        return Stream.of(Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT_ABLEHNEN)),
                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT,
                        RegelName.REGEL_NICHTERFUELLT_ABLEHNEN)),
                Arguments.of(List.of(RegelName.REGEL_ERFUELLT, RegelName.REGEL_NICHTERFUELLT_ABLEHNEN)),
                Arguments.of(List.of(RegelName.REGEL_AUSSTEUERN,
                        RegelName.REGEL_NICHTERFUELLT_ABLEHNEN)), Arguments.of(
                        List.of(RegelName.REGEL_ERFUELLT,
                                RegelName.REGEL_NICHTERFUELLT_ABLEHNEN,
                                RegelName.REGEL_AUSSTEUERN)));
    }

    /**
     * Liefert Parameter für gesamtErgebnisTestAusteuern().
     *
     * @return die Test-Parameter
     */
    private static Stream<Arguments> gesamtErgebnisTestAusteuernArgs() {
        return Stream.of(Arguments.of(List.of(RegelName.REGEL_AUSSTEUERN)),
                Arguments.of(List.of(RegelName.REGEL_ERFUELLT, RegelName.REGEL_AUSSTEUERN)),
                Arguments.of(List.of(RegelName.REGEL_AUSSTEUERN, RegelName.REGEL_AUSSTEUERN)),
                Arguments.of(List.of(RegelName.REGEL_ERFUELLT, RegelName.REGEL_AUSSTEUERN,
                        RegelName.REGEL_ERFUELLT)),

                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT)),
                Arguments.of(List.of(RegelName.REGEL_ERFUELLT, RegelName.REGEL_NICHTERFUELLT)),
                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT, RegelName.REGEL_AUSSTEUERN)),
                Arguments.of(List.of(RegelName.REGEL_ERFUELLT, RegelName.REGEL_AUSSTEUERN,
                        RegelName.REGEL_NICHTERFUELLT)),
                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT, RegelName.REGEL_NICHTERFUELLT)));
    }

    /**
     * Liefert Parameter für AUSSTEUERN wenn personendatenbbgleich schlägt fehl Liefert Parameter für NICHT_ERFUELLT_ABLEHNEN wenn
     * personendatenbbgleich ok.
     *
     * @return die Test-Parameter
     */
    private static Stream<Arguments> personendatenbbgleichArgs() {
        return Stream.of(
                // personendatenbbgleich schlägt fehl => AUSSTEUERN erwartet
                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT_ABLEHNEN, RegelName.REGEL_AUSSTEUERN),
                        true, PruefErgebnis.AUSSTEUERN),
                // personendatenbbgleich ok => NICHT_ERFUELLT_ABLEHNEN erwartet
                Arguments.of(List.of(RegelName.REGEL_NICHTERFUELLT_ABLEHNEN, RegelName.REGEL_AUSSTEUERN),
                        false, PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN)
        );
    }

    /**
     * Testet das Gesamtergebnis Nicht Erfuellt Ablehnen.
     *
     * @param regeln Die Regeln, die geprüft werden.
     */
    @ParameterizedTest
    @MethodSource("gesamtErgebnisTestNichtErfuelltAblehnenArgs")
    void gesamtErgebnisTestNichtErfuelltAblehnen(final List<RegelName> regeln) {

        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());

        final var ergebnis = engine.check(regeln, kontext);

        assertThat(ergebnis.getDetail()).as("Teste dass die Prüfung nicht in den Fehlerfall läuft")
                .withFailMessage(() -> "Ergebnisdetail lief in Fehler" + ergebnis.getDetail())
                .doesNotContain("Interner Fehler");
        assertThat(ergebnis.getPruefErgebnis()).as(
                        "Teste Prüfergebnis NICHT_ERFUELLT_ABLEHNEN überschreibt alle anderen")
                .withFailMessage(() -> "Ergebnisdetail lief in Fehler" + ergebnis.getDetail())
                .isSameAs(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
    }

    /**
     * Testet das Gesamtergebnis nicht Erfüllt, wenn keine Regeln übergeben werden.
     */
    @Test
    void gesamtErgebnisTestKeineRegelnAussteuern() {
        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());

        assertEquals(PruefErgebnis.AUSSTEUERN,
                engine.check(List.of(RegelName.REGEL_ERFUELLT), null).getPruefErgebnis());

        assertEquals(PruefErgebnis.AUSSTEUERN, engine.check(null, kontext).getPruefErgebnis());

        assertEquals(PruefErgebnis.AUSSTEUERN,
                engine.check(new ArrayList<>(), kontext).getPruefErgebnis());

    }

    /**
     * Testet das Gesamtergebnis Erfuellt.
     */
    @Test
    void gesamtErgebnisTestErfuellt() {
        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());
        assertEquals(PruefErgebnis.ERFUELLT,
                engine.check(List.of(RegelName.REGEL_ERFUELLT), kontext).getPruefErgebnis());
        assertEquals(PruefErgebnis.ERFUELLT,
                engine.check(Arrays.asList(RegelName.REGEL_ERFUELLT, RegelName.REGEL_ERFUELLT), kontext)
                        .getPruefErgebnis());
    }

    /**
     * Testet das Gesamtergebnis Austeuern.
     *
     * @param regeln Die Regeln, die geprüft werden.
     */
    @ParameterizedTest
    @MethodSource("gesamtErgebnisTestAusteuernArgs")
    void gesamtErgebnisTestAusteuern(final List<RegelName> regeln) {
        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());

        final var ergebnis = engine.check(regeln, kontext);

        assertThat(ergebnis.getPruefErgebnis()).isSameAs(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Testet das Detailergebnis.
     */
    @Test
    void detailErgebnisTest() {
        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());
        final RegelErgebnis gesamtErgebnis = engine.check(
                Arrays.asList(RegelName.REGEL_ERFUELLT, RegelName.REGEL_NICHTERFUELLT,
                        RegelName.REGEL_AUSSTEUERN, RegelName.REGEL_ERFUELLT), kontext);
        assertEquals(PruefErgebnis.AUSSTEUERN, gesamtErgebnis.getPruefErgebnis());
        assertEquals(
                "Regelprüfung in mindestens einem Fall negativ und erfordert manuelle Bearbeitung!",
                gesamtErgebnis.getDetail());

        assertEquals(3, gesamtErgebnis.getDetailErgebnisse().size());
        assertNotNull(gesamtErgebnis.getDetailErgebnisse().stream()
                .filter(e -> e.getPruefErgebnis().equals(PruefErgebnis.AUSSTEUERN)).findAny()
                .orElse(null));
        assertNotNull(gesamtErgebnis.getDetailErgebnisse().stream()
                .filter(e -> e.getPruefErgebnis().equals(PruefErgebnis.ERFUELLT)).findAny()
                .orElse(null));
        assertNotNull(gesamtErgebnis.getDetailErgebnisse().stream().filter(e -> e.getPruefErgebnis()
                .equals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)).findAny().orElse(null));
        assertEquals("Diese Regel wird immer OK liefern.",
                gesamtErgebnis.getDetailErgebnisse().stream()
                        .filter(e -> e.getPruefErgebnis().equals(PruefErgebnis.ERFUELLT)).findAny()
                        .orElse(null).getDetail());
        assertEquals("Regel ist immer nicht erfüllt.",
                gesamtErgebnis.getDetailErgebnisse().stream().filter(e -> e.getPruefErgebnis()
                                .equals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)).findAny().orElse(null)
                        .getDetail());
        assertEquals("Diese Regel wird immer AUSSTEUERN liefern.",
                gesamtErgebnis.getDetailErgebnisse().stream()
                        .filter(e -> e.getPruefErgebnis().equals(PruefErgebnis.AUSSTEUERN))
                        .findAny().orElse(null).getDetail());
    }

    /**
     * Testet das Gesamtergebnis. personendatenbbgleich schlägt fehl => AUSSTEUERN erwartet personendatenbbgleich ok =>
     * NICHT_ERFUELLT_ABLEHNEN erwartet
     *
     * @param regeln             Liste von Regeln, die geprüft werden sollen
     * @param abgleichFailed     Ergebnis des Abgleichs
     * @param erwartetesErgebnis Erwartetes Prüfergebnis des RegelEngine
     */
    @ParameterizedTest
    @MethodSource("personendatenbbgleichArgs")
    void testPersonendatenabgleichTrueFalse(List<RegelName> regeln, boolean abgleichFailed, PruefErgebnis erwartetesErgebnis) {
        final RegelKontext kontext = new RegelKontext(new Antrag(), new Stammdaten(),
                new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>());

        // Static-Mocking von PruefergebnisUtils
        try (MockedStatic<PruefergebnisUtils> mocked = mockStatic(PruefergebnisUtils.class)) {
            mocked.when(() -> PruefergebnisUtils.personendatenabgleichFailed(anyList()))
                    .thenReturn(abgleichFailed);

            RegelErgebnis ergebnis = engine.check(regeln, kontext);

            assertEquals(ergebnis.getPruefErgebnis(), erwartetesErgebnis);
        }
    }
}
