package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import static org.assertj.core.api.Assertions.assertThat;

class AusschlussgruendeTest {

    private static final RegelEngine REGEL_ENGINE = new RegelEngine(List.of(new LaufenderRehaAntragRegel(), new BezugEMRenteRegel(),
        new AntragEMRenteRegel(),
        new BeamteneigenschaftRegelBezuege(), new BeamteneigenschaftRegelAnwaerterschaft(), new AntragAltersrenteRegel(),
        new BezugAltersrenteRegel(), new WiderspruchsverfahrenRegel()));

    /**
     * Prüft auf Aussteuern bei Stammdaten = null.
     *
     * @param regel Regelname
     */
    @ParameterizedTest
    @MethodSource("getRegelNamenAuschlussgruende")
    void stammdatenNullShouldReturnAussteuern(final RegelName regel) {
        final RegelKontext kontext =
            new RegelKontext(new Antrag(), null, new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis = REGEL_ENGINE.check(List.of(regel), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Aussteuern bei Kontoinformationen = null.
     *
     * @param regel Regelname
     */
    @ParameterizedTest
    @MethodSource("getRegelNamenAuschlussgruende")
    void kontoinformationNullShouldReturnAussteuern(final RegelName regel) {
        final RegelKontext kontext =
            new RegelKontext(new Antrag(), new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis = REGEL_ENGINE.check(List.of(regel), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Aussteuern bei Ausschlussgründe = null (außer bei Beamteneigenschaft).
     *
     * @param regel Regelname
     */
    @ParameterizedTest
    @MethodSource("getRegelNamenAuschlussgruende")
    void ausschlussgruendeNullShoudlReturnAussteuern(final RegelName regel) {
        final Antrag antrag = new Antrag();
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis = REGEL_ENGINE.check(List.of(regel), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Erfüllt, wenn alle Ausschlussgründe false sind.
     *
     * @param regel Regelname
     */
    @ParameterizedTest
    @MethodSource("getRegelNamenAuschlussgruende")
    void ausschlussgruendeAlleFalseShouldReturnErfuellt(final RegelName regel) {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setRechtsbehelfReha(false);
        kontoinformation.setRechtsbehelfRente(false);
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis = REGEL_ENGINE.check(List.of(regel), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
    }

    /**
     * Prüft auf Erfüllt bei Beamteneigenschaft Bezug = null.
     */
    @Test
    void beamteneigenschaftBezugNullRestFalseShouldReturnErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = getKontoinformationWithAusschlussgruenden();
        kontoinformation.setBeamteneigenschaft(null);
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_BEAMTENEIGENSCHAFT_BEZUEGE), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
    }

    /**
     * Prüft auf Erfüllt bei Beamteneigenschaft Anwaerter = null.
     */
    @Test
    void beamteneigenschaftAnwaerterNullRestFalseShouldReturnErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = getKontoinformationWithAusschlussgruenden();
        kontoinformation.setBeamteneigenschaft(null);
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
    }

    /**
     * Prüft auf Nicht erfüllt bei laufendem Rehaantrag.
     */
    @Test
    void laufenderRehaAntragTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setAntragRehaMsat("4");
        kontoinformation.setAntragRehaArt("11");

        antrag.addKontoinformation(kontoinformation);

        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_LAUFENDERREHAANTRAG), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt bei Bezug von EM Rente.
     */
    @Test
    void bezugEmRenteTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setBezugRenteLeat("74");

        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis = REGEL_ENGINE.check(List.of(RegelName.REGEL_BEZUGEMRENTE), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt bei laufendem EM Rentenantrag.
     */
    @Test
    void antragEMRenteTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setAntragRenteLeat("74");
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_ANTRAGEMRENTE), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt bei Beamteneigenschaft mit Vollbezügen.
     */
    @Test
    void beamteneigenschaftBezugTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = getKontoinformationWithAusschlussgruenden();
        kontoinformation.setBeamteneigenschaft(true);
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_BEAMTENEIGENSCHAFT_BEZUEGE), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt bei Beamteneigenschaft mit Anwerterschaft.
     */
    @Test
    void beamteneigenschaftAnwaerterTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = getKontoinformationWithAusschlussgruenden();
        kontoinformation.setBeamteneigenschaft(true);
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt ablehnen bei laufendem Antrag auf Altersrente.
     */
    @Test
    void antragAltersrenteTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setAntragRenteLeat("65");
        kontoinformation.setAntragRenteTlrt("0");
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_ANTRAGALTERSRENTE), kontext);
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Prüft auf Nicht erfüllt ablehnen bei Bezug von Altersrente.
     */
    @Test
    void bezugAltersrenteTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setBezugRenteLeat("65");
        kontoinformation.setBezugRenteTlrt("0");
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_BEZUGALTERSRENTE), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
    }

    /**
     * Prüft auf Nicht erfüllt bei laufendem Widerspruchsverfahren.
     */
    @Test
    void widerspruchsverfahrenTrueShouldReturnNichtErfuellt() {
        final Antrag antrag = new Antrag();
        final Kontoinformation kontoinformation = getKontoinformationWithAusschlussgruenden();
        antrag.addKontoinformation(kontoinformation);
        final RegelKontext kontext =
            new RegelKontext(antrag, new Stammdaten(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>());
        final RegelErgebnis ergebnis =
            REGEL_ENGINE.check(List.of(RegelName.REGEL_WIDERSPRUCHSVERFAHREN), kontext);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }

    /**
     * Test Kontoinformationen.
     *
     * @return Kontoinformationen
     */
    private Kontoinformation getKontoinformationWithAusschlussgruenden() {
        final var kontoinformation = new Kontoinformation();
        kontoinformation.setBeamteneigenschaft(false);
        return kontoinformation;
    }

    private Kontoinformation getKontoinformationLaufenderRehaAntrag() {
        final Kontoinformation kontoinformation = new Kontoinformation();
        kontoinformation.setAntragRehaMsat("4");
        kontoinformation.setAntragRehaArt("11");
        return kontoinformation;
    }

    /**
     * Regelnamen für Ausschlussgruende.
     *
     * @return Stream<RegelName>
     */
    private static Stream<RegelName> getRegelNamenAuschlussgruende() {
        return Stream.of(RegelName.REGEL_LAUFENDERREHAANTRAG, RegelName.REGEL_BEZUGEMRENTE,
            RegelName.REGEL_ANTRAGEMRENTE, RegelName.REGEL_BEAMTENEIGENSCHAFT_BEZUEGE,
            RegelName.REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT, RegelName.REGEL_ANTRAGALTERSRENTE,
            RegelName.REGEL_BEZUGALTERSRENTE, RegelName.REGEL_WIDERSPRUCHSVERFAHREN);
    }
}
