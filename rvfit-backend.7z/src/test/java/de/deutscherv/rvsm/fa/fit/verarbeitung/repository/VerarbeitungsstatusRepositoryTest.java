package de.deutscherv.rvsm.fa.fit.verarbeitung.repository;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@QuarkusTest
@Slf4j
class VerarbeitungsstatusRepositoryTest {

    @Inject
    VerarbeitungsstatusRepository verarbeitungsstatusRepository;
    @Inject
    DrvMandant drvMandant;

    /**
     * Testet das Speichern von PSD in der DB.
     */
    @Test
    @Transactional
    void shouldPersistAndFlushInDB() {
        drvMandant.setInScope("70");
        final UUID antragId = UUID.randomUUID();

        final Verarbeitungsstatus verarbeitungsstatus = createVerarbeitungsstatus(antragId);

        verarbeitungsstatusRepository.persistAndFlush(verarbeitungsstatus);

        final Optional<Verarbeitungsstatus> foundVerarbeitungsstatus = verarbeitungsstatusRepository.findByAntragId(antragId);

        assertThat(foundVerarbeitungsstatus).isNotNull();
        assertDoesNotThrow(foundVerarbeitungsstatus::get);
        assertThat(foundVerarbeitungsstatus).isPresent();
    }

    @Test
    @Transactional
    void shouldPersistFlushInDB() {
        drvMandant.setInScope("70");
        final UUID antragId = UUID.randomUUID();

        final Verarbeitungsstatus verarbeitungsstatus = createVerarbeitungsstatus(antragId);

        verarbeitungsstatusRepository.persist(verarbeitungsstatus);
        verarbeitungsstatusRepository.flush();

        final Optional<Verarbeitungsstatus> foundVerarbeitungsstatus = verarbeitungsstatusRepository.findByAntragId(antragId);

        assertThat(foundVerarbeitungsstatus).isNotNull();
        assertDoesNotThrow(foundVerarbeitungsstatus::get);
        assertThat(foundVerarbeitungsstatus).isPresent();
    }

    private Verarbeitungsstatus createVerarbeitungsstatus(final UUID antragId) {
        return Verarbeitungsstatus.builder()
                .status(VerarbeitungStatus.OHNE_VERSAND_ERLEDIGT)
                .art(Art.GESPERRT)
                .antragId(antragId)
                .auftragId(UUID.randomUUID())
                .created(LocalDateTime.now())
                .meldung("Hallo")
                .lastmodified(LocalDateTime.now())
                .build();
    }
}
