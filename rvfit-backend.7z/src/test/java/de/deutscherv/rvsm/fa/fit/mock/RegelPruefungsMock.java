package de.deutscherv.rvsm.fa.fit.mock;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.Regel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichGeburtsdatumRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichHausnummerRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichLandRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichNachnameRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichPlzRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichStaatsangehoerigkeitRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichStrasseRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichVornameRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichVsnrRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AbgleichWohnortRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AktiveBeschaeftigungRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AltersteilzeitRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AntragAltersrenteRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AntragEMRenteRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.AufenthaltRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.BeamteneigenschaftRegelAnwaerterschaft;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.BeamteneigenschaftRegelBezuege;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.BezugAltersrenteRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.BezugEMRenteRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungAngebotEindeutig;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungFreiePlaetze;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.EinrichtungVorhandenUndIdentisch;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.LaufenderRehaAntragRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.MassnahmenRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.StaatsangehoerigkeitRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.WartezeitpruefungRegel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.regeln.WiderspruchsverfahrenRegel;
import java.util.List;
import java.util.Objects;

/**
 * RegelPruefungsMock.
 */
public final class RegelPruefungsMock {

    private static final List<Regel>
        ALLE_REGELN = List.of(new AbgleichGeburtsdatumRegel(), new AbgleichHausnummerRegel(),
        new AbgleichLandRegel(), new AbgleichNachnameRegel(), new AbgleichPlzRegel(),
        new AbgleichStaatsangehoerigkeitRegel(), new AbgleichStrasseRegel(),
        new AbgleichVornameRegel(), new AbgleichVsnrRegel(), new AbgleichWohnortRegel(),
        new AktiveBeschaeftigungRegel(), new AltersteilzeitRegel(),
        new AntragAltersrenteRegel(), new AntragEMRenteRegel(), new AufenthaltRegel(),
        new BeamteneigenschaftRegelAnwaerterschaft(),
        new BeamteneigenschaftRegelBezuege(), new BezugAltersrenteRegel(),
        new BezugEMRenteRegel(), new EinrichtungAngebotEindeutig(),
        new EinrichtungFreiePlaetze(), new EinrichtungVorhandenUndIdentisch(),
        new LaufenderRehaAntragRegel(), new MassnahmenRegel(),
        new StaatsangehoerigkeitRegel(), new WartezeitpruefungRegel(),
        new WiderspruchsverfahrenRegel());

    private RegelPruefungsMock() {
    }

    private static Long getRegelPrioritaet(final RegelName regelName) {
        return switch (regelName) {
            case REGEL_ABGLEICH_VSNR -> 20L;
            case REGEL_ABGLEICH_NACHNAME -> 22L;
            case REGEL_ABGLEICH_VORNAME -> 21L;
            case REGEL_ABGLEICH_GEBURTSDATUM -> 23L;
            case REGEL_ABGLEICH_STRASSE -> 25L;
            case REGEL_ABGLEICH_HAUSNUMMER -> 26L;
            case REGEL_ABGLEICH_PLZ -> 27L;
            case REGEL_ABGLEICH_WOHNORT -> 28L;
            case REGEL_ABGLEICH_LAND -> 29L;
            case REGEL_ABGLEICH_STAATSANGEHOERIGKEIT -> 24L;
            case REGEL_STAATSANGEHOERIGKEIT -> 2L;
            case REGEL_ANTRAGALTERSRENTE -> 4L;
            case REGEL_ANTRAGEMRENTE -> 10L;
            case REGEL_BEAMTENEIGENSCHAFT_BEZUEGE -> 5L;
            case REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT -> 6L;
            case REGEL_BEZUGALTERSRENTE -> 1L;
            case REGEL_BEZUGEMRENTE -> 9L;
            case REGEL_MASSNAHME -> 14L;
            case REGEL_WARTEZEITPRUEFUNG -> 7L;
            case REGEL_WIDERSPRUCHSVERFAHREN -> 13L;
            case REGEL_AKTIVEBESCHAEFTIGUNG -> 8L;
            case REGEL_ALTERSTEILZEIT -> 11L;
            case REGEL_AUFENTHALT -> 3L;
            default -> null;
        };
    }

    /**
     * Regelpruefung durchfuehren.
     *
     * @param regelKontext Regelkontext
     * @param antrag       Antrag
     */
    public static void fuehreRegelPruefungDurch(final RegelKontext regelKontext, final Antrag antrag) {
        final RegelEngine regelEngine = new RegelEngine(ALLE_REGELN);

        final List<RegelName> regelIds = ALLE_REGELN.stream().map(Regel::getRegelName).toList();
        final RegelErgebnis regelErgebnis = regelEngine.check(regelIds, regelKontext);

        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setBegruendung(regelErgebnis.getDetail());
        antragPruefergebnis.setErgebnis(regelErgebnis.getPruefErgebnis());
        antragPruefergebnis.setParentUuid(null);
        antragPruefergebnis.setRegelName(null);
        antragPruefergebnis.setRegelId(null);
        antragPruefergebnis.setPrioritaet(null);
        antragPruefergebnis.setKtan(antrag.getKtan());
        antrag.addAntragPruefergebnis(antragPruefergebnis);

        if (Objects.nonNull(regelErgebnis.getDetailErgebnisse())
            && !regelErgebnis.getDetailErgebnisse().isEmpty()) {
            verkettePruefergebnisse(antragPruefergebnis, regelErgebnis, antrag);
        }
    }

    private static void verkettePruefergebnisse(final AntragPruefergebnis antragPruefergebnisParent, final RegelErgebnis regelErgebnis,
        final Antrag antrag) {
        for (final RegelErgebnis ergebnis : regelErgebnis.getDetailErgebnisse()) {
            final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
            antragPruefergebnis.setBegruendung(ergebnis.getDetail());
            antragPruefergebnis.setErgebnis(ergebnis.getPruefErgebnis());
            antragPruefergebnis.setRegelName(ergebnis.getRegelName());
            antragPruefergebnis.setParentUuid(antragPruefergebnisParent.getUuid());
            antragPruefergebnis.setRegelId(ergebnis.getRegelName().getId());
            antragPruefergebnis.setPrioritaet(getRegelPrioritaet(ergebnis.getRegelName()));
            antragPruefergebnis.setKtan(antrag.getKtan());
            antrag.addAntragPruefergebnis(antragPruefergebnis);
        }
    }

}
