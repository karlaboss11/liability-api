package de.deutscherv.rvsm.fa.fit.kontoinformation;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationException;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.FehlerEintrag;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test Kontoinformationsservice.
 */
@ExtendWith(MockitoExtension.class)
public class KontoinformationServiceTest {

    private static final String KEIN_AF_FEHLER = "TP0101";

    @InjectMocks private KontoinformationService kontoinformationService;
    @Mock private Response response;
    @Mock private WebApplicationException webApplicationException;
    @Mock private KontoinformationResponse kontoinformationResponse;
    @Mock private Antrag antrag;

    /**
     * Exception wird geworfen wenn kein AF-Fehler gegeben ist.
     */
    @Test
    void wirftKontoinformationExceptionWhenKeinAFFehler() {

        FehlerEintrag fehlerEintrag = FehlerEintrag.builder()
                .statuscode(KEIN_AF_FEHLER).message("Ein rvSystem Fehler").build();

        Mockito.lenient().when(antrag.getKtan()).thenReturn("KTAN-001");
        Mockito.lenient().when(antrag.getVsnr()).thenReturn("VSNR-001");

        Mockito.lenient().when(webApplicationException.getResponse()).thenReturn(response);
        Mockito.lenient().when(response.hasEntity()).thenReturn(true);
        Mockito.lenient().when(response.readEntity(KontoinformationResponse.class)).thenReturn(kontoinformationResponse);
        Mockito.lenient().when(kontoinformationResponse.getRvSystemFehler()).thenReturn(List.of(fehlerEintrag));

        assertThrows(KontoinformationException.class,
                () -> kontoinformationService.bestandsfehlerAufgetreten(antrag,webApplicationException));
    }
}
