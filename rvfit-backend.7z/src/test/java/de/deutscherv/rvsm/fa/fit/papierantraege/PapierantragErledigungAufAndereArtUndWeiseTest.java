package de.deutscherv.rvsm.fa.fit.papierantraege;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikClient;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.ErfassungResponseDto;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

/**
 * Test PapierantragErledigungAufAnsdereArtUndWeise.
 */
@Slf4j
@QuarkusTest
class PapierantragErledigungAufAndereArtUndWeiseTest {

    private static final String AUFGABEN_ID = "AUID0123456789";
    private static int iVorgangsnummer = 0;
    private final CountDownLatch latch = new CountDownLatch(1);
    @InjectMock
    @RestClient
    private StatistikClient statistikClient;
    @Inject
    private AntragRepository antragRepository;
    @Inject
    private EntityManager entityManager;
    @Inject
    private DrvMandant drvMandant;

    /**
     * TEST - Testet die Verarbeitung eines Papierantrags im Fall "Erledigung auf andere Art und Weise", wenn Statistik beim
     * Bescheiderstellung (createStatistikBescheid) einen internen Serverfehler (HTTP 500) zurückliefert.
     */
    @SneakyThrows
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    void testVerarbeitePapierantragErledigungAufAndereArtUndWeiseInternalServerError() {
        PapierantragDto dto;
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {

            clearInvocations(statistikClient);

            ErfassungResponseDto entity = new ErfassungResponseDto();
            entity.setATAD("0000");
            entity.setMSNR("00");

            when(statistikClient.createStatistikAntragserfassung(any(), any()))
                .thenReturn(Response.status(201).entity(entity).build());

            // Simulate statistic fails receiving 500 response
            when(statistikClient.createStatistikBescheid(any(), any())).thenThrow(
                new WebApplicationException(Response.status(500).entity("Internal Server Error").build())
            );

            final PapierantragDto papierantragDto = erstellePapierantrag("03080800B018");

            dto = given().contentType(ContentType.JSON).body(papierantragDto).when()
                .post("/papierantraege/erledigung-auf-andere-art-und-weise").then().statusCode(201)
                .extract().as(PapierantragDto.class);
        }

        latch.await(30, TimeUnit.SECONDS);

        Mockito.verify(statistikClient, times(1)).createStatistikBescheid(any(), any());

        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final Optional<Antrag> antrag = antragRepository.findByUuid(UUID.fromString(dto.getAntrag().getUuid()));
            assertThat(antrag).isPresent();
            assertThat(antrag.get().getStatus()).isEqualTo(AntragStatus.BESCHEID_ABGESCHLOSSEN);

            final Fehler fehler = findFehler(antrag.get().getUuid());
            assertThat(fehler).isNotNull();
            assertThat(fehler.getStatus()).isEqualTo(AntragStatus.BESCHEID_ABGESCHLOSSEN);

        }
    }

    private PapierantragDto erstellePapierantrag(String vsnr) {
        if (vsnr.isEmpty()) {
            vsnr = "23270152B506";
        }

        final PapierantragDto papierAntrag = new PapierantragDto();
        final AntragDto antragDto = new AntragDto();

        final StammdatenDto myStamm = new StammdatenDto();
        myStamm.setVsnr(vsnr);
        myStamm.setVorname("Peter");
        myStamm.setNachname("Pan");
        myStamm.setGeburtsdatum("2000-08-08");
        myStamm.setStaatsangehoerigkeit("151");

        myStamm.setWohnort("Wohnort");
        myStamm.setPlz("12345");
        myStamm.setStrasse("Musterstraße");
        myStamm.setHausnummer("123");

        antragDto.setTelefon("0921123456");
        antragDto.setFax("0921987654");
        antragDto.setAntragsdatum(LocalDate.now());
        antragDto.setEingangsdatum(LocalDate.now());
        antragDto.setUuid(UUID.randomUUID().toString());

        antragDto.setWohnort("Wohnort");
        antragDto.setPlz("12345");
        antragDto.setStrasse("Musterstraße");
        antragDto.setHausnummer("123");

        antragDto.setVsnr(vsnr);
        antragDto.setVorname("Peter");
        antragDto.setNachname("Pan");
        antragDto.setGeburtsdatum("2000-08-08");
        antragDto.setStaatsangehoerigkeit("151");
        antragDto.setKtan("17");

        papierAntrag.setAntrag(antragDto);
        papierAntrag.setVersicherter(myStamm);
        papierAntrag.setAufgabenId(AUFGABEN_ID);
        papierAntrag.setVorgangsId(generiereNeueVogID());

        return papierAntrag;
    }

    private String generiereNeueVogID() {
        iVorgangsnummer++;
        return "V24" + String.format("%07d", iVorgangsnummer) + "RV32";
    }

    /**
     * Finden den Fehler. :-)
     *
     * @param antragUuid des Antrags
     * @return gefundener Fehler
     */
    @SneakyThrows
    @Transactional
    public Fehler findFehler(final UUID antragUuid) {
        try (AutoCloseable ignore = drvMandant.setInScope("70")) {
            final TypedQuery<Fehler> query = entityManager.createQuery(
                "select f from Fehler f where f.antragId = :antragUuid",
                Fehler.class);
            query.setParameter("antragUuid", antragUuid);
            return query.getResultStream().findFirst().orElse(null);
        }
    }

}