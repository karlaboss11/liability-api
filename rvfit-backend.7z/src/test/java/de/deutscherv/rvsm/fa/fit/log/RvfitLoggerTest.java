package de.deutscherv.rvsm.fa.fit.log;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.validation.ValidationException;
import java.util.Optional;
import java.util.UUID;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.DRV_ID;
import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.DRV_MANDANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test RvfitLogger.
 */
@QuarkusTest
class RvfitLoggerTest {

    @Inject
    private RvfitLogger rvfitLogger;

    @Inject
    private DrvMandant drvMandant;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeEach
    void setup() {
        drvMandant.setInScope("70");
    }

    /**
     * Test - Erstelle Fachereignis mit Aufgabe.
     */
    @Test
    void createFachereignisMitAufgabe() {
        String drvId = "DRV701000000123";
        String ktan = "70";
        UUID aufgabenId = UUID.randomUUID();
        JsonWebToken jwt = mock(JsonWebToken.class);
        when(jwt.claim(DRV_ID)).thenReturn(Optional.of(drvId));
        when(jwt.claim(DRV_MANDANT)).thenReturn(Optional.of(ktan));
        final Fachereignis fachereignis = LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_USER,
                Ereignistext.ANSPRUCHSPRUEFUNG_ANGEPASST, EreignisFreitext.ANSPRUCHSPRUEFUNG_ANGEPASST,
                "Wartezeit", Antrag.builder().uuid(UUID.randomUUID()).ktan("70").build(),
                Aufgabe.builder().transaktionId(aufgabenId)
                        .aufgabenArt(AufgabenArt.ANSPRUCHSVORAUSSETZUNG).build(),
                jwt, drvMandant);

        assertThat(fachereignis.freitext()).isEqualTo("Das Prüfergebnis zur Anspruchsvoraussetzung Wartezeit wurde manuell geändert.");
        assertThat(fachereignis.ausloeserDTO().getItpName()).isEqualTo("RV Fit");
        assertThat(fachereignis.ausloeserDTO().getAusloesendePerson().getDrvId()).isEqualTo(drvId);
        assertThat(fachereignis.aufgabeDTO().getId()).isEqualTo(String.valueOf(aufgabenId));

        assertDoesNotThrow(() -> rvfitLogger.sendeFachprotokollEreignis(fachereignis));
    }

    /**
     * Test - Erstelle Fachereignis ohne Aufgabe.
     */
    @Test
    void createFachereignisOhneAufgabe() {
        final Fachereignis fachereignis = LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                Ereignistext.KONTOINFORMATION_GESPEICHERT, EreignisFreitext.KONTOINFORMATIONEN_GESPEICHERT,
                "Wartezeit", Antrag.builder().uuid(UUID.randomUUID()).ktan("70").build(),
                Aufgabe.builder().transaktionId(UUID.randomUUID())
                        .aufgabenArt(AufgabenArt.ANSPRUCHSVORAUSSETZUNG).build(),
                null, null);

        assertThat(fachereignis.freitext()).isEqualTo("Die Kontoinformationen wurden gespeichert.");
        assertThat(fachereignis.ausloeserDTO().getItpName()).isEqualTo("RV Fit");
        assertNull(fachereignis.aufgabeDTO());

        assertDoesNotThrow(() -> rvfitLogger.sendeFachprotokollEreignis(fachereignis));
    }

    /**
     * Test - Erstelle Fachereignis mit falscher KTAN.
     */
    @Test
    void createFachereignisInvalideKtan() {
        final Fachereignis fachereignis = LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_EINGANG_MASCHINELL,
                Ereignistext.ANTRAG_EINGEGANGEN, EreignisFreitext.ANTRAG_EINGEANGEN_E, null,
                Antrag.builder().uuid(UUID.randomUUID()).ktan("99").build(),
                Aufgabe.builder().transaktionId(UUID.randomUUID())
                        .aufgabenArt(AufgabenArt.ANSPRUCHSVORAUSSETZUNG).build(),
                null, null);

        assertDoesNotThrow(() -> rvfitLogger.sendeFachprotokollEreignis(fachereignis));

    }

    /**
     * Test - Erstelle Fachereignis mit fehlerhafter Validierung.
     */
    @Test
    void createFehlerhaftesFachereignisShouldThrowValidationException() {
        final Fachereignis fachereignis = LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_EINGANG_MASCHINELL,
                Ereignistext.ANTRAG_EINGEGANGEN, EreignisFreitext.ANTRAG_EINGEANGEN_E, null,
                Antrag.builder().uuid(UUID.randomUUID()).ktan("70").build(),
                Aufgabe.builder().transaktionId(UUID.randomUUID())
                        .aufgabenArt(AufgabenArt.ANSPRUCHSVORAUSSETZUNG).build(),
                null, null);
        fachereignis.ausloeserDTO().setItpName(null);

        assertThatThrownBy(() -> rvfitLogger.sendeFachprotokollEreignis(fachereignis))
                .isInstanceOf(ValidationException.class);
    }
}
