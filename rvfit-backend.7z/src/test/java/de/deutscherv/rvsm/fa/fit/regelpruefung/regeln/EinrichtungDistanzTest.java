package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class EinrichtungDistanzTest {

    private final EinrichtungDistanz einrichtungDistanz = new EinrichtungDistanz();

    private static RehaEinrichtung einrichtungBautzenOhneDistanz;
    private static RehaEinrichtung einrichtungBautzen;
    private static RehaEinrichtung einrichtungMuenchen;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void set() {
        einrichtungBautzenOhneDistanz = RehaEinrichtung.builder().smpEinrichtungsId(10018L).name("ZAR Bautzen")
            .adresse(EinrichtungAnschrift.builder().plz("02625").ort("Bautzen").build())
            .angebote(List.of(
                Angebot.builder().smpAngebotId(17559L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("stationär").build(),
                Angebot.builder().smpAngebotId(17561L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("stationär").build(),
                Angebot.builder().smpAngebotId(17560L).phase("Trainingsphase").freiePlaetzeWert(1)
                    .durchfuehrungsart("online").build()))
            .build();
        einrichtungBautzen = RehaEinrichtung.builder().distanzVersicherter(10).smpEinrichtungsId(10018L)
            .name("ZAR Bautzen")
            .adresse(EinrichtungAnschrift.builder().plz("02625").ort("Bautzen").build())
            .angebote(List.of(
                Angebot.builder().smpAngebotId(17559L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("stationär").distanzVersicherter(10).build(),
                Angebot.builder().smpAngebotId(17561L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("stationär").distanzVersicherter(10).build(),
                Angebot.builder().smpAngebotId(17560L).phase("Trainingsphase").freiePlaetzeWert(1)
                    .durchfuehrungsart("online").distanzVersicherter(10).build()))
            .build();
        einrichtungMuenchen = RehaEinrichtung.builder().distanzVersicherter(10).smpEinrichtungsId(10015L)
            .name("Testklinik Milbertshofen am Hart")
            .adresse(EinrichtungAnschrift.builder().plz("80937").ort("München").build())
            .angebote(List.of(
                Angebot.builder().distanzVersicherter(10).smpAngebotId(17549L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().distanzVersicherter(10).smpAngebotId(17551L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().distanzVersicherter(10).smpAngebotId(17550L).phase("Trainingsphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant").build()))
            .build();
    }

    /**
     * Test, keine Einrichtung vorhanden.
     */
    @Test
    void keineEinrichtungenVorhandenTest() {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().build(), null, null, null, null);
        final List<RegelErgebnis> regelErgebnisse = einrichtungDistanz.pruefeRegel(regelKontext);

        assertThat(regelErgebnisse).isNotNull().isEmpty();
    }

    /**
     * Test, Einrichtung München für Start-, Auffrischungs- und Trainingsphase. In 50 km Umgebung und ambulantes Angebot.
     */
    @Test
    void einrichtungMuenchenStartAufUndTrainingIn50KmUndAmbulanteAngebote04010101G996Test() {
        final Antrag antrag = Antrag.builder().vsnr("04010101G996").wohnort("München").plz("80937")
            .angebotStartName("Testklinik Milbertshofen am Hart").angebotStartOrt("München")
            .angebotStartPlz("80937").angebotStartStrasse("Neuherbergstraße 114")
            .angebotTrainingName("Testklinik Milbertshofen am Hart").angebotTrainingOrt("München")
            .angebotTrainingPlz("80937").angebotTrainingStrasse("Neuherbergstraße 114").build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungMuenchen),
                List.of(einrichtungMuenchen), List.of(einrichtungMuenchen));

        final List<RegelErgebnis> regelErgebnisse = einrichtungDistanz.pruefeRegel(regelKontext);

        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungDistanz.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    /**
     * Test, Einrichtung Bauten  für Start-, Auffrischungssphase. Mehr als 50 km Umgebung.
     */
    @Test
    void einrichtungBautzenStartAufStationaerMehrAls50Km04010399W223Test() {
        final Antrag antrag = Antrag.builder().vsnr("04010399W223").wohnort("Berlin").plz("10709")
            .angebotStartName("ZAR Bautzen").angebotStartOrt("Bautzen").angebotStartPlz("02625")
            .angebotStartStrasse("Steinstraße 37").build();

        final RegelKontext regelKontext = new RegelKontext(antrag, null,
            List.of(einrichtungBautzen), List.of(einrichtungBautzen), null);

        final List<RegelErgebnis> regelErgebnisse = einrichtungDistanz.pruefeRegel(regelKontext);

        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungDistanz.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    /**
     * Test, Einrichtung München für Start-, Auffrischungsphase. Mehr als 50 km und stationaeres Angebot.
     */
    @Test
    void einrichtungBautzenOhneDistanzStartAufStationaerMehrAls50Km04010399W223Test() {
        final Antrag antrag = Antrag.builder().vsnr("04010399W223").wohnort("Berlin").plz("10709")
            .angebotStartName("ZAR Bautzen").angebotStartOrt("Bautzen").angebotStartPlz("02625")
            .angebotStartStrasse("Steinstraße 37").build();

        final RegelKontext regelKontext = new RegelKontext(antrag, null,
            List.of(einrichtungBautzenOhneDistanz), List.of(einrichtungBautzenOhneDistanz), null);

        final List<RegelErgebnis> regelErgebnisse = einrichtungDistanz.pruefeRegel(regelKontext);

        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
    }
}
