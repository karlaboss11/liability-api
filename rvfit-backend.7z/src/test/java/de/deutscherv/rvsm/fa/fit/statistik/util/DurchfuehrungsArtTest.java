package de.deutscherv.rvsm.fa.fit.statistik.util;

import de.deutscherv.rvsm.fa.fit.exceptions.MapperException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DurchfuehrungsArtTest {

    /**
     * Test prüft, dass das Durchführungsart Enum anhand der Bezeichnung abgefragt werden kann.
     *
     * @param durchfuehrungsArt die Durchführungsart
     */
    @ParameterizedTest
    @EnumSource(DurchfuehrungsArt.class)
    void testDurchfuerungsArtErfolgreicheZuordnung(final DurchfuehrungsArt durchfuehrungsArt) {
        DurchfuehrungsArt actual =
                DurchfuehrungsArt.fuerBezeichnung(durchfuehrungsArt.getBezeichnung());
        assertThat(actual).isEqualTo(durchfuehrungsArt);
    }

    /**
     * Test prüft, dass eine MapperException geworfen wird, wenn für eine unbekannte Bezeichnung die Durchführungsart zurückgegeben werden
     * soll.
     */
    @Test
    void testDurchfuehrungsArtNotFoundException() {
        assertThrows(MapperException.class, () -> DurchfuehrungsArt.fuerBezeichnung("invalid"));
    }

}