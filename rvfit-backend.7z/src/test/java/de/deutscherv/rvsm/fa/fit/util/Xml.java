package de.deutscherv.rvsm.fa.fit.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.AbstractMap.SimpleEntry;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Diese Hilfsklasse dient für allgemeine Aufgaben rund um xml.
 */
@UtilityClass
@Slf4j
public class Xml {

    /**
     * Liest ein xml file und konvertiert in string.
     *
     * @param xmlFile die XML Datei
     * @return String mit XML
     */
    private String xmlToString(final String xmlFile) {
        try (InputStream ioStream =
                Thread.currentThread().getContextClassLoader().getResourceAsStream(xmlFile)) {
            return IOUtils.toString(ioStream, StandardCharsets.UTF_8);
        } catch (final IOException e) {
            LOG.atInfo().setCause(e).log("Beim Unmarshalling ist ein Fehler aufgetreten");
        }
        return StringUtils.EMPTY;
    }

    /**
     * eAntrag wird als XML im String ausgegeben.
     * @param eAntragName Name des eAntrags
     * @return XML als String
     */
    public static String getXmlAntrag(final String eAntragName) {
        return xmlToString(eAntragName);
    }

    /**
     * Liefert XML-Antraege.
     * @param antraege Liste der Antrage.
     * @return Map mit Key des Antragsnamen und Value der zugehoerige XML-String
     */
    public static Map<String, String> getXmlAntraege(final List<String> antraege) {
        return antraege.stream()
                .map(a -> new SimpleEntry<>(a, getXmlAntrag("/eAntragXmls/" + a + ".xml")))
                .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue));
    }

    /**
     * Liefert XML-Antraege aus dem Verzeichnis mit den modifizierten Antraegen.
     * @param antraege Liste der Antrage.
     * @return Map mit Key des Antragsnamen und Value der zugehoerige XML-String
     */
    public static Map<String, String> getXmlAntraegeModifiziert(final List<String> antraege) {
        return antraege.stream()
                .map(a -> new SimpleEntry<>(a, getXmlAntrag("/eAntragXmlsModifiziert/" + a + ".xml")))
                .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue));
    }
}
