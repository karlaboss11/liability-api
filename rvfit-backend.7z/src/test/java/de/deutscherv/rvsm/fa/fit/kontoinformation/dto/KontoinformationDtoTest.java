package de.deutscherv.rvsm.fa.fit.kontoinformation.dto;

import de.deutscherv.rvsm.fa.fit.openapi.model.KontoinformationDto;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KontoinformationDtoTest {

    private Validator validator;

    @BeforeEach
    public void setUp() {
        final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void testWhenFieldsTooShort() {

        final KontoinformationDto dto = new KontoinformationDto().vsnr("13240855M5")
                .antragRehaMsat("").antragRehaArt("A").massnahmeRehaElat("1").antragRenteLeat("1")
                .bezugRenteLeat("1").antragRenteTlrt("").bezugRenteTlrt("").beschaeftigungGruppe("AB")
                .beschaeftigungGrund("A").altersteilzeitGruppe("AB").altersteilzeitGrund("A").ktan("7");

        final Set<ConstraintViolation<KontoinformationDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(13, violations.size());
    }

    @Test
    void testWhenFieldsTooLong() {

        final KontoinformationDto dto = new KontoinformationDto().vsnr("23270152B50678")
                .antragRehaMsat("AB").antragRehaArt("ABC").massnahmeRehaElat("ABC")
                .antragRenteLeat("ABC").bezugRenteLeat("ABC").antragRenteTlrt("AB")
                .bezugRenteTlrt("925.78545").beschaeftigungGruppe("ABCD").beschaeftigungGrund("ABC")
                .altersteilzeitGruppe("ABCD").altersteilzeitGrund("ABC").ktan("712");

        final Set<ConstraintViolation<KontoinformationDto>> violations = validator.validate(dto);

        assertFalse(violations.isEmpty());
        assertEquals(13, violations.size());

    }

    @Test
    void testWhenFieldsValid() {

        final KontoinformationDto dto = new KontoinformationDto().vsnr("23270152B506")
                .antragRehaMsat("A").antragRehaArt("AB").massnahmeRehaElat("AB").antragRenteLeat("AB")
                .bezugRenteLeat("AB").antragRenteTlrt("A").bezugRenteTlrt("A")
                .beschaeftigungGruppe("ABC").beschaeftigungGrund("AB").altersteilzeitGruppe("ABC")
                .altersteilzeitGrund("AB").ktan("71");

        final Set<ConstraintViolation<KontoinformationDto>> violations = validator.validate(dto);

        assertTrue(violations.isEmpty());
    }
}
