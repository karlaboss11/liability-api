package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test, AntragAlterrenteRegel.
 */
class AntragAltersrenteRegelTest {

    private static final String AUSSTEUERN_KEINE_DATEN = "Es liegen keine vollstaendigen Daten vor";
    private static final String ERFUELLT = "Es wurde kein Antrag auf Altersente gestellt";
    private static final String NICHT_ERFUELLT_AUSSTEUERN =
        "Es wurde ein Antrag auf Altersente gestellt";

    private static final RegelEngine engine = new RegelEngine(List.of(new AntragAltersrenteRegel()));

    /**
     * Test, fehlende Kontoinformationen.
     */
    @Test
    void testEmptyKontoinformationen() {
        final RegelErgebnis teilErgebnis = getTeilErgebnis(null, LocalDate.now(), null);

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Test, Aussteuern wenn Fragezeichen.
     *
     * @param antragRenteLeat Antrag Rente Leat
     * @param antragRenteTlrt Antrag Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({ "??, ?", "??, 0", "00, ?" })
    void aussteuernWhenQuestionMark(final String antragRenteLeat, final String antragRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .antragRenteLeat(antragRenteLeat).antragRenteTlrt(antragRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Test, Antrag Rente Leat nicht in der Liste.
     *
     * @param antragRenteLeat Antrag Rente Leat
     * @param antragRenteTlrt Antrag Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "1, null", "3, 4", "00, 0"
    })
    void testAntragRenteLeatNotInList(final String antragRenteLeat, final String antragRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .antragRenteLeat(antragRenteLeat).antragRenteTlrt(antragRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    /**
     * Test, Amtrag Rente Leat ist in der Liste und Rente Tlrt is Neun.
     *
     * @param antragRenteLeat Antrag Rente Leat
     * @param antragRenteTlrt Antrag Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "65, 9", "18, 9", "63, 9", "62, 9", "17, 9", "16, 9", "10, 9", "19, 9"
    })
    void testAntragRenteLeatInListAndTlrtIsNine(final String antragRenteLeat,
        final String antragRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .antragRenteLeat(antragRenteLeat).antragRenteTlrt(antragRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis())
            .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(NICHT_ERFUELLT_AUSSTEUERN);
    }

    private RegelErgebnis getTeilErgebnis(final List<Kontoinformation> kontoinformationen,
        final LocalDate antragsDatum, final Stammdaten stammdaten) {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().kontoinformationen(kontoinformationen)
                .antragsDatum(antragsDatum).build(), stammdaten, null, null, null);
        final RegelErgebnis gesamtErgebnis =
            engine.check(List.of(RegelName.REGEL_ANTRAGALTERSRENTE), regelKontext);
        return gesamtErgebnis.getDetailErgebnisse().getFirst();
    }
}
