package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.util.Json;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static de.deutscherv.rvsm.fa.fit.testdaten.TestPerson.PETER_PAN;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test des SachverhaltsaufklaerungsDokumentErzeugungsService.
 */
@Slf4j
class SachverhaltsaufklaerungsDokumentErzeugungsServiceTest
        extends DokumentenErzeugungsServiceTestParent {

    private static SachverhaltsaufklaerungsDokumentErzeugungsService sachverhaltsaufklaerungDoeService;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeAll
    static void setup() {
        sachverhaltsaufklaerungDoeService = new SachverhaltsaufklaerungsDokumentErzeugungsService(new DokumentenErzeugungTestConfig());
    }

    /**
     * Vorbereitung vor jedem Test.
     */
    @BeforeEach
    void reset() {
        this.dto = null;
    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @SneakyThrows
    @AfterEach
    void afterEach() {
        printResult();
    }

    /**
     * Test Staatsangehoerigkeitsregel ist nicht erfuellt.
     */
    @SneakyThrows
    @Test
    void testeDokumentenErzeugungFuerStaatsangehoerigkeitRegelNichtErfuellt() {
        DokumentenErstellungsDaten daten = erstelleDokumentenErstellungsTestDaten(PETER_PAN);

        this.dto = sachverhaltsaufklaerungDoeService.erzeugeAuftragsDto(daten);

        assertThat(dto.getFall()).isEqualTo(PETER_PAN.VSNR);
        assertThat(dto.getAigr()).isEqualTo(String.format("%04d", daten.antrag().getAtad()));
        Map<String, String> variablen = dto.getInputs().getVariablen();
        assertThat(variablen).isNotNull().isNotEmpty();
        assertThat(variablen.get("rvEvolution")).isEqualTo("1");
        assertThat(variablen.get("teilprozess")).isEqualTo("08");
        assertThat(variablen).containsEntry("massnahmeArtNummer", "8" + String.format("%02d", daten.antrag().getMsnr()));
        assertThat(variablen.get("terminDatum")).isEqualTo(LocalDate.now().plusDays(28).format(
                DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        assertThat(variablen.get("sv_kk_maschineller_Aufruf")).matches("true");

        System.out.println(Json.objectToJson(dto));
    }

}
