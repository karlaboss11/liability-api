package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class PruefergebnisUtilsTest {

    static Stream<Arguments> testcases() {
        return Stream.of(
            Arguments.of(RegelName.REGEL_ABGLEICH_PLZ, PruefErgebnis.AUSSTEUERN, true),
            Arguments.of(RegelName.REGEL_ABGLEICH_VORNAME, PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, true),
            Arguments.of(RegelName.REGEL_ABGLEICH_VORNAME, PruefErgebnis.ERFUELLT, false)
        );
    }

    /**
     * Test Personendatenabgleich mit fehlgeschlagenem Abgleich.
     *
     * @param regelName Name der Regel
     * @param ergebnis  Pruefergebnis
     * @param expected  erwartete Antwort.
     */
    @ParameterizedTest
    @MethodSource("testcases")
    void testPersonendatenabgleichFailedAntrag(RegelName regelName, PruefErgebnis ergebnis, boolean expected) {
        final AntragPruefergebnis pruefergebnis = mock(AntragPruefergebnis.class);
        Mockito.lenient().when(pruefergebnis.getRegelName()).thenReturn(regelName);
        Mockito.lenient().when(pruefergebnis.getErgebnis()).thenReturn(ergebnis);

        final Antrag antrag = mock(Antrag.class);
        Mockito.lenient().when(antrag.getAntragPruefergebnisse()).thenReturn(List.of(pruefergebnis));

        final boolean result = PruefergebnisUtils.personendatenabgleichFailed(antrag);
        assertThat(result).isEqualTo(expected);
    }

    /**
     * Test Personendatenabgleich mit fehlgeschlagenem Regelergebnisses.
     *
     * @param regelName Name der Regel
     * @param ergebnis  Pruefergebnis
     * @param expected  erwartete Antwort.
     */
    @ParameterizedTest
    @MethodSource("testcases")
    void testPersonendatenabgleichFailedRegelErgebnis(RegelName regelName, PruefErgebnis ergebnis, boolean expected) {
        final RegelErgebnis regelErgebnis = mock(RegelErgebnis.class);
        Mockito.lenient().when(regelErgebnis.getRegelName()).thenReturn(regelName);
        Mockito.lenient().when(regelErgebnis.getPruefErgebnis()).thenReturn(ergebnis);

        assertThat(PruefergebnisUtils.personendatenabgleichFailed(List.of(regelErgebnis))).isEqualTo(expected);
    }

    /**
     * Test Pruefergenis erfordert Freitext ist True wenn wichtigste Regel einen Freitext erfordert.
     */
    @Test
    void testPruefergebnisErforderFeitextIsTrueWennWichtigsteRegelFreitextErfordert() {
        final var erfordertFreitext = new AntragPruefergebnis();
        erfordertFreitext.setRegelName(RegelName.REGEL_ANTRAGEMRENTE);
        erfordertFreitext.setBegruendung("begründung");
        erfordertFreitext.setPrioritaet(1L);
        erfordertFreitext.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        final var erfordertKeinenFreitext = new AntragPruefergebnis();
        erfordertKeinenFreitext.setRegelName(RegelName.REGEL_ANTRAGALTERSRENTE);
        erfordertKeinenFreitext.setBegruendung("begründung");
        erfordertKeinenFreitext.setPrioritaet(10L);
        erfordertKeinenFreitext.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        final var ergebnisse = List.of(erfordertFreitext, erfordertKeinenFreitext);

        final var antrag = mock(Antrag.class);
        Mockito.lenient().when(antrag.getAntragPruefergebnisse()).thenReturn(ergebnisse);

        assertThat(PruefergebnisUtils.pruefergebnisErfordertFreitextEingabe(antrag)).isTrue();
    }

    /**
     * Test Pruefergenis erfordert Freitext ist False wenn wichtigste Regel keinen Freitext erfordert.
     */
    @Test
    void testPruefergebnisErforderFreitextIsFalseWennWichtigsteRegelKeinenFreitextErfordert() {
        final var erfordertFreitext = new AntragPruefergebnis();
        erfordertFreitext.setRegelName(RegelName.REGEL_ANTRAGEMRENTE);
        erfordertFreitext.setBegruendung("begründung");
        erfordertFreitext.setPrioritaet(10L);
        erfordertFreitext.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        final var erfordertKeinenFreitext = new AntragPruefergebnis();
        erfordertKeinenFreitext.setRegelName(RegelName.REGEL_ANTRAGALTERSRENTE);
        erfordertKeinenFreitext.setBegruendung("begründung");
        erfordertKeinenFreitext.setPrioritaet(1L);
        erfordertKeinenFreitext.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        final var ergebnisse = List.of(erfordertFreitext, erfordertKeinenFreitext);

        final var antrag = mock(Antrag.class);
        Mockito.lenient().when(antrag.getAntragPruefergebnisse()).thenReturn(ergebnisse);

        assertThat(PruefergebnisUtils.pruefergebnisErfordertFreitextEingabe(antrag)).isFalse();
    }
}