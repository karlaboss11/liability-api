package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.exceptions.PapierantragValidierungException;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlercodeDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import jakarta.ws.rs.ServiceUnavailableException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import lombok.SneakyThrows;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper.erstellePapierantrag;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test PapierantragValidierung.
 */
class PapierantragValidierungTest {

    private static final String AUFGABEN_ID = "AUID0123456789";
    private static final String VORGANGS_KENNUNG = "V240000001RV32";

    private PapierantragValidierung papierantragValidierung;
    private RVFitJsonSchemaValidator jsonSchemaValidator;
    private PapierantragsPruefung papierantragsPruefung;
    private AntragRepository antragRepository;

    /**
     * Globale Testvorbereitung.
     */
    @BeforeEach
    void setUp() {
        final JsonWebToken jwt = Mockito.mock(JsonWebToken.class);
        this.jsonSchemaValidator = Mockito.mock(RVFitJsonSchemaValidator.class);
        this.papierantragsPruefung = Mockito.mock(PapierantragsPruefung.class);
        this.antragRepository = Mockito.mock(AntragRepository.class);
        this.papierantragValidierung = new PapierantragValidierungImpl(jwt, jsonSchemaValidator,
            papierantragsPruefung, antragRepository);

        Mockito.when(jwt.getClaim(JwtUtils.DRV_MANDANT)).thenReturn("70");
    }

    /**
     * Test, sollte keine Exception werfen wenn alle Teilvalidierungen Ok sind.
     */
    @SneakyThrows
    @Test
    void sollteKeineExceptionWerfenWennAlleTeilvalidierungenOk() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertDoesNotThrow(() -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen, kein Antragsdatum.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenKeinAntragsdatum() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setAntragsdatum(null);

        assertThrows(PapierantragValidierungException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen, kein Eingangsdatum.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenKeinEingangsdatum() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setEingangsdatum(null);

        assertThrows(PapierantragValidierungException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test. sollte Exception werfen wenn FehlerDtoListe nicht Leer.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennFehlerDtoListeNichtLeer() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(List.of(new FehlerDto()));
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(PapierantragValidierungException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception Werfen wenn StammdatenException geworfen wird.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennStammdatenExceptionGeworfenWird() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenThrow(new StammdatenException(""));
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(ServiceUnavailableException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen wenn SecurityException geworfen Wird.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennSecurityExceptionGeworfenWird() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenThrow(new SecurityException(""));
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(ServiceUnavailableException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen wenn NoSuchFieldException geworfen wird.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennNoSuchFieldExceptionGeworfenWird() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenThrow(new NoSuchFieldException(""));
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(ServiceUnavailableException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen wenn SchemaValidierung fehlschlaegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennSchemaValidierungFehlschlaegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(false);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(PapierantragValidierungException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen wenn VorgangsId belegt ist.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennVorgangsIdBelegtIst() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(true);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getFehlerListe()).hasSize(1);
        assertThat(exception.getFehlerListe().getFirst().getFeld()).isEqualTo("vogid");
        assertThat(exception.getFehlerListe().getFirst().getCode()).isEqualTo(FehlercodeDto.FELD_UNGUELTIG);
    }

    /**
     * Test, sollte Exception werfen wenn VorgangsId Null ist.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennVorgangsIdNullIst() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, null,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getFehlerListe()).hasSize(1);
        assertThat(exception.getFehlerListe().getFirst().getFeld()).isEqualTo("vogid");
        assertThat(exception.getFehlerListe().getFirst().getCode()).isEqualTo(FehlercodeDto.FELD_LEER);
    }

    /**
     * Test, sollte Exception werfen wenn AufgabenId Null ist.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennAufgabenIdNullIst() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                null);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);

        assertThrows(PapierantragValidierungException.class, () -> papierantragValidierung.validiere(papierantragDto));
    }

    /**
     * Test, sollte Exception werfen wenn EingangsDatum in Zukunft liegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennEingangsDatumInZukunftLiegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setEingangsdatum(LocalDate.now().plusDays(2));

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getMessage()).contains("Datum darf nicht in der Zukunft liegen.");
        assertThat(exception.getFehlerListe()).contains(new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG)
            .feld("eingangsdatum"));
    }

    /**
     * Test, sollte Exception werfen wenn EingangsDatum mehr als 10 Jahre in Vergangenheit liegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennEingangsDatumMehrAls10JahreInVergangenheitLiegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setEingangsdatum(
            LocalDate.now()
                .minusYears(10)
                .minusDays(1));

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getMessage()).contains("Datum darf nicht mehr als 10 Jahre zurück liegen.");
        assertThat(exception.getFehlerListe()).contains(
            new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld("eingangsdatum")
        );
    }

    /**
     * Test, sollte Exception werfen wenn AntragsDatum in Zukunft liegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennAntragsDatumInZukunftLiegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setAntragsdatum(LocalDate.now().plusDays(2));

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getMessage()).contains("Datum darf nicht in der Zukunft liegen.");
        assertThat(exception.getFehlerListe()).contains(
            new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld("antragsdatum")
        );
    }

    /**
     * Test, sollte Exception werfen wenn AntragsDatum mehr als 10 Jahre in Vergangenheit liegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennAntragsDatumMehrAls10JahreInVergangenheitLiegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setAntragsdatum(
            LocalDate.now()
                .minusYears(10)
                .minusDays(1)
        );

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getMessage()).contains("Datum darf nicht mehr als 10 Jahre zurück liegen.");
        assertThat(exception.getFehlerListe()).contains(
            new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld("antragsdatum")
        );
    }

    /**
     * Test, sollte Exception werfen wenn Antragsdatum nach Eingangsdatum liegt.
     */
    @SneakyThrows
    @Test
    void sollteExceptionWerfenWennAntragsDatumNachEingangsDatumLiegt() {
        Mockito.when(jsonSchemaValidator.isValid(any(), any())).thenReturn(true);
        Mockito.when(papierantragsPruefung.pruefePapierAntrag(any())).thenReturn(Collections.emptyList());
        Mockito.when(antragRepository.istVorgangsIdBelegt(any())).thenReturn(false);

        final PapierantragTestDatenHelper.PapierantragInput papierantragInput =
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN, VORGANGS_KENNUNG,
                AUFGABEN_ID);
        final PapierantragDto papierantragDto = erstellePapierantrag(papierantragInput);
        papierantragDto.getAntrag().setEingangsdatum(LocalDate.now().minusDays(2));
        papierantragDto.getAntrag().setAntragsdatum(LocalDate.now());

        final PapierantragValidierungException exception =
            assertThrows(PapierantragValidierungException.class,
                () -> papierantragValidierung.validiere(papierantragDto));
        assertThat(exception.getMessage()).contains("Das Antragsdatum darf nicht nach dem Eingangsdatum liegen.");
        assertThat(exception.getFehlerListe()).contains(
            new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld("antragsdatum")
        );
    }

}
