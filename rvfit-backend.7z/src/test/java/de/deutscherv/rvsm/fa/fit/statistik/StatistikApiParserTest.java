package de.deutscherv.rvsm.fa.fit.statistik;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.BescheidDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.KopfDto;
import java.util.function.Supplier;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test StatistikApiParser.
 */
public class StatistikApiParserTest {

    /**
     * Test prüft, dass die richtige Repräsentation für die Statistik-Objekte in JSON verwendet wird.
     */
    @SneakyThrows
    @Test
    void sollteInJsonRepraesentationRichtigeBezeichnerVerwenden() {
        BescheidDto bescheidDto = new BescheidDto();
        KopfDto kopfDto = new KopfDto();
        kopfDto.setVsnr("03080800B018");
        bescheidDto.setHeader(kopfDto);

        Supplier<String> fehlerMeldung =
                () -> "Parsen des DTOs fehlgeschlagen. Pruefe Statistk-API Version.";
        String asString = new ObjectMapper().writeValueAsString(bescheidDto);
        assertThat(asString).contains("Header");
        assertThat(asString).overridingErrorMessage(fehlerMeldung).contains("REQUEST-FESTER-TEIL");
        assertThat(asString).overridingErrorMessage(fehlerMeldung).contains("REQUEST-VARIABLER-TEIL");
    }

}
