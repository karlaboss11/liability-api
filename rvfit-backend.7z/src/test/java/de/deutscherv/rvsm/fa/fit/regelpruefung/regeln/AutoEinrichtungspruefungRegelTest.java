package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test zur Prüfung ob für hinterlegte KTANS die Einrichtungsprüfung immer aussteuern soll.
 */
class AutoEinrichtungspruefungRegelTest {

    /**
     * KeineDatenTest - Aussteuern, da RegelKontext leer.
     */
    @Test
    void keineDatenTest() {
        AutoEinrichtungspruefungEnabled regel = new AutoEinrichtungspruefungEnabled("");
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    /**
     * PositivTest -> Prüfung/Regel. Erfolgreich Fall/Regel wird für eine KTAN ausgeführt (70), die NICHT in der KTAN-Liste (hier) für eine
     * zwingende Aussteuerung gelistet ist.
     */
    @Test
    void positivTest() {
        AutoEinrichtungspruefungEnabled regel = new AutoEinrichtungspruefungEnabled("17");
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().ktan("70").build(), null, null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first().isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    /**
     * NegativTest -> Prüfung/Regel. AUSSTEUERN Fall/Regel wird für eine KTAN ausgeführt (17), die in der KTAN-Liste für eine zwingende
     * Aussteuerung (hier 17,15,21) gelistet ist.
     */
    @Test
    void negativTest() {
        AutoEinrichtungspruefungEnabled regel = new AutoEinrichtungspruefungEnabled("17,15,21");
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().ktan("17").build(), null, null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first().isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN).get());

    }
}

