package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BemerkungRegelTest {

    private final BemerkungRegel regel = new BemerkungRegel();

    @Test
    void keineDatenTest() {
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first().isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    @Test
    void positivTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().bemerkungen("").build(), null, null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first().isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    @Test
    void negativTest() {
        final RegelKontext kontext = new RegelKontext(
                Antrag.builder().bemerkungen("Ich möchte meine RV Fit-Leistung gerne mit meiner Partnerin gemeinsam durchführen.").build(),
                null,null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);

        assertThat(pruefeRegel).map(RegelErgebnis::getPruefErgebnis).first().isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).map(RegelErgebnis::getDetail).first().isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN).get());

    }
}
