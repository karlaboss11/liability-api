package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.fa.fit.exceptions.NichtAutorisiertException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.container.ContainerRequestContext;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class JwtValidationFilterTest {

    private JwtValidationFilter filter;
    private JsonWebToken token;
    private HttpServletRequest request;

    @BeforeEach
    public void setup() {
        token = Mockito.mock(JsonWebToken.class);
        request = Mockito.mock(HttpServletRequest.class);

        filter = new JwtValidationFilter(token, request, false, "drvId", "fullname",
                "given_name", "family_name");


        Mockito.doReturn(Optional.of("value")).when(token).claim(ArgumentMatchers.anyString());
        Mockito.doReturn("127.0.0.1").when(request).getRemoteAddr();
    }

    @Test
    void testSecurityDisabled() {
        filter = new JwtValidationFilter(token, request, true, "drvId", "fullname",
                "given_name", "family_name");

        assertDoesNotThrow(() -> filter.filter(null));

        Mockito.verifyNoInteractions(token);
    }

    @Test
    void testAllClaimsPresent() {
        final var ctx = Mockito.mock(ContainerRequestContext.class);

        assertDoesNotThrow(() -> filter.filter(ctx));

        Mockito.verify(ctx, Mockito.times(1)).getUriInfo();
    }

    @ParameterizedTest
    @ValueSource(strings = { "drvId", "fullname", "given_name", "family_name" })
    void testClaimNotPresentShouldAbort(final String claim) {
        final var ctx = Mockito.mock(ContainerRequestContext.class);

        Mockito.doReturn(Optional.empty()).when(token).claim(claim);

        assertThatThrownBy(() -> filter.filter(ctx)).isInstanceOf(NichtAutorisiertException.class);
        Mockito.verify(ctx, Mockito.times(1)).getUriInfo();
    }
}