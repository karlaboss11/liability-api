package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BezugEMRenteRegelTest {

    private final BezugEMRenteRegel regel = new BezugEMRenteRegel();

    @Test
    void keineDatenTest() {
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(new RegelKontext());
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Aussteuern sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(pruefeRegel).as("Die Nachricht sollte entsprechend AUSSTEUERN_KEINE_DATEN sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    @Test
    void keineEMRenteTest() {
        RegelKontext kontext =
                new RegelKontext(Antrag.builder().kontoinformationen(
                        List.of(Kontoinformation.builder().bezugRenteLeat(null).build())).build(),
                        null, null, null, null);
        List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Erfüllt sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).as("Die Nachricht sollte ERFUELLT sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
        kontext =
                new RegelKontext(Antrag.builder().kontoinformationen(
                        List.of(Kontoinformation.builder().bezugRenteLeat("999").build())).build(),
                        null, null, null, null);
        pruefeRegel = regel.pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Erfüllt sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(pruefeRegel).as("Die Nachricht sollte ERFUELLT sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    @Test
    void emRenteTest() {
        final RegelKontext kontext =
                new RegelKontext(Antrag.builder().kontoinformationen(
                        List.of(Kontoinformation.builder().bezugRenteLeat("74").build())).build(),
                        null, null, null, null);
        final List<RegelErgebnis> pruefeRegel = regel.pruefeRegel(kontext);
        assertThat(pruefeRegel).as("nur ein Ergebnis sollte geliefert werden").size().isEqualTo(1);
        assertThat(pruefeRegel).as("Das Ergebnis sollte Erfüllt sein").map(RegelErgebnis::getPruefErgebnis).first()
                .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(pruefeRegel).as("Die Nachricht sollte ERFUELLT sein")
                .map(RegelErgebnis::getDetail).first()
                .isEqualTo(regel.getRegelDetail(RegelUtils.NICHT_ERFUELLT_AUSSTEUERN).get());
    }

}
