package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class WartezeitpruefungRegelTest {

    private static final String AUSSTEUERN_KEIN_DATEN = "Es liegen keine vollstaendigen Daten vor";
    private static final String NICHT_ERFUELLT_AUSSTEUERN_KEINE_VOLLSTAENDIGEN_DATEN =
            "Es liegen keine vollstaendigen Daten der Wartezeitberechnung vor";
    private static final String AUSSTEUERN_WEGEN_WARTEZEITFEHLER =
            "Wartezeitprüfung ist nicht erfüllt, wegen Wartezeitfehler";

    /**
     * Testet auf Aussteuern bei keiner Anspruchsprüfung.
     */
    @Test
    void anspruchspruefungObjectIsNullPruefergebnisIsAussteuernTest() {
        final RegelErgebnis teilErgebnis = getTeilErgebnis(null, LocalDate.now(), null);

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo("Es liegen keine vollstaendigen Daten vor");
    }

    /**
     * Testet auf Aussteuern bei keinen Wartezeitdaten.
     */
    @Test
    void wartezeitpruefungObjectIsNullPruefergebnisIsAussteuernTest() {
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(null, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo("Es liegen keine vollstaendigen Daten vor");
    }

    /**
     * Testet Regelprüfung.
     *
     * @param wartezeit6in24m          6 in 24
     * @param wartezeit180m            180
     * @param expectedErfuelltErgebnis erwartetes Ergebnis
     */
    @ParameterizedTest
    @CsvSource({
            "0, 0, false", "5, 179, false", "6, 0, true", "0, 180, true", "20, 200, true"
    })
    void setWartezeitberechnungPruefergebnisIsOrNotErfuelltTest(final int wartezeit6in24m,
            final int wartezeit180m, final boolean expectedErfuelltErgebnis) {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().wartezeit6in24m(wartezeit6in24m)
                        .wartezeit180m(wartezeit180m).wartezeitfehler(false).build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        if (expectedErfuelltErgebnis) {
            assertEquals(PruefErgebnis.ERFUELLT, teilErgebnis.getPruefErgebnis());
        } else {
            assertNotEquals(PruefErgebnis.ERFUELLT, teilErgebnis.getPruefErgebnis());
        }
    }

    @Test
    void setWartezeitberechnungDetailPruefergebnisIsErfuelltTest() {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
                .wartezeit6in24m(6).wartezeit180m(180).wartezeitfehler(false).build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo("Wartezeitprüfung ist erfüllt!");
    }

    /**
     * Testet Regelprüfung.
     *
     * @param wartezeit6in24m               6 in 24
     * @param wartezeit180m                 180
     * @param expectedNichtErfuelltErgebnis erwartetes Ergebnis
     */
    @ParameterizedTest
    @CsvSource({
            "0, 0, true", "5, 179, true", "6, 0, false", "0, 180, false"
    })
    void setWartezeitberechnungPruefergebnisIsOrNotNichtErfuelltTest(final int wartezeit6in24m,
            final int wartezeit180m, final boolean expectedNichtErfuelltErgebnis) {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().wartezeit6in24m(wartezeit6in24m)
                        .wartezeit180m(wartezeit180m).wartezeitfehler(false).build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        if (expectedNichtErfuelltErgebnis) {
            assertEquals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, teilErgebnis.getPruefErgebnis());
        } else {
            assertNotEquals(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                    teilErgebnis.getPruefErgebnis());
        }
    }

    @Test
    void setWartezeitberechnungDetailPruefergebnisIsNichtErfuelltTest() {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
                .wartezeit6in24m(1).wartezeit180m(1).wartezeitfehler(false).build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis())
                .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo("Wartezeitprüfung ist nicht erfüllt!");
    }

    /**
     * Testet auf Aussteuern bei Wartezeitfehler.
     *
     * @param wartezeit6in24M 6 in 24
     * @param wartezeit180M   180
     */
    @ParameterizedTest
    @CsvSource({
            "6, 180", "1, 1"
    })
    void setWartezeitfehlerTruePruefergebnisIsAussteuernTest(final int wartezeit6in24M,
            final int wartezeit180M) {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().wartezeit6in24m(wartezeit6in24M)
                        .wartezeit180m(wartezeit180M).wartezeitfehler(true).build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_WEGEN_WARTEZEITFEHLER);
    }

    /**
     * Testet auf nicht Erfüllt bei nicht vollständigen Daten.
     */
    @Test
    void setWartezeitberechnungNullPruefergebnisIsNichtErfuelltTest() {
        final List<Kontoinformation> kontoinformationen =
                Stream.of(Kontoinformation.builder().build()).toList();
        final RegelErgebnis teilErgebnis =
                getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis())
                .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail())
                .isEqualTo(NICHT_ERFUELLT_AUSSTEUERN_KEINE_VOLLSTAENDIGEN_DATEN);
    }

    private RegelErgebnis getTeilErgebnis(final List<Kontoinformation> kontoinformationen,
            final LocalDate antragsDatum, final Stammdaten stammdaten) {
        final RegelKontext regelKontext =
                new RegelKontext(Antrag.builder().kontoinformationen(kontoinformationen)
                        .antragsDatum(antragsDatum).build(), stammdaten, null, null, null);

        return new WartezeitpruefungRegel().pruefeRegel(regelKontext).getFirst();
    }
}
