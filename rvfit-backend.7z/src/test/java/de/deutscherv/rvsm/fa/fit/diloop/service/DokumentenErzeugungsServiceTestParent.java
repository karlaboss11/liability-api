package de.deutscherv.rvsm.fa.fit.diloop.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.testdaten.AntragTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.KontoTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragDTO;
import java.util.Collections;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * DokumentenErzeugungsServiceTestParent.
 */
@Slf4j
public class DokumentenErzeugungsServiceTestParent {

    protected DokumentgenerierungsAuftragDTO dto;

    @SneakyThrows
    protected void printResult() {
        LOG.atInfo().log(new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(this.dto));
    }

    @SneakyThrows
    protected DokumentenErstellungsDaten erstelleDokumentenErstellungsTestDaten(final TestPerson testPerson) {
        return erstelleDokumentenErstellungsTestDaten(testPerson, Collections.emptyMap());
    }

    @SneakyThrows
    protected DokumentenErstellungsDaten erstelleDokumentenErstellungsTestDaten(final TestPerson testPerson,
            final Map<VariablesFeld, String> freitext) {
        final KontoDto kontoDto = KontoTestDaten.getKontoDaten(testPerson);
        Antrag antrag = AntragTestDaten.getAntrag(testPerson);
        return new DokumentenErstellungsDaten(antrag, kontoDto, new DokumentenErzeugungTestConfig(), false, freitext);
    }
}
