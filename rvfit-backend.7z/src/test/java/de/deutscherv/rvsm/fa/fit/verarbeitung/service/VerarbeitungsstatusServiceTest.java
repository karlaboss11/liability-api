package de.deutscherv.rvsm.fa.fit.verarbeitung.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragCreator;
import de.deutscherv.rvsm.fa.fit.testdaten.StammdatenTestDaten;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import io.restassured.http.ContentType;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import lombok.SneakyThrows;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test VerarbeitungsstaatusService.
 */
@QuarkusTest
@TestInstance(Lifecycle.PER_CLASS)
@ActivateRequestContext
class VerarbeitungsstatusServiceTest {

    private PapierantragCreator papierantragCreator;

    @InjectMock
    private JsonWebToken jwt;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private AntragRepository antragRepository;

    private VersandErgebnisDto versandErgebnisDto;

    @Inject
    private VerarbeitungsstatusService verarbeitungsstatusService;

    @Inject
    private EntityManager entityManager;

    @Inject
    private CamelContext camelContext;
    private CountDownLatch latch;
    private WireMockServer wiremockServer;

    private UUID uuidAntrag;
    private UUID uuidAuftragId;

    /**
     * Vorbereitungen for jedem Test.
     */
    @SneakyThrows
    @BeforeEach
    protected void setUp() {
        wiremockServer = WireMockStub.connect(WireMockStub.PORT);
        WireMockStub.stubForAzk();
        WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);

        uuidAntrag = UUID.randomUUID();
        uuidAuftragId = UUID.randomUUID();

        drvMandant.setInScope("70");
        latch = new CountDownLatch(1);
        camelContext.getRouteController().stopRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
        AdviceWith.adviceWith(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS, camelContext,
            new AdviceWithRouteBuilder() {
                @Override
                public void configure() {
                    weaveAddLast().process(exchange -> latch.countDown());
                }
            });
        camelContext.getRouteController().startRoute(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);
    }

    /**
     * Abschlussarbeiten nach jedem Test.
     */
    @AfterEach
    protected void tearDown() {
        WireMockStub.disconnect(wiremockServer);
    }

    /**
     * Testet das Ändern eines bestehenden Verarbeitungsstatus.
     * <p>
     * Voraussetzung: Anlage/Speichern eines Verarbeitungsstatus in der DB Mittels AntragUUID sowie der ART dieser können die restlichen
     * Verarbeitungsdetails upgedatet werden Erwartung: Änderungen 'verarbeitungsdetails'
     */
    @Test
    @Transactional
    void saveVerarbeitungsstatus() {

        final String sMeldung = "Fehler weil es huddel gab";

        // Anlage eines neuen Verarbeitungsstatus in DB
        legeVerarbeitungsstatusInDatenbankAn(this.uuidAntrag);

        //
        versandErgebnisDto = new VersandErgebnisDto();
        versandErgebnisDto.setMeldung(sMeldung);
        versandErgebnisDto.setAuftragId(uuidAuftragId);
        versandErgebnisDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);

        final Verarbeitungsstatus verarbeitungsstatusUpdate =
            verarbeitungsstatusService.saveVerarbeitungsstatus(uuidAntrag,
                versandErgebnisDto, Art.ABLEHNUNG);

        assertThat(verarbeitungsstatusUpdate.getAuftragId()).isEqualTo(uuidAuftragId);
        assertThat(verarbeitungsstatusUpdate.getAntragId()).isEqualTo(uuidAntrag);
        assertThat(verarbeitungsstatusUpdate.getArt()).isEqualTo(Art.ABLEHNUNG);
        assertThat(verarbeitungsstatusUpdate.getStatus()).isEqualTo(VerarbeitungStatus.VERSANDT);
        assertThat(verarbeitungsstatusUpdate.getMeldung()).isEqualTo(sMeldung);
    }

    /**
     * Test createVerarbeitung.
     *
     * @throws StatistikException Fehler in Statistik.
     */
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void createVerarbeitung() throws StatistikException {
        Mockito.when(jwt.claim(JwtUtils.DRV_MANDANT)).thenReturn(Optional.of("70"));
        final DrvMandant drvMandantMock = Mockito.mock(DrvMandant.class);
        Mockito.doReturn("70").when(drvMandantMock).getOrElse(any());
        QuarkusMock.installMockForInstance(drvMandantMock, drvMandant);

        WireMockStub.stubForStammdaten(TestPerson.MICKEY_MOUSE);
        WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);
        WireMockStub.stubForSmp(null, null, null, "2", null);
        WireMockStub.stubForSmp(null, null, null, "3", null);
        WireMockStub.stubForSmp(null, null, null, "4", null);
        WireMockStub.stubForSmp(null, null, null, "4", "4");

        final UUID antragUuid = createAntrag(TestPerson.MICKEY_MOUSE).getUuid();

        final VersandErgebnisDto verarbeitungsdetailsDto = new VersandErgebnisDto();
        verarbeitungsdetailsDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);
        verarbeitungsdetailsDto.setMeldung("meldung");
        verarbeitungsdetailsDto.setAuftragId(UUID.randomUUID());

        given().body(verarbeitungsdetailsDto).contentType(ContentType.JSON)
            .pathParam("uuid", antragUuid).when()
            .post("antraege/{uuid}/ablehnung").then().statusCode(200);
    }

    /**
     * Test, update Verarbeitungsstatus nicht in Bearbeitung, erwartet Returncode 404.
     */
    @Transactional
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Test
    void updateVerarbeitungsstatusNichtInBearbeitungErwarte404() {
        Mockito.when(jwt.claim(JwtUtils.DRV_MANDANT)).thenReturn(Optional.of("70"));
        final DrvMandant drvMandantMock = Mockito.mock(DrvMandant.class);
        Mockito.doReturn("70").when(drvMandantMock).getOrElse(any());
        QuarkusMock.installMockForInstance(drvMandantMock, drvMandant);

        final UUID antragUuid = UUID.fromString("2c684ca0-c002-49d7-aab0-cb3c411be0de");

        final VersandErgebnisDto verarbeitungsdetailsDto = new VersandErgebnisDto();
        verarbeitungsdetailsDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);
        verarbeitungsdetailsDto.setMeldung("meldung");
        verarbeitungsdetailsDto.setAuftragId(UUID.randomUUID());

        given().body(verarbeitungsdetailsDto).contentType(ContentType.JSON)
            .pathParam("uuid", antragUuid).when()
            .post("antraege/{uuid}/ablehnung").then().statusCode(404);
    }

    private void legeVerarbeitungsstatusInDatenbankAn(final UUID uuid) {
        final Antrag antrag = new Antrag();
        antrag.setUuid(uuid);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.setVsnr(StammdatenTestDaten.getStammdaten(TestPerson.PETER_PAN).getVsnr());
        antragRepository.persist(antrag);

        final Verarbeitungsstatus verarbeitungsstatus = new Verarbeitungsstatus();
        verarbeitungsstatus.setCreated(LocalDateTime.now());
        verarbeitungsstatus.setLastmodified(LocalDateTime.now());
        verarbeitungsstatus.setAntragId(uuid);
        verarbeitungsstatus.setAuftragId(uuidAuftragId);
        verarbeitungsstatus.setStatus(VerarbeitungStatus.FEHLER);
        verarbeitungsstatus.setArt(Art.ABLEHNUNG);

        verarbeitungsstatusRepository.persist(verarbeitungsstatus);
    }

    /**
     * Test - Versuch eines nicht vorhandenen Verarbeitungsstatus zu ändern. Erwartung: Neuer Verarbeitungsstatus wird erstellt
     */
    @Test
    @Transactional
    void saveVerarbeitungsstatusNichtVorhanden() {

        versandErgebnisDto = new VersandErgebnisDto();
        versandErgebnisDto.setMeldung("xxx");
        versandErgebnisDto.setAuftragId(uuidAuftragId);
        versandErgebnisDto.setStatus(VersandErgebnisDto.StatusEnum.VERSAND);

        assertThat(verarbeitungsstatusService.saveVerarbeitungsstatus(uuidAntrag,
            versandErgebnisDto, Art.ABLEHNUNG)).isNotNull();

    }

    /**
     * Test zum Lesen des Verarbeitungsstatus mit einer UUID.
     */
    @Test
    @Transactional
    void getVerarbeitungsstatusValidUuid() {
        // Anlage eines neuen Verarbeitungsstatus in DB
        legeVerarbeitungsstatusInDatenbankAn(this.uuidAntrag);

        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusService.getVerarbeitungsstatusFallsAbgeschlossen(
            this.uuidAntrag);

        assertThat(verarbeitungsstatus).isPresent();
        assertThat(verarbeitungsstatus.get().getArt()).isEqualTo(Art.ABLEHNUNG);

    }

    /**
     * Test, getVearbeitungsstatus Invalid UUID.
     */
    @Test
    @Transactional
    void getVerarbeitungsstatusInvalidUuid() {
        // Anlage eines neuen Verarbeitungsstatus in DB
        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusService.getVerarbeitungsstatusFallsAbgeschlossen(
            UUID.randomUUID());

        assertThat(verarbeitungsstatus).isEmpty();
    }

    @SneakyThrows
    private Antrag createAntrag(final TestPerson testPerson) {
        if (papierantragCreator == null) {
            papierantragCreator = new PapierantragCreator(wiremockServer, entityManager, drvMandant, latch);
        }
        return papierantragCreator.createAntrag(testPerson);
    }
}
