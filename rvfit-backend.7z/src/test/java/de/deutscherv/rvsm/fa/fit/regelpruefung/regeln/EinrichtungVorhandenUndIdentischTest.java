package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test EinrichtungVorhandenUndIdentisch.
 */
class EinrichtungVorhandenUndIdentischTest {

    private static RehaEinrichtung einrichtungStuttgart;
    private static RehaEinrichtung einrichtungMuenchen;
    private final EinrichtungVorhandenUndIdentisch einrichtungVorhandenUndIdentisch =
        new EinrichtungVorhandenUndIdentisch();

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void set() {
        einrichtungStuttgart =
            RehaEinrichtung.builder().smpEinrichtungsId(10000L).name("Testklinik_DF")
                .adresse(EinrichtungAnschrift.builder().plz("70469").ort("Stuttgart").build())
                .angebote(List.of(
                    Angebot.builder().smpAngebotId(11112L).phase("Startphase").freiePlaetzeWert(-2)
                        .durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11112L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(-2).durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("Ambulant").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("online").build()))
                .build();
        einrichtungMuenchen = RehaEinrichtung.builder().smpEinrichtungsId(10006L)
            .name("Testklinik Milbertshofen am Hart")
            .adresse(EinrichtungAnschrift.builder().plz("80937").ort("München").build())
            .angebote(List.of(
                Angebot.builder().smpAngebotId(17601L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17601L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17602L).phase("Trainingsphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant").build()))
            .build();
    }

    /**
     * Test, Einrichtung vorhanden und identisch, Aussteuern keine Daten.
     */
    @Test
    void einrichtungVorhandenUndIdentischAussteuernKeineDatenTest() {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().build(), null, null, null, null);

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungVorhandenUndIdentisch.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungVorhandenUndIdentisch
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_DATEN).get());
    }

    /**
     * Test, Einrichtung vorhanden und identisch, Aussteuern kein Angebot.
     */
    @Test
    void einrichtungVorhandenUndIdentischAussteuernKeinAngebotTest() {
        final Antrag antrag =
            Antrag.builder()
                .angebotStartName("Keinklinik")
                .angebotStartOrt("Penzberg")
                .angebotStartPlz("82377")
                .angebotStartStrasse("keinestraße 666")

                .angebotAufName("Keinklinik")
                .angebotAufOrt("Penzberg")
                .angebotAufPlz("82377")
                .angebotAufStrasse("keinestraße 666")

                .angebotTrainingName("Keinklinik")
                .angebotTrainingOrt("Penzberg")
                .angebotTrainingPlz("82377")
                .angebotTrainingStrasse("keinestraße 666")
                .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(), List.of(), List.of());

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungVorhandenUndIdentisch.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungVorhandenUndIdentisch
            .getRegelDetail(RegelUtils.AUSSTEUERN_KEIN_ANGEBOT).get());
    }

    /**
     * Test, Einrichtung vorhanden und identisch, Aussteuern nicht identisch.
     */
    @Test
    void einrichtungVorhandenUndIdentischAussteuernNichtIdentischtTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik Milbertshofen am Hart")
            .angebotStartOrt("München")
            .angebotStartPlz("80937")
            .angebotStartStrasse("Neuherbergstraße 114")

            .angebotAufName("Testklinik Milbertshofen am Hart")
            .angebotAufOrt("München")
            .angebotAufPlz("80937")
            .angebotAufStrasse("Neuherbergstraße 114")

            .angebotTrainingName("Testklinik_DF")
            .angebotTrainingOrt("Stuttgart")
            .angebotTrainingPlz("70469")
            .angebotTrainingStrasse("Stuttgarter Str. 33")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungMuenchen),
                List.of(einrichtungMuenchen), List.of(einrichtungStuttgart));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungVorhandenUndIdentisch.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(einrichtungVorhandenUndIdentisch
            .getRegelDetail(RegelUtils.AUSSTEUERN_NICHT_IDENTISCH).get());
    }

    /**
     * Test, Einrichtung vorhanden und identisch, erfuellt.
     */
    @Test
    void einrichtungVorhandenUndIdentischErfuelltTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik Milbertshofen am Hart")
            .angebotStartOrt("München")
            .angebotStartPlz("80937")
            .angebotStartStrasse("Neuherbergstraße 114")

            .angebotAufName("Testklinik Milbertshofen am Hart")
            .angebotAufOrt("München")
            .angebotAufPlz("80937")
            .angebotAufStrasse("Neuherbergstraße 114")

            .angebotTrainingName("Testklinik Milbertshofen am Hart")
            .angebotTrainingOrt("München")
            .angebotTrainingPlz("80937")
            .angebotTrainingStrasse("Neuherbergstraße 114")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungMuenchen),
                List.of(einrichtungMuenchen), List.of(einrichtungMuenchen));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungVorhandenUndIdentisch.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungVorhandenUndIdentisch.getRegelDetail(RegelUtils.ERFUELLT).get());
    }
}
