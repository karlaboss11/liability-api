package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test EinrichtungEindeutigesAngebot.
 */
class EinrichtungEindeutigesAngebotTest {

    private static RehaEinrichtung einrichtungStuttgart;
    private static RehaEinrichtung einrichtungMuenchen;
    private final EinrichtungAngebotEindeutig einrichtungAngebotEindeutig = new EinrichtungAngebotEindeutig();

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void set() {
        einrichtungStuttgart =
            RehaEinrichtung.builder().smpEinrichtungsId(10000L).name("Testklinik_DF")
                .adresse(EinrichtungAnschrift.builder().plz("70469").ort("Stuttgart").build())
                .angebote(List.of(
                    Angebot.builder().smpAngebotId(11112L).phase("Startphase").freiePlaetzeWert(-2)
                        .durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11112L).phase("Auffrischungsphase")
                        .freiePlaetzeWert(-2).durchfuehrungsart("Ambulant (ganztägig)").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("Ambulant").build(),
                    Angebot.builder().smpAngebotId(11111L).phase("Trainingsphase")
                        .freiePlaetzeWert(4).durchfuehrungsart("online").build()))
                .build();
        einrichtungMuenchen = RehaEinrichtung.builder().smpEinrichtungsId(10006L)
            .name("Testklinik Milbertshofen am Hart")
            .adresse(EinrichtungAnschrift.builder().plz("80937").ort("München").build())
            .angebote(List.of(
                Angebot.builder().smpAngebotId(17601L).phase("Startphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17601L).phase("Auffrischungsphase")
                    .freiePlaetzeWert(4).durchfuehrungsart("Ambulant (ganztägig)").build(),
                Angebot.builder().smpAngebotId(17602L).phase("Trainingsphase").freiePlaetzeWert(4)
                    .durchfuehrungsart("Ambulant").build()))
            .build();
    }

    /**
     * Test, Einrichtung Angebot eindeutig, Aussteuern Leer.
     */
    @Test
    void einrichtungAngebotEindeutigAussteuernLeerTest() {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().build(), null, null, null, null);
        final List<RegelErgebnis> regelErgebnisse =
            einrichtungAngebotEindeutig.pruefeRegel(regelKontext);

        assertTrue(regelErgebnisse.isEmpty());
    }

    /**
     * Test, Einrichtung Angebot eindeutig, Aussteuern.
     */
    @Test
    void einrichtungAngebotEindeutigAussteuernTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik_DF")
            .angebotStartOrt("Stuttgart")
            .angebotStartPlz("70469")
            .angebotStartStrasse("Stuttgarter Str. 33")

            .angebotAufName("Testklinik_DF")
            .angebotAufOrt("Stuttgart")
            .angebotAufPlz("70469")
            .angebotAufStrasse("Stuttgarter Str. 33")

            .angebotTrainingName("Testklinik_DF")
            .angebotTrainingOrt("Stuttgart")
            .angebotTrainingPlz("70469")
            .angebotTrainingStrasse("Stuttgarter Str. 33")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungStuttgart),
                List.of(einrichtungStuttgart), List.of(einrichtungStuttgart));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungAngebotEindeutig.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.AUSSTEUERN).get());
    }

    /**
     * Test, Einrichtung Angebot eindeutig, Erfuellt.
     */
    @Test
    void einrichtungAngebotEindeutigErfuelltTest() {
        final Antrag antrag = Antrag.builder()
            .angebotStartName("Testklinik Milbertshofen am Hart")
            .angebotStartOrt("München")
            .angebotStartPlz("80937")
            .angebotStartStrasse("Neuherbergstraße 114")

            .angebotAufName("Testklinik Milbertshofen am Hart")
            .angebotAufOrt("München")
            .angebotAufPlz("80937")
            .angebotAufStrasse("Neuherbergstraße 114")

            .angebotTrainingName("Testklinik Milbertshofen am Hart")
            .angebotTrainingOrt("München")
            .angebotTrainingPlz("80937")
            .angebotTrainingStrasse("Neuherbergstraße 114")
            .build();

        final RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(einrichtungMuenchen),
                List.of(einrichtungMuenchen), List.of(einrichtungMuenchen));

        final List<RegelErgebnis> regelErgebnisse =
            einrichtungAngebotEindeutig.pruefeRegel(regelKontext);
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail())
            .isEqualTo(einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.ERFUELLT).get());
    }

    void testmitPhasen(final RegelKontext kontext, final boolean leeresErgebnis,
        final PruefErgebnis erwartetesErgebnis, final String erwarteteNachricht) {
        final List<RegelErgebnis> regelErgebnisse =
            einrichtungAngebotEindeutig.pruefeRegel(kontext);
        if (leeresErgebnis) {
            assertThat(regelErgebnisse).isEmpty();
            return;
        }
        final RegelErgebnis ergebnis = regelErgebnisse.getFirst();
        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(erwartetesErgebnis);
        assertThat(ergebnis.getDetail()).isEqualTo(erwarteteNachricht);

    }

    /**
     * Test aller Faelle.
     */
    @Test
    void testAllTheCases() {
        Antrag antrag = Antrag.builder().build();

        RegelKontext regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 0)));
        // keine Phasen im Antrag
        testmitPhasen(regelKontext, true, null, null);

        antrag = Antrag.builder()
            .angebotTrainingName("Testklinik Training")
            .angebotTrainingOrt("Training Ort")
            .angebotTrainingPlz("Training Plz")
            .angebotTrainingStrasse("Training Str")
            .build();
        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 0)));
        // trainingsphase hat keine freien Plätze
        testmitPhasen(regelKontext, true, null, null);

        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // traingsphase gesetzt und eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.ERFUELLT,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.ERFUELLT).get());

        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 4),
                    createRehaEinrichtung("Trainingsphase", 4)));
        // trainingsphase gesetzt aber nicht eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.AUSSTEUERN,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.AUSSTEUERN).get());

        antrag = Antrag.builder()
            .angebotStartName("StartAuf Klinik")
            .angebotStartOrt("StartAuf Ort")
            .angebotStartPlz("StartAuf Plz")
            .angebotStartStrasse("StartAuf Str")

            .angebotAufName("StartAuf Klinik")
            .angebotAufOrt("StartAuf Ort")
            .angebotAufPlz("StartAuf Plz")
            .angebotAufStrasse("StartAuf Str")
            .build();

        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // StartAuf gesetzt und eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.ERFUELLT,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.ERFUELLT).get());

        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 0)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 0)),
                List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // Start und Auffrischungsphase haben keine freien Plätze
        testmitPhasen(regelKontext, true, null, null);

        regelKontext = new RegelKontext(antrag, null,
            List.of(createRehaEinrichtung("Startphase", 4), createRehaEinrichtung("Startphase", 4)),
            List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
            List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // Startphase nicht eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.AUSSTEUERN,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.AUSSTEUERN).get());

        antrag = Antrag.builder()
            .angebotStartName("StartAuf Klinik")
            .angebotStartOrt("StartAuf Ort")
            .angebotStartPlz("StartAuf Plz")
            .angebotStartStrasse("StartAuf Str")

            .angebotAufName("StartAuf Klinik")
            .angebotAufOrt("StartAuf Ort")
            .angebotAufPlz("StartAuf Plz")
            .angebotAufStrasse("StartAuf Str")

            .angebotTrainingName("Testklinik Training")
            .angebotTrainingOrt("Training Ort")
            .angebotTrainingPlz("Training Plz")
            .angebotTrainingStrasse("Training Str")
            .build();
        regelKontext = new RegelKontext(antrag, null,
            List.of(createRehaEinrichtung("Startphase", 4), createRehaEinrichtung("Startphase", 4)),
            List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
            List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // alles gesetzt, Trainingsphase aber nich eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.AUSSTEUERN,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.AUSSTEUERN).get());

        regelKontext =
            new RegelKontext(antrag, null, List.of(createRehaEinrichtung("Startphase", 4)),
                List.of(createRehaEinrichtung("Auffrischungsphase", 4)),
                List.of(createRehaEinrichtung("Trainingsphase", 4)));
        // alles gesetzt und eindeutig
        testmitPhasen(regelKontext, false, PruefErgebnis.ERFUELLT,
            einrichtungAngebotEindeutig.getRegelDetail(RegelUtils.ERFUELLT).get());

        regelKontext = new RegelKontext(antrag, null, null, null, null);
        // keine Phasen, keine Ergebnisse
        testmitPhasen(regelKontext, true, null, null);

    }

    private RehaEinrichtung createRehaEinrichtung(final String phase, final int freiePlaetze) {
        return RehaEinrichtung.builder().name("Testklinik " + phase + UUID.randomUUID())
            .angebote(
                List.of(Angebot.builder().phase(phase).freiePlaetzeWert(freiePlaetze).build()))
            .build();
    }
}
