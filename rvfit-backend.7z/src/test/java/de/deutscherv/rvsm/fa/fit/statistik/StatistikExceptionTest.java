package de.deutscherv.rvsm.fa.fit.statistik;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@QuarkusTest
class StatistikExceptionTest {

    /**
     * Test prüft, dass die richtige Nachricht gespeichert wird.
     */
    @Test
    void testStatistikExceptionTestNachricht() {
        String errorMessage = "Test Fehler Nachricht";
        StatistikException statistikException = new StatistikException(errorMessage);
        assertEquals(errorMessage, statistikException.getMessage());
    }

    /**
     * Test prüft, dass die richtige Nachricht gespeichert wird.
     */
    @Test
    void testStatistikExceptionNullNachricht() {
        StatistikException statistikException = new StatistikException(null);
        assertNull(statistikException.getMessage());
    }

}
