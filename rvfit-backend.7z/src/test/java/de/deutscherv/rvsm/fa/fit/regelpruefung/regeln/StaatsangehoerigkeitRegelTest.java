package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

class StaatsangehoerigkeitRegelTest {

    private static final String ERFUELLT = "Es liegt eine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vor.";
    private static final String AUSSTEUERN_NICHT_ERMITTELBAR =
            "Es konnte nicht ermittelt werden, ob eine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vorliegt.";
    private static final String AUSSTEUERN_KEINE_DATEN = "Es liegen keine vollstaendigen Daten vor.";
    private static final String NICHT_ERFUEELT = "Es liegt keine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vor.";

    /**
     * Testet auf Aussteuern bei keinen Stammdaten.
     */
    @Test
    void testStammdatenObjectIsNullPruefergebnisIsAussteuern() {
        final RegelErgebnis ergebnis = getTeilErgebnis(null);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Testet auf Aussteuern bei keiner Staatsangehörigkeit.
     */
    @Test
    void testStaatsangehoerigkeitIsNullPruefergebnisIsAussteuern() {
        final var stammdaten = Stammdaten.builder().staatsangehoerigkeit(null).build();
        final RegelErgebnis ergebnis = getTeilErgebnis(stammdaten);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Testet auf Aussteuern bei einer unbekannten/unbestimmten Staatsangehörigkeit.
     */
    @ParameterizedTest
    @ValueSource(strings = {
            "996", "997", "998", "999"
    })
    void testStaatsangehoerigkeitUnbekanntPruefergebnisIsAussteuern(final String land) {
        final var stammdaten = Stammdaten.builder().staatsangehoerigkeit(land).build();
        final RegelErgebnis ergebnis = getTeilErgebnis(stammdaten);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(AUSSTEUERN_NICHT_ERMITTELBAR);
    }

    /**
     * Testet auf Erfüllt bei einer EU/EWR/schweizer/türkischen Staatsangehörigkeit.
     */
    @ParameterizedTest
    @ValueSource(strings = {
            "000", "151", "163", "158"
    })
    void testStaatsangehoerigkeitValidePruefergebnisIsErfuellt(final String land) {
        final var stammdaten = Stammdaten.builder().staatsangehoerigkeit(land).build();
        final RegelErgebnis ergebnis = getTeilErgebnis(stammdaten);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(ergebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    /**
     * Testet auf nicht Erfüllt bei keiner EU/EWR/schweizer/türkischen Staatsangehörigkeit.
     */
    @ParameterizedTest
    @ValueSource(strings = {
            "423", "460", "479", "442"
    })
    void testStaatsangehoerigkeitNichtValidePruefergebnisIsErfuellt(final String land) {
        final var stammdaten = Stammdaten.builder().staatsangehoerigkeit(land).build();
        final RegelErgebnis ergebnis = getTeilErgebnis(stammdaten);

        assertThat(ergebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(ergebnis.getDetail()).isEqualTo(NICHT_ERFUEELT);
    }

    private RegelErgebnis getTeilErgebnis(final Stammdaten stammdaten) {
        final RegelKontext regelKontext = new RegelKontext(null, stammdaten, null, null, null);
        return new StaatsangehoerigkeitRegel().pruefeRegel(regelKontext).getFirst();
    }
}
