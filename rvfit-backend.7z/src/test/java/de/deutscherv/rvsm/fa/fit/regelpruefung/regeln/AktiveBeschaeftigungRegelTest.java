package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test AktiveBeschaeftigungRegel.
 */
class AktiveBeschaeftigungRegelTest {

    public static final String AUSSTEUERN_KEINE_DATEN =
        "Prüfung auf Vorlage einer aktiven Beschäftigung nicht möglich.";
    public static final String ERFUELLT = "Eine aktive Beschäftigung liegt vor.";
    public static final String NICHT_ERFUELLT_AUSSTEUERN =
        "Es liegt keine aktive Beschäftigung vor.";
    private final AktiveBeschaeftigungRegel regel = new AktiveBeschaeftigungRegel();

    /**
     * Test Aussteuerung wegen fehlender Daten.
     */
    @Test
    void testAusteuernWegenFehlenderDaten() {
        RegelKontext regelKontext = new RegelKontext();

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);

        RegelErgebnis expectedRegelErgebnis = new RegelErgebnis(PruefErgebnis.AUSSTEUERN,
            RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, AUSSTEUERN_KEINE_DATEN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test aussteuern bei Question mark.
     */
    @Test
    void aussteuernWhenQuestionMark() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().beschaeftigungGruppe("???").beschaeftigungGrund("??").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis = new RegelErgebnis(PruefErgebnis.AUSSTEUERN, RegelName.REGEL_AKTIVEBESCHAEFTIGUNG,
            AUSSTEUERN_KEINE_DATEN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel erfüllt Selbstständigkeit.
     */
    @Test
    void testRegelErfuelltSelbststaendigkeit() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(true).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.ERFUELLT, RegelName.REGEL_AKTIVEBESCHAEFTIGUNG,
                ERFUELLT);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel erfüllt keine Selbstständigkeit.
     */
    @Test
    void testRegelErfuelltKeineSelbststaendigkeit() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(false).beschaeftigungGruppe("101")
                .beschaeftigungGrund("10").beschaeftigungKobs(LocalDate.now())
                .build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.ERFUELLT, RegelName.REGEL_AKTIVEBESCHAEFTIGUNG,
                ERFUELLT);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllte Selbstständigkeit und ist beschäftigt.
     */
    @Test
    void testRegelNichtErfuelltKeineSelbststaendigkeitIsBeschaeftigungKobs() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(false).beschaeftigungGruppe("100")
                .beschaeftigungGrund("9").beschaeftigungKobs(LocalDate.now())
                .build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Nicht erfüllt, Aussteuerung bei Zero.
     */
    @Test
    void nichtErfuelltAussterungWhenZeros() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().beschaeftigungGruppe("000").beschaeftigungGrund("00").build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllt, keine Selbstständigkeit Beschäftigungsgrund.
     */
    @Test
    void testRegelNichtErfuelltKeineSelbststaendigkeitIsBeschaeftigungsGrund() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(false).beschaeftigungGruppe("100")
                .beschaeftigungGrund("10")
                .beschaeftigungKobs(LocalDate.now().minusYears(2)).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllt, keine Selbstständigkeit Beschäftigungsgruppe.
     */
    @Test
    void testRegelNichtErfuelltKeineSelbststaendigkeitIsBeschaeftigungsGruppe() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(false).beschaeftigungGruppe("101")
                .beschaeftigungGrund("9")
                .beschaeftigungKobs(LocalDate.now().minusYears(2)).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    @Test
    void testRegelNichtErfuelltSelbstaendigkeitNullIsBeschaeftigungKobsNull() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(null).beschaeftigungGruppe("100")
                .beschaeftigungGrund("9").beschaeftigungKobs(null).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllt Selbstständigkeit Null, Beschäftigungsgrund leer.
     */
    @Test
    void testRegelNichtErfuelltSelbstaendigkeitNullIsBeschaeftigungBeschaeftigungsGrundLeer() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(null).beschaeftigungGruppe("101")
                .beschaeftigungGrund("").beschaeftigungKobs(LocalDate.now())
                .build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllt Selbstständigkeit Null, Beschäftigungsgruppe leer.
     */
    @Test
    void testRegelNichtErfuelltSelbstaendigkeitNullIsBeschaeftigungBeschaeftigungsGruppeLeer() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(null).beschaeftigungGruppe("")
                .beschaeftigungGrund("10").beschaeftigungKobs(LocalDate.now())
                .build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis =
            new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    /**
     * Test Regel nicht erfüllt Selbstständigkeit Null, Rest vorhanden keine Daten.
     */
    @Test
    void testRegelNichtErfuelltSelbstaendigkeitNullRestVorhandenAusteuernKeineDaten() {
        final LocalDate antragsDatum = LocalDate.now().minusDays(7);
        final RegelKontext regelKontext = getRegelKontext(antragsDatum,
            Kontoinformation.builder().selbstaendigkeit(null).beschaeftigungGruppe("100")
                .beschaeftigungGrund("9")
                .beschaeftigungKobs(LocalDate.now().minusYears(2)).build());

        final List<RegelErgebnis> regelErgebnis = regel.pruefeRegel(regelKontext);
        final RegelErgebnis expectedRegelErgebnis = new RegelErgebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
            RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(regelErgebnis).hasSize(1).containsOnly(expectedRegelErgebnis);
    }

    private RegelKontext getRegelKontext(LocalDate antragsDatum,
        Kontoinformation kontoinformation) {
        final Antrag antrag = new Antrag();
        antrag.setAntragsDatum(antragsDatum);
        antrag.setKontoinformationen(List.of(kontoinformation));

        final RegelKontext regelKontext = new RegelKontext();
        regelKontext.setAntrag(antrag);

        return regelKontext;
    }
}
