package de.deutscherv.rvsm.fa.fit.statistik.util;

import com.google.inject.name.Named;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import java.time.LocalDate;
import java.util.List;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.AUFFRISCHUNGSPHASE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.STARTPHASE;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.TRAININGSPHASE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test StatistikUtil.
 */
class StatistikUtilTest {

    private static RehaEinrichtung createRehaEinrichtung(final String durchfuehrungsArt,
        final String phase, final String resc) {
        final Angebot angebot = new Angebot();
        angebot.setPhase(phase);
        angebot.setDauer(1);
        angebot.setDurchfuehrungsart(durchfuehrungsArt);

        final RehaEinrichtung rehaEinrichtung = new RehaEinrichtung();
        rehaEinrichtung.setResc(resc);
        rehaEinrichtung.setAngebote(List.of(angebot));
        return rehaEinrichtung;
    }

    /**
     * Test prüft, dass entsprechend der Rehaeinrichtung der korrekte Zahlenwert für die Durchführungsart zurückgegeben wird
     * (Auffrischungsphase).
     *
     * @param durchfuehrungsArt die Durchführungsart der Rehamaßnahme
     * @param zahlWert          erwarteter Zahlwert
     */
    @ParameterizedTest
    @CsvSource(value = { "KEINE,0", "stationär,1", "Ambulant (ganztägig),2", "Ambulant,3",
        "online,2" })
    void testeGetDurchfuehrungsArtFuerRehaEinrichtungUndAuffrischungsphase(
        final String durchfuehrungsArt, final String zahlWert) {
        final RehaEinrichtung rehaEinrichtung =
            createRehaEinrichtung(durchfuehrungsArt, AUFFRISCHUNGSPHASE, "aresc_Auffrischung");

        assertThat(StatistikUtil.getDF(rehaEinrichtung, AUFFRISCHUNGSPHASE)).isEqualTo(zahlWert);
    }

    /**
     * Test prüft, dass entsprechend der Rehaeinrichtung der korrekte Zahlenwert für die Durchführungsart zurückgegeben wird (Startphase).
     *
     * @param durchfuehrungsArt die Durchführungsart der Rehamaßnahme
     * @param zahlWert          erwarteter Zahlwert
     */
    @ParameterizedTest
    @CsvSource(value = { "KEINE,0", "stationär,1", "Ambulant (ganztägig),2", "Ambulant,3",
        "online,2" })
    void testeGetDurchfuehrungsArtFuerRehaEinrichtungUndStartphase(final String durchfuehrungsArt,
        final String zahlWert) {
        final RehaEinrichtung rehaEinrichtung =
            createRehaEinrichtung(durchfuehrungsArt, STARTPHASE, "aresc_Start");

        assertThat(StatistikUtil.getDF(rehaEinrichtung, STARTPHASE)).isEqualTo(zahlWert);
    }

    /**
     * Test prüft, dass entsprechend der Rehaeinrichtung der korrekte Zahlenwert für die Durchführungsart zurückgegeben wird
     * (Trainingsphase).
     *
     * @param durchfuehrungsArt die Durchführungsart der Rehamaßnahme
     * @param zahlWert          erwarteter Zahlwert
     */
    @ParameterizedTest
    @CsvSource(value = { "KEINE,0", "stationär,1", "Ambulant (ganztägig),2", "Ambulant,3",
        "online,3" })
    void testeGetDurchfuehrungsArtFuerRehaEinrichtungUndTrainingsphase(
        final String durchfuehrungsArt, final String zahlWert) {
        final RehaEinrichtung rehaEinrichtung =
            createRehaEinrichtung(durchfuehrungsArt, TRAININGSPHASE, "aresc_Training");

        assertThat(StatistikUtil.getDF(rehaEinrichtung, TRAININGSPHASE)).isEqualTo(zahlWert);
    }

    private static Antrag createAntrag() {
        final Antrag antrag = new Antrag();
        antrag.setKtan("70");
        antrag.setVsnr("2109356D484");
        antrag.setAntragsDatum(LocalDate.of(2024, 7, 9));
        antrag.setEingangsdatum(LocalDate.of(2024, 7, 9).plusDays(1));
        antrag.setBescheiddatum(LocalDate.of(2024, 7, 9).plusDays(7));
        antrag.setAntragsart(AntragsArt.PAPIERANTRAG);
        antrag.setMsnr(12);
        antrag.setAtad(1234);

        final Angebot angebotStart = new Angebot();
        angebotStart.setPhase(STARTPHASE);
        angebotStart.setDauer(3);
        angebotStart.setDurchfuehrungsart(DurchfuehrungsArt.STATIONAER.getBezeichnung());

        final Angebot angebotTraining = new Angebot();
        angebotTraining.setPhase(TRAININGSPHASE);
        angebotTraining.setDauer(5);
        angebotTraining.setDurchfuehrungsart(DurchfuehrungsArt.AMBULANT.getBezeichnung());

        final Angebot angebotAuffrischung = new Angebot();
        angebotAuffrischung.setPhase(AUFFRISCHUNGSPHASE);
        angebotAuffrischung.setDauer(1);
        angebotAuffrischung
            .setDurchfuehrungsart(DurchfuehrungsArt.GANZTAEGIG_AMBULANT.getBezeichnung());

        final RehaEinrichtung rehaEinrichtungStart = new RehaEinrichtung();
        rehaEinrichtungStart.setResc("resc_Start");
        rehaEinrichtungStart.setAngebote(List.of(angebotStart));

        final RehaEinrichtung rehaEinrichtungTraining = new RehaEinrichtung();
        rehaEinrichtungTraining.setResc("resc_Training");
        rehaEinrichtungTraining.setAngebote(List.of(angebotTraining));

        final RehaEinrichtung rehaEinrichtungAuffrischung = new RehaEinrichtung();
        rehaEinrichtungAuffrischung.setResc("resc_Auffrischung");
        rehaEinrichtungAuffrischung.setAngebote(List.of(angebotAuffrischung));

        antrag.setEinrichtungStartObjekt(rehaEinrichtungStart);
        antrag.setEinrichtungTrainingObjekt(rehaEinrichtungTraining);
        antrag.setEinrichtungAufObjekt(rehaEinrichtungAuffrischung);

        return antrag;
    }

    private static AntragPruefergebnis getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelAbgleichGeburtsdatum() {
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setPrioritaet(2L);
        antragPruefergebnis.setRegelName(RegelName.REGEL_ABGLEICH_GEBURTSDATUM);

        return antragPruefergebnis;
    }

    private static AntragPruefergebnis getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelWiderspruchsverfahren() {
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setPrioritaet(2L);
        antragPruefergebnis.setRegelName(RegelName.REGEL_WIDERSPRUCHSVERFAHREN);

        return antragPruefergebnis;
    }

    private static AntragPruefergebnis getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelLaufenderRehaantrag() {
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setPrioritaet(2L);
        antragPruefergebnis.setRegelName(RegelName.REGEL_LAUFENDERREHAANTRAG);

        return antragPruefergebnis;
    }

    private static AntragPruefergebnis getAntragPruefErgebnisErfuellt() {
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.ERFUELLT);
        antragPruefergebnis.setPrioritaet(2L);
        return antragPruefergebnis;
    }

    /**
     * Test prüft, dass der MTEP korrekt ermittelt wird für den Fall, dass der Antrag nicht vor der Regelprüfung erledigt wird.
     *
     * @param pruefergebnisErfuellt ist das Pruefergebnis erfüllt
     * @param verarbeitungsArt      die Vearbeitungsart
     * @param expected              erwarteter Zahlwert
     */
    @ParameterizedTest
    @CsvSource(value = { "true,BEWILLIGUNG,80", "true,ABLEHNUNG,80",
        "true,SACHVERHALTSAUFKLAERUNG,80", "true,ERLEDIGUNG_ANDERE_ART_UND_WEISE,85",
        "true,STORNO,98", "true,RUECKNAHME,85", "false,BEWILLIGUNG,85", "false,ABLEHNUNG,85",
        "false,SACHVERHALTSAUFKLAERUNG,85", "false,ERLEDIGUNG_ANDERE_ART_UND_WEISE,85",
        "false,STORNO,98", "false,RUECKNAHME,85" })
    void testeErmittleMtep(final boolean pruefergebnisErfuellt, final String verarbeitungsArt,
        final String expected) {
        assertThat(StatistikUtil.ermittleMTEP(Art.valueOf(verarbeitungsArt), pruefergebnisErfuellt, false))
            .isEqualTo(expected);
    }

    /**
     * Test prüft, dass der MTEP korrekt ermittelt wird für den Fall, dass der Antrag vor der Regelprüfung erledigt wird.
     *
     * @param pruefergebnisErfuellt ist das Pruefergebnis erfüllt
     * @param verarbeitungsArt      die Vearbeitungsart
     * @param expected              erwarteter Zahlwert
     */
    @ParameterizedTest
    @CsvSource(value = {
        "true,BEWILLIGUNG,85", "true,ABLEHNUNG,85",
        "true,SACHVERHALTSAUFKLAERUNG,85", "true,ERLEDIGUNG_ANDERE_ART_UND_WEISE,85",
        "true,STORNO,98", "true,RUECKNAHME,85",
        "false,BEWILLIGUNG,85", "false,ABLEHNUNG,85",
        "false,SACHVERHALTSAUFKLAERUNG,85", "false,ERLEDIGUNG_ANDERE_ART_UND_WEISE,85",
        "false,STORNO,98", "false,RUECKNAHME,85" })
    void testeErmittleMtepErledigungVorRegelPruefung(final boolean pruefergebnisErfuellt, final String verarbeitungsArt,
        final String expected) {
        assertThat(StatistikUtil.ermittleMTEP(Art.valueOf(verarbeitungsArt), pruefergebnisErfuellt, true))
            .isEqualTo(expected);
    }

    /**
     * Test prüft, dass die TXNR korrekt ermittelt wird (Storno).
     *
     * @param pruefergebnisErfuellt ist das Pruefergebnis erfüllt
     * @param verarbeitungsArt      die Vearbeitungsart
     * @param expected              erwarteter Zahlwert
     */
    @SneakyThrows
    @ParameterizedTest
    @CsvSource(value = { "true, STORNO, 000", "false, STORNO, 000", })
    void testeErmittleTxnrFuerStorno(final boolean pruefergebnisErfuellt,
        final String verarbeitungsArt, final String expected) {
        assertThat(
            StatistikUtil.ermittleTXNR(Art.valueOf(verarbeitungsArt), pruefergebnisErfuellt, null))
            .isEqualTo(expected);
    }

    /**
     * Test prüft, dass die TXNR korrekt ermittelt wird (Erledigung auf andere Art und Weise).
     *
     * @param pruefergebnisErfuellt ist das Pruefergebnis erfüllt
     * @param verarbeitungsArt      die Vearbeitungsart
     * @param expected              erwarteter Zahlwert
     */
    @SneakyThrows
    @ParameterizedTest
    @CsvSource(value = { "true, ERLEDIGUNG_ANDERE_ART_UND_WEISE, '72 '",
        "false, ERLEDIGUNG_ANDERE_ART_UND_WEISE, '72 '", })
    void testeErmittleTxnrFuerErledigungAndereArtUndWeise(final boolean pruefergebnisErfuellt,
        final String verarbeitungsArt, final String expected) {
        assertThat(
            StatistikUtil.ermittleTXNR(Art.valueOf(verarbeitungsArt), pruefergebnisErfuellt, null))
            .isEqualTo(expected);
    }

    /**
     * Test prüft, dass die TXNR korrekt ermittelt wird (Rücknahme).
     *
     * @param pruefergebnisErfuellt ist das Pruefergebnis erfüllt
     * @param verarbeitungsArt      die Vearbeitungsart
     * @param expected              erwarteter Zahlwert
     */
    @SneakyThrows
    @ParameterizedTest
    @CsvSource(value = { "true, RUECKNAHME, '70 '", "false, RUECKNAHME, '70 '", })
    void testeErmittleTxnrFuerRuecknahme(final boolean pruefergebnisErfuellt,
        final String verarbeitungsArt, final String expected) {
        assertThat(
            StatistikUtil.ermittleTXNR(Art.valueOf(verarbeitungsArt), pruefergebnisErfuellt, null))
            .isEqualTo(expected);
    }

    /**
     * Test prüft, dass die DTEL korrekt erstellt wird.
     */
    @Test
    void testeErmittleDtel() {
        final Antrag antrag = createAntrag();
        assertThat(StatistikUtil.ermittleDTEL(antrag, Art.STORNO)).isEqualTo(LocalDate.now());
        assertThat(StatistikUtil.ermittleDTEL(antrag, Art.BEWILLIGUNG))
            .isEqualTo(antrag.getBescheiddatum());
    }

    /**
     * Test prüft, dass die Ausprägung eines Prüfergebnis korrekt erstellt wird.
     *
     * @param regelName   Name der Regel
     * @param auspraegung die erwartete Ausprägung
     */
    @SneakyThrows
    @ParameterizedTest
    @CsvSource(value = { "REGEL_STAATSANGEHOERIGKEIT,'169'", "REGEL_AUFENTHALT,'169'",
        "REGEL_BEZUGALTERSRENTE,'163'", "REGEL_ANTRAGALTERSRENTE,'163'",
        "REGEL_BEAMTENEIGENSCHAFT_BEZUEGE,'170'", "REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT,'171'",
        "REGEL_WARTEZEITPRUEFUNG,'160'", "REGEL_AKTIVEBESCHAEFTIGUNG,'50 '",
        "REGEL_BEZUGEMRENTE,'50 '", "REGEL_ANTRAGEMRENTE,'50 '", "REGEL_MASSNAHME,'50 '",
        "REGEL_ALTERSTEILZEIT ,'50 '" })
    @Named("Ermittle Auspraegung zu einem Pruefergebnis")
    void testeGetAuspraegungPruefergebnis(final String regelName, final String auspraegung) {

        final Antrag antrag = createAntrag();
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setRegelName(RegelName.valueOf(regelName));
        antragPruefergebnis.setBegruendung("Fehler");
        antragPruefergebnis.setPrioritaet(1L);
        antrag.addAntragPruefergebnis(antragPruefergebnis);

        assertThat(StatistikUtil.getAuspraegungPruefergebnis(antrag)).isEqualTo(auspraegung);
    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn das Prüfergebnis fehlt, jedoch trotzdem die Ausprägung abgerufen wird.
     */
    @Test
    @Named("Ermittle Auspraegung ohne Pruefergebnis")
    void testeGetAuspraegungPruefergebnisOhnePruefergebnis() {
        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(getAntragPruefErgebnisErfuellt());
        antrag.getAntragPruefergebnisse().stream().filter(p -> p.getPrioritaet() != null)
            .forEach(p -> p.setPrioritaet(null));

        assertThatExceptionOfType(StatistikException.class)
            .isThrownBy(() -> StatistikUtil.getAuspraegungPruefergebnis(antrag))
            .withMessageContaining("Kein Pruefergebnis enthalten in Antrag");
    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn ein ungültiges Prüfergebnis vorhanden ist und versucht wird die
     * Ausprägung abzurufen.
     */
    @Test
    @Named("Ermittle Auspraegung ohne Pruefergebnis")
    void testeGetAuspraegungPruefergebnisMitUngueltigemPruefergebnis() {
        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(
            getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelAbgleichGeburtsdatum());

        assertThatExceptionOfType(StatistikException.class)
            .isThrownBy(() -> StatistikUtil.getAuspraegungPruefergebnis(antrag))
            .withMessageContaining("Unbekanntes Pruefergebnis");
    }

    /**
     * Test prüft, ob die korrekte Ausprägung mit Regel Widerspruchsverfahren ermittelt wird, wenn das Prüfergebnis "nicht erfüllt ablehnen"
     * ist.
     */
    @Test
    @Named("Ermittle Auspraegung mit Regel Widerspruchsverfahren")
    void testeGetAuspraegungPruefergebnisMitRegelWiderspruchsverfahren() {
        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(
            getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelWiderspruchsverfahren());

        assertEquals("50 ", StatistikUtil.getAuspraegungPruefergebnis(antrag));
    }

    /**
     * Test prüft, ob die korrekte Ausprägung bei fehlender Regel Laufender Rehaantrag ermittelt wird, wenn das Prüfergebnis "nicht erfüllt
     * ablehnen" ist.
     */
    @Test
    @Named("Ermittle Auspraegung ohne Regel Laufender Rehaantrag")
    void testeGetAuspraegungPruefergebnisMitRegelLaufenderRehaantrag() {
        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(
            getAntragPruefErgebnisNichtErfuelltAblehnenMitRegelLaufenderRehaantrag());

        assertEquals("50 ", StatistikUtil.getAuspraegungPruefergebnis(antrag));
    }

    /**
     * Test prüft, dass man für die jeweilige Bezeichnung das passende PhaseEnum bekommt.
     */
    @Test
    void testeGetPhaseEnumFuerStringBezeichner() {
        assertThat(StatistikUtil.getPhaseEnumFuerStringBezeichner(AUFFRISCHUNGSPHASE))
            .isEqualTo(PhaseEnumDto.AUFFRISCHUNG);
        assertThat(StatistikUtil.getPhaseEnumFuerStringBezeichner(STARTPHASE))
            .isEqualTo(PhaseEnumDto.STARTPHASE);
        assertThat(StatistikUtil.getPhaseEnumFuerStringBezeichner(TRAININGSPHASE))
            .isEqualTo(PhaseEnumDto.TRAININGSPHASE);
        assertThatExceptionOfType(IllegalArgumentException.class)
            .isThrownBy(() -> StatistikUtil.getPhaseEnumFuerStringBezeichner("invalid"));
    }

    /**
     * Test Substring Methode.
     */
    @Test
    void testeSubstringMethode() {
        assertThat(StatistikUtil.trimmed("MediClin Klinik am Rennsteig Tabarz", 30))
            .hasSize(30);
        assertThat(StatistikUtil.trimmed("MediClin Klinik am Rennsteig Tabarz", 8))
            .isEqualTo("MediClin");
        assertThat(StatistikUtil.trimmed("MediClin ", 9))
            .isEqualTo("MediClin");

        assertThat(StatistikUtil.trimmed(null, 30)).isEqualTo("?");
        assertThat(StatistikUtil.trimmed("", 30)).isEqualTo("?");
        assertThat(StatistikUtil.trimmed(" ", 30)).isEqualTo("?");
    }
}
