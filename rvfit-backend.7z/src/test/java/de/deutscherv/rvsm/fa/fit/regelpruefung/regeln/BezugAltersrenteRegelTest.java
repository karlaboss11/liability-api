package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test BezugAltersrenteRegel.
 */
class BezugAltersrenteRegelTest {

    private static final String AUSSTEUERN_KEINE_DATEN = "Es liegen keine vollstaendigen Daten vor";
    private static final String ERFUELLT = "Es besteht kein laufender Bezug einer Altersrente";
    private static final String NICHT_ERFUELLT_ABLEHNEN = "Es besteht ein laufender Bezug einer Altersrente";
    private static final String NICHT_ERFUELLT_AUSSTEUERN = "Es besteht ein laufender Bezug einer Altersrente";

    /**
     * Test, fehlende Kontoinformationen.
     */
    @Test
    void testEmptyKontoinformationen() {
        final RegelErgebnis teilErgebnis = getTeilErgebnis(null, LocalDate.now(), null);

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Test, Aussteuern wenn Fragezeichen enthalten ist.
     *
     * @param bezugRenteLeat Rente Leat
     * @param bezugRenteTlrt Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "??, ?", "??, null", "null, ?"
    })
    void aussteuernWhenQuestionMark(final String bezugRenteLeat, final String bezugRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .bezugRenteLeat(bezugRenteLeat).bezugRenteTlrt(bezugRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(AUSSTEUERN_KEINE_DATEN);
    }

    /**
     * Test, Bezug Rente Leat ist nicht in der Liste.
     *
     * @param bezugRenteLeat Rente Leat
     * @param bezugRenteTlrt Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "1, null", "3, 4", "00, null"
    })
    void testBezugRenteLeatNotInList(final String bezugRenteLeat, final String bezugRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .bezugRenteLeat(bezugRenteLeat).bezugRenteTlrt(bezugRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis()).isEqualTo(PruefErgebnis.ERFUELLT);
        assertThat(teilErgebnis.getDetail()).isEqualTo(ERFUELLT);
    }

    /**
     * Test, Bezug Rente Leat ist in der Liste und Bezug Rente Tlrt ist in der Liste.
     *
     * @param bezugRenteLeat Rente Leat
     * @param bezugRenteTlrt Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "65, 8", "18, 8", "63, 8", "62, 8", "17, 8", "16, 8", "10, 8", "19, 8", "65, 9",
        "18, 9", "63, 9", "62, 9", "17, 9", "16, 9", "10, 9", "19, 9"
    })
    void testBezugRenteLeatInListAndTlrtInList(final String bezugRenteLeat,
        final String bezugRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .bezugRenteLeat(bezugRenteLeat).bezugRenteTlrt(bezugRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis())
            .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(NICHT_ERFUELLT_AUSSTEUERN);
    }

    /**
     * Test, Bezug Rente Leat ist in der Liste und Bezug Rente Tlrt ist Null.
     *
     * @param bezugRenteLeat Rente Leat
     * @param bezugRenteTlrt Rente Tlrt
     */
    @ParameterizedTest
    @CsvSource({
        "65, 0", "18, 0", "63, 0", "62, 0", "17, 0", "16, 0", "10, 0", "19, 0"
    })
    void testBezugRenteLeatInListAndTlrtIsZero(final String bezugRenteLeat,
        final String bezugRenteTlrt) {
        final List<Kontoinformation> kontoinformationen = Stream.of(Kontoinformation.builder()
            .bezugRenteLeat(bezugRenteLeat).bezugRenteTlrt(bezugRenteTlrt).build()).toList();
        final RegelErgebnis teilErgebnis =
            getTeilErgebnis(kontoinformationen, LocalDate.now(), Stammdaten.builder().build());

        assertThat(teilErgebnis.getPruefErgebnis())
            .isEqualTo(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        assertThat(teilErgebnis.getDetail()).isEqualTo(NICHT_ERFUELLT_ABLEHNEN);
    }

    private RegelErgebnis getTeilErgebnis(final List<Kontoinformation> kontoinformationen,
        final LocalDate antragsDatum, final Stammdaten stammdaten) {
        final RegelKontext regelKontext =
            new RegelKontext(Antrag.builder().kontoinformationen(kontoinformationen)
                .antragsDatum(antragsDatum).build(), stammdaten, null, null, null);

        return new BezugAltersrenteRegel().pruefeRegel(regelKontext).getFirst();
    }
}
