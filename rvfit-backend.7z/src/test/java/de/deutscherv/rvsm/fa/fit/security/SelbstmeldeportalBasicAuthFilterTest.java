package de.deutscherv.rvsm.fa.fit.security;

import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Base64;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class SelbstmeldeportalBasicAuthFilterTest {

    private SelbstmeldeportalBasicAuthFilter smpBasicAuthFilter;
    private String authorizationHeader;
    private ClientRequestContext clientRequestContext;

    @BeforeEach
    void init() {
        smpBasicAuthFilter = new SelbstmeldeportalBasicAuthFilter();
        smpBasicAuthFilter.setUser("rvfit");
        smpBasicAuthFilter.setPassword("rvfit");
        authorizationHeader = "Basic " + Base64.getEncoder().encodeToString(
            (smpBasicAuthFilter.getUser() + ":" + smpBasicAuthFilter.getPassword())
                .getBytes());
        clientRequestContext = Mockito.mock(ClientRequestContext.class);
    }

    @Test
    void sollteBasicAuthFilterHinzufuegen() {
        final MultivaluedMap<String, Object> headers = Mockito.mock(MultivaluedHashMap.class);
        Mockito.doReturn(headers).when(clientRequestContext).getHeaders();

        assertDoesNotThrow(() -> smpBasicAuthFilter.filter(clientRequestContext));
        Mockito.verify(clientRequestContext.getHeaders(), Mockito.times(1)).add(HttpHeaders.AUTHORIZATION,
            authorizationHeader);
    }
}