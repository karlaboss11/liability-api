package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.oidc.client.OidcClient;
import io.quarkus.oidc.client.Tokens;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.groups.UniAwait;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.core.MultivaluedHashMap;
import java.util.Base64;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;

/**
 * Test JwtOidcFilter.
 */
public class JwtOidcFilterTest {

    private final static String ACCESS_TOKEN =
            "Basic " + Base64.getEncoder().encodeToString(("user" + ":" + "pass").getBytes());

    private JwtOidcFilter accessTokenFilter;

    private ClientRequestContext clientRequestContext;

    private OidcClient oidcClient;

    /**
     * Vorbereitungen zu jedem Test.
     */
    @BeforeEach
    public void init() {
        clientRequestContext = Mockito.mock(ClientRequestContext.class);
        oidcClient = Mockito.mock(OidcClient.class);
        accessTokenFilter = new JwtOidcFilter(false, oidcClient);
    }

    /**
     * Testet, ob die Abschaltung des Filter's funktioniert.
     */
    @Test
    void securityDisabledTest() {
        accessTokenFilter = new JwtOidcFilter(true, oidcClient);

        assertDoesNotThrow(() -> accessTokenFilter.filter(clientRequestContext));
        Mockito.verifyNoInteractions(clientRequestContext);
    }

    /**
     * Testet, ob der Authorization Header durch den Filter gesetzt wird.
     */
    @Test
    void accessTokenFilterAddsAuthToHeadersTest() {
        final MultivaluedHashMap headers = Mockito.mock(MultivaluedHashMap.class);
        Mockito.when(clientRequestContext.getHeaders()).thenReturn(headers);
        final Tokens tokens = Mockito.mock(Tokens.class);
        final Uni uniTokens = Mockito.mock(Uni.class);
        final UniAwait uniAwaitTokens = Mockito.mock(UniAwait.class);
        Mockito.doReturn(uniTokens).when(oidcClient).getTokens();
        Mockito.doReturn(uniAwaitTokens).when(uniTokens).await();
        Mockito.doReturn(tokens).when(uniAwaitTokens).atMost(any());
        Mockito.doReturn(false).when(tokens).isAccessTokenExpired();
        Mockito.doReturn(ACCESS_TOKEN).when(tokens).getAccessToken();

        assertDoesNotThrow(() -> accessTokenFilter.filter(clientRequestContext));
        Mockito.verify(clientRequestContext.getHeaders(), Mockito.times(1)).add("Authorization",
                "Bearer " + ACCESS_TOKEN);
    }

    @Test
    void accessTokenFilterAddsAuthToHeadersRefreshTest() {
        final MultivaluedHashMap headers = Mockito.mock(MultivaluedHashMap.class);
        Mockito.when(clientRequestContext.getHeaders()).thenReturn(headers);
        final Tokens tokens = Mockito.mock(Tokens.class);
        final Uni uniTokens = Mockito.mock(Uni.class);
        final UniAwait uniAwaitTokens = Mockito.mock(UniAwait.class);
        Mockito.doReturn(uniTokens).when(oidcClient).getTokens();
        Mockito.doReturn(uniAwaitTokens).when(uniTokens).await();
        Mockito.doReturn(tokens).when(uniAwaitTokens).atMost(any());
        Mockito.doReturn(true).when(tokens).isAccessTokenExpired();
        Mockito.doReturn(ACCESS_TOKEN).when(tokens).getAccessToken();
        assertDoesNotThrow(() -> accessTokenFilter.filter(clientRequestContext));
        Mockito.verify(clientRequestContext.getHeaders(), Mockito.times(1)).add("Authorization",
                "Bearer " + ACCESS_TOKEN);
    }
}
