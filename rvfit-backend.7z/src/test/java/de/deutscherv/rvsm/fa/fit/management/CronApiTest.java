package de.deutscherv.rvsm.fa.fit.management;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import lombok.SneakyThrows;
import org.jboss.resteasy.reactive.RestResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests fuer die CronApi Endpunkte.
 */
@QuarkusTest
@ActivateRequestContext
@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class CronApiTest {

    @Inject
    private FehlerRepository fehlerRepository;
    @Inject
    private AntragRepository antragRepository;
    @Inject
    private DrvMandant drvMandant;

    /**
     * Bereinigt die Fehlertabelle und erstellt einen Test-Antrag inkl. Fehler.
     *
     * @throws IOException IO-Fehler
     */
    @BeforeEach
    @Transactional
    void setUp() throws IOException {
        clearFehlerTabelle();
        saveEantragMitFehlern();
    }

    /**
     *  Testet, ob der Fehlerreset funktioniert.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "TR_Fit_JOBS")
    @Transactional
    void resetFehlertabelle() {
        given().pathParam("ktan", "70").put("cron/fehlerreset/{ktan}").then().statusCode(RestResponse.StatusCode.OK);

        List<Fehler> list = fehlerRepository.findAll();
        System.out.println(list);
        assertThat(list).hasSize(2);
        assertThat(list.getFirst().getRetries()).isZero();
        assertThat(list.getLast().getRetries()).isEqualTo(3);
    }

    /**
     * Bereinigt die Fehlertabelle.
     */
    @AfterEach
    @Transactional
    void cleanUp() {
        clearFehlerTabelle();
    }

    @SneakyThrows
    private void saveEantragMitFehlern() throws IOException {
        String eantrag = new String(
                CronApiTest.class.getClassLoader()
                        .getResourceAsStream("eAntragXmls/eAntrag_04021093N590.xml").readAllBytes(),
                StandardCharsets.UTF_8);

        UUID uuid = UUID.randomUUID();

        Antrag antrag = Antrag.builder().xml(eantrag)
                .ktan("70").vsnr("04021093N590").uuid(uuid).status(AntragStatus.ENTWURF).build();
        drvMandant.setInScope("70");

        antragRepository.persist(antrag);
        antragRepository.flush();

        Fehler fehler1 = Fehler.builder().status(antrag.getStatus()).antragId(uuid).retries(10).build();
        Fehler fehler2 = Fehler.builder().status(antrag.getStatus()).antragId(uuid).retries(3).build();

        fehlerRepository.persist(fehler1);
        fehlerRepository.persist(fehler2);
        fehlerRepository.flush();
        antragRepository.flush();
    }

    private void clearFehlerTabelle() {
        drvMandant.setInScope("70");
        List<Fehler> fehlerListe = fehlerRepository.findAll();
        fehlerRepository.deleteAll(fehlerListe);
    }
}