package de.deutscherv.rvsm.fa.fit.statistik;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import com.google.inject.name.Named;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentendatenService;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.DatenphaseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestFesterTeilDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestVariablerTeilAntragserfassungDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.RequestVariablerTeilBescheidDto;
import de.deutscherv.rvsm.fa.fit.statistik.util.DurchfuehrungsArt;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikUtil;
import de.deutscherv.rvsm.fa.fit.testdaten.PapierantragTestDatenHelper;
import de.deutscherv.rvsm.fa.fit.testdaten.TestPerson;
import de.deutscherv.rvsm.fa.fit.util.WireMockStub;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDebugDTO;
import io.quarkus.artemis.test.ArtemisTestResource;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.quarkus.test.security.oidc.Claim;
import io.quarkus.test.security.oidc.OidcSecurity;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten.AUFFRISCHUNGSPHASE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;

/**
 * Test StatistikService.
 */
@QuarkusTest
@Slf4j
@QuarkusTestResource(ArtemisTestResource.class)
class StatistikServiceTest {

    private static final String STARTPHASE = "Startphase";
    private static final String TRAININGSPHASE = "Trainingsphase";
    private static final String AUFGABEN_ID = "AUID0123456789";
    private static WireMockServer wireMockServer;
    private static StubMapping stubMappingBescheid;
    private static StubMapping stubMappingAntragserfassung;

    @Inject
    private AntragRepository antragRepository;

    @Inject
    private VerarbeitungsstatusRepository verarbeitungsstatusRepository;

    @Inject
    private DrvMandant drvMandant;

    @Inject
    private StatistikService statistikService;

    private int iVorgangsnummer = 0;

    /**
     * Globale Testvorbereitungen.
     */
    @BeforeAll
    static void setUpBeforeClass() {
        LOG.atInfo().log("Statistik Service Tests");

        installWiremockServer();

    }

    private static void installWiremockServer() {
        // WireMock aufsetzen
        wireMockServer = new WireMockServer(WireMockStub.PORT);

        wireMockServer.start();
        configureFor("localhost", wireMockServer.port());

        // wird immer benoetigt
        stubFor(post(urlEqualTo("/antragsdaten"))
            .willReturn(aResponse().withStatus(Status.CREATED.getStatusCode())));
    }

    /**
     * Globale Abschlussarbeiten.
     */
    @AfterAll
    static void tearDownAfterClass() {
        // WireMock beenden
        wireMockServer.stop();
    }

    /**
     * Vorbereitungen vor jedem Test.
     */
    @BeforeEach
    void setUp() {
        drvMandant.setInScope("70");
        final DokumentendatenService mock = Mockito.mock(DokumentendatenService.class);
        final AuftragsStatusDTO auftragsStatusDTO = new AuftragsStatusDTO();
        final AuftragsStatusDebugDTO debug = new AuftragsStatusDebugDTO();
        debug.setDiloopResponse("string");
        auftragsStatusDTO.setDebug(debug);
        auftragsStatusDTO.setStatus(AuftragsStatusDTO.StatusEnum.IN_BEARBETUNG);
        auftragsStatusDTO.setAuftragId(UUID.randomUUID());
        Mockito.doReturn(auftragsStatusDTO).when(mock).getDokumentendaten(any(), any(),
            anyBoolean());
        QuarkusMock.installMockForType(mock, DokumentendatenService.class);
    }

    /**
     * Test prüft, dass eine Not Found Exception geworfen wird, wenn eine unbekannte UUID übergeben wird, und daher kein Antrag im
     * Statistikservice abgefragt werden kann.
     */
    @Test
    @Named("Kein Antrag zur ID - Statistik Exception")
    void createBescheidKeinAntragZuID() {
        drvMandant.setInScope("70");
        final Antrag antrag = new Antrag();
        antrag.setUuid(UUID.fromString("FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"));
        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));
    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn ein Antrag mit nicht validem Prüfergebnis übergeben wird.
     */
    @Test
    @Named("Pruefergebnis invalide")
    @Transactional
    void createStatistikPruefergebnisInvalid() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(null);
        antragRepository.merge(antrag);

        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test prüft, dass für einen abgeschlossenen Papierantrag eine Bewilligungsstatistik erstellt wird.
     */
    @Test
    @Transactional
    @Named("Bewilligung Papierantrag/E-Antrag")
    void createStatistikBewilligung() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // Papierantrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);

        createVerarbeitungsstatus(antrag.getUuid());

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test CreateStatisik mit StatistikException.
     */
    @Test
    @TestSecurity(user = "userJwt", roles = "PR_Fit_BST")
    @OidcSecurity(claims = { @Claim(key = "drv_mandant", value = "70") })
    @Transactional
    @Named("Statistik Erfassung Papierantrag, Web-Service-Fehler")
    void createStatistikErfassungInvalid() {
        drvMandant.setInScope("70");
        stubMappingAntragserfassungNoContent();
        final String vorgangsKennung = generiereNeueVogID();
        final PapierantragDto papierantragsDto = PapierantragTestDatenHelper.erstellePapierantrag(
            new PapierantragTestDatenHelper.PapierantragInput(TestPerson.PETER_PAN,
                vorgangsKennung, AUFGABEN_ID));

        final Antrag antrag = createAntrag(AntragStatus.VORGANG_WIRD_ERSTELLT);
        antragRepository.persist(antrag);
        final Optional<PapierantragDto> papierantragDtoOptional = Optional.of(papierantragsDto);
        assertThrows(StatistikException.class, () -> statistikService.createStatistikErfassung(antrag, papierantragDtoOptional));

        wireMockServer.removeStubMapping(stubMappingAntragserfassung);

    }

    /**
     * Test prüft, dass für einen abgeschlossenen Papierantrag eine Bewilligungsstatistik erstellt wird.
     */
    @Test
    @Transactional
    @Named("Bewilligung E-Antrag")
    void createStatistikBewilligungEantrag() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // E-Antrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        createVerarbeitungsstatus(antrag.getUuid());
        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        antragRepository.merge(antrag);
        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass für einen E-Antrag dessen Ergebnis Aussteuern ist, eine Bewilligungsstatistik erstellt wird.
     */
    @Test
    @Transactional
    @Named("Bewilligung E-Antrag")
    void createStatistikBewilligungEantragAussteuerung() {
        drvMandant.setInScope("70");
        stubMappingBescheid();
        // E-Antrag mit Aussteuerung
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        createVerarbeitungsstatus(antrag.getUuid());
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_WARTEZEITPRUEFUNG));
        antragRepository.merge(antrag);
        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));
        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass die Bewilligungsstatistik für einen Papierantrag der automatisch bewilligt wurde erstellt wurde.
     */
    @Test
    @Transactional
    @Named("Automatische Bewilligung Papierantrag")
    void createStatistikAutomatischeBewilligungPapier() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // Papierantrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));

        antragRepository.merge(antrag);

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass die Bewilligungsstatistik für einen Eantrag der automatisch bewilligt wurde erstellt wurde.
     */
    @Test
    @Transactional
    @Named("Automatische Bewilligung E-Antrag")
    void createStatistikAutomatischeBewilligungEAntrag() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // E-Antrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        antragRepository.merge(antrag);
        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass die Ablehnungsstatistik für einen Eantrag der automatisch abgelehnt wurde erstellt wurde.
     */
    @Test
    @Transactional
    @Named("Automatische Ablehnung E-Antrag")
    void createStatistikAutomatischeAblehnungEantrag() {
        drvMandant.setInScope("70");
        wireMockServer.addStubMapping(stubMappingBescheid);

        // E-Antrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN, RegelName.REGEL_WARTEZEITPRUEFUNG));
        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        antragRepository.merge(antrag);
        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass die Abklehnungsstatistik für einen Papierantrag der automatisch abgelehnt wurde erstellt wurde.
     */
    @Test
    @Transactional
    @Named("Automatische Ablehnung Papierantrag")
    void createStatistikAutomatischeAblehnungPapier() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // Papierantrag
        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN, RegelName.REGEL_WARTEZEITPRUEFUNG));

        antragRepository.merge(antrag);
        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn ein Antrag ohne Verarbeitungsstatus erstellt wird.
     */
    @Test
    @Transactional
    @Named("Automatische Ablehnung Papierantrag/E-Antrag")
    void createStatistikAutomatischeAblehnungOhneVerarbeitungsstatus() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        // Papierantrag
        final Antrag antrag = createAntrag();

        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);

    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn die Statistik einen Internal Server Error (500) zurückgibt.
     */
    @Test
    @Transactional
    void createStatistikStatusCodeUngleich200SolltExceptionWerfen() {
        drvMandant.setInScope("70");
        stubMappingBescheidStatusCode500();

        // Papierantrag
        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antrag.setStatus(AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);
        antrag.setStatus(AntragStatus.AUTOMATISCH);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.setStatus(AntragStatus.AUFGABE_ABGESCHLOSSEN);
        antragRepository.merge(antrag);

        createVerarbeitungsstatus(antrag.getUuid());
        assertThrows(StatistikException.class, () -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Prüft, dass keine Exception geworfen wird, wenn eine Bescheid-Statistik erstellt werden soll bei fehlender Einrichtung für
     * Auffrischungs- und Trainingsphase.
     */
    @Test
    @Named("Bewilligung ohne Einrichtung fuer Auffrischung/Training")
    @Transactional
    void createStatistikBewilligungOhneEinrichtungAufTraining() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag1 = createAntrag();
        antrag1.setEinrichtungTrainingObjekt(null);
        antrag1.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag1);

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag1, false));

        final Antrag antrag2 = createAntrag();
        antrag2.setEinrichtungAufObjekt(null);
        antrag2.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag2);

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag2, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test prüft, dass das StatistikUtil aus der Rehaeinrichtung den Code für die Durchführungsart korrekt ableitet.
     */
    @Test
    @Named("Ermittle Durchfuehrungsart")
    @Transactional
    void getDFTTest() {

        // Keine Reha-Einrichtung
        assertEquals("0", StatistikUtil.getDF(null, STARTPHASE));

        final Angebot angebot = new Angebot();
        angebot.setPhase(AUFFRISCHUNGSPHASE);
        angebot.setDauer(1);
        angebot.setDurchfuehrungsart("stationär");

        final RehaEinrichtung rehaEinrichtung = new RehaEinrichtung();
        rehaEinrichtung.setResc("aresc_Auffrischung");
        rehaEinrichtung.setAngebote(List.of(angebot));
        // stationär
        assertEquals("1", StatistikUtil.getDF(rehaEinrichtung, AUFFRISCHUNGSPHASE));

        // Ambulant (ganztägig)
        angebot.setDurchfuehrungsart("Ambulant (ganztägig)");
        assertEquals("2", StatistikUtil.getDF(rehaEinrichtung, AUFFRISCHUNGSPHASE));

        // Ambulant
        angebot.setDurchfuehrungsart("Ambulant");
        assertEquals("3", StatistikUtil.getDF(rehaEinrichtung, AUFFRISCHUNGSPHASE));
    }

    /**
     * Test prüft, dass eine dem Antrag entsprechende Datenphase für die Startophase erstellt wird.
     */
    @Test
    @Named("Erstellen DatenphaseDto Start")
    @Transactional
    void createDatenphaseStartTest() {

        drvMandant.setInScope("70");

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        DatenphaseDto datenphaseDto = null;
        try {
            datenphaseDto = StatistikUtil.createDatenphaseStart(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        assertEquals("A12345", datenphaseDto.getRESC());
        assertEquals("1", datenphaseDto.getDF());
        assertEquals("003", datenphaseDto.getDA731());
        assertEquals("1", datenphaseDto.getAT731());
        assertNull(datenphaseDto.getZLHBTG());

        final Angebot angebot = antrag.getEinrichtungStartObjekt().getAngebote().getFirst();
        angebot.setPhase(STARTPHASE);
        angebot.setDauer(3);
        angebot.setDurchfuehrungsart("ambulant");
        antragRepository.merge(antrag);
        try {
            datenphaseDto = StatistikUtil.createDatenphaseStart(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertEquals("003", datenphaseDto.getZLHBTG());

        antrag.setEinrichtungStartObjekt(null);

        final DatenphaseDto datenphaseNull = new DatenphaseDto();
        datenphaseNull.setDF("0");

        try {
            assertEquals(datenphaseNull,
                StatistikUtil.createDatenphaseStart(antrag));
        } catch (final StatistikException e) {
            LOG.atError().setCause(e).log(e.getMessage());
        }
    }

    /**
     * Test prüft, dass eine dem Antrag entsprechende Datenphase für die Trainingsphase erstellt wird.
     */
    @Test
    @Named("Erstellen DatenphaseDto Training")
    @Transactional
    void createDatenphaseTrainingTest() {
        drvMandant.setInScope("70");

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        DatenphaseDto datenphaseDto = null;
        try {
            datenphaseDto = StatistikUtil.createDatenphaseTraining(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        assertEquals("B12345", datenphaseDto.getRESC());
        assertEquals("3", datenphaseDto.getDF());
        assertEquals("005", datenphaseDto.getDA731());
        assertEquals("2", datenphaseDto.getAT731());
        assertEquals("005", datenphaseDto.getZLHBTG());

        final Angebot angebot = antrag.getEinrichtungTrainingObjekt().getAngebote().getFirst();
        angebot.setPhase(TRAININGSPHASE);
        angebot.setDauer(1);
        angebot.setDurchfuehrungsart("stationär");
        antragRepository.merge(antrag);
        try {
            datenphaseDto = StatistikUtil.createDatenphaseTraining(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertNull(datenphaseDto.getZLHBTG());

        antrag.setEinrichtungTrainingObjekt(null);

        final DatenphaseDto datenphaseNull = new DatenphaseDto();

        try {
            assertEquals(datenphaseNull,
                StatistikUtil.createDatenphaseTraining(antrag));
        } catch (final StatistikException e) {
            LOG.atError().setCause(e).log(e.getMessage());
        }

    }

    /**
     * Test prüft, dass eine dem Antrag entsprechende Datenphase für die Auffrischungsphase erstellt wird.
     */
    @Test
    @Named("Erstellen DatenphaseDto Auffrischung")
    @Transactional
    void createDatenphaseAufTest() {
        drvMandant.setInScope("70");

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        DatenphaseDto datenphaseDto = null;
        try {
            datenphaseDto = StatistikUtil.createDatenphaseAuffrischung(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        assertEquals("C12345", datenphaseDto.getRESC());
        assertEquals("2", datenphaseDto.getDF());
        assertEquals("001", datenphaseDto.getDA731());
        assertEquals("1", datenphaseDto.getAT731());
        assertEquals("001", datenphaseDto.getZLHBTG());

        final Angebot angebot = antrag.getEinrichtungAufObjekt().getAngebote().getFirst();
        angebot.setPhase(AUFFRISCHUNGSPHASE);
        angebot.setDauer(1);
        angebot.setDurchfuehrungsart("stationär");
        antragRepository.merge(antrag);
        try {
            datenphaseDto = StatistikUtil.createDatenphaseAuffrischung(antrag);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertNull(datenphaseDto.getZLHBTG());

        antrag.setEinrichtungAufObjekt(null);

        final DatenphaseDto datenphaseNull = new DatenphaseDto();

        try {
            assertEquals(datenphaseNull,
                StatistikUtil.createDatenphaseAuffrischung(antrag));
        } catch (final StatistikException e) {
            LOG.atError().setCause(e).log(e.getMessage());
        }

    }

    /**
     * Test prüft, dass der RequestVariableTeil für unterschiedliche Konstellationen bei Bescheiden korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTest() {
        drvMandant.setInScope("70");

        Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto = null;
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.ABLEHNUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        assertEquals("12", requestVariablerTeilBescheidDto.getMSNR());
        assertEquals("1234", requestVariablerTeilBescheidDto.getATAD());
        assertEquals("2024-07-09", requestVariablerTeilBescheidDto.getDTAQ().toString());
        assertEquals("2024-07-16", requestVariablerTeilBescheidDto.getDTEL().toString());
        assertEquals("2024-07-10", requestVariablerTeilBescheidDto.getEQDT14().toString());
        assertEquals("2", requestVariablerTeilBescheidDto.getBEAT());
        assertEquals(antrag.getCreated().toLocalDate(), requestVariablerTeilBescheidDto.getZKDT());
        assertEquals("6", requestVariablerTeilBescheidDto.getZKPY()); // weil Created >14Tage als
        // EQDT14
        assertEquals("80", requestVariablerTeilBescheidDto.getMTEP());
        assertNull(requestVariablerTeilBescheidDto.getTXNR());

        // E-Antrag und Erfuellt.
        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertEquals(antrag.getEingangsdatum(), requestVariablerTeilBescheidDto.getZKDT());

        // Papierantrag und Ausgesteuert
        antrag.setAntragsart(AntragsArt.PAPIERANTRAG);
        antrag.addAntragPruefergebnis(createdRegel(
            PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_WARTEZEITPRUEFUNG));
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertEquals("3", requestVariablerTeilBescheidDto.getBEAT());

        // E-Antrag und Ausgesteuert
        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        // Antrag ist nicht erfuellt
        antrag.getAntragPruefergebnisse().stream()
            .filter(p -> p.getRegelName() == null && p.getErgebnis() == PruefErgebnis.ERFUELLT)
            .forEach(p -> p.setErgebnis(PruefErgebnis.AUSSTEUERN));
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setRegelName(RegelName.REGEL_STAATSANGEHOERIGKEIT);
        antragPruefergebnis.setBegruendung("Fehler");
        antragPruefergebnis.setPrioritaet(1L);
        antrag.addAntragPruefergebnis(antragPruefergebnis);
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }
        assertEquals("169", requestVariablerTeilBescheidDto.getTXNR());

    }

    /**
     * Test prüft, dass der RequestVariableTeil für unterschiedliche Konstellationen bei Bescheiden korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestAblehnung() {
        drvMandant.setInScope("70");

        Antrag antrag = createAntrag();
        final var regel1 = createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_WARTEZEITPRUEFUNG);
        regel1.setCreated(LocalDateTime.now().minusHours(1));
        regel1.setPrioritaet(1L);
        final var regel2 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_WARTEZEITPRUEFUNG);
        regel2.setCreated(LocalDateTime.now());
        regel2.setPrioritaet(1L);
        final var regel3 = createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_AKTIVEBESCHAEFTIGUNG);
        regel3.setCreated(LocalDateTime.now());
        regel3.setPrioritaet(4L);
        antrag.addAntragPruefergebnis(regel1);
        antrag.addAntragPruefergebnis(regel2);
        antrag.addAntragPruefergebnis(regel3);
        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.ABLEHNUNG, false);

        assertEquals("50 ", requestVariablerTeilBescheidDto.getTXNR());
    }

    /**
     * Test prüft, dass der RequestVariableTeil für unterschiedliche Konstellationen bei Bescheiden korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestBewilligungWithMoreThanOneResult() {
        drvMandant.setInScope("70");

        Antrag antrag = createAntrag();
        final var regel1 = createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_AUSSTEUERN);
        regel1.setCreated(LocalDateTime.now().minusHours(1));
        final var regel2 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel2.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        antrag.addAntragPruefergebnis(regel2);
        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);

        assertNull(requestVariablerTeilBescheidDto.getTXNR());
        assertEquals("80", requestVariablerTeilBescheidDto.getMTEP());
    }

    /**
     * Test prüft, dass der RequestVariableTeil für Bewilligung mit Einrichtungsregel Aussteuern bei Bescheiden korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestBewilligungWithEinrichtungsRegelAussteuern() {
        drvMandant.setInScope("70");

        Antrag antrag = createAntrag();
        final var regel1 = createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
            RegelName.REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH);
        regel1.setCreated(LocalDateTime.now().minusHours(1));
        final var regel2 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel2.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        antrag.addAntragPruefergebnis(regel2);
        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);

        assertNull(requestVariablerTeilBescheidDto.getTXNR());
        assertEquals("80", requestVariablerTeilBescheidDto.getMTEP());
    }

    /**
     * Test prüft, dass der RequestVariableTeil für Bewilligung für Einrichtung ohne RESC bei Bescheiden korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestBewilligungEinrichtungNoRescSetAddresse() {
        drvMandant.setInScope("70");

        final String strasse = "Test";
        final String hausnummer = "1";
        final String plz = "12345";
        final String adresszusatz = "test";
        final String ort = "Test Ort";
        Antrag antrag = createAntrag();

        final var regel1 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel1.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        EinrichtungAnschrift einrichtungAnschrift = new EinrichtungAnschrift();
        einrichtungAnschrift.setHausnummer(hausnummer);
        einrichtungAnschrift.setStrasse(strasse);
        einrichtungAnschrift.setPlz(plz);
        einrichtungAnschrift.setAdresszusatz(adresszusatz);
        einrichtungAnschrift.setOrt(ort);

        final String einrichtungName = "Test Einrichtung";

        final RehaEinrichtung rehaStart = new RehaEinrichtung();
        rehaStart.setResc(null);
        rehaStart.setName(einrichtungName);
        rehaStart.setAdresse(einrichtungAnschrift);
        rehaStart.setAngebote(List.of(createStartAngebot()));

        antrag.setEinrichtungStartObjekt(rehaStart);

        final RehaEinrichtung rehaTraining = new RehaEinrichtung();
        rehaTraining.setResc(null);
        rehaTraining.setName(einrichtungName);
        rehaTraining.setAdresse(einrichtungAnschrift);
        rehaTraining.setAngebote(List.of(createAngebotTraining()));

        antrag.setEinrichtungTrainingObjekt(rehaTraining);

        final RehaEinrichtung rehaAuffrischung = new RehaEinrichtung();
        rehaAuffrischung.setResc(null);
        rehaAuffrischung.setName(einrichtungName);
        rehaAuffrischung.setAdresse(einrichtungAnschrift);
        rehaAuffrischung.setAngebote(List.of(createAngebotAuffrischung()));

        antrag.setEinrichtungAufObjekt(rehaAuffrischung);

        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);

        assertEquals(3, requestVariablerTeilBescheidDto.getDATENPHASE().size());
        requestVariablerTeilBescheidDto.getDATENPHASE().forEach(datenphaseDto -> {
            assertNull(datenphaseDto.getRESC());
            assertEquals(strasse + " " + hausnummer, datenphaseDto.getAdresse());
            assertEquals(ort, datenphaseDto.getOrt());
            assertEquals(plz, datenphaseDto.getPostleitzahl());
            assertEquals(einrichtungName, datenphaseDto.getNameEinrichtung());
        });
    }

    /**
     * Test prüft, dass der RequestVariableTeil für Bewilligung für Einrichtung mit RESC ohne Buchstaben am Anfang bei Bescheiden korrekt
     * erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestBewilligungEinrichtungRescWithOutLetterAtBeginning() {
        drvMandant.setInScope("70");

        final String strasse = "Test";
        final String hausnummer = "1";
        final String plz = "12345";
        final String ort = "Test Ort";
        Antrag antrag = createAntrag();

        final var regel1 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel1.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        EinrichtungAnschrift einrichtungAnschrift = new EinrichtungAnschrift();
        einrichtungAnschrift.setHausnummer(hausnummer);
        einrichtungAnschrift.setStrasse(strasse);
        einrichtungAnschrift.setPlz(plz);
        einrichtungAnschrift.setOrt(ort);

        final String einrichtungName = "Test Einrichtung";

        final RehaEinrichtung rehaStart = new RehaEinrichtung();
        rehaStart.setResc("012345");
        rehaStart.setName(einrichtungName);
        rehaStart.setAdresse(einrichtungAnschrift);
        rehaStart.setAngebote(List.of(createStartAngebot()));

        antrag.setEinrichtungStartObjekt(rehaStart);

        final RehaEinrichtung rehaTraining = new RehaEinrichtung();
        rehaTraining.setResc("012345");
        rehaTraining.setName(einrichtungName);
        rehaTraining.setAdresse(einrichtungAnschrift);
        rehaTraining.setAngebote(List.of(createAngebotTraining()));

        antrag.setEinrichtungTrainingObjekt(rehaTraining);

        final RehaEinrichtung rehaAuffrischung = new RehaEinrichtung();
        rehaAuffrischung.setResc("012345");
        rehaAuffrischung.setName(einrichtungName);
        rehaAuffrischung.setAdresse(einrichtungAnschrift);
        rehaAuffrischung.setAngebote(List.of(createAngebotAuffrischung()));

        antrag.setEinrichtungAufObjekt(rehaAuffrischung);

        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);

        assertEquals(3, requestVariablerTeilBescheidDto.getDATENPHASE().size());
        requestVariablerTeilBescheidDto.getDATENPHASE().forEach(datenphaseDto -> {
            assertEquals("012345", datenphaseDto.getRESC());
            assertEquals(strasse + " " + hausnummer, datenphaseDto.getAdresse());
            assertEquals(ort, datenphaseDto.getOrt());
            assertEquals(plz, datenphaseDto.getPostleitzahl());
            assertEquals(einrichtungName, datenphaseDto.getNameEinrichtung());
        });
    }

    /**
     * Test prüft, dass der RequestVariableTeil für eine Antragserfassung korrekt erstellt wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestBewilligungEinrichtungTrainingsphaseSetDauerWhenMehrereAngebote() {
        drvMandant.setInScope("70");

        final String strasse = "Test";
        final String hausnummer = "1";
        final String plz = "12345";
        final String adresszusatz = "test";
        final String ort = "Test Ort";
        Antrag antrag = createAntrag();

        final var regel1 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel1.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        EinrichtungAnschrift einrichtungAnschrift = new EinrichtungAnschrift();
        einrichtungAnschrift.setHausnummer(hausnummer);
        einrichtungAnschrift.setStrasse(strasse);
        einrichtungAnschrift.setPlz(plz);
        einrichtungAnschrift.setAdresszusatz(adresszusatz);
        einrichtungAnschrift.setOrt(ort);

        final String einrichtungName = "Test Einrichtung";

        RehaEinrichtung rehaStart = new RehaEinrichtung();
        rehaStart.setResc("012345");
        rehaStart.setName(einrichtungName);
        rehaStart.setAdresse(einrichtungAnschrift);
        rehaStart.setAngebote(List.of(createStartAngebot()));

        antrag.setEinrichtungStartObjekt(rehaStart);

        final RehaEinrichtung rehaTraining = new RehaEinrichtung();
        rehaTraining.setResc("012348");
        rehaTraining.setName(einrichtungName);
        rehaTraining.setAdresse(einrichtungAnschrift);
        rehaTraining.setAngebote(List.of(createStartAngebot(), createAngebotTraining(), createAngebotAuffrischung()));

        antrag.setEinrichtungTrainingObjekt(rehaTraining);

        final RehaEinrichtung rehaAuffrischung = new RehaEinrichtung();
        rehaAuffrischung.setResc("012345");
        rehaAuffrischung.setName(einrichtungName);
        rehaAuffrischung.setAdresse(einrichtungAnschrift);
        rehaAuffrischung.setAngebote(List.of(createAngebotAuffrischung()));

        antrag.setEinrichtungAufObjekt(rehaAuffrischung);

        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.BEWILLIGUNG, false);

        DatenphaseDto datenphaseDto = requestVariablerTeilBescheidDto.getDATENPHASE()
            .stream().filter(datenphaseDto1 -> datenphaseDto1.getRESC().equals("012348")).findAny().orElseThrow();
        assertEquals("005", datenphaseDto.getDA731());
    }

    /**
     * Test prüft, dass der RequestVariableTeil eine Datenphase mit gesetztem DF-Wert hat, wenn Antrag via Erledigungsart Erledigung auf
     * andere Art und Weise, Storno oder Ruecknahme abgeschlossen wird.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void createRequestVariablerTeilBescheidTestErledigungAndereArtUndWeiseStornoRuecknahmeDatenphaseDFGesetzt() {
        drvMandant.setInScope("70");

        final String strasse = "Test";
        final String hausnummer = "1";
        final String plz = "12345";
        final String adresszusatz = "test";
        final String ort = "Test Ort";
        Antrag antrag = createAntrag();

        final var regel1 = createdRegel(PruefErgebnis.ERFUELLT, RegelName.REGEL_AUSSTEUERN);
        regel1.setCreated(LocalDateTime.now());
        antrag.addAntragPruefergebnis(regel1);
        final EinrichtungAnschrift einrichtungAnschrift = new EinrichtungAnschrift();
        einrichtungAnschrift.setHausnummer(hausnummer);
        einrichtungAnschrift.setStrasse(strasse);
        einrichtungAnschrift.setPlz(plz);
        einrichtungAnschrift.setAdresszusatz(adresszusatz);
        einrichtungAnschrift.setOrt(ort);

        final String einrichtungName = "Test Einrichtung";

        final RehaEinrichtung rehaStart = new RehaEinrichtung();
        rehaStart.setResc("012345");
        rehaStart.setName(einrichtungName);
        rehaStart.setAdresse(einrichtungAnschrift);
        rehaStart.setAngebote(List.of(createStartAngebot()));

        antrag.setEinrichtungStartObjekt(rehaStart);

        final RehaEinrichtung rehaTraining = new RehaEinrichtung();
        rehaTraining.setResc("012348");
        rehaTraining.setName(einrichtungName);
        rehaTraining.setAdresse(einrichtungAnschrift);
        rehaTraining.setAngebote(List.of(createStartAngebot(), createAngebotTraining(), createAngebotAuffrischung()));

        antrag.setEinrichtungTrainingObjekt(rehaTraining);

        final RehaEinrichtung rehaAuffrischung = new RehaEinrichtung();
        rehaAuffrischung.setResc("012345");
        rehaAuffrischung.setName(einrichtungName);
        rehaAuffrischung.setAdresse(einrichtungAnschrift);
        rehaAuffrischung.setAngebote(List.of(createAngebotAuffrischung()));

        antrag.setEinrichtungAufObjekt(rehaAuffrischung);

        antragRepository.merge(antrag);
        antrag = antragRepository.findByUuid(antrag.getUuid()).orElseThrow();

        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDtoErlAndereArtUndWeise =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE, false);
        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDtoStorno =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.STORNO, false);
        final RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDtoRuecknahme =
            StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.RUECKNAHME, false);

        assertThat(requestVariablerTeilBescheidDtoErlAndereArtUndWeise.getDATENPHASE()).isNotNull().isNotEmpty();
        assertThat(requestVariablerTeilBescheidDtoErlAndereArtUndWeise.getDATENPHASE().getFirst().getDF()).isNotNull();
        assertThat(requestVariablerTeilBescheidDtoStorno.getDATENPHASE()).isNotNull().isNotEmpty();
        assertThat(requestVariablerTeilBescheidDtoStorno.getDATENPHASE().getFirst().getDF()).isNotNull();
        assertThat(requestVariablerTeilBescheidDtoRuecknahme.getDATENPHASE()).isNotNull().isNotEmpty();
        assertThat(requestVariablerTeilBescheidDtoRuecknahme.getDATENPHASE().getFirst().getDF()).isNotNull();

    }

    /**
     * Test Request variabler Teil AntragserfassungDTO.
     */
    @Test
    @Named("RequestVariablerTeilAntragserfassungDto")
    @Transactional
    void createRequestVariablerTeilAntragserfassungDtoTest() {
        drvMandant.setInScope("70");

        final Antrag antrag = createAntrag();
        antrag.setAntragsart(AntragsArt.PAPIERANTRAG);

        RequestVariablerTeilAntragserfassungDto requestVariablerTeilAntragserfassungDto;
        requestVariablerTeilAntragserfassungDto =
            StatistikUtil.createRequestVariablerTeilAntragserfassungDto(antrag);
        assertEquals("1", requestVariablerTeilAntragserfassungDto.getBEAT());
        assertEquals("2024-07-09", requestVariablerTeilAntragserfassungDto.getDTAQ().toString());
        assertEquals("2024-07-10", requestVariablerTeilAntragserfassungDto.getDTEQ().toString());
        assertEquals("1", requestVariablerTeilAntragserfassungDto.getDF());

        antrag.setAntragsart(AntragsArt.E_ANTRAG);
        requestVariablerTeilAntragserfassungDto =
            StatistikUtil.createRequestVariablerTeilAntragserfassungDto(antrag);
        assertEquals("2", requestVariablerTeilAntragserfassungDto.getBEAT());

    }

    /**
     * Test prüft, dass bei einem nicht gesetzten Bescheiddatum das DTEL das aktuelle Datum nimmt.
     */
    @Test
    @Named("RequestVariablerTeilBescheidDto")
    @Transactional
    void requestVariablerTeilBescheiddatumIsNullTest() {
        drvMandant.setInScope("70");

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antrag.setBescheiddatum(null);
        antragRepository.merge(antrag);

        RequestVariablerTeilBescheidDto requestVariablerTeilBescheidDto = null;
        try {
            requestVariablerTeilBescheidDto =
                StatistikUtil.createRequestVariablerTeilBescheid(antrag, Art.ABLEHNUNG, false);
        } catch (final StatistikException e) {
            fail(e.getMessage());
        }

        assertEquals(LocalDate.now(), requestVariablerTeilBescheidDto.getDTEL());
    }

    /**
     * Test prüft, dass der feste Teil bei der Statistik korrekt gebildet wird, und der PNR Wert beispielsweise korrekt erstellt wird.
     *
     * @param statistikTyp der Statistiktyp
     * @param pnrWert      der erwartete PNR-Wert
     */
    @ParameterizedTest
    @CsvSource(value = { "ANTRAGSERFASSUNG,5", "BESCHEIDDATEN,15" })
    @Named("RequestFesterTeilDto")
    void createFesterTeilTest(final String statistikTyp, final String pnrWert) {
        final RequestFesterTeilDto requestFesterTeilDtoFuerAntragserfassung =
            StatistikUtil.createFesterTeil(StatistikTyp.valueOf(statistikTyp));
        assertThat(requestFesterTeilDtoFuerAntragserfassung.getPNR()).isEqualTo(pnrWert);
        assertThat(requestFesterTeilDtoFuerAntragserfassung.getSUSY()).isEqualTo("RHFIT");
        assertThat(requestFesterTeilDtoFuerAntragserfassung.getDATENBANK()).hasSize(20)
            .containsOnly("");
    }

    /**
     * Test prueft, dass die Statistik angelegt wurde.
     */
    @Test
    @Named("Bewilligung_StatusWrong")
    @Transactional
    void createStatistikBewilligungStatusWrong() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test prüft, dass eine Bescheid Statistik geschrieben wird, wenn die Staatsangehörigkeitsregel nicht erfüllt ist.
     */
    @Test
    @Named("Ablehnung (mit Pruefergebnis NICHT_ERFUELLT_ABLEHNEN)")
    @Transactional
    void createStatistikAblehnungNichtErfuellt() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setRegelName(RegelName.REGEL_STAATSANGEHOERIGKEIT);
        antragPruefergebnis.setBegruendung("Fehler");
        antragPruefergebnis.setPrioritaet(1L);
        antrag.addAntragPruefergebnis(antragPruefergebnis);
        antragRepository.merge(antrag);

        createVerarbeitungsstatus(antrag.getUuid());

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test prüft, dass eine Bescheid Statistik geschrieben wird, wenn die Hausnummer Regel nicht erfüllt ist.
     */
    @Test
    @Named("Ablehnung (mit nicht gueltigem Pruefergebnis REGEL_ABGLEICH_HAUSNUMMER)")
    @Transactional
    void createStatistikAblehnungUngueltigesPruefergebnis() {
        drvMandant.setInScope("70");
        wireMockServer.addStubMapping(stubMappingBescheid);

        final Antrag antrag = createAntrag();
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis.setRegelName(RegelName.REGEL_ABGLEICH_HAUSNUMMER);
        antragPruefergebnis.setBegruendung("Fehler");
        antragPruefergebnis.setPrioritaet(2L);
        antrag.addAntragPruefergebnis(antragPruefergebnis);
        antragRepository.merge(antrag);

        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test prüft, dass eine Bescheid Statistik geschrieben wird, wenn das Ergebnis nicht erfüllt aussteuern vorhanden ist.
     */
    @Test
    @Named("Ablehnung (mit Pruefergebnis NICHT_ERFUELLT_AUSSTEUERN)")
    @Transactional
    void createStatistikAblehnungNichtErfuelltAussteuern() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag = createAntrag(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, RegelName.REGEL_WARTEZEITPRUEFUNG));

        final AntragPruefergebnis antragPruefergebnis1 = new AntragPruefergebnis();
        antragPruefergebnis1.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis1.setRegelName(RegelName.REGEL_STAATSANGEHOERIGKEIT);
        antragPruefergebnis1.setBegruendung("Fehler");
        antragPruefergebnis1.setPrioritaet(5L);
        antrag.addAntragPruefergebnis(antragPruefergebnis1);

        final AntragPruefergebnis antragPruefergebnis2 = new AntragPruefergebnis();
        antragPruefergebnis2.setErgebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);
        antragPruefergebnis2.setRegelName(RegelName.REGEL_WARTEZEITPRUEFUNG);
        antragPruefergebnis2.setBegruendung("Fehler");
        antragPruefergebnis2.setPrioritaet(3L);
        antrag.addAntragPruefergebnis(antragPruefergebnis2);

        antragRepository.merge(antrag);

        createVerarbeitungsstatus(antrag.getUuid());

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test Create Statistik Ablehnung Status Wrong.
     */
    @Test
    @Named("Ablehnung_StatusWrong")
    @Transactional
    void createStatistikAblehnungStatusWrong() {
        drvMandant.setInScope("70");
        stubMappingBescheid();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN, RegelName.REGEL_WARTEZEITPRUEFUNG));
        antragRepository.persist(antrag);

        assertDoesNotThrow(() -> statistikService.createStatistik(antrag, false));

        wireMockServer.removeStubMapping(stubMappingBescheid);
    }

    /**
     * Test Create Statistik Antragserfassung.
     */
    @Test
    @Named("Antragserfassung")
    @Transactional
    void createStatistikAntragserfassung() {
        drvMandant.setInScope("17");
        stubMappingAntragserfassung = WireMockStub.stubForStatistik(StatistikTyp.ANTRAGSERFASSUNG);

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.persist(antrag);

        Assertions.assertDoesNotThrow(() -> statistikService.createStatistikAntragserfassung(antrag));

        antragRepository.findByUuid(antrag.getUuid());
        assertEquals(0, antrag.getMsnr());
        assertEquals(0, antrag.getAtad());

        wireMockServer.removeStubMapping(stubMappingAntragserfassung);
    }

    /**
     * Test prüft, dass eine StatistikException geworfen wird, wenn ein Antrag ohne Verarbeitungsstatus erstellt wird (für eine
     * Antragserfassungs Statistik).
     */
    @Test
    @Named("AntragserfassungStatusWrong")
    @Transactional
    void createStatistikAntragserfassungStatusWrong() {
        drvMandant.setInScope("70");
        stubMappingAntragserfassungNoContent();

        final Antrag antrag = createAntrag();
        antragRepository.merge(antrag);
        // Wieder zurück, wenn Statistik Fehlerbehandlung aktiv
        assertThrows(
            StatistikException.class,
            () -> statistikService.createStatistikAntragserfassung(antrag));

        wireMockServer.removeStubMapping(stubMappingAntragserfassung);
    }

    /**
     * Test prüft, dass eine Exception geworfen wird, wenn der Statistik Webservice nicht verfügbar ist.
     */
    @Test
    @Named("Web-Service nicht aktiv (Bewilligung)")
    @Transactional
    void createStatistikBewilligungWebserviceInaktiv() {
        drvMandant.setInScope("70");
        wireMockServer.stop();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);

        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));

        installWiremockServer();

    }

    /**
     * Test prüft, dass eine Exception geworfen wird, wenn der Statistik Webservice nicht verfügbar ist.
     */
    @Test
    @Named("Web-Service nicht aktiv (Ablehnung")
    @Transactional
    void createStatistikAblehnungWebserviceInaktiv() {
        drvMandant.setInScope("70");
        wireMockServer.stop();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(
            createdRegel(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN, RegelName.REGEL_WARTEZEITPRUEFUNG));
        antragRepository.merge(antrag);

        assertThrows(StatistikException.class,
            () -> statistikService.createStatistik(antrag, false));

        installWiremockServer();
    }

    /**
     * Test prüft, dass eine Exception geworfen wird, wenn der Statistik Webservice nicht verfügbar ist.
     */
    @Test
    @Named("Web-Service nicht aktiv (Antragsserfassung)")
    @Transactional
    void createStatistikAntragsserfassungWebserviceInaktiv() {
        drvMandant.setInScope("70");
        wireMockServer.stop();

        final Antrag antrag = createAntrag();
        antrag.addAntragPruefergebnis(createdRegel(PruefErgebnis.ERFUELLT, null));
        antragRepository.merge(antrag);
        // Wieder zurück, wenn Statistik Fehlerbehandlung aktiv
        // assertThrows(StatistikException.class,
        assertThrows(StatistikException.class,
            () -> statistikService.createStatistikAntragserfassung(antrag));

        installWiremockServer();
    }

    private AntragPruefergebnis createdRegel(final PruefErgebnis pruefergebnis, final RegelName regelName) {
        final AntragPruefergebnis antragPruefergebnis = new AntragPruefergebnis();
        antragPruefergebnis.setErgebnis(pruefergebnis);
        antragPruefergebnis.setPrioritaet(2L);

        antragPruefergebnis.setRegelName(regelName);

        return antragPruefergebnis;
    }

    private Antrag createAntrag() {
        return createAntrag(AntragStatus.STATISTIK_ERFASST);
    }

    private Antrag createAntrag(final AntragStatus status) {
        final Antrag antrag = new Antrag();
        antrag.setKtan("70");
        antrag.setVsnr("2109356D484");
        antrag.setAntragsDatum(LocalDate.of(2024, 7, 9));
        antrag.setEingangsdatum(LocalDate.of(2024, 7, 9).plusDays(1));
        antrag.setBescheiddatum(LocalDate.of(2024, 7, 9).plusDays(7));

        antrag.setAntragsart(AntragsArt.PAPIERANTRAG);
        antrag.setMsnr(12);
        antrag.setAtad(1234);

        final Angebot angebotStart = createStartAngebot();

        final Angebot angebotTraining = createAngebotTraining();

        final Angebot angebotAuffrischung = createAngebotAuffrischung();

        final RehaEinrichtung rehaEinrichtungStart = new RehaEinrichtung();
        rehaEinrichtungStart.setResc("A12345");
        rehaEinrichtungStart.setAngebote(List.of(angebotStart));

        final RehaEinrichtung rehaEinrichtungTraining = new RehaEinrichtung();
        rehaEinrichtungTraining.setResc("B12345");
        rehaEinrichtungTraining.setAngebote(List.of(angebotTraining));

        final RehaEinrichtung rehaEinrichtungAuffrischung = new RehaEinrichtung();
        rehaEinrichtungAuffrischung.setResc("C12345");
        rehaEinrichtungAuffrischung.setAngebote(List.of(angebotAuffrischung));

        antrag.setEinrichtungStartObjekt(rehaEinrichtungStart);
        antrag.setEinrichtungTrainingObjekt(rehaEinrichtungTraining);
        antrag.setEinrichtungAufObjekt(rehaEinrichtungAuffrischung);

        antrag.setStatus(status);
        antragRepository.merge(antrag);

        final Stammdaten stammdaten = new Stammdaten();

        stammdaten.setVorname("Stan");
        stammdaten.setNachname("Marsh");
        stammdaten.setVsnr("48210470M496");
        stammdaten.setPlz("38102");
        stammdaten.setStaatsangehoerigkeit("Deutsch");
        stammdaten.setGeburtsland("000");
        stammdaten.setGeburtsdatum(LocalDate.of(1970, 4, 21));
        stammdaten.setGeburtsort("Bernburg (Saale)");
        stammdaten.setStrasse("Kurt-Schumacher-Str.");
        stammdaten.setHausnummer("20");
        stammdaten.setWohnort("Braunschweig");
        stammdaten.setGeschlecht(StammdatenDto.GeschlechtEnum.W);
        stammdaten.setKtan("70");
        antrag.getVersichertenStammdaten().add(stammdaten);
        antragRepository.merge(antrag);
        antragRepository.flush();
        return antragRepository.findByUuid(antrag.getUuid()).orElseThrow();
    }

    private void createVerarbeitungsstatus(final UUID antragId) {

        final Verarbeitungsstatus verarbeitungsstatus = new Verarbeitungsstatus();
        verarbeitungsstatus.setAntragId(antragId);
        verarbeitungsstatus.setArt(Art.BEWILLIGUNG);

        verarbeitungsstatusRepository.persist(verarbeitungsstatus);

    }

    private void stubMappingAntragserfassungNoContent() {

        stubMappingAntragserfassung = stubFor(post(urlEqualTo("/statistik/antragserfassung"))
            .willReturn(aResponse().withStatus(Status.NO_CONTENT.getStatusCode())));
    }

    @SneakyThrows
    private void stubMappingBescheid() {
        stubMappingBescheid = WireMockStub.stubForStatistik(StatistikTyp.BESCHEIDDATEN);
    }

    private void stubMappingBescheidStatusCode500() {
        stubMappingBescheid = stubFor(post(urlEqualTo("/statistik/bescheid"))
            .willReturn(aResponse().withStatus(Status.INTERNAL_SERVER_ERROR.getStatusCode())));
    }

    /**
     * Erzeugt neue Vorgangsid (14Stellig) Prefix + fortlaufendeNummer + Suffix.
     *
     * @return vorgangsID 14stellige VorgangsID
     */
    private String generiereNeueVogID() {
        iVorgangsnummer++;
        return "V24" + String.format("%07d", iVorgangsnummer) + "RV32";
    }

    private Angebot createStartAngebot() {
        final Angebot angebotStart = new Angebot();
        angebotStart.setPhase(STARTPHASE);
        angebotStart.setDauer(3);
        angebotStart.setDurchfuehrungsart(DurchfuehrungsArt.STATIONAER.getBezeichnung());
        return angebotStart;
    }

    private Angebot createAngebotTraining() {
        final Angebot angebotTraining = new Angebot();
        angebotTraining.setPhase(TRAININGSPHASE);
        angebotTraining.setDauer(5);
        angebotTraining.setDurchfuehrungsart(DurchfuehrungsArt.AMBULANT.getBezeichnung());
        return angebotTraining;
    }

    private Angebot createAngebotAuffrischung() {
        final Angebot angebotAuffrischung = new Angebot();
        angebotAuffrischung.setPhase(AUFFRISCHUNGSPHASE);
        angebotAuffrischung.setDauer(1);
        angebotAuffrischung
            .setDurchfuehrungsart(DurchfuehrungsArt.GANZTAEGIG_AMBULANT.getBezeichnung());
        return angebotAuffrischung;
    }

}
