drop sequence antrag_seq;
drop sequence einrichtung_anschrift_seq;
drop sequence kontoinformation_seq;
drop sequence angebot_seq;
drop sequence pruefergebnis_seq;
drop sequence regel_seq;
drop sequence versicherten_stammdaten_seq;
drop sequence aufgabe_seq;

drop database rvfit;
