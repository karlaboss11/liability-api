package de.deutscherv.rvsm.fa.fit.cronlock;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Repository Cronlock.
 */
@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class CronlockRepository {
    private final EntityManager entityManager;

    /**
     * Laeschen aller Cronlocks mit einem bestimmten Cronname.
     * @param cronname Cronlocks mit diesem Cronnamen werden geloescht.
     * @return Anzahl der geloeschten Cronlocks
     */
    @RequiresMandant
    @Transactional
    public int deleteByCronname(final String cronname) {
        return entityManager.createNativeQuery("delete from Cronlock where cronname like :cronname")
                .setParameter("cronname", cronname)
                .executeUpdate();
    }

    /**
     * Löschen aller Cronlocks.
     */
    @RequiresMandant
    @Transactional
    public void deleteAll() {
        entityManager.createNativeQuery("delete from Cronlock")
                .executeUpdate();
    }

    /**
     * Festschreiben aller Aenderungen.
     */
    @RequiresMandant
    @Transactional
    public void flush() {
        entityManager.flush();
    }

    /**
     * Persistieren von Cronlock.
     * @param cronlock betroffenes Cronlock
     */
    @RequiresMandant
    @Transactional
    public void persist(final Cronlock cronlock) {
        entityManager.persist(cronlock);
    }
}
