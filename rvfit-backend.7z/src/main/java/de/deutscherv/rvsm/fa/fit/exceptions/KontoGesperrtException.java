package de.deutscherv.rvsm.fa.fit.exceptions;

/**
 * Konto-gesperrt Exception.
 */
public class KontoGesperrtException extends RvfitException {

    /**
     * Konstruktor.
     * @param vsnr Versicherungsnr.
     * @param ktan KTAN
     * @param cause Grund der zur Anlage dieser Exception gefuehrt hat
     */
    public KontoGesperrtException(final String vsnr, final String ktan, final Throwable cause) {
        super(String.format("Das Konto ist gesperrt! KTAN [%s], VSNR [%s].", ktan, vsnr), cause);
    }

    /**
     * Konstruktor.
     * @param vsnr Versicherungsnr.
     * @param ktan KTAN
     */
    public KontoGesperrtException(final String vsnr, final String ktan) {
        super(String.format("Das Konto ist gesperrt! KTAN [%s], VSNR [%s].", ktan, vsnr));
    }
}
