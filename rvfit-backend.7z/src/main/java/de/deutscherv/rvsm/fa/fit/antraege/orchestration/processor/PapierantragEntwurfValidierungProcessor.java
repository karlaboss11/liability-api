package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierantragValidierung;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Ruft {@link PapierantragValidierung} auf um einen eingehenden Papierantragsentwurf zu validieren.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragEntwurfValidierungProcessor implements Processor {
    /**
     * Routennamen zur Validierung eines Papierantragentwurfs.
     */
    public static final String DIRECT_PAPIERANTRAG_ENTWURF_VALIDIERUNG = "direct:papierantragValidierungEntwurf";

    private final PapierantragValidierung papierantragValidierung;

    @Override
    public void process(final Exchange exchange) {
        final PapierantragDto papierantragDto = exchange.getMessage().getBody(PapierantragDto.class);
        LoggingUtils.logProcessorPapierantrag(exchange.getFromRouteId(), getClass().getSimpleName(), papierantragDto);
        papierantragValidierung.validiereEntwurf(papierantragDto);
    }
}
