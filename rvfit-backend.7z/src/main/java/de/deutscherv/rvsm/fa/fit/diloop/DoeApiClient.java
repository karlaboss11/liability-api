package de.deutscherv.rvsm.fa.fit.diloop;

import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragDTO;
import io.quarkus.oidc.token.propagation.AccessToken;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * DoeApiClient.
 */
@ApplicationScoped
@RegisterRestClient(configKey = "dokumentenerzeugung-api")
@AccessToken
@Path("/auftraege")
public interface DoeApiClient {

    /**
     * Sende Auftrag.
     *
     * @param dokumentgenerierungsAuftragDTO zu sendender Auftrag.
     * @param drvMandant                     DRV-Mandant
     * @return Antwort.
     */
    @POST
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    Response sendeAuftrag(@Valid @NotNull DokumentgenerierungsAuftragDTO dokumentgenerierungsAuftragDTO,
        @HeaderParam("drv-mandant")
        @Parameter(description = """
            DRV-Mandant für technische Benutzer.
            Für normale Benutzer wird der Mandant aus dem JWT-Token extrahiert.
            (a.k.a. KTAN - Kontoführende Anstalt).
            """)
        @Pattern(regexp = "\\d{2}$") String drvMandant);

}
