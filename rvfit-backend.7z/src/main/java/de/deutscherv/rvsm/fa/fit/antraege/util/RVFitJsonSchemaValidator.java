package de.deutscherv.rvsm.fa.fit.antraege.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion.VersionFlag;
import com.networknt.schema.ValidationMessage;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import jakarta.enterprise.context.RequestScoped;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;

/**
 * rvFit-Json-Schema Validator.
 */
@RequestScoped
@Slf4j
public class RVFitJsonSchemaValidator {

    private final Map<String, JsonSchema> jsonSchemaMap = new HashMap<>();

    /**
     * Checkt wenn ein Objekt gültig ist.
     *
     * @param restServiceClient Enum für den Namen des RestClients
     * @param obj Das Objekt
     * @return true, wenn das Objekt gültig ist
     */
    public boolean isValid(final RestServiceClient restServiceClient, final Object obj) {
        if (Objects.isNull(obj) || obj instanceof List && ((List<?>) obj).isEmpty()) {
            return false;
        }
        if (obj instanceof List) {
            return ((List<?>) obj).stream().allMatch(o -> isValidItem(restServiceClient, o));
        } else {
            return isValidItem(restServiceClient, obj);
        }
    }

    private boolean isValidItem(final RestServiceClient restServiceClient, final Object obj) {
        try {
            final String path = getPath(restServiceClient, obj);
            final ObjectMapper objectMapper = createObjectMapper(restServiceClient);

            final String jsonString = objectMapper.writeValueAsString(obj);

            final JsonSchema jsonSchema = jsonSchemaMap.computeIfAbsent(path, p ->
                    JsonSchemaFactory.getInstance(VersionFlag.V202012)
                            .getSchema(getClass().getClassLoader().getResourceAsStream(p)));

            final Set<ValidationMessage> result = jsonSchema.validate(objectMapper.readTree(jsonString));
            if (result.isEmpty()) {
                return true;
            }
            result.forEach(validationMessage -> LOG.atError().addArgument(validationMessage.getMessage())
                    .log("Json validierung schlägt fehl: [{}]"));
            return false;
        } catch (final JsonProcessingException e) {
            MDCUtils.setFailed();
            LOG.atError().setCause(e).log("Bei der Json Validierung ist ein Fehler aufgetreten");
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private static ObjectMapper createObjectMapper(final RestServiceClient restServiceClient) {
        final ObjectMapper objectMapper = new ObjectMapper();
        if (restServiceClient.equals(RestServiceClient.STATISTIK)) {
            objectMapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
        }
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return objectMapper;
    }

    private static String getPath(final RestServiceClient restServiceClient, final Object obj) {
        final StringBuilder path = new StringBuilder();
        if (restServiceClient.equals(RestServiceClient.KONTOINFORMATION)
                || restServiceClient.equals(RestServiceClient.SELBSTMELDEPORTAL)) {
            path.append("/jsonschemas/");
        }
        path.append(obj.getClass().getName().replace(".", "/"));
        path.append(".json");
        return path.toString();
    }
}
