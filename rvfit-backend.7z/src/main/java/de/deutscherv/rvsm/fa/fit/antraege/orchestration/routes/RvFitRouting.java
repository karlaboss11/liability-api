package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import lombok.experimental.UtilityClass;

import java.util.Map;
import java.util.Set;

import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.AUFGABE_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.AUTOMATISCH;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.BESCHEID_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.DOPPELVERGABE_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.DOPPELVERGABE_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.DOPPELVERGABE_PRUEFUNG_OK;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.ENTWURF;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.KONTOINFORMATION_ABGEFRAGT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.PAPIERANTRAG_GESPEICHERT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.RVPUR_AUFGABE_GESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIK_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIK_ERFASST;
import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.VORGANG_ERZEUGT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.EingangEAntragRoutes.DIRECT_INIT_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_CHECK_DOPPELVERGABE;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERFASSE_STATISTIK;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_BESCHEID;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERSTELLE_VORGANG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_GET_METADATA;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_OHNE_BESCHEID_ROUTING;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PRUEFE_REGELN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SCHLIESSE_OFFENE_AUFGABEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB;

/**
 * Stellt den Zusammenhang zwischen dem {@link AntragStatus} und der weiteren Verarbeitung her.
 */
@UtilityClass
public final class RvFitRouting {

    private static final Map<AntragStatus, String> STATUS_ZU_ROUTE_MAP;

    /**
     * Alle AntragStatus, für die der dynamische Router keine weitere Routen zur automatischen Weiterverarbeitung hat.
     */
    private static final Set<AntragStatus> STATUS_OHNE_NACHFOLGE_ROUTE = Set.of(
            PERSONENDATEN_AUFGABE_ERSTELLT,
            ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
            DOPPELVERGABE_AUFGABE_ERSTELLT,
            BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
            STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT,
            STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT,
            STATISTIK_ABGESCHLOSSEN
    );

    static {
        STATUS_ZU_ROUTE_MAP = Map.ofEntries(
                Map.entry(ENTWURF, DIRECT_ERSTELLE_VORGANG),
                Map.entry(VORGANG_ERZEUGT, DIRECT_GET_METADATA),
                Map.entry(KONTOINFORMATION_ABGEFRAGT, DIRECT_ERFASSE_STATISTIK),
                Map.entry(STATISTIK_ERFASST, DIRECT_CHECK_DOPPELVERGABE),
                Map.entry(DOPPELVERGABE_PRUEFUNG_OK, DIRECT_PRUEFE_REGELN),
                Map.entry(PAPIERANTRAG_GESPEICHERT, DIRECT_ERFASSE_STATISTIK),
                Map.entry(RVPUR_AUFGABE_GESCHLOSSEN, DIRECT_OHNE_BESCHEID_ROUTING),
                Map.entry(AUTOMATISCH, DIRECT_ERSTELLE_BESCHEID),
                Map.entry(AUFGABE_ABGESCHLOSSEN, DIRECT_SCHLIESSE_STATISTIK_AB),

                Map.entry(STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN, DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE),
                Map.entry(STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN, DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE),
                Map.entry(STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN, DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE),
                Map.entry(KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN, DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE),

                Map.entry(BESCHEID_ABGESCHLOSSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN),
                Map.entry(STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN),
                Map.entry(STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN),
                Map.entry(STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN),
                Map.entry(KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN),
                Map.entry(DOPPELVERGABE_AUFGABE_SCHLIESSEN, DIRECT_SCHLIESSE_OFFENE_AUFGABEN)
        );
    }

    /**
     * Gibt anhand des {@link AntragStatus} die Route zur Weiterverarbeitung zurück.
     * @param antrag der zu verarbeitende Antrag
     * @return die Camel Route welche für den nächsten Prozesschritt nötig ist
     */
    public static String routingSlip(final Antrag antrag) {
        final var status = antrag.getStatus();
        if (status == null) {
            return DIRECT_INIT_EANTRAG;
        }

        if (STATUS_OHNE_NACHFOLGE_ROUTE.contains(status)) {
            return null;
        }

        return STATUS_ZU_ROUTE_MAP.getOrDefault(status, null);
    }
}
