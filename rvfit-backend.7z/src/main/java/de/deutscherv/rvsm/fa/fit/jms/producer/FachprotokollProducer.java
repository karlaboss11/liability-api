package de.deutscherv.rvsm.fa.fit.jms.producer;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.vom.adapter.mq.common.DrvJmsHeaders;
import de.deutscherv.rvsm.fa.fit.log.MDCKey;
import de.deutscherv.rvsm.qs.fap.async.model.FachereignisDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidationException;
import jakarta.validation.ValidatorFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.ProducerTemplate;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.slf4j.MDC;

import static de.deutscherv.rvsm.fa.fit.jms.FapRoutes.DIRECT_SENDE_FACHLICHES_PROTOKOLL;
import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_KTAN;
import static de.deutscherv.rvsm.fa.fit.util.MessagingUtils.getTraceparent;

/**
 * Producer fuer das Anlegen der Fachereignisse.
 *
 * @author v215169
 */
@Slf4j
@ApplicationScoped
public class FachprotokollProducer {

    private static final String HEADER_TRACEPARENT = "traceparent";
    private static final String HEADER_JWT = "auth_token";
    private final ProducerTemplate producerTemplate;
    private final String apiVersion;
    private final String absender;
    private final Jsonb jsonbMapper = JsonbBuilder.create();
    private final ValidatorFactory valFactory = Validation.buildDefaultValidatorFactory();
    private final boolean fapEnabled;
    private final JsonWebToken jsonWebToken;
    private final DrvMandant drvMandant;

    /**
     * Konstruktor.
     *
     * @param producerTemplate Producer-Template
     * @param fapEnabled       true wenn Fachprotokoll enabled ist.
     * @param apiVersion       API-Version
     * @param absender         Absender
     * @param jsonWebToken     JSON-Web-Tocken
     * @param drvMandant       DRV-Mandant
     */
    @Inject
    public FachprotokollProducer(final ProducerTemplate producerTemplate,
            @ConfigProperty(name = "quarkus.artemis.messaging.enabled", defaultValue = "true") boolean fapEnabled,
            @ConfigProperty(name = "fap.asyncapi.version") final String apiVersion,
            @ConfigProperty(name = "quarkus.http.header.\"absender\"") final String absender,
            final JsonWebToken jsonWebToken,
            final DrvMandant drvMandant) {
        this.producerTemplate = producerTemplate;
        this.fapEnabled = fapEnabled;
        this.apiVersion = apiVersion;
        this.absender = absender;
        this.jsonWebToken = jsonWebToken;
        this.drvMandant = drvMandant;
    }

    /**
     * Erstellen eines Fachereignisses.
     *
     * @param fachereignisDTO Fachereignis
     * @param jwt             Jwt-Token
     */
    public void createFachereignis(final FachereignisDTO fachereignisDTO, final JsonWebToken jwt) {
        validateFachereignis(fachereignisDTO);
        final String jsonBody = jsonbMapper.toJson(fachereignisDTO);
        LOG.atInfo()
                .addArgument(GET_KTAN.apply(jwt, drvMandant))
                .addArgument(jsonBody)
                .log("Fachereignis Event: KTAN [{}] Message[{}]");
        sendMessage(jsonBody, jwt);
    }

    /**
     * Validiert das übergebene {@link FachereignisDTO} anhand der Definition im DTO.
     *
     * @param fachereignisDTO das zu validierende fachereignisDTO.
     * @throws ValidationException inklusive der verstöße.
     */
    private void validateFachereignis(final FachereignisDTO fachereignisDTO) {
        final Set<ConstraintViolation<FachereignisDTO>> violations =
                valFactory.getValidator().validate(fachereignisDTO);
        if (!violations.isEmpty()) {
            LOG.atWarn()
                    .addArgument(fachereignisDTO)
                    .addArgument(violations)
                    .log("Fehler bei der Validierung des Fachereignisses [{}], Violaton [{}]");
            throw new ValidationException(violations.toString());
        }
    }

    /**
     * Sendet eine Message in die Queue fürs fachliche Protokoll.
     *
     * @param body der Body der Message
     * @param jwt der JsonWebToken
     */
    private void sendMessage(final String body, final JsonWebToken jwt) {
        if(!fapEnabled) {
            return;
        }
        LOG.atDebug().log("Erstelle Jms Nachricht fuer Fachereignis");

        final Map<String, Object> headers = new HashMap<>(Map.of(
                DrvJmsHeaders.MANDANT, GET_KTAN.apply(jsonWebToken, drvMandant),
                HEADER_TRACEPARENT, getTraceparent(),
                DrvJmsHeaders.API_VERSION, apiVersion,
                DrvJmsHeaders.ABSENDER, absender,
                "JMSMessageID", String.format("ID:%s", UUID.randomUUID()),
                "JMSCorrelationID", Optional.ofNullable(MDC.get(MDCKey.HEADER_CORRELATION_ID.valueOf()))
                        .orElse("")
        ));
        if(jwt != null) {
            headers.put(HEADER_JWT, jwt.getRawToken());
        }

        producerTemplate.sendBodyAndHeaders(DIRECT_SENDE_FACHLICHES_PROTOKOLL, body, headers);
    }

}
