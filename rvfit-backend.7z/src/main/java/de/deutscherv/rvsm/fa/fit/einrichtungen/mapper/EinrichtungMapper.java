package de.deutscherv.rvsm.fa.fit.einrichtungen.mapper;

import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungAutovervollstaendigungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.ArrayList;
import java.util.List;

/**
 * EinrichtungMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR,
        uses = { EinrichtungAnschriftMapper.class, AngebotMapper.class })
public interface EinrichtungMapper {

    /**
     * Mappt eine Einruchtung in ein DTO.
     *
     * @param entity die Einrichtung
     * @return das DTO
     */
    @Mapping(source = "angebote", target = "phasen", qualifiedByName = "toPhasenDto")
    @Mapping(source = "smpEinrichtungsId", target = "selbstmeldeportalId")
    @Mapping(source = "resc", target = "aresc")
    @Mapping(target = "removePhasenItem", ignore = true)
    @Mapping(target = "id", source = "uuid")
    RehaEinrichtungDto toDto(RehaEinrichtung entity);

    /**
     * Mappt Angebote in DTOs.
     *
     * @param angebote die Angebote
     * @return die DTOs
     */
    @Named("toPhasenDto")
    List<PhaseDto> toPhasenDto(List<Angebot> angebote);

    /**
     * Mappt ein Einrichtung DTO in eine Einrichtung.
     *
     * @param dto das DTO
     * @return die Einrichtung
     */
    @Mapping(source = "phasen", target = "angebote", qualifiedByName = "toAngebote")
    @Mapping(source = "id", target = "uuid")
    @Mapping(target = "distanz", ignore = true)
    @Mapping(target = "distanzVersicherter", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created",ignore=true)
    @Mapping(target = "lastModified",ignore=true)
    @InheritInverseConfiguration
    RehaEinrichtung toEntity(RehaEinrichtungDto dto);

    /**
     * Mappt DTOs in Angebote.
     *
     * @param phasen die Phasen
     * @return die angebote
     */
    @Named("toAngebote")
    List<Angebot> toAngebote(List<PhaseDto> phasen);

    /**
     * Mappt Angebote in Autovervollstaendigung DTOs.
     *
     * @param angebote die Angebote
     * @return die DTOs
     */
    @Named("toAutovervollstaendigungPhasenDto")
    static List<String> toAutovervollstaendigungPhasenDto(final List<Angebot> angebote) {
        final List<String> phasen = new ArrayList<>();
        angebote.forEach(angebot -> {
            if (!phasen.contains(angebot.getPhase())) {
                phasen.add(angebot.getPhase());
            }
        });
        return phasen;
    }

    /**
     * Mappt eine Einruchtung in ein Autovervollstaendigung DTO.
     *
     * @param entity die Einrichtung
     * @return das DTO
     */
    @Mapping(source = "angebote", target = "phasen", qualifiedByName = "toAutovervollstaendigungPhasenDto")
    @Mapping(source = "smpEinrichtungsId", target = "id")
    @Mapping(source = "name", target = "anbietername")
    @Mapping(target = "removePhasenItem", ignore = true)
    RehaEinrichtungAutovervollstaendigungDto toAutovervollstaendigungDto(RehaEinrichtung entity);

    /**
     * Mappt einen eAntrag in eine Einrichtung.
     *
     * @param antragsdaten der eAntrag
     * @return die Einrichtung
     */
    @Mapping(target = "adresse", ignore = true)
    @Mapping(target = "angebote", ignore = true)
    @Mapping(target = "distanz", ignore = true)
    @Mapping(target = "distanzVersicherter", ignore = true)
    @Mapping(target = "email", ignore = true)
    @Mapping(target = "uuid", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "name", ignore = true)
    @Mapping(target = "postanschrift", ignore = true)
    @Mapping(target = "resc", ignore = true)
    @Mapping(target = "smpEinrichtungsId", ignore = true)
    @Mapping(target = "telefonnummer", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    RehaEinrichtung antragsdatenToEntity(Antragsdaten antragsdaten);

}
