package de.deutscherv.rvsm.fa.fit.log.model;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

/**
 * Entity RvfitLog.
 */
@Entity
@Table(name = "rvfitlog")
@Cacheable
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RvfitLog {

    /**
     * Quelle fuer die Log.
     */
    public enum QUELLE {
        /**
         * Quelle ANTRAG.
         */
        ANTRAG,
        /**
         * Quelle EINRICHTUNG.
         */
        EINRICHTUNG,
        /**
         * Quelle PRUEFUNG.
         */
        PRUEFUNG,
        /**
         * Quelle BESCHEID.
         */
        BESCHEID,
        /**
         * Quelle AUFGABE.
         */
        AUFGABE
    }

    /**
     * Aktion fuer die Log.
     */
    public enum AKTION {
        /**
         * Aktion CREATE.
         */
        CREATE,
        /**
         * Aktion UPDATE.
         */
        UPDATE,
        /**
         * Aktion DELETE.
         */
        DELETE,
        /**
         * Aktion ASSIGN.
         */
        ASSIGN,
        /**
         * Aktion COMPLETE.
         */
        COMPLETE
    }

    /**
     * ID des Eintrags.
     */
    @Id
    @SequenceGenerator(name = "rvfitLogSequence", sequenceName = "rvfitlog_seq", allocationSize = 1, initialValue = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rvfitLogSequence")
    private Long id;

    @Column
    private QUELLE quelle;
    @Column
    private AKTION aktion;
    @Column
    private String daten;
    @Column
    private String benutzer;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;
}
