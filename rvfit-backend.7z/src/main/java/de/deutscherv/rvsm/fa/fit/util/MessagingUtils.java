package de.deutscherv.rvsm.fa.fit.util;

import io.opentelemetry.api.trace.Span;

/**
 * Utility-Klasse für asynchrone Kommunikation.
 */
public class MessagingUtils {

    private MessagingUtils() {}

    /**
     * OpenTelemetry Trace-ID, Span-ID, Parent-Span-ID; Feldname nach W3C TR Trace Context.
     *
     * @return den Traceparent für eine Nachricht.
     */
    public static String getTraceparent() {
        Span span = Span.current();
        String spanId = span.getSpanContext().getSpanId();
        String traceId = span.getSpanContext().getTraceId();
        return String.format("00-%s-%s-01", traceId, spanId);
    }

    /**
     * Erstellt den Namen einer JMS-Route für die übergebene Queue.
     *
     * @param queue die Adresse der Queue
     * @return den vollständigen Namen der Route
     */
    public static String getJmsRouteForTextMessageType(final String queue) {
        return String.format("xajms:queue:%s?jmsMessageType=Text", queue);
    }
}
