package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.StatistikBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor, welcher eine Statistik zur erfolgreichen Antragsannahme erstellt.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class StatistikErfassungsProcessor implements Processor {

    /**
     * Routenname zum Erfassen der Statistikdaten eines Papierantrags.
     */
    public static final String DIRECT_ERFASSE_STATISTIK_PAPIERANTRAG = "direct:erfasseStatistikPapierantrag";
    private static final String PERSISTIERE_ANTRAG_IN_DB = "Persistiere Antrag nach Statistikerfassung in DB [{}] ";

    private final StatistikService statistikService;
    private final AntragRepository antragRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);

        var erfassungErfolgreichOderException = erfasseStatistik(antrag);

        if (erfassungErfolgreichOderException.erfolgreich()) {
            if (antrag.getStatus() == AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT) {
                antrag.setStatus(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN);
            } else {
                antrag.setStatus(AntragStatus.STATISTIK_ERFASST);
            }
        } else {
            if (erfassungErfolgreichOderException.exception() instanceof StatistikBestandsFehlerException e) {
                if (antrag.getStatus() != AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT) {
                    antrag.setStatus(AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN);
                }
                exchange.getMessage().setHeader(RVFitCamelHeader.STATISTIK_BESTANDSFEHLER, e);
            } else {
                throw erfassungErfolgreichOderException.exception();
            }
        }
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        LOG.atDebug().addArgument(antrag).log(PERSISTIERE_ANTRAG_IN_DB);
        exchange.getMessage().setBody(antrag);
    }

    private ErfassungErfolgreichOderException erfasseStatistik(final Antrag antrag) {
        try {
            boolean erfolgreich = statistikService.createStatistikAntragserfassung(antrag);
            return new ErfassungErfolgreichOderException(erfolgreich, null);
        } catch (final Exception e) {
            return new ErfassungErfolgreichOderException(false, e);
        }
    }

    /**
     * Record mit dem Ergebnis der Statistik Antragerfassung.
     * @param erfolgreich true wenn erfolrreich
     * @param exception Evtl. aufgetretene Exception
     */
    private record ErfassungErfolgreichOderException(boolean erfolgreich, Exception exception) {
    }
}
