package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * Exception, die bei unvollständigen Stammdaten geworfen wird.
 */
public class UnvollstaendigeStammdatenException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Erzeugt ein Exception-Objekt.
     *
     * @param message eine detaillierte Beschreibung des Fehlers
     */
    public UnvollstaendigeStammdatenException(final String message) {
        super(message);
    }

}
