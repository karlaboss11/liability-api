package de.deutscherv.rvsm.fa.fit.verarbeitung.mapper;

import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto.StatusEnum;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

/**
 * VerarbeitunStatusMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface VerarbeitungStatusMapper {

    /**
     * Mappt den Status des Bescheids.
     *
     * @param status des Bescheids
     * @return der Status des Bescheids für das Frontend
     */
    @ValueMapping(source = "VERSANDT", target = "VERSAND")
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
    StatusEnum toDto(VerarbeitungStatus status);

    /**
     * Mappt den Status des Bescheids aus dem Frontend.
     *
     * @param dto Status des Bescheids aus dem Frontend
     * @return der Status des Bescheids
     */
    @InheritInverseConfiguration
    VerarbeitungStatus toEntity(StatusEnum dto);

}
