package de.deutscherv.rvsm.fa.fit.diloop.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentenErzeugungConfig;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.ValidationException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

import static de.deutscherv.rvsm.fa.fit.util.DRVStringFormat.MSNR;
import static java.util.Objects.isNull;

/**
 * Implementierung des DokumentErzeugungsService für Ablehnungsbescheide.
 */
@Slf4j
@ApplicationScoped
public final class AblehnungsDokumentErzeugungsService extends DokumentErzeugungsService {

    private final DokumentenErzeugungConfig dokumentenErzeugungConfig;

    /**
     * Erzeugung von DokumentgenerierungsAuftragDTOs.
     *
     * @param dokumentenErzeugungConfig Zugewiesenes DokumentErzeugungConfig
     */
    public AblehnungsDokumentErzeugungsService(final DokumentenErzeugungConfig dokumentenErzeugungConfig) {
        this.dokumentenErzeugungConfig = dokumentenErzeugungConfig;
    }

    @Override
    protected UUID getTemplateId(DokumentenErstellungsDaten dokumentenErstellungsDaten) {
        return UUID.fromString(dokumentenErzeugungConfig.getVorlagenIdBescheidAblehnung());
    }

    @Override
    protected AllgemeineDokumentenDaten getAllgemeineDokumentenDaten(@Nonnull final DokumentenErstellungsDaten daten) {
        final KontoDto konto = daten.konto();
        final Antrag antrag = daten.antrag();
        return AllgemeineDokumentenDaten.builder()
                .fall(konto.getVersicherungsnummer())
                .ktan(konto.getKtan())
                .aigr(getAigr(antrag))
                .doReview(!daten.dunkelVerarbeitung())
                .isBatchPrint(false)
                .build();
    }

    @Override
    protected Map<String, String> getVariablen(@Nonnull final DokumentenErstellungsDaten daten) {
        final Map<String, String> variablen = new HashMap<>();
        variablen.put("rvEvolution", "1");
        variablen.putAll(getVariablenZurBefuellungDerKonkretenVorlage(daten));
        variablen.putAll(getVariablenZurKommunikationMitRvPur(daten));
        return variablen;
    }

    /**
     * Daten für die Kommunikation mit rvPuR.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return Variablen für die Kommunikation mit rvPur
     */
    private Map<String, String> getVariablenZurKommunikationMitRvPur(@Nonnull final DokumentenErstellungsDaten daten) {
        final Antrag antrag = daten.antrag();
        final Map<String, String> bescheid = new HashMap<>();
        bescheid.put("vorgangsID", antrag.getVorgangskennung());
        bescheid.put("terminUebergeben", "1");
        bescheid.put("terminDatum", LocalDate.now().plusDays(56).toString());
        bescheid.put("terminBemerkung", "Vorgang archivieren");
        bescheid.put("inWiedervorlageSchieben", "0");
        bescheid.put("massnahmeArtNummer", "8".concat(MSNR.format(antrag.getMsnr())));

        return bescheid;
    }

    /**
     * Daten zur Befüllung der konkreten Vorlage.
     *
     * @param daten die Daten zur Dokumentenerstellung
     * @return die Variablen zur Befüllung der konkreten Vorlage
     */
    private Map<String, String> getVariablenZurBefuellungDerKonkretenVorlage(@Nonnull final DokumentenErstellungsDaten daten) {
        final Antrag antrag = daten.antrag();
        final PersonDto versicherter = daten.konto().getPersonen().getFirst();
        final PersonAnschriftDto anschrift = versicherter.getAnschrift();

        final Map<String, String> map = new HashMap<>();
        final String ablehnungsgrund = getAblehnungsgrund(antrag);
        map.put("sv_kk_maschineller_Aufruf", "true");
        map.put("sv_op_G9581_00_Ablehnungsgrund", ablehnungsgrund);
        if (ablehnungsgrund.equals("1")) {
            final LocalDate datumLetzteMassnahme = antrag.getKontoinformationen().getFirst().getMassnahmeRehaKobs();
            map.put("sv_d_G9581_00_vorhergehende_Leistung_End",
                    Optional.ofNullable(datumLetzteMassnahme).map(LocalDate::toString).orElse(null));
        }
        map.put("sv_tm_G9581_00_Freier_Text_Eingabe", daten.variableFelder().get(VariablesFeld.FREITEXT_VERSICHERTER));
        map.put("tm_G9581_00_Ablehnung_Freitext", daten.variableFelder().get(VariablesFeld.FREITEXT_VERSICHERTER));
        map.put("d_G9581_00_Antragsdatum", antrag.getAntragsDatum().toString());
        map.put("USEQ_RBH_11_op_Bekanntg_SGG", "Bekanntgabe");
        if (anschrift.getLaenderschluessel() == null || anschrift.getLaenderschluessel().equals("000")) {
            map.put("USEQ_RBH_22_op_Inland_Ausland_EU", "1");
        } else {
            map.put("USEQ_RBH_22_op_Inland_Ausland_EU", "2");
        }
        return map;
    }

    /**
     * Sucht fuer einen abgelehnten Antrag den wichtigsten Ablehnungsgrund und liefert den entsprechenden Code zurueck.
     *
     * @param antrag Der Antrag, zu dem der Ablehnungsgrund ermittelt werden soll.
     * @return Code für den Ablehnungstext anhand des Pruefrergebnisses
     */
    private String getAblehnungsgrund(final Antrag antrag) {
        final AntragPruefergebnis ergebnis = getWichtigstenAblehnungsgrund(antrag);
        if (isNull(ergebnis)) {
            LOG.atWarn()
                    .addArgument(antrag.getKtan())
                    .addArgument(antrag.getVsnr())
                    .addArgument(antrag.getUuid())
                    .log("Kein Ablehnungsgrund vorhanden. Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new ValidationException("Kein Ablehnungsgrund vorhanden.");
        }

        return switch (ergebnis.getRegelName()) {
            case REGEL_STAATSANGEHOERIGKEIT -> "0";
            case REGEL_MASSNAHME -> "1";
            case REGEL_AKTIVEBESCHAEFTIGUNG, REGEL_ALTERSTEILZEIT -> "2";
            case REGEL_WARTEZEITPRUEFUNG -> "3";
            case REGEL_AUFENTHALT -> "4";
            case REGEL_ANTRAGALTERSRENTE, REGEL_BEZUGALTERSRENTE -> "5";
            case REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT -> "6";
            case REGEL_BEAMTENEIGENSCHAFT_BEZUEGE -> "7";
            default -> "9";
        };
    }

    /**
     * Lese den Ablehnungsgrund mit der höchsten Priorität für einen Antrag aus.
     *
     * @param antrag - der Antrag
     * @return Pruefergebnis des Antrags (AntragPruefergebnis)
     */
    private AntragPruefergebnis getWichtigstenAblehnungsgrund(final Antrag antrag) {
        //Hinweis: wird eine maschinell erstelltes Regelergenis manuell abgeändert, wird hierzu ein 2.Eintrag in die DB geschrieben
        // (Grund warum nicht überschrieben wird ist, dass es wohl zurückgesetzt werden können soll)
        //dadruch kann es sein, dass zu einer Regel 2 Einträge vorhanden sind und man auf das LastModifiedDatum zurückgreifen muss

        final List<AntragPruefergebnis> antragPruefergebnisse
                = Optional.ofNullable(antrag.getAntragPruefergebnisse()).orElse(Collections.emptyList());

        return antragPruefergebnisse.stream()
                // 1. Alle Einträge ohne Regelname rausfiltern
                .filter(pruefergebnis -> Objects.nonNull(pruefergebnis.getRegelName()))
                // 2. Bei Einträgen mit gleichem Regel-Name das neueste "LastModified" nehmen
                .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName))
                .values().stream() // Durch jede Gruppe iterieren
                .map(gruppe -> gruppe.stream()
                        .max(Comparator.comparing(AntragPruefergebnis::getLastModified,
                                Comparator.nullsFirst(Comparator.naturalOrder())))
                        .orElse(null)).filter(Objects::nonNull)
                // 3. Entferne alle "ERFUELLT" und "AUSSTEUERN" Einträge
                .filter(ergebnis -> ergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN
                        || ergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)
                // 4. Sortiere nach Priorität und nimm den mit der geringsten Priorität
                .min(Comparator.comparing(AntragPruefergebnis::getPrioritaet,
                        Comparator.nullsLast(Comparator.naturalOrder()))).orElse(null);

    }
}
