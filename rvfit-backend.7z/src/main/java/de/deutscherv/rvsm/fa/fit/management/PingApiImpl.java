package de.deutscherv.rvsm.fa.fit.management;

import de.deutscherv.rvsm.fa.fit.openapi.api.PingApi;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

/**
 * API zum Pingen.
 */
@Path("/ping")
@SecurityRequirement(name = "keycloak")
@ApplicationScoped
public class PingApiImpl implements PingApi {

    @GET
    @Produces({ "application/json", "application/problem+json" })
    @Override
    public Response ping() {
        return Response.ok().build();
    }
}
