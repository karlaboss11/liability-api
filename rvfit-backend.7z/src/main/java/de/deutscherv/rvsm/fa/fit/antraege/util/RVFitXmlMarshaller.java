package de.deutscherv.rvsm.fa.fit.antraege.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser;
import com.fasterxml.jackson.module.jakarta.xmlbind.JakartaXmlBindAnnotationModule;
import jakarta.enterprise.context.ApplicationScoped;
import javax.xml.stream.XMLInputFactory;

/**
 * RVFitXmlMarshaller.
 */
@ApplicationScoped
public class RVFitXmlMarshaller {

    /**
     * Mappt ein XML in ein Java Objekt.
     *
     * @param <T>         the generic type
     * @param targetClass the target class
     * @param xml         Das XML
     * @return Das Java Objekt
     * @throws JsonProcessingException the json processing exception
     */
    public <T> T unmarshall(final Class<T> targetClass, final String xml) throws JsonProcessingException {
        final JacksonXmlModule jacksonXmlModule = new JacksonXmlModule();
        jacksonXmlModule.setDefaultUseWrapper(false);
        jacksonXmlModule.setXMLTextElementName("value");
        final JakartaXmlBindAnnotationModule module = new JakartaXmlBindAnnotationModule();
        final XmlMapper xmlMapper = new XmlMapper(jacksonXmlModule);
        xmlMapper.registerModule(module);

        /*
         * Sicherheitsfeatures konfigurieren
         */
        xmlMapper.getFactory().getXMLInputFactory().setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        xmlMapper.getFactory().getXMLInputFactory().setProperty(XMLInputFactory.SUPPORT_DTD, false);
        xmlMapper.configure(FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL, true);
        xmlMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        xmlMapper.disable(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
        xmlMapper.disable(MapperFeature.ALLOW_COERCION_OF_SCALARS);

        return xmlMapper.readValue(xml, targetClass);
    }
}
