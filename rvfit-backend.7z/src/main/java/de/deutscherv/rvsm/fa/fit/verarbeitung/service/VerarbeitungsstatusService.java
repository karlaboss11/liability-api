package de.deutscherv.rvsm.fa.fit.verarbeitung.service;

import de.deutscherv.rvsm.fa.fit.verarbeitung.model.VerarbeitungStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.verarbeitung.VerarbeitungsstatusUpdateException;
import de.deutscherv.rvsm.fa.fit.verarbeitung.mapper.VerarbeitungStatusMapper;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.TransactionRequiredException;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * VerarbeitungsstatusService.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class VerarbeitungsstatusService {

    private final VerarbeitungsstatusRepository verarbeitungsstatusRepository;
    private final VerarbeitungStatusMapper verarbeitungStatusMapper;

    /**
     * Schreibt den Verarbeitungsstatus.
     *
     * @param antragUuid         UUID des betroffenen Antrags
     * @param versandErgebnisDto das Versandergebnis
     * @param art                die Verarbeitungsart
     * @return Erstellter Satz Verarbeitungsstatus
     */
    public Verarbeitungsstatus saveVerarbeitungsstatus(final UUID antragUuid,
                                                       final VersandErgebnisDto versandErgebnisDto, final Art art) {
        LOG.atDebug().addArgument(antragUuid).log(
            "Service saveVerarbeitungsstatus: Der Verarbeitungsstatus wird gespeichert. UUID [{}]");

        try {
            final Verarbeitungsstatus verarbeitungsstatus =
                findeOderErstelleNeuenVerarbeitungsstatus(antragUuid);
            verarbeitungsstatus.setLastmodified(LocalDateTime.now());
            verarbeitungsstatus
                .setStatus(verarbeitungStatusMapper.toEntity(versandErgebnisDto.getStatus()));
            verarbeitungsstatus.setAuftragId(versandErgebnisDto.getAuftragId());
            verarbeitungsstatus.setMeldung(versandErgebnisDto.getMeldung());
            verarbeitungsstatus.setArt(art);
            LOG.atDebug().addArgument(verarbeitungsstatus)
                .log("Persistiere Verarbeitungsstatus [{}] in DB");
            verarbeitungsstatusRepository.persistAndFlush(verarbeitungsstatus);

            return verarbeitungsstatus;
        } catch (final IllegalArgumentException | TransactionRequiredException
            | NotFoundException e) {
            LOG.atWarn().addArgument(antragUuid).addArgument(e.getMessage()).log(
                "Fehler beim Sichern des Verarbeitungsstatus. UUID [{}], ExceptionMeldung [{}]");
            throw new VerarbeitungsstatusUpdateException(e);
        }
    }

    /**
     * Schreibt den Verarbeitungsstatus.
     *
     * @param antragUuid UUID des betroffenen Antrags
     * @param art        die Verarbeitungsart
     * @return Erstellter Satz Verarbeitungsstatus
     */
    @Transactional
    public Verarbeitungsstatus saveVerarbeitungsstatusOhneVersand(final UUID antragUuid,
        final Art art) {
        LOG.atDebug().addArgument(antragUuid).log(
            "Service saveVerarbeitungsstatusOhneVersand: Der Verarbeitungsstatus wird gespeichert. UUID [{}]");
        try {
            final Verarbeitungsstatus verarbeitungsstatus =
                findeOderErstelleNeuenVerarbeitungsstatus(antragUuid);
            verarbeitungsstatus.setLastmodified(LocalDateTime.now());
            verarbeitungsstatus.setStatus(VerarbeitungStatus.OHNE_VERSAND_ERLEDIGT);
            verarbeitungsstatus.setArt(art);
            verarbeitungsstatusRepository.persistAndFlush(verarbeitungsstatus);
            return verarbeitungsstatus;
        } catch (final IllegalArgumentException | TransactionRequiredException
            | NotFoundException e) {
            LOG.atWarn().addArgument(antragUuid).addArgument(e.getMessage()).log(
                "Fehler beim Sichern des Verarbeitungsstatus ohne Versand .UUID [{}], ExceptionMeldung [{}]");
            throw new VerarbeitungsstatusUpdateException(e);
        }
    }

    /**
     * Finde oder Erstelle einen neuen Verarbeitungsstatus.
     *
     * @param antragUuid UUID des zu suchenden Verabeitungsstatus
     * @return gefundener oder neu angelegter Verarbeitungsstatu.
     */
    public Verarbeitungsstatus findeOderErstelleNeuenVerarbeitungsstatus(final UUID antragUuid) {
        return verarbeitungsstatusRepository.findByAntragId(antragUuid)
            .orElseGet(() -> createNewVerarbeitungsstatus(antragUuid));
    }

    private Verarbeitungsstatus createNewVerarbeitungsstatus(final UUID antragUuid) {
        final Verarbeitungsstatus verarbeitungsstatus = new Verarbeitungsstatus();
        verarbeitungsstatus.setCreated(LocalDateTime.now());
        verarbeitungsstatus.setAntragId(antragUuid);
        return verarbeitungsstatus;
    }

    /**
     * Lesen des Verarbeitungsstatus mit der UUID des Antrags für abgeschlossene Anträge.
     *
     * @param antragUuid UUID des Antrags
     * @return gelesener Verarbeitungsstatus
     */
    @Transactional
    public Optional<Verarbeitungsstatus> getVerarbeitungsstatusFallsAbgeschlossen(final UUID antragUuid) {
        final AntragStatus[] mitAntragStatus = {
            AntragStatus.BESCHEID_ABGESCHLOSSEN,
            AntragStatus.AUFGABE_ABGESCHLOSSEN,
            AntragStatus.STATISTIK_ABGESCHLOSSEN
        };
        return verarbeitungsstatusRepository.findByAntragId(antragUuid, mitAntragStatus);
    }

    /**
     * Lesen des Verarbeitungsstatus mit der UUID des Antrags für beliebige Anträge.
     *
     * @param antragUuid UUID des Antrags
     * @return gelesener Verarbeitungsstatus
     */
    @Transactional
    public Optional<Verarbeitungsstatus> getVerarbeitungsstatus(final UUID antragUuid) {
        return verarbeitungsstatusRepository.findByAntragId(antragUuid);
    }
}
