package de.deutscherv.rvsm.fa.fit.antraege.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.DoppelvergabeStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypAntrag;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypFrage;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.KomTypFragefeld;
import de.deutscherv.rvsm.fa.fit.einrichtungen.mapper.EinrichtungMapper;
import de.deutscherv.rvsm.fa.fit.kontoinformation.model.KontoinformationResponse;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.ArtZugaenglichkeitDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoinformationDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PruefergebnisDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.mapper.AntragPruefergebnisMapper;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.KontoinformationMapper;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.StammdatenMapper;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.AnschriftUtils;
import de.deutscherv.rvsm.fa.fit.util.GeburtsdatumUtils;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.mapstruct.AfterMapping;
import org.mapstruct.BeanMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

/**
 * Mapping-Klasse für Anträge.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR,
        uses = { StammdatenMapper.class, KontoinformationMapper.class,
    EinrichtungMapper.class, AntragPruefergebnisMapper.class, AntragStatusMapper.class }, imports = { Arrays.class })
public interface AntragMapper {

    /**
     * Formatierte Ausgabe Datum im ISO-Format.
     */
    String ISO_DATEFORMAT = "%04d-%02d-%02d";

    /**
     * XML Element für die AngebotsId.
     */
    String ANGEBOT_ID = "angebotsId";

    /**
     * XML Element für die Straße eines Angebots.
     */
    String ANEGBOT_STRASSE = "strasse";

    /**
     * XML Element für die PLZ eines Angebots.
     */
    String ANGEBOT_PLZ = "plz";

    /**
     * XML Element für den Ort eines Angebots.
     */
    String ANGEBOT_ORT = "ort";

    /**
     * XML Element für den Anbieter eines Angebots.
     */
    String ANGEBOT_ANBIETER = "bezeichnung60Anbieter";

    /**
     * XML Elemente für Anschrift/Telefon.
     */
    String VANSCHRIFTTELEFON = "vAnschriftTelefon";

    /**
     * XML Elemente für Namen.
     */
    String VNAMEN = "vNamen";

    /**
     * XML Elemente für Geburtsangaben.
     */
    String VGEBURTSANGABEN = "vGeburtsangaben";

    /**
     * XML Elemente für Einrichtunegnn.
     */
    String VFREITEXTEINRICHTUNG = "vorgeseheneRehabilitationseinrichtung";

    /**
     * Der Wert, der im eAntrag XML gesetzt ist, wenn eine Doppelvergabe vorliegt.
     */
    String DOPPELVERGABE_TRUE = "D";

    /**
     * Wert für Bemerkung wenn eine Bemerkung an einer Frage gesetzt ist.
     */
    String BEMERKUNG_SET_MESSAGE = "Bitte Bemerkungen im Formular R0990 beachten";

    /**
     * Wert für das Vorhandensein eines digitalen Anhangs.
     */
    String HAT_DIGITALEN_ANHANG = "hatDigitalenAnhang";

    /**
     * Mappt einen Antrag zu einem Antrag DTO.
     *
     * @param antrag der Antrag
     * @return das DTO
     */
    @Mapping(source = "versichertenStammdaten", target = "versichertenStammdaten", qualifiedByName = "toVersichertenStammdatenDto")
    @Mapping(source = "kontoinformationen", target = "kontoinformationen", qualifiedByName = "toKontoinformationenDto")
    @Mapping(source = "antragPruefergebnisse", target = "pruefergebnisse", qualifiedByName = "toPruefergebnisseDto")
    @Mapping(source = "eingangsdatum", target = "eingangsdatum")
    @Mapping(source = "antragsDatum", target = "antragsdatum")
    @Mapping(source = HAT_DIGITALEN_ANHANG, target = "digitaleranhang")
    @Mapping(source = "antrag", target = "geburtsdatum", qualifiedByName = "geburtsdatumToGeburtsdatumDto")
    @Mapping(source = "einrichtungStartObjekt", target = "einrichtungStartObjekt")
    @Mapping(source = "uuid", target = "uuid")
    @Mapping(source = "status", target = "status", qualifiedByName = "toStatusDto")
    @Mapping(source = "antrag", target = "einrichtungStartAuf", qualifiedByName = "toStartAufText")
    @Mapping(source = "antrag", target = "einrichtungTraining", qualifiedByName = "toTrainingText")
    @Mapping(target = "fruehererName",ignore = true)
    @Mapping(target = "geburtsname",ignore = true)
    @Mapping(target = "removeVersichertenStammdatenItem",ignore = true)
    @Mapping(target = "removeKontoinformationenItem",ignore = true)
    @Mapping(target = "removePruefergebnisseItem",ignore = true)
    AntragDto toDto(Antrag antrag);

    /**
     * Aus der Kombination von geburtsdatum und geburtsdatumStatus wird ein String im ISO-Format erzeugt.
     *
     * @param antrag mit dem Geburtsdatum
     * @return Geburtsdatum
     */
    @Named("geburtsdatumToGeburtsdatumDto")
    static String geburtsdatumToGeburtsdatumDto(final Antrag antrag) {
        return GeburtsdatumUtils.getGeburtsdatumAsString(antrag.getGeburtsdatum(), antrag.getGeburtsdatumStatus());
    }

    /**
     * Der Adresstext für die Start-/Aufrischungeinrichtung wird ermittelt.
     *
     * @param antrag aus dem die Daten ermittlent werden
     * @return Text mit Name, Strasse, PLZ und Ort getrennt durch Komma
     */
    @Named("toStartAufText")
    static String toStartAufText(final Antrag antrag) {
        return Stream.of(
                Objects.toString(antrag.getAngebotStartName(), "").trim(),
                Objects.toString(antrag.getAngebotStartStrasse(), "").trim(),
                String.format("%s %s",
                    Objects.toString(antrag.getAngebotStartPlz(), "").trim(),
                    Objects.toString(antrag.getAngebotStartOrt(), "").trim()).trim())
            .filter(s -> !s.isEmpty())
            .collect(Collectors.joining(", "));
    }

    /**
     * Der Adresstext für die Trainingseinrichtung wird ermittelt.
     *
     * @param antrag aus dem die Daten ermittlent werden
     * @return Text mit Name, Strasse, PLZ und Ort getrennt durch Komma
     */
    @Named("toTrainingText")
    static String toTrainingText(final Antrag antrag) {
        return Stream.of(
                Objects.toString(antrag.getAngebotTrainingName(), "").trim(),
                Objects.toString(antrag.getAngebotTrainingStrasse(), "").trim(),
                String.format("%s %s",
                    Objects.toString(antrag.getAngebotTrainingPlz(), "").trim(),
                    Objects.toString(antrag.getAngebotTrainingOrt(), "").trim()).trim())
            .filter(s -> !s.isEmpty())
            .collect(Collectors.joining(", "));
    }

    /**
     * Mappt VerischertenStammdaten in DTOs.
     *
     * @param versichertenStammdaten die Stammdaten
     * @return die DTOs
     */
    @Named("toVersichertenStammdatenDto")
    List<StammdatenDto> toVersichertenStammdatenDto(List<Stammdaten> versichertenStammdaten);

    /**
     * Mappt StatusDTO in StatusEnum.
     *
     * @param antragStatus Antrag-Status
     * @return ermittletes Enum
     */
    @Named("toStatusDto")
    @ValueMapping(source = "VORGANG_WIRD_ERSTELLT", target = MappingConstants.NULL)
    AntragDto.StatusEnum toStatusDto(AntragStatus antragStatus);

    /**
     * Mappt Kontoinformationen in DTOs.
     *
     * @param kontoinformationen die Kontoinformationen
     * @return die DTOs
     */
    @Named("toKontoinformationenDto")
    List<KontoinformationDto> toKontoinformationenDto(List<Kontoinformation> kontoinformationen);

    /**
     * Mappt KontoinformationenResponse aus rvSystem Bestand in Entity.
     *
     * @param kontoinformationResponse die KontoinforamtionenResponse.
     * @return die Entity.
     */
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "uuid", ignore = true)
    @Mapping(target = "rvSystemFehler", ignore = true)
    @Mapping(target = "antragId", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    @Named("toKontoinformationEntity")
    Kontoinformation toKontoinformationEntity(KontoinformationResponse kontoinformationResponse);

    /**
     * Mappt Prüfergebnisse in DTOs.
     *
     * @param antragPruefergebnisse die Prüfergebnisse
     * @return die DTOs
     */
    @Named("toPruefergebnisseDto")
    List<PruefergebnisDto> toPruefergebnisseDto(List<AntragPruefergebnis> antragPruefergebnisse);

    /**
     * Mappt ein AntragDTO in einen Antrag.
     *
     * @param dto das DTO
     * @return der Antrag
     */
    @Mapping(source = "versichertenStammdaten", target = "versichertenStammdaten", qualifiedByName = "toVersichertenStammdaten")
    @Mapping(source = "kontoinformationen", target = "kontoinformationen", qualifiedByName = "toKontoinformationen")
    @Mapping(source = "pruefergebnisse", target = "antragPruefergebnisse", qualifiedByName = "toAntragPruefergebnisse")
    @Mapping(source = "geburtsdatum", target = "geburtsdatumStatus", qualifiedByName = "geburtsdatumToGeburtsdatumStatus")
    @Mapping(source = "geburtsdatum", target = "geburtsdatum", qualifiedByName = "geburtsdatumFromString")
    @Mapping(source = "status", target = "status", qualifiedByName = "toStatus")
    @Mapping(source = "antragsdatum", target = "antragsDatum")
    @Mapping(target = "bescheiddatum", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    @Mapping(target = "aufgaben", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "angebotStartSmpId", ignore = true)
    @Mapping(target = "angebotStartName", ignore = true)
    @Mapping(target = "angebotStartOrt", ignore = true)
    @Mapping(target = "angebotStartPlz", ignore = true)
    @Mapping(target = "angebotStartStrasse", ignore = true)
    @Mapping(target = "angebotTrainingSmpId", ignore = true)
    @Mapping(target = "angebotTrainingName", ignore = true)
    @Mapping(target = "angebotTrainingOrt", ignore = true)
    @Mapping(target = "angebotTrainingPlz", ignore = true)
    @Mapping(target = "angebotTrainingStrasse", ignore = true)
    @Mapping(target = "angebotAufSmpId", ignore = true)
    @Mapping(target = "angebotAufName", ignore = true)
    @Mapping(target = "angebotAufOrt", ignore = true)
    @Mapping(target = "angebotAufPlz", ignore = true)
    @Mapping(target = "angebotAufStrasse", ignore = true)
    @Mapping(target = "vorgangskennung", ignore = true)
    @Mapping(target = "msnr", ignore = true)
    @Mapping(target = "atad", ignore = true)
    @Mapping(target = "doppelvergabe", ignore = true)
    @InheritInverseConfiguration
    Antrag toEntity(AntragDto dto);

    /**
     * GeburtsdatumStatus wird anhand des Geburtsdatum gesetzt.
     *
     * @param geburtsdatum Geburtsdatum als String im Format YYYY-MM-DD
     * @return geburtsdatumStatus
     */
    @Named("geburtsdatumToGeburtsdatumStatus")
    static GeburtsdatumStatus geburtsdatumToGeburtsdatumStatus(final String geburtsdatum) {
        return GeburtsdatumUtils.detectGeburtsdatumStatus(geburtsdatum);
    }

    /**
     * Mappt String mit dem Geburtsdatum zu einem LocalDate. Falls Monat und/oder Tag den Wert "00" haben wird jeweils "01" eingetragen.
     *
     * @param geburtsdatum String mit dem Datum
     * @return Geburtsdatum als LocalDate.
     */
    @Named("geburtsdatumFromString")
    static LocalDate geburtsdatumFromString(final String geburtsdatum) {
        return GeburtsdatumUtils.getGeburtsdatumAsLocalDate(geburtsdatum);
    }

    /**
     * Mappt ein PapierantragDto in einen Antrag.
     *
     * @param dto papierantragDto
     * @return der Antrag
     */
    default Antrag toEntity(final PapierantragDto dto) {
        final Antrag entity = toEntity(dto.getAntrag());
        entity.setVorgangskennung(dto.getVorgangsId());
        entity.setDoppelvergabe(DoppelvergabeStatus.KEINE_DOPPELVERGABE);

        if (Optional.ofNullable(dto.getVersicherter()).isPresent()) {
            final StammdatenDto versicherter = dto.getVersicherter();
            entity.setLand(versicherter.getLand());
            entity.setGeburtsland(versicherter.getGeburtsland());
            entity.setTelefon(versicherter.getTelefon());
            entity.setGeburtsdatumStatus(toGeburtsdatumStatus(versicherter));
            entity.setGeburtsdatum(GeburtsdatumUtils.getGeburtsdatumAsLocalDate(versicherter.getGeburtsdatum()));
        }

        final var startAuf = dto.getEinrichtung1();
        if (startAuf != null) {
            final var adresse = startAuf.getAdresse();

            if (adresse != null) {
                final String strasse = adresse.getStrasse() + " " + adresse.getHausnummer();
                entity.setAngebotStartPlz(adresse.getPlz());
                entity.setAngebotStartOrt(adresse.getOrt());
                entity.setAngebotAufPlz(adresse.getPlz());
                entity.setAngebotAufOrt(adresse.getOrt());
                entity.setAngebotStartStrasse(strasse);
                entity.setAngebotAufStrasse(strasse);
            }
            entity.setAngebotStartName(startAuf.getName());
            entity.setAngebotAufName(startAuf.getName());
        }

        final var training = dto.getEinrichtung2();
        if (training != null) {
            final var adresse = training.getAdresse();
            entity.setAngebotTrainingName(training.getName());

            if (adresse != null) {
                final String strasse = adresse.getStrasse() + " " + adresse.getHausnummer();
                entity.setAngebotTrainingPlz(adresse.getPlz());
                entity.setAngebotTrainingOrt(adresse.getOrt());
                entity.setAngebotTrainingStrasse(strasse);
            }

        }
        return entity;
    }

    /**
     * Mappt Stammdaten DTOs zu Stammdaten.
     *
     * @param versichertenStammdatenDto die DTOs
     * @return die Stammdaten
     */
    @Named("toVersichertenStammdaten")
    List<Stammdaten> toVersichertenStammdaten(List<StammdatenDto> versichertenStammdatenDto);

    /**
     * Mappt StatusEnum in AntragStatus.
     *
     * @param statusDto Status-Dto
     * @return zugeordneter Status
     */
    @Named("toStatus")
    // @ValueMapping(target = "ENTWURF", source = MappingConstants.NULL)
    AntragStatus toStatus(AntragDto.StatusEnum statusDto);

    /**
     * Aus dem Geburtsdatum wird der GeburtsdatumStatus ermittelt.
     *
     * @param stammdatenDto Stammdaten mit dem Geburtsdatum
     * @return GeburtsdatumStatus
     */
    @Named("toGeburtsdatumStatus")
    static GeburtsdatumStatus toGeburtsdatumStatus(StammdatenDto stammdatenDto) {
        return GeburtsdatumUtils.detectGeburtsdatumStatus(stammdatenDto.getGeburtsdatum());
    }

    /**
     * Mappt Kontoinformationen DTOs zu Kontoinformationen.
     *
     * @param kontoinformationenDto die DTOs
     * @return die Kontoinformationen
     */
    @Named("toKontoinformationen")
    List<Kontoinformation> toKontoinformationen(List<KontoinformationDto> kontoinformationenDto);

    /**
     * Mappt Prüefergebnis DTOs in Prüfergenisse.
     *
     * @param antragPruefergebnisse die DTOs
     * @return die Ergebnisse
     */
    @Named("toAntragPruefergebnisse")
    List<AntragPruefergebnis> toAntragPruefergebnisse(List<PruefergebnisDto> antragPruefergebnisse);

    /**
     * Mappt einen eAntrag in einen Antrag.
     *
     * @param antragsdaten der eAntrag
     * @return der Antrag
     */
    @Mapping(source = "steuerdaten.vsnr", target = "vsnr")
    @Mapping(source = "steuerdaten.empfaenger", target = "ktan")
    @Mapping(source = "steuerdaten.zeitpunktErstellung", target = "antragsDatum")
    @Mapping(source = "steuerdaten.zeitpunktErstellung", target = "eingangsdatum")
    @Mapping(source = "steuerdaten.doppelvergabe", target = "doppelvergabe", qualifiedByName = "mapDoppelvergabe")
    @Mapping(source = "steuerdaten.version", target = "version")
    @Mapping(target = "antragPruefergebnisse", ignore = true)
    @Mapping(source = "antragsdaten", target = HAT_DIGITALEN_ANHANG, qualifiedByName = "antragsdatenToDigitalerAnhang")
    @Mapping(source = "antragsdaten", target = ANEGBOT_STRASSE, qualifiedByName = "antragsdatenToStrasse")
    @Mapping(source = "antragsdaten", target = "hausnummer", qualifiedByName = "antragsdatenToHausnummer")
    @Mapping(source = "antragsdaten", target = ANGEBOT_PLZ, qualifiedByName = "antragsdatenToPlz")
    @Mapping(source = "antragsdaten", target = "wohnort", qualifiedByName = "antragsdatenToWohnort")
    @Mapping(source = "antragsdaten", target = "land", qualifiedByName = "antragsdatenToLand")
    @Mapping(source = "antragsdaten", target = "telefon", qualifiedByName = "antragsdatenToTelefon")
    @Mapping(source = "antragsdaten", target = "nachname", qualifiedByName = "antragsdatenToNachname")
    @Mapping(source = "antragsdaten", target = "vorname", qualifiedByName = "antragsdatenToVorname")
    @Mapping(source = "antragsdaten", target = "geburtsdatum", qualifiedByName = "antragsdatenToGeburtsdatum")
    @Mapping(source = "antragsdaten", target = "geburtsdatumStatus", qualifiedByName = "antragsdatenToGeburtsdatumStatus")
    @Mapping(source = "antragsdaten", target = "geburtsort", qualifiedByName = "antragsdatenToGeburtsort")
    @Mapping(source = "antragsdaten", target = "geburtsland", qualifiedByName = "antragsdatenToGeburtsland")
    @Mapping(source = "antragsdaten", target = "staatsangehoerigkeit", qualifiedByName = "antragsdatenToStaatsangehoerigkeit")
    @Mapping(source = "antragsdaten", target = "bemerkungen", qualifiedByName = "antragsdatenToFreitext")
    @Mapping(source = "antragsdaten", target = "artZugaenglichkeit", qualifiedByName = "antragsdatenToZugaenglichkeit")
    @Mapping(target = "antragsart", constant = "E_ANTRAG")
    @Mapping(target = "uuid",ignore = true)
    @Mapping(target = "versichertenStammdaten",ignore = true)
    @Mapping(target = "kontoinformationen",ignore = true)
    @Mapping(target = "aufgaben",ignore = true)
    @Mapping(target = "status",ignore = true)
    @Mapping(target = "geschlecht",ignore = true)
    @Mapping(target = "xml",ignore = true)
    @Mapping(target = "angebotStartSmpId",ignore = true)
    @Mapping(target = "angebotStartName",ignore = true)
    @Mapping(target = "angebotStartPlz",ignore = true)
    @Mapping(target = "angebotStartStrasse",ignore = true)
    @Mapping(target = "angebotTrainingSmpId",ignore = true)
    @Mapping(target = "angebotTrainingName",ignore = true)
    @Mapping(target = "angebotTrainingOrt",ignore = true)
    @Mapping(target = "angebotTrainingPlz",ignore = true)
    @Mapping(target = "angebotTrainingStrasse",ignore = true)
    @Mapping(target = "angebotAufSmpId",ignore = true)
    @Mapping(target = "angebotAufName",ignore = true)
    @Mapping(target = "angebotAufOrt",ignore = true)
    @Mapping(target = "angebotAufPlz",ignore = true)
    @Mapping(target = "angebotAufStrasse",ignore = true)
    @Mapping(target = "einrichtungStartObjekt",ignore = true)
    @Mapping(target = "einrichtungAufObjekt",ignore = true)
    @Mapping(target = "einrichtungTrainingObjekt",ignore = true)
    @Mapping(target = "lastModifiedStart",ignore = true)
    @Mapping(target = "lastModifiedAuf",ignore = true)
    @Mapping(target = "lastModifiedTraining",ignore = true)
    @Mapping(target = "fax",ignore = true)
    @Mapping(target = "bescheiddatum",ignore = true)
    @Mapping(target = "created",ignore = true)
    @Mapping(target = "lastModified",ignore = true)
    @Mapping(target = "vorgangskennung",ignore = true)
    @Mapping(target = "msnr",ignore = true)
    @Mapping(target = "atad",ignore = true)
    @Mapping(target = "vorsatzwort",ignore = true)
    @Mapping(target = "namenszusatz",ignore = true)
    @Mapping(target = "titel",ignore = true)
    @Mapping(target = "angebotStartOrt",ignore = true)
    Antrag antragsdatenToEntity(Antragsdaten antragsdaten);

    /**
     * Setzt die Daten für die Startphase.
     *
     * @param antragsdaten die Antragsdaten, der die Daten enthält
     * @param antrag       der AntragBuilder, in dem die Daten gesetzt werden
     */
    @AfterMapping
    static void setAngebotStart(final Antragsdaten antragsdaten, @MappingTarget final Antrag.AntragBuilder antrag) {
        final var frage = getFrage(antragsdaten, "vorgeseheneRehabilitationseinrichtungStartphase");
        if (frage == null) {
            return;
        }

        final var id = getFragefeld(frage, ANGEBOT_ID);
        antrag.angebotStartSmpId(id == null ? null : Long.parseLong(id));
        antrag.angebotStartName(getFragefeld(frage, ANGEBOT_ANBIETER));
        antrag.angebotStartOrt(getFragefeld(frage, ANGEBOT_ORT));
        antrag.angebotStartPlz(getFragefeld(frage, ANGEBOT_PLZ));
        antrag.angebotStartStrasse(getFragefeld(frage, ANEGBOT_STRASSE));
    }

    /**
     * Setzt die Daten für die Trainingsphase.
     *
     * @param antragsdaten die Antragsdaten, der die Daten enthält
     * @param antrag       der AntragBuilder, in dem die Daten gesetzt werden
     */
    @AfterMapping
    static void setAngebotTraining(final Antragsdaten antragsdaten, @MappingTarget final Antrag.AntragBuilder antrag) {
        final var frage = getFrage(antragsdaten, "vorgeseheneRehabilitationseinrichtungTrainingsphase");
        if (frage == null) {
            return;
        }

        final var id = getFragefeld(frage, ANGEBOT_ID);
        antrag.angebotTrainingSmpId(id == null ? null : Long.parseLong(id));
        antrag.angebotTrainingName(getFragefeld(frage, ANGEBOT_ANBIETER));
        antrag.angebotTrainingOrt(getFragefeld(frage, ANGEBOT_ORT));
        antrag.angebotTrainingPlz(getFragefeld(frage, ANGEBOT_PLZ));
        antrag.angebotTrainingStrasse(getFragefeld(frage, ANEGBOT_STRASSE));
    }

    /**
     * Setzt die Daten für die Auffrischungsphase.
     *
     * @param antragsdaten die Antragsdaten, der die Daten enthält
     * @param antrag       der AntragBuilder, in dem die Daten gesetzt werden
     */
    @AfterMapping
    static void setAngebotAuffrischung(final Antragsdaten antragsdaten, @MappingTarget final Antrag.AntragBuilder antrag) {
        final var frage = getFrage(antragsdaten, "vorgeseheneRehabilitationseinrichtungAuffrischungsphase");
        if (frage == null) {
            return;
        }

        final var id = getFragefeld(frage, ANGEBOT_ID);
        antrag.angebotAufSmpId(id == null ? null : Long.parseLong(id));
        antrag.angebotAufName(getFragefeld(frage, ANGEBOT_ANBIETER));
        antrag.angebotAufOrt(getFragefeld(frage, ANGEBOT_ORT));
        antrag.angebotAufPlz(getFragefeld(frage, ANGEBOT_PLZ));
        antrag.angebotAufStrasse(getFragefeld(frage, ANEGBOT_STRASSE));
    }

    /**
     * Mappt den Inhalt des Strings zu DoppelvergabeStatus.
     *
     * @param doppelverabe Text mit dem Status
     * @return Status nach Mapping
     */
    @Named("mapDoppelvergabe")
    static DoppelvergabeStatus mapDoppelvergabe(final String doppelverabe) {
        if (DOPPELVERGABE_TRUE.equals(doppelverabe)) {
            return DoppelvergabeStatus.PRUEFEN;
        }
        return DoppelvergabeStatus.KEINE_DOPPELVERGABE;
    }

    /**
     * Mappt die numerische Id der Zugänglichkeit im eAntrag zum entsrechenden Enum-Feld.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Zugänglichkeit
     */
    @Named("antragsdatenToZugaenglichkeit")
    static ArtZugaenglichkeitDto antragsdatenToZugaenglichkeit(final Antragsdaten antragsdaten) {
        String fragefeld = getFragefeld(antragsdaten, "dokumentenzugangFuerSehbehinderte", "dokumentenzugang");
        return switch (fragefeld) {
            case "01" -> ArtZugaenglichkeitDto.GROSSDRUCK;
            case "02" -> ArtZugaenglichkeitDto.BRAILLE_KURZSCHRIFT;
            case "03" -> ArtZugaenglichkeitDto.BRAILLE_VOLLSCHRIFT;
            case "04" -> ArtZugaenglichkeitDto.CD_ROM;
            case "06" -> ArtZugaenglichkeitDto.HOERMEDIUM;
            case null, default -> null;
        };
    }

    /**
     * Bestimmt die Straße aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Straße
     */
    @Named("antragsdatenToStrasse")
    static String antragsdatenToStrasse(final Antragsdaten antragsdaten) {
        final String fragefeld = getFragefeld(antragsdaten, VANSCHRIFTTELEFON, ANEGBOT_STRASSE);
        return AnschriftUtils.getStrasse(fragefeld);
    }

    /**
     * Test, ob ein digitialer Anhang im Antrag vorhanden ist.
     *
     * @param antragsdaten die Antragsdaten
     * @return true bei vorhandenem digitalem Anhang.
     */
    @Named("antragsdatenToDigitalerAnhang")
    static boolean antragsdatenToDigitalerAnhang(final Antragsdaten antragsdaten) {
        final Antragsdaten.Anlagen anlagen = antragsdaten.getAnlagen();
        if (anlagen == null || anlagen.getAnlage() == null) {
            return false;
        }
        return !anlagen.getAnlage().isEmpty();
    }

    /**
     * Bestimmt die Hausnummer aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Hausnummer
     */
    @Named("antragsdatenToHausnummer")
    static String antragsdatenToHausnummer(final Antragsdaten antragsdaten) {
        final String fragefeld = getFragefeld(antragsdaten, VANSCHRIFTTELEFON, ANEGBOT_STRASSE);
        return AnschriftUtils.getHausnummer(fragefeld);
    }

    /**
     * Bestimmt die Plz aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Plz
     */
    @Named("antragsdatenToPlz")
    static String antragsdatenToPlz(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VANSCHRIFTTELEFON, ANGEBOT_PLZ);
    }

    /**
     * Bestimmt den Wohnort aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return den Wohnort
     */
    @Named("antragsdatenToWohnort")
    static String antragsdatenToWohnort(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VANSCHRIFTTELEFON, ANGEBOT_ORT);
    }

    /**
     * Bestimmt das Land aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return das Land
     */
    @Named("antragsdatenToLand")
    static String antragsdatenToLand(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VANSCHRIFTTELEFON, "ntsc");
    }

    /**
     * Bestimmt die Telefon aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Telefon
     */
    @Named("antragsdatenToTelefon")
    static String antragsdatenToTelefon(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VANSCHRIFTTELEFON, "telefon");
    }

    /**
     * Bestimmt den Nachname naus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return der Nachname
     */
    @Named("antragsdatenToNachname")
    static String antragsdatenToName(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VNAMEN, "name");
    }

    /**
     * Bestimmt den Vornamen aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return der vorname
     */
    @Named("antragsdatenToVorname")
    static String antragsdatenToVorname(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VNAMEN, "vorname");
    }

    /**
     * Bestimmt das Geburtsdatum aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return das Geburtsdatum
     */
    @Named("antragsdatenToGeburtsdatum")
    static LocalDate antragsdatenToGeburtsdatum(final Antragsdaten antragsdaten) {
        final String geburtsdatum = getFragefeld(antragsdaten, VGEBURTSANGABEN, "datumSpezial");

        if (Optional.ofNullable(geburtsdatum).isEmpty()) {
            return null;
        }

        final int day = Integer.parseInt(geburtsdatum.substring(0, 2));
        final int month = Integer.parseInt(geburtsdatum.substring(3, 5));
        final int year = Integer.parseInt(geburtsdatum.substring(6));

        return GeburtsdatumUtils.getGeburtsdatumAsLocalDate(String.format(ISO_DATEFORMAT, year, month, day));
    }

    /**
     * Bestimmt das GeburtsdatumStatus aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return das Geburtsdatum
     */
    @Named("antragsdatenToGeburtsdatumStatus")
    static GeburtsdatumStatus antragsdatenToGeburtsdatumStatus(final Antragsdaten antragsdaten) {
        final String geburtsdatum = getFragefeld(antragsdaten, VGEBURTSANGABEN, "datumSpezial");

        if (Optional.ofNullable(geburtsdatum).isEmpty()) {
            return null;
        }

        final int day = Integer.parseInt(geburtsdatum.substring(0, 2));
        final int month = Integer.parseInt(geburtsdatum.substring(3, 5));
        final int year = Integer.parseInt(geburtsdatum.substring(6));
        return GeburtsdatumUtils.detectGeburtsdatumStatus(String.format(ISO_DATEFORMAT, year,
            month, day));
    }

    /**
     * Bestimmt den Geburtsort aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return der Geburtsort
     */
    @Named("antragsdatenToGeburtsort")
    static String antragsdatenToGeburtsort(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VGEBURTSANGABEN, ANGEBOT_ORT);
    }

    /**
     * Bestimmt das Geburtsland aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return das Geburtsland
     */
    @Named("antragsdatenToGeburtsland")
    static String antragsdatenToGeburtsland(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VGEBURTSANGABEN, "ntsc");
    }

    /**
     * Liest die Bemerkung eines Antrags aus.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Bemerkung
     */
    @Named("antragsdatenToFreitext")
    static String antragsdatenToFreitext(final Antragsdaten antragsdaten) {
        final boolean frageHatBemerkung = antragsdaten.getDaten()
            .getAntrag()
            .stream()
            .filter(KomTypAntrag::isIsHauptantrag)
            .flatMap(antrag -> antrag.getFrage().stream())
            .map(KomTypFrage::getBemerkung)
            .anyMatch(bemerkung -> bemerkung != null && !bemerkung.isEmpty());

        if (frageHatBemerkung) {
            return BEMERKUNG_SET_MESSAGE;
        }

        final String bemerkungenZumAntrag = getAntragByName(antragsdaten, "r0990")
            .flatMap(antrag -> antrag.getFrage().stream()
                .filter(frage -> Objects.equals(frage.getName(), "bemerkungenZumAntragLang"))
                .findFirst())
            .map(frage -> frage.getBemerkung() == null ? getFragefeld(frage, "bemerkungenLang") : frage.getBemerkung())
            .orElse(null);

        final String angabenEingereichteUnterlagen = getAntragByName(antragsdaten, "r0990")
            .flatMap(antrag -> antrag.getFrage().stream()
                .filter(frage -> Objects.equals(frage.getName(), "angabenEingereichteUnterlagen2"))
                .findFirst())
            .map(KomTypFrage::getBemerkung)
            .orElse(null);

        final String newLine = System.lineSeparator();

        return Stream.of(bemerkungenZumAntrag, angabenEingereichteUnterlagen)
            .filter(Objects::nonNull)
            .filter(s -> !s.isBlank())
            .collect(Collectors.joining(newLine + newLine));
    }

    /**
     * Bestimmt die Staatsangehörigkeit aus Antragdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @return die Staatsangehörigkeit
     */
    @Named("antragsdatenToStaatsangehoerigkeit")
    static String antragsdatenToStaatsangehoerigkeit(final Antragsdaten antragsdaten) {
        return getFragefeld(antragsdaten, VNAMEN, "ntsc");
    }

    /**
     * Gets the antrag by name.
     *
     * @param antragsdaten the antragsdaten
     * @param antragsName  the antrags name
     * @return the antrag by name
     */
    private static Optional<KomTypAntrag> getAntragByName(final Antragsdaten antragsdaten,
        final String antragsName) {
        return antragsdaten.getDaten().getAntrag().stream()
            .filter(antrag -> antrag.getName().equals(antragsName)).findFirst();
    }

    /**
     * Ließt ein Fargefeld aus den Antragsdaten aus.
     *
     * @param antragsdaten  die Antragsdaten
     * @param frageName     der Name der Frage
     * @param fragefeldName der Name des Fragefeld
     * @return der Inhalt des Fragefelds oder {@code null}, wenn das Fragefeld nicht existiert.
     */
    private static String getFragefeld(final Antragsdaten antragsdaten, final String frageName,
        final String fragefeldName) {
        final KomTypFrage frage = getFrage(antragsdaten, frageName);
        if (null == frage) {
            return null;
        }

        return getFragefeld(frage, fragefeldName);
    }

    /**
     * Liest den wert eines Fragefelds aus einer Frage aus.
     *
     * @param frage    die Frage
     * @param feldName der name des Felds
     * @return der Inhalt des Fragefelds oder {@code null}, wenn das Fragefeld nicht existiert.
     */
    private static String getFragefeld(final KomTypFrage frage, final String feldName) {
        return frage.getZeile()
            .stream()
            .flatMap(zeile -> zeile.getFragefeld().stream())
            .filter(feld -> feld.getName().equals(feldName))
            .findFirst()
            .map(KomTypFragefeld::getValue)
            .orElse(null);
    }

    /**
     * Sucht eine Frage in den Antragsdaten.
     *
     * @param antragsdaten die Antragsdaten
     * @param frageName    der Name der Frage
     * @return die Frage oder {@code null}, wenn die Frage nicht existiert.
     */
    private static KomTypFrage getFrage(final Antragsdaten antragsdaten, final String frageName) {
        final List<KomTypAntrag> antraege = antragsdaten.getDaten().getAntrag();
        final KomTypAntrag antrag = antraege.stream().filter(KomTypAntrag::isIsHauptantrag).findFirst().orElse(null);
        if (null == antrag) {
            return null;
        }
        final List<KomTypFrage> komTypFragen = antrag.getFrage();
        return komTypFragen.stream().filter(f -> f.getName().equals(frageName)).findFirst()
            .orElse(null);
    }

    /**
     * Mappt Stammdaten in Antrag Versicherter Stammdaten.
     *
     * @param stammdaten Stammdaten der Person
     * @param antrag     der eAntrag
     * @return der Antrag mit updated Versicehrter Stammdaten
     */
    @Mapping(source = "vorname", target = "vorname")
    @Mapping(source = "nachname", target = "nachname")
    @Mapping(source = "namenszusatz", target = "namenszusatz")
    @Mapping(source = "geburtsdatum", target = "geburtsdatum")
    @Mapping(source = "titel", target = "titel")
    @Mapping(source = "geburtsort", target = "geburtsort")
    @Mapping(source = "geburtsland", target = "geburtsland")
    @Mapping(source = "geburtsdatumStatus", target = "geburtsdatumStatus")
    @Mapping(source = "geschlecht", target = "geschlecht")
    @Mapping(source = "strasse", target = "strasse")
    @Mapping(source = "hausnummer", target = "hausnummer")
    @Mapping(source = "plz", target = "plz")
    @Mapping(source = "wohnort", target = "wohnort")
    @Mapping(source = "land", target = "land")
    @Mapping(source = "staatsangehoerigkeit", target = "staatsangehoerigkeit")
    @Mapping(target = "uuid", ignore = true)
    @BeanMapping(ignoreByDefault = true, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    Antrag fromStammdatenToAntrag(Stammdaten stammdaten, @MappingTarget Antrag antrag);
}
