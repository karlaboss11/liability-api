package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.mapper.EantragsBestaetigungMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.AntragsdatenToAntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.EantragsUnmarshaller;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.builder.RouteBuilder;

/**
 * Routen zum Mapping von Antraegen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class MappingRoutes extends RouteBuilder {
    /**
     * Routenname: Unmarshal eAntrag.
     */
    public static final String DIRECT_UNMARSHAL_EANTRAG = "direct:unmarshalEantrag";
    /**
     * Routenname: Map Antragsdaten zu eAntrag.
     */
    public static final String DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG = "direct:mapAntragsdatenToEantrag";
    /**
     * Routenname: Map eAntrag zu Bestaetigung.
     */
    public static final String DIRECT_MAP_EANTRAG_TO_BESTAETIGUNG = "direct:mapEantragToBestaetigung";

    private final AntragsdatenToAntragMapper antragsdatenToAntragMapper;
    private final EantragsUnmarshaller eantragsUnmarshaller;

    @Override
    public void configure() throws Exception {
        from(DIRECT_UNMARSHAL_EANTRAG)
            .routeId(DIRECT_UNMARSHAL_EANTRAG)
            .process(eantragsUnmarshaller);

        from(DIRECT_MAP_EANTRAG_TO_BESTAETIGUNG)
            .routeId(DIRECT_MAP_EANTRAG_TO_BESTAETIGUNG)
            .setBody(method(EantragsBestaetigungMapper.class,
                "antragsdatenToEantragsBestaetigung(*)"));

        from(DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
            .routeId(DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
            .process(antragsdatenToAntragMapper);
    }
}
