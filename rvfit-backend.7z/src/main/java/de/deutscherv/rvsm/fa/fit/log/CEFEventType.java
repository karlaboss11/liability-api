package de.deutscherv.rvsm.fa.fit.log;

import lombok.Getter;

/**
 * CEF-Eventtyp.
 */
@Getter
public enum CEFEventType {
    /**
     * Authentication.
     */
    AUTHENTICATION("Authentication"),
    /**
     * Application.
     */
    APPLICATION("Application");

    private final String value;

    /**
     * Konstruktor.
     *
     * @param value zu setzender Wert.
     */
    CEFEventType(final String value) {
        this.value = value;
    }

}
