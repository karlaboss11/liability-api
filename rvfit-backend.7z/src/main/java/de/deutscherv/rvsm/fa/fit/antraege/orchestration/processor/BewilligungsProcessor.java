package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDate;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.FACHEREIGNIS;

/**
 * Processor zum Erstellen einer Bewilligung.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class BewilligungsProcessor implements Processor {

    private final AntragRepository antragRepository;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(Exchange exchange) throws Exception {
        Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        antrag.setStatus(AntragStatus.BESCHEID_ABGESCHLOSSEN);
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        verarbeitungsstatusService.saveVerarbeitungsstatus(antrag.getUuid(),
                exchange.getMessage().getHeader(RVFitCamelHeader.VERSANDERGEBNIS,
                        VersandErgebnisDto.class), Art.BEWILLIGUNG);
        Fachereignis fachereignis = null;
        if (PruefergebnisUtils.anspruchsvorausetzungFailed(antrag)) {
            fachereignis = LogUtils.getFachereignis(
                    EreignisTyp.ZWISCHENEREIGNIS_USER,
                    Ereignistext.ANSPRUCHS_PRUEFUNG_DURCHGEFUEHRT,
                    EreignisFreitext.ANSPRUCHS_PRUEFUNG_ERFUELLT_USER,
                    null, antrag, null, jwt, drvMandant
            );

        } else if (PruefergebnisUtils.einrichtungspruefungFailed(antrag)) {
            fachereignis = LogUtils.getFachereignis(
                    EreignisTyp.ZWISCHENEREIGNIS_USER,
                    Ereignistext.EINRICHTUNGS_PRUEFUNG_DURCHGEFUEHRT,
                    EreignisFreitext.EINRICHTUNGS_PRUEFUNG_ERFUELLT_USER,
                    null, antrag, null, jwt, drvMandant
            );
        }
        antrag.setBescheiddatum(LocalDate.now());
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setHeader(FACHEREIGNIS, fachereignis);
        exchange.getMessage().setBody(antrag);

    }
}
