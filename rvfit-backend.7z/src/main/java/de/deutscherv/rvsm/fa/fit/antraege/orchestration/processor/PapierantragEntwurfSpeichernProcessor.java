package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragStatusService;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierAntragEinrichtungUtil;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Ruft {@link AntragStatusService} auf um den Status des Antragsentwurfs zu aktualisieren.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragEntwurfSpeichernProcessor implements Processor {

    /**
     * Routenname zum Speichern eines Papierantragentwurfs.
     */
    public static final String DIRECT_PAPIERANTRAG_ENTWURF_SPEICHERN = "direct:papierantragEntwurfSpeichern";

    private final AntragStatusService antragStatusService;
    private final PapierAntragEinrichtungUtil papierAntragEinrichtungUtil;

    @Override
    public void process(final Exchange exchange) {
        Antrag antrag = Optional.of(exchange)
                .map(Exchange::getMessage)
                .map(msg -> msg.getBody(Antrag.class))
                .orElseThrow(NullPointerException::new);

        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);

        final String aufgabenId = exchange.getMessage().getHeader(RVFitCamelHeader.PUR_AUFGABEN_ID, String.class);
        final Long rehaEinrichtungStartAufId = exchange.getMessage().getHeader(RVFitCamelHeader.REHA_EINRICHTUNG_STARTAUF_ID, Long.class);
        final Long rehaEinrichtungTrainingId = exchange.getMessage().getHeader(RVFitCamelHeader.REHA_EINRICHTUNG_TRAINING_ID, Long.class);

        antrag = papierAntragEinrichtungUtil.ensureSmpIdForSelectedEinrichtungenForAntragInEntwurf(antrag, rehaEinrichtungStartAufId,
                rehaEinrichtungTrainingId);

        final Aufgabe erfassungsAufgabe = Aufgabe.builder()
                .aufgabenArt(AufgabenArt.ANTRAGSERFASSUNG).transaktionId(UUID.randomUUID())
                .vomAufgabenId(aufgabenId)
                .datumErstellung(LocalDateTime.now()).build();
        antrag.addAufgabe(erfassungsAufgabe);

        antragStatusService.setAntragStatus(antrag, AntragStatus.ENTWURF);
    }

}
