package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Utility Klasse um das Schreiben von Regeln zu vereinfachen. Bietet oft genutzte Konstanten und Hilfsmethoden zur erstellung von
 * Regelergebnissen
 *
 * @author e0180041
 */
public final class RegelUtils {

    /**
     * String zur identifiziern der Regeldetails wenn erfüllt.
     */
    public static final String ERFUELLT = "ERFUELLT";
    /**
     * String zur identifiziern der Regeldetails wenn aussteuern.
     */
    public static final String AUSSTEUERN = "AUSSTEUERN";
    /**
     * String zur identifiziern der Regeldetails wenn aussteuern keine Daten.
     */
    public static final String AUSSTEUERN_KEINE_DATEN = "AUSSTEUERN_KEINE_DATEN";
    /**
     * String zur identifiziern der Regeldetails bei aussteren aufgrund falscher Antragsdaten.
     */
    public static final String AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT =
        "AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT";
    /**
     * String zur identifiziern der Regeldetails bei nicht erfüllt Ausstuern.
     */
    public static final String NICHT_ERFUELLT_AUSSTEUERN = "NICHT_ERFUELLT_AUSSTEUERN";
    /**
     * String zur identifiziern der Regeldetails bei nicht erfüllt ablehnen.
     */
    public static final String NICHT_ERFUELLT_ABLEHNEN = "NICHT_ERFUELLT_ABLEHNEN";
    /**
     * String zur identifiziern der Regeldetails bei keinen freien Pletzen.
     */
    public static final String AUSSTEUERN_KEINE_FREIE_PLAETZE = "AUSSTEUERN_KEINE_FREIE_PLAETZE";
    /**
     * String zur identifiziern der Regeldetails bei Distanz mehr als 50 Km.
     */
    public static final String AUSSTEUERN_DISTANZ_MEHR_ALS_50 = "AUSSTEUERN_DISTANZ_MEHR_ALS_50";
    /**
     * String zur identifiziern der Regeldetails bei Aussteuern auf Angfrag.
     */
    public static final String AUSSTEUERN_AUF_ANFRAGE = "AUSSTEUERN_AUF_ANFRAGE";
    /**
     * String zur identifiziern der Regeldetails bei pausiertem Angebot.
     */
    public static final String AUSSTEUERN_ANGEBOT_PAUSIERT = "AUSSTEUERN_ANGEBOT_PAUSIERT";
    /**
     * String zur identifiziern der Regeldetails bei fehlendem Angebot.
     */
    public static final String AUSSTEUERN_KEIN_ANGEBOT = "AUSSTEUERN_KEIN_ANGEBOT";
    /**
     * String zur identifiziern der Regeldetails bei Ungleichheit zwischen Antrags- und Stammdaten.
     */
    public static final String AUSSTEUERN_NICHT_IDENTISCH = "AUSSTEUERN_NICHT_IDENTISCH";
    /**
     * String zur identifiziern der Regeldetails bei nicht fehlerhaftem Gebutsdatum.
     */
    public static final String AUSSTEUERN_GEBURTSDATUM_NICHT_VALIDE =
        "AUSSTEUERN_GEBURTSDATUM_NICHT_VALIDE";

    /**
     * Regeln für den Personendatenabgleich.
     */
    public static final List<RegelName> PERSONENDATENABGLEICH_REGELN =
        Arrays.asList(RegelName.REGEL_ABGLEICH_GEBURTSDATUM, RegelName.REGEL_ABGLEICH_HAUSNUMMER,
            RegelName.REGEL_ABGLEICH_LAND, RegelName.REGEL_ABGLEICH_NACHNAME,
            RegelName.REGEL_ABGLEICH_PLZ, RegelName.REGEL_ABGLEICH_STAATSANGEHOERIGKEIT,
            RegelName.REGEL_ABGLEICH_STRASSE, RegelName.REGEL_ABGLEICH_VORNAME,
            RegelName.REGEL_ABGLEICH_VSNR, RegelName.REGEL_ABGLEICH_WOHNORT);

    /**
     * Regeln für die Anspruchsprüfung.
     */
    public static final List<RegelName> ANSPRUCHSPRUEFUNG_REGELN =
        Arrays.asList(RegelName.REGEL_ANTRAGALTERSRENTE, RegelName.REGEL_ANTRAGEMRENTE,
            RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, RegelName.REGEL_ALTERSTEILZEIT,
            RegelName.REGEL_AUFENTHALT, RegelName.REGEL_BEAMTENEIGENSCHAFT_BEZUEGE,
            RegelName.REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT, RegelName.REGEL_BEZUGALTERSRENTE,
            RegelName.REGEL_BEZUGEMRENTE, RegelName.REGEL_LAUFENDERREHAANTRAG,
            RegelName.REGEL_MASSNAHME, RegelName.REGEL_WARTEZEITPRUEFUNG,
            RegelName.REGEL_WIDERSPRUCHSVERFAHREN, RegelName.REGEL_STAATSANGEHOERIGKEIT);

    private RegelUtils() {
    }

    /**
     * Überprüft ob die Kontoinformationen imRegelkontext gesetzt sind.
     *
     * @param kontext der zu überprüfende Kontext
     * @return true, wenn Kontoinformationen gefunden wurden
     */
    public static boolean kontoInformationenVorhanden(final RegelKontext kontext) {
        return !Optional.ofNullable(kontext).map(RegelKontext::getAntrag)
            .map(Antrag::getKontoinformationen).orElseGet(Collections::emptyList).isEmpty();
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern keine Daten.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisAussteuernKeineDaten(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(AUSSTEUERN_KEINE_DATEN).orElse(AUSSTEUERN_KEINE_DATEN));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Erfüllt.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisErfuellt(final Regel regel) {
        return ergebnis(PruefErgebnis.ERFUELLT, regel.getRegelName(),
            regel.getRegelDetail(ERFUELLT).orElse(ERFUELLT));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisAussteuern(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(AUSSTEUERN).orElse(AUSSTEUERN));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Nicht erfüllt Aussteuern.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisNichtErfuelltAussteuern(final Regel regel) {
        return ergebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(NICHT_ERFUELLT_AUSSTEUERN).orElse(NICHT_ERFUELLT_AUSSTEUERN));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von nicht erfüllt Ablehnen.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisNichtErfuelltAblehnen(final Regel regel) {
        return ergebnis(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN, regel.getRegelName(),
            regel.getRegelDetail(NICHT_ERFUELLT_ABLEHNEN).orElse(NICHT_ERFUELLT_ABLEHNEN));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern Antragsdaten stimmt nicht.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisAussteuernAntragsdatenStimmtNicht(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT)
                .orElse(RegelUtils.AUSSTEUERN_ANTRAGSDATEN_STIMMT_NICHT));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern eine Einrichtung hat ein Angebot auf
     * Anfrage.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungAussteuernAufAnfrage(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_AUF_ANFRAGE)
                .orElse(RegelUtils.AUSSTEUERN_AUF_ANFRAGE));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern eine Einrichtung hat ein Angebot mit keine
     * Freieplaetze.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungAussteuernKeineFreiePlaetze(
        final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE)
                .orElse(RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern eine Einrichtung ist mehr als 50 Kilometer
     * vom Wohnort des Versicherten entfernt.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungMehrAls50KmEntfernt(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_DISTANZ_MEHR_ALS_50)
                .orElse(RegelUtils.AUSSTEUERN_DISTANZ_MEHR_ALS_50));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern eine Einrichtung hat ein Angebot
     * pausiert.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungAussteuernAngebotPausiert(
        final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT)
                .orElse(RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern eine Einrichtung hat kein Angebot.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungAussteuernKeinAngebot(final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_KEIN_ANGEBOT)
                .orElse(RegelUtils.AUSSTEUERN_KEIN_ANGEBOT));
    }

    /**
     * Liefert eine Standart Liste mit einem Element für das Prüfergebnis im Falle von Aussteuern die Einrichtungen für Start- und
     * Trainingsphase sind nicht identisch.
     *
     * @param regel die Regel zur Bereitstellung des Regelnamen und der Regelergebnisse
     * @return eine {@link List} mit einem Element
     */
    public static List<RegelErgebnis> ergebnisEinrichtungAussteuernNichtIdentisch(
        final Regel regel) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, regel.getRegelName(),
            regel.getRegelDetail(RegelUtils.AUSSTEUERN_NICHT_IDENTISCH)
                .orElse(RegelUtils.AUSSTEUERN_NICHT_IDENTISCH));
    }

    /**
     * Erstellt eine Liste mit einem Element des Typs {@link RegelErgebnis}, welches dem {@link PruefErgebnis} und den übergebenen
     * Regelnamen und Details entspricht.
     *
     * @param ergebnis    das Regelergebnis
     * @param regelname   der Regelnmae, welcher zu dem Ergebnis geführt hat
     * @param regeldetail die Detailbeschreibung des Ergebnisses
     * @return eine Liste mit dem {@link RegelErgebnis}r
     */
    public static List<RegelErgebnis> ergebnis(final PruefErgebnis ergebnis,
        final RegelName regelname, final String regeldetail) {
        return List.of(new RegelErgebnis(ergebnis, regelname, regeldetail));
    }

}
