package de.deutscherv.rvsm.fa.fit.azk;

import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;

/**
 * AZK-Exception.
 */
public class AzkException extends RvfitException {

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     */
    public AzkException(String message) {
        super(message);
    }

    /**
     * Konstruktor.
     * @param message Fehlernachricht
     * @param throwable Grund der Exception.
     */
    public AzkException(String message, final Throwable throwable) {
        super(message, throwable);
    }

}
