package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.cronlock.Cronlock;
import de.deutscherv.rvsm.fa.fit.cronlock.CronlockRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.EventNotifierSupport;

import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * Processor zum Setzen eines Cron-Lock.
 */
@ApplicationScoped
@Slf4j
public class CronlockProcessor extends EventNotifierSupport
    implements Processor {
    private static final String CRONLOCK_PROPERTY = "cronlock";
    private final CronlockRepository cronlockRepository;
    private final DrvMandant mandant;

    /**
     * Konstruktor.
     *
     * @param cronlockRepository CronLockRepository
     * @param mandant            DRV-Mandant
     */
    public CronlockProcessor(final CronlockRepository cronlockRepository, final DrvMandant mandant) {
        this.cronlockRepository = cronlockRepository;
        this.mandant = mandant;
        setIgnoreCamelContextEvents(true);
        setIgnoreRouteEvents(true);
        setIgnoreServiceEvents(true);
        setIgnoreExchangeAsyncProcessingStartedEvents(true);
        setupIgnore(true);
        setIgnoreExchangeEvents(false);
        setIgnoreExchangeCompletedEvent(false);
        setIgnoreExchangeFailedEvents(false);
    }

    @Override
    public void process(final Exchange exchange) throws Exception {
        final String cronlock = exchange.getProperty(CRONLOCK_PROPERTY, String.class);
        final Cronlock cl = Cronlock.builder().cronname(cronlock).build();
        try (AutoCloseable ignore = mandant.setInScope("91")) {
            cronlockRepository.persist(cl);
        } catch (Exception e) {
            LOG.info("Cronlock {} bereits gesetzt", cronlock);
            exchange.setRouteStop(true);
        }
    }

    @Override
    public void notify(final CamelEvent event) throws Exception {
        final CamelEvent.ExchangeEvent exchangeEvent = (CamelEvent.ExchangeEvent) event;
        final Exchange ex = exchangeEvent.getExchange();
        final String property = ex.getProperty(CRONLOCK_PROPERTY, String.class);
        if (isBlank(property)) {
            return;
        }
        try (AutoCloseable ignore = mandant.setInScope("91")) {
            if (cronlockRepository.deleteByCronname(property) > 0) {
                LOG.info("Cronlock für [{}] gelöst", property);
            }
        }
    }
}
