package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * Utility-Klasse für Prüfergebnisse.
 */
@Slf4j
@UtilityClass
public class PruefergebnisUtils {

    /**
     * Regeln für den Personendatenabgleich.
     */
    public static final List<RegelName> PERSONENDATENABGLEICH_REGELN =
        List.of(RegelName.REGEL_ABGLEICH_GEBURTSDATUM, RegelName.REGEL_ABGLEICH_HAUSNUMMER,
            RegelName.REGEL_ABGLEICH_LAND, RegelName.REGEL_ABGLEICH_NACHNAME,
            RegelName.REGEL_ABGLEICH_PLZ, RegelName.REGEL_ABGLEICH_STAATSANGEHOERIGKEIT,
            RegelName.REGEL_ABGLEICH_STRASSE, RegelName.REGEL_ABGLEICH_VORNAME,
            RegelName.REGEL_ABGLEICH_VSNR, RegelName.REGEL_ABGLEICH_WOHNORT);
    /**
     * Reglen für die Einrichtungsprüfung.
     */
    public static final List<RegelName> EINRICHTUNG_REGELN =
        List.of(RegelName.REGEL_EINRICHTUNGANGEBOTEINDEUTIG,
            RegelName.REGEL_EINRICHTUNGDURCHFUEHRUNGSARTEINDEUTIG,
            RegelName.REGEL_EINRICHTUNGFREIEPLAETZE, RegelName.REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH,
            RegelName.REGEL_EINRICHTUNG_DISTANZ,
            RegelName.REGEL_AUTO_EINRICHTUNG_ENABLED);

    /**
     * Regeln für die Anspruchsprüfung.
     */
    public static final List<RegelName> ANSPRUCHSVORAUSSETZUNG_REGELN =
        List.of(RegelName.REGEL_ANTRAGALTERSRENTE, RegelName.REGEL_ANTRAGEMRENTE,
            RegelName.REGEL_AKTIVEBESCHAEFTIGUNG, RegelName.REGEL_ALTERSTEILZEIT,
            RegelName.REGEL_AUFENTHALT, RegelName.REGEL_BEAMTENEIGENSCHAFT_BEZUEGE,
            RegelName.REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT, RegelName.REGEL_BEZUGALTERSRENTE,
            RegelName.REGEL_BEZUGEMRENTE, RegelName.REGEL_LAUFENDERREHAANTRAG,
            RegelName.REGEL_MASSNAHME, RegelName.REGEL_WARTEZEITPRUEFUNG,
            RegelName.REGEL_WIDERSPRUCHSVERFAHREN, RegelName.REGEL_STAATSANGEHOERIGKEIT);

    /**
     * Regeln für die Validierung des Freitextes bei der Ablehnung.
     */
    public static final List<RegelName> VALIDIERUNGSREGELN_ABLEHNUNG_FREITEXT =
        List.of(RegelName.REGEL_ANTRAGEMRENTE, RegelName.REGEL_BEZUGEMRENTE,
            RegelName.REGEL_LAUFENDERREHAANTRAG, RegelName.REGEL_WIDERSPRUCHSVERFAHREN);

    private static final String EXCEPTION_PARENT_REGEL_PRUEFERGEBNIS_NOT_FOUND =
        "Gesmant Pruefergebnis wurde nicht gefunden.";

    /**
     * Gibt für einen Antrag das erste Pruefergebnis zurück.
     *
     * @param antrag der Antrag
     * @return das Pruefergebnis des Antrags
     */
    public static AntragPruefergebnis getParentRegelAntragPruefergebnis(final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream()
            .filter(p -> Objects.isNull(p.getRegelName())).findFirst()
            .orElseThrow(() -> new RvfitException(EXCEPTION_PARENT_REGEL_PRUEFERGEBNIS_NOT_FOUND) {
            });
    }

    /**
     * Gibt ein neues Pruefergebnis für eine Regel zu einem Antrag zurück.
     *
     * @param antrag           der Antrag
     * @param updateRegelName  Name der Regel, für die das Ergebnis aktualisiert werden soll
     * @param newPruefErgebnis das neue Pruefergebnis
     * @return das neue Pruefergebnis
     */
    public static PruefErgebnis getNewParentErgebnis(final Antrag antrag,
        final RegelName updateRegelName, final PruefErgebnis newPruefErgebnis) {
        final List<PruefErgebnis> pruefErgebnisse =
            getNewAntragPruefergebnisse(antrag, updateRegelName, newPruefErgebnis).stream()
                .map(AntragPruefergebnis::getErgebnis).distinct().toList();

        // Gesamtergebnis NICHT_ERFUELLT_ABLEHNEN nur wenn keine abweichende Personendaten vorhanden sind
        final boolean personendatenabgleichFailed = personendatenabgleichFailed(antrag);

        if (pruefErgebnisse.contains(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN) && !personendatenabgleichFailed) {
            return PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN;
        } else if (pruefErgebnisse.contains(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)) {
            return PruefErgebnis.AUSSTEUERN;
        } else if (pruefErgebnisse.isEmpty() || pruefErgebnisse.contains(PruefErgebnis.AUSSTEUERN)) {
            return PruefErgebnis.AUSSTEUERN;
        } else {
            return PruefErgebnis.ERFUELLT;
        }
    }

    /**
     * Gibt eine Liste der AntragPruefergebnisse nach der Aktualisierung zurück.
     *
     * @param antrag           der Antrag
     * @param updateRegelName  Name der Regel zur Aktualisierung
     * @param newPruefErgebnis das neue Prüfergebnis
     * @return Liste der Prüfergebnisse zum Antrag
     */
    private List<AntragPruefergebnis> getNewAntragPruefergebnisse(final Antrag antrag,
        final RegelName updateRegelName, final PruefErgebnis newPruefErgebnis) {
        final List<AntragPruefergebnis> newAntragPruefergebnisse = new ArrayList<>();
        for (final RegelName regelName : RegelName.values()) {
            final AntragPruefergebnis currentRegelAntragPruefergebnis =
                getCurrentAntragPruefergebnisByRegelName(antrag, regelName);
            if (Objects.nonNull(currentRegelAntragPruefergebnis)) {
                if (regelName.equals(updateRegelName)) {
                    currentRegelAntragPruefergebnis.setErgebnis(newPruefErgebnis);
                }
                newAntragPruefergebnisse.add(currentRegelAntragPruefergebnis);
            }
        }
        return newAntragPruefergebnisse;
    }

    /**
     * Gibt für einen Antrag zu einer bestimmten Regel das Prüfergebnis zurück.
     *
     * @param antrag    der Antrag
     * @param regelName der Name der Regel
     * @return Prüfergebnis des Antrags zur Regel
     */
    public static AntragPruefergebnis getCurrentAntragPruefergebnisByRegelName(final Antrag antrag,
        final RegelName regelName) {
        final List<AntragPruefergebnis> antragPruefergebnisse =
            getAntragPruefergebnisseByRegelName(antrag, regelName);

        if (antragPruefergebnisse.isEmpty() || antragPruefergebnisse.size() > 2) {
            return null;
        }

        final var createdIsNull = antragPruefergebnisse.stream().filter(a -> Objects.isNull(a.getCreated())).findFirst();
        return createdIsNull.orElseGet(
            () -> antragPruefergebnisse.stream().max(Comparator.comparing(AntragPruefergebnis::getCreated)).orElse(null));

    }

    /**
     * Gibt zu einem Antrag alle Prüfergebnisse für einen bestimmten Regelnamen zurück.
     *
     * @param antrag    der Antrag
     * @param regelName der Name der Regel
     * @return Prüfergebnisse des Antrags zur Regel
     */
    public static List<AntragPruefergebnis> getAntragPruefergebnisseByRegelName(final Antrag antrag,
        final RegelName regelName) {
        return antrag.getAntragPruefergebnisse().stream()
            .filter(p -> Objects.nonNull(p.getRegelName()) && p.getRegelName().equals(regelName))
            .toList();
    }

    /**
     * Prüft, ob die Personendaten fehlgeschlagen ist. Das ist der Fall, wenn das gesamtergebnis AUSSTEUERN ist und das Ergebnis mindestens
     * einer Regel für Abgleich der Personendaten AUSSTEUERN ist.
     *
     * @param ergebnis das Ergebnis der Regelprüfung
     * @return {@code true}, wenn mindestens eine Personendatenabgleichsregel fehlgeschlagen ist.
     */
    public static boolean personendatenabgleichFailed(final RegelErgebnis ergebnis) {
        return isRegelGruppeAussteuern(ergebnis, PERSONENDATENABGLEICH_REGELN);
    }

    /**
     * Prüft, ob die Einrichtungsprüfung fehlgeschlagen ist. Das ist der Fall, wenn das gesamtergebnis AUSSTEUERN ist und das Ergebnis
     * mindestens einer Regel für Einrichtungen AUSSTEUERN ist.
     *
     * @param ergebnis das Ergebnis der Regelprüfung
     * @return {@code true}, wenn mindestens eine Einrichtungsregel fehlgeschlagen ist.
     */
    public static boolean einrichtungspruefungFailed(final RegelErgebnis ergebnis) {
        return isRegelGruppeAussteuern(ergebnis, EINRICHTUNG_REGELN);
    }

    /**
     * Prüft, ob die Anspruchsvoraussetzung fehlgeschlagen ist. Das ist der Fall, wenn das Gesamtergenis AUSSTEUERN ist und das Ergebnis
     * mindestens einer Regel für Anspruchsvoraussetzungen AUSSTEUERN ist.
     *
     * @param ergebnis das Ergebnis der Regelprüfung
     * @return {@code true}, wenn mindestens eine Anspruchspruefung fehlgeschlagen ist.
     */
    public static boolean anspruchsvorausetzungFailed(final RegelErgebnis ergebnis) {
        return isRegelGruppeAussteuern(ergebnis, ANSPRUCHSVORAUSSETZUNG_REGELN);
    }

    /**
     * Prüft, ob eine der Anspruchsvoraussetzungen den Status NICHT_ERFUELLT_ABLEHNEN hat.
     *
     * @param ergebnis das Ergebnis der Regelprüfung
     * @return {@code true}, wenn mindestens eine Anspruchspruefung NICHT_ERFUELLT_ABLEHNEN ist.
     */
    public static boolean anspruchsvorausetzungAblehnen(final RegelErgebnis ergebnis) {
        return isRegelGruppeAblehnen(ergebnis, ANSPRUCHSVORAUSSETZUNG_REGELN);
    }

    /**
     * Prüft, ob das Regelergebnis Aussteuern ist und mindestens eine der Regeln, für die aussgesteuert werden soll, in der Regelgruppe zum
     * Aussteuern enthalten ist.
     *
     * @param ergebnis    ein RegelErgebnis
     * @param regelGruppe eine Liste von Regeln
     * @return true, falls das PruefErgebnis Aussteuern ergibt und eine der Regeln in der Regelgruppe zu Aussteuern enthalten ist, ansonsten
     * false
     */
    private boolean isRegelGruppeAussteuern(final RegelErgebnis ergebnis,
        final List<RegelName> regelGruppe) {
        if (ergebnis.getPruefErgebnis() != PruefErgebnis.AUSSTEUERN) {
            return false;
        }
        return ergebnis.getDetailErgebnisse().stream()
            .filter(detail -> detail.getPruefErgebnis() == PruefErgebnis.AUSSTEUERN
                || detail.getPruefErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)
            .map(RegelErgebnis::getRegelName).anyMatch(regelGruppe::contains);
    }

    private boolean isRegelGruppeAblehnen(final RegelErgebnis ergebnis,
        final List<RegelName> regelGruppe) {
        if (ergebnis.getPruefErgebnis() != PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN) {
            return false;
        }
        return ergebnis.getDetailErgebnisse().stream()
            .filter(detail -> detail.getPruefErgebnis() == PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN)
            .map(RegelErgebnis::getRegelName).anyMatch(regelGruppe::contains);
    }

    /**
     * Prüft, ob mindestens ein PERSONENDATENABGLEICH_REGEL in dem übergebenen Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     *
     * @param antrag ein Antrag
     * @return true, wenn mindestens ein PERSONENDATENABGLEICH_REGEL zu dem Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     */
    public static boolean personendatenabgleichFailed(final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> pruefergebnis.getRegelName() != null
                && PERSONENDATENABGLEICH_REGELN.contains(pruefergebnis.getRegelName()))
            .anyMatch(pruefergebnis ->
                pruefergebnis.getErgebnis() == PruefErgebnis.AUSSTEUERN
                    || pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
    }

    /**
     * Prüft, ob mindestens ein PERSONENDATENABGLEICH_REGEL in dem übergebenen Ergebnissen AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     *
     * @param ergebnisse die Liste der RegelErgebnisse
     * @return true, wenn mindestens ein PERSONENDATENABGLEICH_REGEL zu dem Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     */
    public static boolean personendatenabgleichFailed(final List<RegelErgebnis> ergebnisse) {
        return ergebnisse.stream()
            .filter(pruefergebnis -> pruefergebnis.getRegelName() != null
                && PERSONENDATENABGLEICH_REGELN.contains(pruefergebnis.getRegelName()))
            .anyMatch(pruefergebnis ->
                pruefergebnis.getPruefErgebnis() == PruefErgebnis.AUSSTEUERN
                    || pruefergebnis.getPruefErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
    }

    /**
     * Prüft, ob mindestens ein EINRICHTUNG_REGELN in dem übergebenen Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     *
     * @param antrag ein Antrag
     * @return true, wenn mindestens ein EINRICHTUNG_REGELN zu dem Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     */
    public static boolean einrichtungspruefungFailed(final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> pruefergebnis.getRegelName() != null
                && EINRICHTUNG_REGELN.contains(pruefergebnis.getRegelName()))
            .anyMatch(pruefergebnis ->
                pruefergebnis.getErgebnis() == PruefErgebnis.AUSSTEUERN
                    || pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
    }

    /**
     * Prüft, ob mindestens ein ANSPRUCHSVORAUSSETZUNG_REGELN in dem übergebenen Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     *
     * @param antrag ein Antrag
     * @return true, wenn mindestens ein ANSPRUCHSVORAUSSETZUNG_REGELN zu dem Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     */
    public static boolean anspruchsvorausetzungFailed(final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> pruefergebnis.getRegelName() != null
                && ANSPRUCHSVORAUSSETZUNG_REGELN.contains(pruefergebnis.getRegelName()))
            .anyMatch(pruefergebnis ->
                pruefergebnis.getErgebnis() == PruefErgebnis.AUSSTEUERN
                    || pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN);
    }

    /**
     * Prüft, ob mindestens ein VALIDIERUNGSREGELN_ABLEHNUNG_FREITEXT in dem übergebenen Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN
     * ist.
     *
     * @param antrag ein Antrag
     * @return true, wenn mindestens ein VALIDIERUNGSREGELN_ABLEHNUNG_FREITEXT zu dem Antrag AUSSTEUERN oder NICHT_ERFUELLT_AUSSTEUERN ist.
     */
    public static boolean pruefergebnisErfordertFreitextEingabe(final Antrag antrag) {
        if (antrag == null) {
            return false;
        }

        final List<AntragPruefergebnis> pruefergebnisse = Optional.ofNullable(antrag.getAntragPruefergebnisse()).orElse(List.of());

        if (pruefergebnisse.isEmpty()) {
            return false;
        }

        return pruefergebnisse.stream()
            .filter(pruefergebnis -> pruefergebnis.getBegruendung() != null
                && !pruefergebnis.getBegruendung().isEmpty()
                && pruefergebnis.getRegelName() != null)
            .filter(pruefergebnis -> pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN
                || pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN)
            // Keep the most recent using lastModified as the key.
            .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName)).values().stream()
            .map(gruppe -> gruppe.stream()
                .max(Comparator.comparing(AntragPruefergebnis::getLastModified,
                    Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null))
            .filter(Objects::nonNull)
            // Only look at the most important rule
            .min(Comparator.comparing(AntragPruefergebnis::getPrioritaet,
                Comparator.nullsLast(Comparator.naturalOrder())))
            .filter(pruefergebnis -> VALIDIERUNGSREGELN_ABLEHNUNG_FREITEXT.contains(pruefergebnis.getRegelName()))
            .isPresent();
    }
}
