package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungAussteuernKeinAngebot;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungAussteuernNichtIdentisch;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * The Regel Class EinrichtungVorhandenUndIdentisch.
 */
@Singleton
public class EinrichtungVorhandenUndIdentisch extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(RegelUtils.ERFUELLT,
            "Die Einrichtungsdaten für Startphase und die Trainingsphase sind identisch.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN,
            "Es wurden keine Daten für die Einrichtung der Start- oder Trainingsphase angegeben.",
            RegelUtils.AUSSTEUERN_KEIN_ANGEBOT,
            "Die Einrichtung der Start- oder Trainingsphase wurde nicht gefunden.",
            RegelUtils.AUSSTEUERN_NICHT_IDENTISCH,
            "Die Einrichtungsdaten für Startphase und die Trainingsphase sind nicht identisch.");

    /**
     * Gets the regel name.
     *
     * @return the regel name
     */
    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH;
    }

    /**
     * Gets the regel detail.
     *
     * @param regelErgebnis the regel ergebnis
     * @return the regel detail
     */
    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    /**
     * Pruefe regel.
     *
     * @param kontext the kontext
     * @return the RegelErgebnis list
     */
    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!EinrichtungsdatenUtils.alleEinrichtungenVorhanden(kontext.getAntrag())) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (Objects.isNull(kontext.getStartphaseEinrichtungen())
                || kontext.getStartphaseEinrichtungen().isEmpty() || Objects.isNull(
                kontext.getAuffrishungsphaseEinrichtungen())
                || kontext.getAuffrishungsphaseEinrichtungen().isEmpty() || Objects.isNull(
                kontext.getTrainingsphaseEinrichtungen())
                || kontext.getTrainingsphaseEinrichtungen().isEmpty()) {
            return ergebnisEinrichtungAussteuernKeinAngebot(this);
        }
        if (!isAlleEinrichtungenIdentisch(kontext.getStartphaseEinrichtungen(),
                kontext.getAuffrishungsphaseEinrichtungen(),
                kontext.getTrainingsphaseEinrichtungen())) {
            return ergebnisEinrichtungAussteuernNichtIdentisch(this);
        }
        return ergebnisErfuellt(this);
    }


    /**
     * Prüft, ob alle Einrichtungen identisch sind.
     *
     * @param einrichtungenStart Einrichtungen Startphase
     * @param einrichtungenAuffrischung Einrichtungen Auffrischungsphase
     * @param einrichtungenTraining Einrichtungen Trainingsphase
     * @return <code>true</code>, falls alle Einrichtungen identisch sind, ansonsten <code>false</code>
     */
    private boolean isAlleEinrichtungenIdentisch(final List<RehaEinrichtung> einrichtungenStart,
            final List<RehaEinrichtung> einrichtungenAuffrischung,
            final List<RehaEinrichtung> einrichtungenTraining) {
        if (Objects.isNull(einrichtungenStart) || Objects.isNull(einrichtungenAuffrischung)
                || Objects.isNull(einrichtungenTraining)) {
            return false;
        }
        final List<Long> getStartSmpEinrichtungsIds = getSmpEinrichtungsIds(einrichtungenStart);
        final List<Long> getAuffrischungSmpEinrichtungsIds =
                getSmpEinrichtungsIds(einrichtungenAuffrischung);
        final List<Long> getTrainingSmpEinrichtungsIds =
                getSmpEinrichtungsIds(einrichtungenTraining);
        return getStartSmpEinrichtungsIds.stream()
                .anyMatch(getAuffrischungSmpEinrichtungsIds::contains)
                && getStartSmpEinrichtungsIds.stream()
                .anyMatch(getTrainingSmpEinrichtungsIds::contains);
    }

    private List<Long> getSmpEinrichtungsIds(final List<RehaEinrichtung> einrichtungen) {
        final List<Long> smpEinrichtungsIds = new ArrayList<>();
        einrichtungen.forEach(e -> smpEinrichtungsIds.add(e.getSmpEinrichtungsId()));
        return smpEinrichtungsIds;
    }
}
