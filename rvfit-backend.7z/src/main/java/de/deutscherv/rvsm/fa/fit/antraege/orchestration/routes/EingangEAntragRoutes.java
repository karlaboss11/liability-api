package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.EantragEingangFachprotokollProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.antraege.util.ValidationUtil;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import de.deutscherv.rvsm.fa.fit.util.VsnrValidator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes.DIRECT_ERROR;
import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * Routen fuer den Eingang von eAntraegen.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class EingangEAntragRoutes extends RouteBuilder {
    /**
     * Routenname zum Initialisieren eine eAntrag.
     */
    public static final String DIRECT_INIT_EANTRAG = "direct:initEantrag";
    /**
     * Routenname zur Vollverarbeitung.
     */
    public static final String DIRECT_VOLLVERARBEITUNG = "direct:vollverarbeitung";
    /**
     * Routennamen zum ersten Beladen.
     */
    public static final String DIRECT_ERSTES_BELADEN = "direct:erstesBeladen";
    /**
     * Routennamen zum Erstellen von Fachprotokolleinträgen für den Antragseingang.
     */
    public static final String DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG = "direct:fachprotokollEantragEingang";

    private static final String UNGUELTIGE_VSNR_ERROR_MSG =
            "Der eAntrag hat eine ungueltige vsnr: [{}]";

    private final RequestContextController requestContext;

    private final EantragEingangFachprotokollProcessor eantragEingangFachprotokollProcessor;

    @Override
    public void configure() throws Exception {
        //@formatter:off
        from(DIRECT_INIT_EANTRAG)
            .routeId(DIRECT_INIT_EANTRAG)
            .log(LoggingLevel.DEBUG, LOG, "eantrag UUID HEADER ${header.rvfit_uuid}")
            .trace(true)
            .to(DIRECT_ERSTES_BELADEN)
            .to(DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG)
            .choice()
            .when().method(VsnrValidator.class, "isValidVsnr(${body.vsnr})").endChoice()
            .otherwise()
            .process(exchange -> {
                var antrag = exchange.getMessage().getBody(Antrag.class);
                LOG.atError().addArgument(antrag.getVsnr()).log(UNGUELTIGE_VSNR_ERROR_MSG);
                final var antragsbestaetigung = exchange.getMessage().getHeader("antragsbestaetigung",
                        EantragsBestaetigungDTO.class);
                final var jwt = exchange.getMessage().getHeader("jwt",
                        JsonWebToken.class);
                antragsbestaetigung.geteAntragDaten().setFehlerNummer(UNGUELTIGE_VSNR_ERROR_MSG);
                antragsbestaetigung.geteAntragDaten().setFehlerText(UNGUELTIGE_VSNR_ERROR_MSG);
                exchange.getMessage().setHeader("antragsbestaetigung", antragsbestaetigung);

                throw new EingabevalidierungException(AntragService.class.getName(),
                        GET_DRV_ID_AUS_JWT.apply(jwt), UNGUELTIGE_VSNR_ERROR_MSG);
            }).end()
            .to(DIRECT_VOLLVERARBEITUNG);

        from(DIRECT_VOLLVERARBEITUNG)
            .routeId(DIRECT_VOLLVERARBEITUNG)
            .trace(true)
            .process(ex -> {
                LOG.trace("Activating RequestContext.");
                requestContext.activate();
            }).id("activate Request Context")
            .to(RouteNames.DIRECT_EXTRACT_MANDANT)
            .doTry()
                .to(RouteNames.RVFIT_STATUS_BASED_ROUTING)
            .endDoTry()
            .doCatch(Exception.class)
                .log(LoggingLevel.WARN, LOG, "${body.uuid} : ${body}")
                .to(DIRECT_ERROR)
            .end();

        from(DIRECT_ERSTES_BELADEN)
            .routeId(DIRECT_ERSTES_BELADEN)
            .transacted()
            .to(MappingRoutes.DIRECT_UNMARSHAL_EANTRAG)
            .setHeader("valideAntragsversion", method(ValidationUtil.class, "pruefeAntragsVersion"))
            .setHeader(RVFitCamelHeader.ANTRAGSDATEN, body())
            .to(MappingRoutes.DIRECT_MAP_ANTRAGSDATEN_TO_EANTRAG)
            .to(RouteNames.DIRECT_EXTRACT_MANDANT)
            .to(RouteNames.DIRECT_SAVE_EANTRAG);

        from(DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG)
            .routeId(DIRECT_FACHPROTOKOLL_EANTRAG_EINGANG)
            .transacted()
            .process(ex -> {
                LOG.trace("Activating RequestContext.");
                requestContext.activate();
            }).id("activate Request Context")
            .to(DIRECT_EXTRACT_MANDANT)
            .process(eantragEingangFachprotokollProcessor);
        //@formatter:on

    }
}
