package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * Ermitteln von Informationen zu Regeln.
 */
@Singleton
public class BemerkungRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "Es liegt keine Bemerkung im Antrag vor.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.AUSSTEUERN, "Es liegt eine Bemerkung im Antrag vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_BEMERKUNG;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {

        if (Objects.isNull(kontext.getAntrag())) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final boolean keinBemerkungInAntrag = kontext.getAntrag().getBemerkungen() == null
                || kontext.getAntrag().getBemerkungen().isEmpty();

        if (keinBemerkungInAntrag) {
            return ergebnisErfuellt(this);
        }

        return ergebnisAussteuern(this);

    }
}
