package de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Erweitert den Eantrag um die Einrichtugnen aus dem SMP.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class SMPEinrichtungsEnricher implements Processor {

    private final SelbstmeldeportalService selbstmeldeportalService;
    private final AntragRepository repository;
    private final RvfitLogger rvfitLogger;
    private final DrvMandant drvMandant;
    private final JsonWebToken jwt;

    @Override
    public void process(final Exchange exchange) throws Exception {
        Antrag body = exchange.getMessage().getBody(Antrag.class);
        LOG.atInfo().addArgument(body.getUuid()).addArgument(body.getVsnr())
                .log("SMPEinrichtungsEnricher wird aufgerufen. UUID [{}] VSNR [{}]");
        var antrag = selbstmeldeportalService.setSmpEinrichtungen(body);
        LOG.atInfo()
                .addArgument(Optional.ofNullable(body)
                        .map(Antrag::getEinrichtungTrainingObjekt)
                        .map(RehaEinrichtung::getSmpEinrichtungsId))
                .addArgument(body.getUuid())
                .addArgument(body.getVsnr())
                .log("SMP Training ID [{}]. UUID [{}] VSNR [{}]");
        antrag = repository.merge(antrag);
        repository.flush();
        LOG.atInfo().addArgument(body.getUuid()).addArgument(body.getVsnr())
                .log("Synchronisation abgeschlossen. UUID [{}] VSNR [{}]");
        exchange.getMessage().setBody(antrag);

        if (antrag.getEinrichtungStartObjekt() != null || antrag.getEinrichtungTrainingObjekt() != null) {
            rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                    EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                    Ereignistext.EINRICHTUNGSDATEN_GESPEICHERT,
                    EreignisFreitext.EINRICHTUNGSDATEN_GESPEICHERT,
                    null,
                    antrag,
                    null,
                    jwt,
                    drvMandant
            ));
        }

    }
}
