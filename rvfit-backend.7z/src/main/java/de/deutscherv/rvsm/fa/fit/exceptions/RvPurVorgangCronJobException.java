package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * RvPurVorgangCronJobException.
 */
public class RvPurVorgangCronJobException extends RvfitException {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Fehlergrund
     */
    public RvPurVorgangCronJobException(String message, Throwable cause) {
        super(message, cause);
    }
}
