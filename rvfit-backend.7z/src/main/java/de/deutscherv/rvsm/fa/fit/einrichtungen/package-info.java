/**
 * Beinhaltet Klassen, die sich mit Einrichtungen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.einrichtungen;
