package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;

import static java.util.Objects.nonNull;

/**
 * PapierAntrachEinrichtungUtil.
 */
@RequiredArgsConstructor
@ApplicationScoped
public class PapierAntragEinrichtungUtil {

    private final SelbstmeldeportalService selbstmeldeportalService;

    /**
     * Die Einrichtungen aus dem PapierantragDTO werden in den Papierantrag uebernommen.
     *
     * @param papierantragDto aus dem die Einrichtungen ermittelt werden
     * @param papierAntrag    in das die Einrichtungen uebernommen werden
     * @return Antrag mit den Einrichtungen
     */
    public Antrag getAntragMitEinrichtung(final PapierantragDto papierantragDto,
            final Antrag papierAntrag) {

        // akzeptiere Eingaben ohne Einrichtung
        if (papierantragDto.getEinrichtung1() == null
                && papierantragDto.getEinrichtung2() == null) {
            return papierAntrag;
        }

        if (papierantragDto.getEinrichtung1() != null) {
            final Long rehaEinrichtungIdStart =
                    papierantragDto.getEinrichtung1().getSelbstmeldeportalId();

            if (rehaEinrichtungIdStart != null) {
                final RehaEinrichtung startRehaEinrichtung = selbstmeldeportalService
                        .getEinrichtungById(rehaEinrichtungIdStart)
                        .orElseThrow(() -> new RuntimeException(
                                "Dem Antrag zugehoerige Einrichtung fuer Startphase wurde nicht gefunden!"));

                final RehaEinrichtung aufRehaEinrichtung = selbstmeldeportalService
                        .getEinrichtungById(rehaEinrichtungIdStart)
                        .orElseThrow(() -> new RuntimeException(
                                "Dem Antrag zugehoerige Einrichtung fuer Auffrischungsphase wurde nicht gefunden!"));

                final RehaEinrichtung eindeutigeEinrichtungStart =
                        selbstmeldeportalService.eindeutigeEinrichtungMitStartphase(PhaseEnumDto.STARTPHASE, startRehaEinrichtung);

                final RehaEinrichtung eindeutigeEinrichtungAuf =
                        selbstmeldeportalService.eindeutigeEinrichtungMitStartphase(PhaseEnumDto.AUFFRISCHUNG, aufRehaEinrichtung);

                if (nonNull(eindeutigeEinrichtungStart) && nonNull(eindeutigeEinrichtungAuf)) {
                    papierAntrag.setEinrichtungStartObjekt(eindeutigeEinrichtungStart);
                    papierAntrag.setEinrichtungAufObjekt(eindeutigeEinrichtungAuf);
                }
            }
        }

        if (papierantragDto.getEinrichtung2() != null) {
            final Long rehaEinrichtungIdTraining =
                    papierantragDto.getEinrichtung2().getSelbstmeldeportalId();

            if (rehaEinrichtungIdTraining != null) {
                final RehaEinrichtung trainingRehaEinrichtung = selbstmeldeportalService
                        .getEinrichtungById(rehaEinrichtungIdTraining)
                        .orElseThrow(() -> new RuntimeException(
                                "Dem Antrag zugehoerige Einrichtung fuer Training wurde nicht gefunden!"));

                EinrichtungsdatenUtils.deleteAngeboteOhneFreiePlaetzeFromEinrichtung(PhaseEnumDto.TRAININGSPHASE,
                        trainingRehaEinrichtung);

                if (trainingRehaEinrichtung.getAngebote().size() == 1) {
                    papierAntrag.setEinrichtungTrainingObjekt(trainingRehaEinrichtung);
                }
            }
        }

        return papierAntrag;

    }

    /**
     * Beim Speichern eines Entwurfs werden, aufgrund von nicht eindeutigen Angeboten, die Einrichtungen nicht richtig gespeichert.
     * Dementsprechend werden die Einrichtungen, nach dem Neuladen des Entwurfs, nicht richtig im Frontend angezeigt. Diese Methode ist ein
     * Workaround um temporär SMP-Id's zu vergeben, damit nach dem Neuladen des Entwurfs die Einrichtungen angezeigt werden. Dies hat später
     * bei der eigentlichen Verarbeitung keine Auswirkungen, da der Entwurf vorher gelöscht wird.
     *
     * @param antrag                    betroffener Antrag
     * @param rehaEinrichtungStartAufId Einrichtung fuer Start- und Auftrischungsphase.
     * @param rehaEinrichtungTrainingId Einrichtung fuer Trainingsphase
     * @return angepasster Antrag
     */
    public Antrag ensureSmpIdForSelectedEinrichtungenForAntragInEntwurf(final Antrag antrag, final Long rehaEinrichtungStartAufId,
            final Long rehaEinrichtungTrainingId) {

        if (antrag.getAngebotStartName() != null && antrag.getAngebotStartSmpId() == null) {
            Optional<RehaEinrichtung> rehaEinrichtung = selbstmeldeportalService.getEinrichtungById(rehaEinrichtungStartAufId);
            if (rehaEinrichtung.isPresent()) {
                final List<Angebot> angebote = rehaEinrichtung.get().getAngebote();
                antrag.setAngebotStartSmpId(angebote.getFirst().getSmpAngebotId());
                antrag.setEinrichtungStartObjekt(rehaEinrichtung.get());
            }
        }

        if (antrag.getAngebotTrainingName() != null && antrag.getAngebotTrainingSmpId() == null) {
            Optional<RehaEinrichtung> rehaEinrichtung = selbstmeldeportalService.getEinrichtungById(rehaEinrichtungTrainingId);
            if (rehaEinrichtung.isPresent()) {
                final List<Angebot> angebote = rehaEinrichtung.get().getAngebote();
                antrag.setAngebotTrainingSmpId(angebote.getFirst().getSmpAngebotId());
                antrag.setEinrichtungTrainingObjekt(rehaEinrichtung.get());
            }
        }
        return antrag;
    }
}
