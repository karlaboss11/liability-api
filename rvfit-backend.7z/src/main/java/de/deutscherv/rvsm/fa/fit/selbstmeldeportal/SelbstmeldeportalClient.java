package de.deutscherv.rvsm.fa.fit.selbstmeldeportal;

import de.deutscherv.rvsm.fa.fit.security.SelbstmeldeportalBasicAuthFilter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Rest Client für das Selbstmeldeprotal.
 */
@ApplicationScoped
@RegisterProvider(SelbstmeldeportalBasicAuthFilter.class)
@RegisterRestClient(configKey = "selbstmeldeportal")
@Path("/nachderreha-api/rvfit/v2")
public interface SelbstmeldeportalClient {

    /**
     * Gibt alle Einrichtungen zurück.
     *
     * @return die Einrichtungen
     */
    @GET
    @Path("/einrichtungen/all")
    @Produces(MediaType.APPLICATION_JSON)
    Response getAlleEinrichtungen();

    /**
     * Gibt alle Einrichtungen zurück.
     *
     * @param durchfuehrungsart Durchfuehrungsart
     * @param ort               Ort
     * @param phase             Phase
     * @param plz               Postleitzahl
     * @param plzVersicherter   Postleitzahl Versicherter.
     * @param umkreis           Umkreis in km.
     * @return die Einrichtungen
     */
    @GET
    @Path("/einrichtungen")
    @Produces(MediaType.APPLICATION_JSON)
    Response getEinrichtungen(@QueryParam("plz") final String plz,
            @QueryParam("plz-versicherter") final String plzVersicherter,
            @QueryParam("ort") final String ort, @QueryParam("umkreis") final Integer umkreis,
            @QueryParam("phase") final Integer phase,
            @QueryParam("durchfuehrungsart") final Integer durchfuehrungsart);
}
