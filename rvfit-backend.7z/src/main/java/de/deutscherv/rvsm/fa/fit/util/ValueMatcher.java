package de.deutscherv.rvsm.fa.fit.util;

import lombok.Builder;
import lombok.Getter;

/**
 * Die Klasse dient zur Überprüfung, ob die angegebenen Werte auf Gleichheit übereinstimmen.
 */
@Builder
@Getter
public class ValueMatcher {

    private String firstValue;
    private String firstExpected;
    private String secondValue;
    private String secondExpected;

    /**
     * Überprüft, ob eines der beiden Paare von Werten übereinstimmt.
     *
     * @return true, wenn entweder das erste oder das zweite Paar übereinstimmt<p>
     *  false, wenn keine Übereinstimmung vorliegt
     */
    public boolean matches() {
        return (firstValue != null && firstValue.trim().equals(firstExpected)) ||
                (secondValue != null && secondValue.trim().equals(secondExpected));
    }
}
