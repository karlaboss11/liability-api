/**
 * Beinhaltet JPA Entities für Anträge.
 */
package de.deutscherv.rvsm.fa.fit.antraege.model;
