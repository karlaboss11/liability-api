package de.deutscherv.rvsm.fa.fit.util;

import lombok.Getter;

/**
 * Mapping von KTAN und Namen aller DRV-Tröger.
 */
@Getter
public enum MetricNames {

    /**
     * Metrikname fuer eingehende eAntraege.
     */
    EINGEHENDE_E_ANTRAEGE("eingehende_eAntrage"),

    /**
     * Metrikname fuer eingehende Papierantraege.
     */
    EINGEHENDE_PAPIERANTRAEGE("eingehende_papierAntrage"),

    /**
     * Metrikname fuer Ergebnisse der Regelpruefung.
     */
    ERGEBNIS_REGELPRUEFUNG("ergebnis_regelpruefung"),

    /**
     * Metrikname fuer Verarbeitungsdaur von eAntraegen.
     */
    E_ANTRAG_DAUER("eAntrag_dauer"),

    /**
     * Metrikname fuer Verarbeitungsdaur von Papierantraegen.
     */
    PAPIERANTRAG_DAUER("papierAntrag_dauer");

    final String name;

    MetricNames(final String name) {
        this.name = name;
    }
}
