package de.deutscherv.rvsm.fa.fit.regelpruefung.mapper;

import de.deutscherv.rvsm.fa.fit.openapi.model.RegelNameDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

/**
 * RegelNameMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface RegelNameMapper {

    /**
     * Mappt den Namen der Regel.
     *
     * @param regelName der Name Regel
     * @return der Name der Regel für das Frontend
     */
    RegelNameDto toDto(RegelName regelName);

    /**
     * Mappt den Regelnamen aus dem Frontend.
     *
     * @param dto der Regelname aus dem Frontend
     * @return der Regelname
     */
    @InheritInverseConfiguration
    RegelName toEntity(RegelNameDto dto);
}
