package de.deutscherv.rvsm.fa.fit.kontoinformation.model;

import lombok.Builder;
import lombok.Data;

/**
 * Request Dto.
 *
 * @author V215169
 */
@Data
@Builder
public class FehlerEintrag {
    private String statuscode;
    private String message;
}
