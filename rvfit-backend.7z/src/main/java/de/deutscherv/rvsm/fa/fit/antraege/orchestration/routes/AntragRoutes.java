package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.KontoinformationEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.SMPEinrichtungsEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.StammdatenEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.AntragsdatenAktualisierungProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.AutomatischeBescheiderstellungsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.BescheiderstellungFachprotokollProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.BewilligungsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.DoppelvergabeProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.ErstelleRVDialogFehlerAufgabeProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.MandantFromEantragExtractor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.MergeEantragsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.MetricRegelpruefungProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PDFArchiveProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PersonendatenableichProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.RegelpruefungsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.SaveEantragsProccessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.SchliesseAufgabenProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.SchliesseStatistikAbProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.StatistikErfassungsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.Vorgangserzeuger;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.VorgangskennungProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SensitiveCreateLogProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;

import static de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes.DIRECT_ERROR;
import static org.apache.camel.support.builder.PredicateBuilder.or;

/**
 * Definition von Routen fuer die Antragsbearbeitung.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class AntragRoutes extends RouteBuilder {

    private static final String BODY = "${body}";
    private final MandantFromEantragExtractor mandantExtractor;
    private final SMPEinrichtungsEnricher smpEinrichtungsEnricher;
    private final AntragRepository antragRepository;
    private final RegelpruefungsProcessor regelpruefungsProcessor;
    private final Vorgangserzeuger vorgangserzeuger;
    private final StatistikErfassungsProcessor statistikErfassungsProcessor;
    private final SaveEantragsProccessor saveEantragsProcessor;
    private final MergeEantragsProcessor mergeEantragsProccesssor;
    private final StammdatenEnricher stammdatenEnricher;
    private final PDFArchiveProcessor pdfArchiveProcessor;
    private final AutomatischeBescheiderstellungsProcessor automatischeBEscheiderstellungsProcessor;
    private final DoppelvergabeProcessor doppelvergabeProcessor;
    private final KontoinformationEnricher kontoinformationEnricher;
    private final SchliesseAufgabenProcessor schliesseAufgabenProcessor;
    private final SchliesseStatistikAbProcessor schliesseStatistikAbProcessor;
    private final ErstelleRVDialogFehlerAufgabeProcessor erstelleRVDialogFehlerAufgabeProcessor;
    private final PersonendatenableichProcessor personendatenableichProcessor;
    private final AntragsdatenAktualisierungProcessor antragsdatenAktualisierungProcessor;
    private final MetricRegelpruefungProcessor metricRegelpruefungProcessor;
    private final SensitiveCreateLogProcessor sensitiveCreateLogProcessor;
    private final BewilligungsProcessor bewilligungsProcessor;
    private final VorgangskennungProcessor vorgangskennungProcessor;
    private final RvfitLogger rvfitLogger;
    private final BescheiderstellungFachprotokollProcessor bescheiderstellungFachprotokollProcessor;

    @Override
    public void configure() throws Exception {
        // @formatter:off
        from(RouteNames.DIRECT_CONTINUE_DOPPELVERGABE)
                .routeId(RouteNames.DIRECT_CONTINUE_DOPPELVERGABE)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .to(RouteNames.DIRECT_EXTRACT_MANDANT)
                .to(RouteNames.DIRECT_SCHLIESSE_OFFENE_AUFGABEN)
                .wireTap(EingangEAntragRoutes.DIRECT_VOLLVERARBEITUNG);

        from(RouteNames.DIRECT_EXTRACT_MANDANT)
                .routeId(RouteNames.DIRECT_EXTRACT_MANDANT)
                .process(mandantExtractor);

        from(RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG)
                .routeId(RouteNames.DIRECT_GENERATE_VORGANGSKENNUNG)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .routeDescription("Generiert eine Vorgangskennung zu einem Antrag")
                .transacted()
                .process(vorgangskennungProcessor);

        from(RouteNames.DIRECT_SETSMP_EINRICHTUNGEN)
                .routeId(RouteNames.DIRECT_SETSMP_EINRICHTUNGEN)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .routeDescription("Setzt die Selbstmeldeport Einrichtungen in einem Antrag anhand der Antragsdaten")
                .transacted()
                .process(smpEinrichtungsEnricher);

        from(RouteNames.DIRECT_SAVE_EANTRAG)
                .transacted()
                .routeId(RouteNames.DIRECT_SAVE_EANTRAG)
                .routeDescription("Speichert einen EAntrag")
                .process(saveEantragsProcessor);

        from(RouteNames.DIRECT_MERGE_EANTRAG)
                .transacted()
                .routeId(RouteNames.DIRECT_MERGE_EANTRAG)
                .routeDescription("Updatet einen EAntrag")
                .process(mergeEantragsProccesssor);

        from(RouteNames.DIRECT_FETCH_STAMMDATEN)
                .routeId(RouteNames.DIRECT_FETCH_STAMMDATEN)
                .transacted()
                .process(stammdatenEnricher);

        from(RouteNames.DIRECT_ERSTELLE_VORGANG)
                .routeId(RouteNames.DIRECT_ERSTELLE_VORGANG)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .transacted()
                .process(vorgangskennungProcessor)
                .process(vorgangserzeuger);

        from(RouteNames.DIRECT_CHECK_VORGANG)
                .routeId(RouteNames.DIRECT_CHECK_VORGANG)
                .process(x -> {
                    final var antrag = x.getMessage().getBody(Antrag.class);
                    antrag.setStatus(AntragStatus.VORGANG_ERZEUGT);
                    antragRepository.merge(antrag);
                });

        from(RouteNames.DIRECT_ERFASSE_STATISTIK)
            .routeId(RouteNames.DIRECT_ERFASSE_STATISTIK)
            .errorHandler(deadLetterChannel(DIRECT_ERROR))
            .transacted()
            .process(statistikErfassungsProcessor);

        from(RouteNames.DIRECT_CHECK_DOPPELVERGABE)
                .routeId(RouteNames.DIRECT_CHECK_DOPPELVERGABE)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .transacted()
                .to(RouteNames.DIRECT_EXTRACT_MANDANT)
                .process(doppelvergabeProcessor);

        from(RouteNames.DIRECT_PRUEFE_REGELN)
                .routeId(RouteNames.DIRECT_PRUEFE_REGELN)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .transacted()
                .process(regelpruefungsProcessor)
                .process(metricRegelpruefungProcessor)
                .to(MetricRouteDefinitions.METRIC_COUNTER_ERGEBNIS_REGELPRUEFUNG);

        from(RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN)
                .routeId(RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN)
                .transacted()
                .process(kontoinformationEnricher);

        from(RouteNames.DIRECT_CREATE_PDF_ARCHIVE)
                .routeId(RouteNames.DIRECT_CREATE_PDF_ARCHIVE)
                .transacted()
                .process(pdfArchiveProcessor);

        from(RouteNames.DIRECT_OHNE_BESCHEID_ROUTING)
                .routeId(RouteNames.DIRECT_OHNE_BESCHEID_ROUTING)
                .log(BODY);

        from(RouteNames.DIRECT_ERSTELLE_BESCHEID)
                .routeId(RouteNames.DIRECT_ERSTELLE_BESCHEID)
                .transacted()
                .process(automatischeBEscheiderstellungsProcessor);

        from(RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB)
                .routeId(RouteNames.DIRECT_SCHLIESSE_STATISTIK_AB)
                .transacted()
                .process(bescheiderstellungFachprotokollProcessor)
                .process(schliesseStatistikAbProcessor)
                .log(BODY);

        from(RouteNames.DIRECT_SCHLIESSE_OFFENE_AUFGABEN)
                .routeId(RouteNames.DIRECT_SCHLIESSE_OFFENE_AUFGABEN)
                .transacted()
                .process(schliesseAufgabenProcessor)
                .log(BODY);

        from(RouteNames.DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE)
                .routeId(RouteNames.DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE)
                .transacted()
                .process(erstelleRVDialogFehlerAufgabeProcessor)
                .log(BODY);

        from(RouteNames.DIRECT_PERSONENDATENABGLEICH)
                .routeId(RouteNames.DIRECT_PERSONENDATENABGLEICH)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .transacted()
                .process(personendatenableichProcessor)
                .choice()
                .when(header("stammdatenUpdated").isEqualTo(true))
                .to(RouteNames.DIRECT_PRUEFE_REGELN)
                .to(RouteNames.RVFIT_STATUS_BASED_ROUTING)
                .endChoice().end();

        from(RouteNames.DIRECT_AKTUALISIEREANTRAGSDATEN)
                .routeId(RouteNames.DIRECT_AKTUALISIEREANTRAGSDATEN)
                .errorHandler(deadLetterChannel(DIRECT_ERROR))
                .transacted()
                .process(antragsdatenAktualisierungProcessor)
                .to(RouteNames.DIRECT_PRUEFE_REGELN)
                .log(BODY);

        from(RouteNames.DIRECT_VERARBEITE_BEWILLIGUNG)
                .routeId(RouteNames.DIRECT_VERARBEITE_BEWILLIGUNG)
                .process(sensitiveCreateLogProcessor)
                .transacted()
                .process(bewilligungsProcessor)
                .to(RouteNames.DIRECT_SEND_FACHEREIGNIS);

        from(RouteNames.DIRECT_SEND_FACHEREIGNIS)
            .routeId(RouteNames.DIRECT_SEND_FACHEREIGNIS)
            .filter(simple("${header."+ RVFitCamelHeader.FACHEREIGNIS+"} != null"))
                .process(exchange -> {
                    final Fachereignis fachereignis = exchange.getMessage().getHeader(RVFitCamelHeader.FACHEREIGNIS, Fachereignis.class);
                    rvfitLogger.sendeFachprotokollEreignis(fachereignis);
                    exchange.getMessage().removeHeader(RVFitCamelHeader.FACHEREIGNIS);
                })
        ;

        from(RouteNames.DIRECT_GET_METADATA)
            .routeId(RouteNames.DIRECT_GET_METADATA)
                .doTry()
                    .to(RouteNames.DIRECT_FETCH_STAMMDATEN)
                .doCatch(KontoGesperrtException.class)
                    .to(RouteNames.DIRECT_EXTRACT_MANDANT)
                    .process(ex -> {
                        final Antrag antrag = ex.getMessage().getBody(Antrag.class);
                        antrag.setStatus(AntragStatus.STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN);
                        ex.getMessage().setBody(antragRepository.merge(antrag));
                    })
                    .to(RouteNames.DIRECT_ERSTELLE_RVDIALOG_FEHLER_AUFGABE)
                .end()
                .choice()
                .when(simple("${body.status} == 'STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN'"))
                    .to(RouteNames.DIRECT_SCHLIESSE_OFFENE_AUFGABEN)
                .endChoice()
                .end()
                .choice()
                .when(or(simple("${body.status} == 'STAMMDATEN_FEHLER_AUFGABE_ERSTELLT'"),
                        simple("${body.status} == 'STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN'")))
                    .log(LoggingLevel.WARN, LOG, "Fehler bei den Stammdaten")
                .otherwise()
                    .to(RouteNames.DIRECT_SETSMP_EINRICHTUNGEN)
                    .to(RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN)
                .endChoice()
                .end();
        // @formatter:on

    }
}
