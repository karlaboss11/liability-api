/**
 * Beinhaltet Klassen, die sich mit Aufgaben beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.aufgaben;
