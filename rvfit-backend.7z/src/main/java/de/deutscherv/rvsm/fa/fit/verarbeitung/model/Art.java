package de.deutscherv.rvsm.fa.fit.verarbeitung.model;

/**
 * Verarbeitungsart.
 */
public enum Art {

    /**
     * Bewilligungsbescheid.
     */
    BEWILLIGUNG,

    /**
     * Ablehnungsbescheid.
     */
    ABLEHNUNG,

    /**
     * Sachverhaltsaufklärungsbescheid.
     */
    SACHVERHALTSAUFKLAERUNG,

    /**
     * Antrag erledigt auf Andere Art und Weise.
     */
    ERLEDIGUNG_ANDERE_ART_UND_WEISE,

    /**
     * Antrag wurde Storniert.
     */
    STORNO,

    /**
     * Antrag wurde zurückgenommen.
     */
    RUECKNAHME,

    /**
     * Antrag ist gesperrt zur Verarbeitung.
     */
    GESPERRT,

    /**
     * Antrag wird in rvDialog weiterbearbeitet.
     */
    WEITERBEARBEITUNG_IN_RVDIALOG
}
