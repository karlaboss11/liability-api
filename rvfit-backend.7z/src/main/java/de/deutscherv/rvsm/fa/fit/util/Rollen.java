package de.deutscherv.rvsm.fa.fit.util;

/**
 * siehe: <a href="https://rvwiki.drv.drv/display/VT15BRVECDP/RV+Fit%3A+Rollen-+und+Rechtekonzept">...</a> .
 */
public final class Rollen {

    /**
     * Bearbeiter.
     */
    public static final String RVSM_QSTT_PR_FIT_BST = "${rollen.rvfit.bst:PR_Fit_BST}";
    /**
     * Erfasser.
     */
    public static final String RVSM_QSTT_PR_FIT_EF = "${rollen.rvfit.ef:PR_Fit_EF}";
    /**
     * Techn. Nutzer fuer Jobs / Cronjobs.
     */
    public static final String RVSM_TR_FIT_TE = "${rollen.rvfit.te:TR_Fit_JOBS}";

    private Rollen() {
        super();
    }
}
