package de.deutscherv.rvsm.fa.fit.diloop;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.diloop.service.AblehnungsDokumentErzeugungsService;
import de.deutscherv.rvsm.fa.fit.diloop.service.BewilligungsDokumentErzeugungsService;
import de.deutscherv.rvsm.fa.fit.diloop.service.DokumentenErstellungsDaten;
import de.deutscherv.rvsm.fa.fit.diloop.service.SachverhaltsaufklaerungsDokumentErzeugungsService;
import de.deutscherv.rvsm.fa.fit.diloop.service.VariablesFeld;
import de.deutscherv.rvsm.fa.fit.exceptions.DoeNoAcceptedResponseException;
import de.deutscherv.rvsm.fa.fit.exceptions.DokumentenErzeugungsException;
import de.deutscherv.rvsm.fa.fit.exceptions.EingabevalidierungException;
import de.deutscherv.rvsm.fa.fit.exceptions.annotation.ExceptionPersist;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.util.Json;
import de.deutscherv.rvsm.fa.fit.util.StatusValidator;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import de.drv.rvevo.shared.api.doe.model.DokumentgenerierungsAuftragDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Service zur Erstellung von Dokumentendaten und zur Anbindung an das IT-Produkt Dokumentenerstellung (DoE).
 */
@Slf4j
@ApplicationScoped
public class DokumentendatenService {

    private static final String RESOURCE_NAME = DokumentendatenService.class.getName();

    private final String dokumentenErzeugungUrl;
    private final DoeApiClient doeApiClient;
    private final DoeTechUserApiClient doeTechUserApiClient;
    private final JsonWebToken jwt;
    private final DokumentenErzeugungConfig dokumentenErzeugungConfig;
    private final VerarbeitungsstatusRepository verarbeitungsstatusRepository;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final AntragRepository antragRepository;
    private final BewilligungsDokumentErzeugungsService bewilligungsDokumentErzeugungsService;
    private final AblehnungsDokumentErzeugungsService ablehnungsDokumentErzeugungsService;
    private final SachverhaltsaufklaerungsDokumentErzeugungsService sachverhaltsaufklaerungsDokumentErzeugungsService;
    private final StammdatenService stammdatenService;
    private final RvfitLogger rvfitLogger;
    private final DrvMandant drvMandant;

    private final List<AntragStatus> statusList = List.of(AntragStatus.STATISTIK_ERFASST,
        AntragStatus.AUTOMATISCH,
        AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT,
        AntragStatus.AUFGABE_ABGESCHLOSSEN,
        AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT,
        AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT,
        AntragStatus.DOPPELVERGABE_PRUEFUNG_OK);

    /**
     * Konstruktor.
     *
     * @param dokumentenErzeugungUrl                            Dokumentenerzeugung-URL
     * @param doeTechUserApiClient                              DOE-Techuser-API-Client
     * @param doeApiClient                                      DOE-API-Client
     * @param jwt                                               JSON-Web-Token
     * @param dokumentenErzeugungConfig                         Dokumenterzeugung-Konfiguration
     * @param verarbeitungsstatusRepository                     Verarbeitungsstatus-Repository
     * @param verarbeitungsstatusService                        Verarbeitungsstatus-Service
     * @param antragRepository                                  Antrag-Repository
     * @param bewilligungsDokumentErzeugungsService             Bewilligung-Dokumenterzeugung-Service
     * @param ablehnungsDokumentErzeugungsService               Ablehnung-Dokumenterzeugung-Service
     * @param sachverhaltsaufklaerungsDokumentErzeugungsService Sachverhaltsaufklaerung-Dokumenterzeugung-Service
     * @param stammdatenService                                 Stammdaten-Service
     * @param rvfitLogger                                       rvFit-Logger
     * @param drvMandant                                        DRV-Mandant
     */
    @Inject
    public DokumentendatenService(
        @ConfigProperty(name = "quarkus.rest-client.dokumentenerzeugung-api.url") final String dokumentenErzeugungUrl,
        @RestClient final DoeApiClient doeApiClient,
        @RestClient final DoeTechUserApiClient doeTechUserApiClient,
        final JsonWebToken jwt,
        final DokumentenErzeugungConfig dokumentenErzeugungConfig,
        final VerarbeitungsstatusRepository verarbeitungsstatusRepository,
        final VerarbeitungsstatusService verarbeitungsstatusService,
        final AntragRepository antragRepository,
        final BewilligungsDokumentErzeugungsService bewilligungsDokumentErzeugungsService,
        final AblehnungsDokumentErzeugungsService ablehnungsDokumentErzeugungsService,
        final SachverhaltsaufklaerungsDokumentErzeugungsService sachverhaltsaufklaerungsDokumentErzeugungsService,
        final StammdatenService stammdatenService,
        final RvfitLogger rvfitLogger,
        final DrvMandant drvMandant) {
        this.dokumentenErzeugungUrl = dokumentenErzeugungUrl;
        this.doeApiClient = doeApiClient;
        this.doeTechUserApiClient = doeTechUserApiClient;
        this.jwt = jwt;
        this.dokumentenErzeugungConfig = dokumentenErzeugungConfig;
        this.verarbeitungsstatusRepository = verarbeitungsstatusRepository;
        this.verarbeitungsstatusService = verarbeitungsstatusService;
        this.antragRepository = antragRepository;
        this.bewilligungsDokumentErzeugungsService = bewilligungsDokumentErzeugungsService;
        this.ablehnungsDokumentErzeugungsService = ablehnungsDokumentErzeugungsService;
        this.sachverhaltsaufklaerungsDokumentErzeugungsService = sachverhaltsaufklaerungsDokumentErzeugungsService;
        this.stammdatenService = stammdatenService;
        this.rvfitLogger = rvfitLogger;
        this.drvMandant = drvMandant;
    }

    /**
     * Erstellt fuer einen Antrag mit der Uebergebenen UUID einen Auftrag auf Dokumentenerstellung fuer die entsprechende Bescheidart und
     * sendet diesen an das DiLoop-Gateaway. Rueckgabewert ist die Antwort des DiLoop-Gateways.
     *
     * @param antrag              der Antrag
     * @param dokumentenklasseDto DokumentenklasseDto mit Informationen zum zu erstellenden Dokument.
     * @param dunkelVerarbeitung  boolean, das angiebt, ob die Dokumenenerstellung dunkelverarbeitet werden soll
     * @return Antwort des DiLoop-Gateways
     */
    public AuftragsStatusDTO getDokumentendaten(final Antrag antrag,
        final @Valid @NotNull DokumentenklasseDto dokumentenklasseDto,
        final boolean dunkelVerarbeitung) {

        StatusValidator.canModify(antrag.getStatus().name(), RESOURCE_NAME,
            JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt));

        Art dokumentenArt = dokumentenklasseDto.getVorlage() == DokumentenklasseDto.VorlageEnum.ABLEHNUNG ? Art.ABLEHNUNG
            : Art.SACHVERHALTSAUFKLAERUNG;

        final DokumentgenerierungsAuftragDTO dto = getDokumentgenerierungsAuftragDTO(dokumentenklasseDto, dunkelVerarbeitung, antrag);

        final AuftragsStatusDTO auftragsStatusDTO = rufeDokumentenerzeugungsClientAuf(dto, antrag, dokumentenArt);

        // Speichern der AuftragsId in der Datenbank
        speicherAktuellesDokument(antrag.getUuid(), auftragsStatusDTO, dokumentenArt);

        return auftragsStatusDTO;
    }

    /**
     * Lese Auftragstatus.
     *
     * @param uuid des Antrags
     * @return ermittelter Auftragsstatus.
     */
    @Transactional
    public AuftragsStatusDTO getAuftragStatus(final UUID uuid) {

        // Prüfen ob ein Schutzbedarf vorliegt
        Optional<Antrag> antragOpt = antragRepository.findByUuid(uuid);
        antragOpt.ifPresent(stammdatenService::getKontoDto);

        final Verarbeitungsstatus verarbeitungsstatus = verarbeitungsstatusRepository.findByAntragId(uuid)
            .orElseThrow(NotFoundException::new);

        final AuftragsStatusDTO auftragsStatusDTO = new AuftragsStatusDTO();
        auftragsStatusDTO.setAuftragId(verarbeitungsstatus.getAuftragId());

        return auftragsStatusDTO;
    }

    /**
     * Erstellt fuer einen Antrag mit der uebergebenen UUID einen Auftrag auf Dokumentenerstellung fuer eine Bewilligung und sendet diesen
     * an das DiLoop-Gateaway. Rueckgabewert ist die Antwort des DiLoop-Gateways.
     *
     * @param antrag               der Antrag
     * @param bewilligungsdatenDto BewilliungsdatenDto (Zusatzinformationen für Bewilligungsbescheid aus SB-Eingaben).
     * @param dunkelVerarbeitung   boolean, das angiebt, ob die Dokumenenerstellung dunkelverarbeitet werden soll.
     * @return Antwort des DiLoop-Gateways
     */
    @Transactional
    public AuftragsStatusDTO getDokumentendatenBewilligung(final Antrag antrag,
        final @Valid @NotNull BewilligungsdatenDto bewilligungsdatenDto,
        final boolean dunkelVerarbeitung) {

        StatusValidator.canModify(antrag.getStatus().name(), RESOURCE_NAME,
            JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt));

        final String freitextVersicherter = bewilligungsdatenDto.getFreitextVersicherter();
        final String freitextEinrichtung = bewilligungsdatenDto.getFreitextEinrichtung();

        // Erstelle DokumentgenerierungsAuftragDTO für die Bewilligung
        final DokumentgenerierungsAuftragDTO dto = getDokumentgenerierungsdatenBewilligung(antrag,
            freitextVersicherter, freitextEinrichtung, dunkelVerarbeitung);

        // Ruft Doe (Paperboy) Client auf und return Response
        final AuftragsStatusDTO auftragsStatusDTO = rufeDokumentenerzeugungsClientAuf(dto, antrag, Art.BEWILLIGUNG);
        speicherAktuellesDokument(antrag.getUuid(), auftragsStatusDTO, Art.BEWILLIGUNG);
        return auftragsStatusDTO;
    }

    private AuftragsStatusDTO rufeDokumentenerzeugungsClientAuf(final DokumentgenerierungsAuftragDTO dto,
        final Antrag antrag, final Art dokumentenArt) {
        try (Response response = sendeAuftrag(dto, antrag)) {
            LOG.atInfo().addArgument(dokumentenErzeugungUrl)
                .log("Datensendung DoE: URL: {}/auftraege");
            LOG.atInfo().log("DoE-Response: Status = {} will be returned", response.getStatus());
            if (response.getStatus() == 202) {
                response.getHeaders().remove(HttpHeaders.CONTENT_TYPE);
                response.getHeaders().add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_TYPE);

                if (dokumentenArt == Art.SACHVERHALTSAUFKLAERUNG) {
                    rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                            EreignisTyp.NACHRICHTEN_AUSGANG_USER,
                            Ereignistext.SACHVERHALTAUFKLAERUNG_DOKUMENT_ERSTELLT,
                            EreignisFreitext.SACHVERHALTAUFKLAERUNG_DOKUMENT_ERSTELLT,
                            null,
                            antrag,
                            null,
                            jwt,
                            drvMandant)
                    );
                }
                return response.readEntity(AuftragsStatusDTO.class);
            } else {
                throw new DoeNoAcceptedResponseException(String.format("Fehler Meldung [%s] von DoE: [%s]",
                    response.getStatus(), response.getEntity()));
            }
        } catch (final WebApplicationException e) {
            LOG.atWarn().setCause(e).addArgument(antrag.getKtan()).addArgument(antrag.getVsnr())
                .addArgument(antrag.getUuid())
                .log("Fehler beim Ermitteln der Dokumentendaten. Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new DokumentenErzeugungsException(
                String.format("%s/%s", dokumentenErzeugungUrl, "auftraege"), e);
        }
    }

    private Response sendeAuftrag(final DokumentgenerierungsAuftragDTO dto, final Antrag antrag) {
        final boolean nutzeTechnischenUser = jwt.getClaim(JwtUtils.DRV_MANDANT) == null;
        LOG.atInfo()
            .addArgument(nutzeTechnischenUser ? "technischen User"
                : "TokenPropagation vom angemeldeten User")
            .addArgument(antrag.getVsnr()).addArgument(antrag.getUuid())
            .log("Nutze {} zum Senden eines Dokumentenauftrags. Vsnr [{}], UUID [{}]");

        LOG.atInfo().addArgument(antrag.getVsnr()).addArgument(antrag.getUuid())
            .addArgument(dto.getInputs().getVariablen().get("vorgangsID"))
            .log("Sende DokumentengenerierungsAuftrag. VSNR [{}], UUID [{}], Vorgangskennung [{}]");

        Set<String> fieldsToAnonymize = Set.of("sv_tm_G9581_00_Freier_Text_Eingabe", "tm_G9581_00_Ablehnung_Freitext",
            "sv_tm_G9582_00_Freie_Eingabe_Versicherte", "sv_tm_G9582_00_Freie_Eingabe_Einrichtung", "fall", "natuerlichePersonen");
        LOG.atInfo()
            .addArgument(Json.anonymizeJsonFields(Json.objectToJson(dto), fieldsToAnonymize))
            .log("Dto an DoE für Dokumentengenerierung: [{}]");
        if (nutzeTechnischenUser) {
            return doeTechUserApiClient.sendeAuftrag(dto, antrag.getKtan());
        }
        return doeApiClient.sendeAuftrag(dto, antrag.getKtan());
    }

    /**
     * Liefert DokumentgeneriungsAuftragDTO.
     *
     * @param dokumentenklasseDto Dokumentenklasse-DTO
     * @param dunkelVerarbeitung  true wenn Dunkleverarbeitung durchgefuehrt wird
     * @param antrag              betroffener Antrag
     * @return erstelltes DTO
     */
    protected DokumentgenerierungsAuftragDTO getDokumentgenerierungsAuftragDTO(
        final @Valid @NotNull DokumentenklasseDto dokumentenklasseDto,
        final boolean dunkelVerarbeitung, final Antrag antrag) {

        final Art art = Art.valueOf(String.valueOf(dokumentenklasseDto.getVorlage()));
        final String freitextVersicherter = dokumentenklasseDto.getFreitextVersicherter();

        return switch (art) {
            case ABLEHNUNG -> getDokumentgernierungsdatenAblenhnung(antrag, freitextVersicherter,
                dunkelVerarbeitung);
            case SACHVERHALTSAUFKLAERUNG -> getDokumentgernierungsdatenSachverhaltsaufklaerung(
                antrag);
            default -> {
                LOG.atWarn().addArgument(art).addArgument(antrag.getKtan())
                    .addArgument(antrag.getVsnr()).addArgument(antrag.getUuid())
                    .log("Unbekannte Dokumentenart [{}]. Ktan [{}] Vsnr [{}] UUID [{}]");
                throw new IllegalArgumentException(); // NOSONAR
            }
        };
    }

    /**
     * Erstellt ein DTO zur Dokumentengenerierung einer Bewilligung.
     *
     * @param antrag               Antrag, fuer den ein Dokument zur Bewilligung erstellt werden soll
     * @param freitextVersicherter Freitext an die Versicherte Person
     * @param freitextEinrichtung  Freitext an die Einrichtung
     * @param dunkelVerarbeitung   gibt an, ob das Dokument in der Benutzeroberfläche bearbeitet werden soll (false) oder ob das Dokument
     *                             ohne Review versendet werden soll (true)
     * @return das DTO fuer die Dokumentengenerierung zum Antrag
     */
    protected DokumentgenerierungsAuftragDTO getDokumentgenerierungsdatenBewilligung(
        final Antrag antrag, final String freitextVersicherter, final String freitextEinrichtung,
        final boolean dunkelVerarbeitung) {

        pruefeStatusFuerBearbeitung(antrag);
        pruefePersonendatenabgleichErfuellt(antrag);
        pruefeAnspruchspruefungErfuellt(antrag);
        pruefeAuswahlEinrichtung(antrag);

        final KontoDto konto = extrahiereVersichertenStammdaten(antrag);
        final DokumentenErstellungsDaten dokumentenErstellungsDaten = new DokumentenErstellungsDaten(antrag, konto,
            dokumentenErzeugungConfig,
            dunkelVerarbeitung,
            Map.of(VariablesFeld.FREITEXT_VERSICHERTER,
                Optional.ofNullable(freitextVersicherter).orElse(""),
                VariablesFeld.FREITEXT_EINRICHTUNG,
                Optional.ofNullable(freitextEinrichtung).orElse("")));
        return bewilligungsDokumentErzeugungsService.erzeugeAuftragsDto(dokumentenErstellungsDaten);
    }

    /**
     * Erstellt ein DTO zur Dokumentengenerierung einer Ablehnung.
     *
     * @param antrag               Antrag, fuer den ein Dokument zur Ablehnung erstellt werden soll
     * @param freitextVersicherter Freitext an den Versicherten für einen Ablehnungsbescheid
     * @param dunkelVerarbeitung   gibt an, ob das Dokument in der Benutzeroberfläche bearbeitet werden soll (false) oder ob das Dokument
     *                             ohne Review versendet werden soll (true)
     * @return das DTO fuer die Dokumentengenerierung zum Antrag
     */
    private DokumentgenerierungsAuftragDTO getDokumentgernierungsdatenAblenhnung(
        final Antrag antrag, final String freitextVersicherter, final boolean dunkelVerarbeitung) {

        pruefeStatusFuerBearbeitung(antrag);
        pruefeAnspruchspruefungNichtErfuellt(antrag);

        final KontoDto konto = extrahiereVersichertenStammdaten(antrag);
        final DokumentenErstellungsDaten dokumentenErstellungsDaten = new DokumentenErstellungsDaten(antrag, konto,
            dokumentenErzeugungConfig,
            dunkelVerarbeitung, Map.of(VariablesFeld.FREITEXT_VERSICHERTER,
            Optional.ofNullable(freitextVersicherter).orElse("")));
        return ablehnungsDokumentErzeugungsService.erzeugeAuftragsDto(dokumentenErstellungsDaten);
    }

    /**
     * Erstellt ein DTO zur Dokumentengenerierung einer Sachverhaltsaufklaerung.
     *
     * @param antrag Antrag, fuer den ein Dokument zur Sachverhaltsaufklaerung erstellt werden soll
     * @return das DTO fuer die Dokumentengenerierung zum Antrag
     */
    private DokumentgenerierungsAuftragDTO getDokumentgernierungsdatenSachverhaltsaufklaerung(
        final Antrag antrag) {
        final KontoDto konto = extrahiereVersichertenStammdaten(antrag);
        final DokumentenErstellungsDaten dokumentenErstellungsDaten = new DokumentenErstellungsDaten(antrag, konto,
            dokumentenErzeugungConfig, false);
        return sachverhaltsaufklaerungsDokumentErzeugungsService
            .erzeugeAuftragsDto(dokumentenErstellungsDaten);
    }

    /**
     * Prueft fuer einen zu bewilligenden Antrag, ob Einrichtungen fuer Start, Training und Aufbau gesetzt sind.
     *
     * @param antrag der Antrag
     */
    private void pruefeAuswahlEinrichtung(final Antrag antrag) {
        if (antrag.getEinrichtungStartObjekt() == null
            || antrag.getEinrichtungTrainingObjekt() == null
            || antrag.getEinrichtungAufObjekt() == null) {

            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr()).log(
                    "Keine Einrichtung für Antrag mit der uuid {} ausgewählt. Ktan [{}] Vsnr [{}]");
            throw new EingabevalidierungException(DokumentendatenService.class.getName(),
                JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt), "Keine Einrichtung für Antrag ausgewählt");
        }
    }

    /**
     * Prueft fuer einen zu bewilligenden Antrag, ob der Status STATISTIK_ERFASST ist.
     *
     * @param antrag der zu bewilligende Antrag
     */
    private void pruefeStatusFuerBearbeitung(final Antrag antrag) {
        if (!statusList.contains(antrag.getStatus())) {
            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr()).log(
                    "Keinen aktiven Antrag (Status 'ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT' zur UUID {} gefunden. Ktan [{}] Vsnr [{}]");
            throw new DokumentenErzeugungsException(String.format(
                "Keinen aktiven Antrag (Status 'ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT' zur uuid %s gefunden",
                antrag.getUuid()), new NotFoundException());
        }
    }

    /**
     * Extrahiert die Stammdaten der anstragsstellenden Person vom PSD.
     *
     * @param antrag Der Antrag, aus dem die Stammdaten der antragsstellenden Person extrahiert werden sollen
     * @return Stammdaten der anstragsstellenden Person vom PSD
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Stammdaten")
    public KontoDto extrahiereVersichertenStammdaten(final Antrag antrag) {
        return stammdatenService.getKontoDto(antrag);
    }

    /**
     * Prueft fuer einen zu bewilligenden Antrag, ob alle Prüfungen der Anspruchsprüfung auf ERFUELLT gesetzt sind.
     *
     * @param antrag der Antrag
     */
    private void pruefeAnspruchspruefungErfuellt(final Antrag antrag) {

        final boolean anspruchspruefungErfuellt = antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> RegelUtils.ANSPRUCHSPRUEFUNG_REGELN
                .contains(pruefergebnis.getRegelName()))
            .filter(pruefergebnis -> pruefergebnis.getBegruendung() != null
                && !pruefergebnis.getBegruendung().isEmpty())
            // Keep the most recent using lastModified as the key.
            .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName)).values().stream()
            .map(gruppe -> gruppe.stream()
                .max(Comparator.comparing(AntragPruefergebnis::getLastModified,
                    Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null))
            .filter(Objects::nonNull)
            .allMatch(pruefergebnis -> pruefergebnis.getErgebnis() == PruefErgebnis.ERFUELLT);

        if (!anspruchspruefungErfuellt) {
            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr()).log(
                    "Nicht alle Prüfungen der Anspruchsprüfung für Antrag mit der uuid {} sind ERFUELLT. Ktan [{}] Vsnr [{}]");
            throw new EingabevalidierungException(DokumentendatenService.class.getName(),
                JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt),
                "Nicht alle Prüfungen der Anspruchsprüfung für Antrag sind ERFUELLT");
        }
    }

    /**
     * Prueft fuer einen zu ablehnenden Antrag, ob mindestens eine Prüfung der Anspruchsprüfung auf NICHT_ERFUELLT_ABLEHNEN oder
     * NICHT_ERFUELLT_AUSSTEUERN gesetzt ist.
     *
     * @param antrag der Antrag
     */
    private void pruefeAnspruchspruefungNichtErfuellt(final Antrag antrag) {

        final boolean anspruchspruefungNichtErfuellt = antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> RegelUtils.ANSPRUCHSPRUEFUNG_REGELN
                .contains(pruefergebnis.getRegelName()))
            .filter(pruefergebnis -> pruefergebnis.getBegruendung() != null
                && !pruefergebnis.getBegruendung().isEmpty())
            // Keep the most recent using lastModified as the key.
            .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName)).values().stream()
            .map(gruppe -> gruppe.stream()
                .max(Comparator.comparing(AntragPruefergebnis::getLastModified,
                    Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null))
            .filter(Objects::nonNull)
            .anyMatch(pruefergebnis -> pruefergebnis
                .getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN
                || pruefergebnis.getErgebnis() == PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN);

        if (!anspruchspruefungNichtErfuellt) {
            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr()).log(
                    "Es gibt keine Prüfungen der Anspruchsprüfung für Antrag mit der uuid {} auf NICHT_ERFUELLT_ABLEHNEN "
                        + "oder NICHT_ERFUELLT_AUSSTEUERN. Ktan [{}] Vsnr [{}]");
            throw new EingabevalidierungException(DokumentendatenService.class.getName(),
                JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt),
                "Es gibt keine Prüfung der Anspruchsprüfung auf NICHT_ERFUELLT");
        }
    }

    /**
     * Prueft fuer einen zu bewilligenden Antrag, ob alle Prüfungen der Personendatenbgleich auf ERFUELLT gesetzt sind.
     *
     * @param antrag der Antrag
     */
    private void pruefePersonendatenabgleichErfuellt(final Antrag antrag) {

        final boolean personendatenabgleichErfuellt = antrag.getAntragPruefergebnisse().stream()
            .filter(pruefergebnis -> RegelUtils.PERSONENDATENABGLEICH_REGELN
                .contains(pruefergebnis.getRegelName()))
            // Keep the most recent using lastModified as the key.
            .collect(Collectors.groupingBy(AntragPruefergebnis::getRegelName)).values().stream()
            .map(gruppe -> gruppe.stream()
                .max(Comparator.comparing(AntragPruefergebnis::getLastModified,
                    Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null))
            .filter(Objects::nonNull)
            .allMatch(pruefergebnis -> pruefergebnis.getErgebnis() == PruefErgebnis.ERFUELLT);

        if (!personendatenabgleichErfuellt) {
            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
                .addArgument(antrag.getVsnr()).log(
                    "Nicht alle Prüfungen der Personendatenabgleich für Antrag mit der uuid {} sind ERFUELLT. Ktan [{}] Vsnr [{}]");
            throw new EingabevalidierungException(DokumentendatenService.class.getName(),
                JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt),
                "Nicht alle Prüfungen der Personendatenabgleich für Antrag sind ERFUELLT");
        }
    }

    private void speicherAktuellesDokument(final UUID uuid, final AuftragsStatusDTO auftragsStatusDTO, final Art dokumentenArt) {
        // Speichern der AuftragsId in der Datenbank
        final Verarbeitungsstatus verarbeitungsstatus = verarbeitungsstatusService.findeOderErstelleNeuenVerarbeitungsstatus(uuid);
        verarbeitungsstatus.setArt(dokumentenArt);
        verarbeitungsstatus.setAuftragId(auftragsStatusDTO.getAuftragId());
        verarbeitungsstatusRepository.merge(verarbeitungsstatus);
    }
}
