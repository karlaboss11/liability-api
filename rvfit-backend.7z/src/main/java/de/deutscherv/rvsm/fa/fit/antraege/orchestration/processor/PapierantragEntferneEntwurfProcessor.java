package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Löscht den Entwurf eines Papierantrags aus dem {@link AntragRepository}.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragEntferneEntwurfProcessor implements Processor {

    /**
     * Routenname fuer Entfernen eines Papierantragsentwurfes.
     */
    public static final String DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF = "direct:papierantragEntferneEntwurf";

    private final AntragRepository antragRepository;
    private final BestandsfehlerRepository bestandsfehlerRepository;

    @Override
    public void process(final Exchange exchange) {
        final UUID antragUuid = getAntragUuid(exchange);
        LoggingUtils.logProcessorUuid(exchange.getFromRouteId(), getClass().getSimpleName(), antragUuid);
        antragRepository.findByUuid(antragUuid)
                .filter(antrag -> AntragStatus.ENTWURF.equals(antrag.getStatus()))
                .ifPresent(antrag -> {
                    bestandsfehlerRepository.entferneAlleFehlerFuerAntrag(antrag);
                    antragRepository.delete(antrag);
                    antragRepository.flush();
                    LOG.atDebug().addArgument(antrag).log("Entferne Entwurf für Antrag [{}] aus DB");
                });
    }

    private UUID getAntragUuid(final Exchange exchange) {
        return Optional.of(exchange)
                .map(Exchange::getMessage)
                .map(msg -> msg.getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class))
                .map(UUID::fromString)
                .orElseGet(() -> Optional.of(exchange)
                        .map(Exchange::getMessage)
                        .map(msg -> msg.getBody(Antrag.class))
                        .map(Antrag::getUuid)
                        .orElseThrow(NullPointerException::new)
                );
    }
}
