package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.mapper;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.Adresse;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.AngebotExtended;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponse;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.EinrichtungResponseExtended;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.List;

/**
 * SelbstmeldeportalMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface SelbstmeldeportalMapper {

    /**
     * Mappt EinrichtungenResponse in RehaEinrichtungen.
     *
     * @param smpEinrichtungenResponseAlle die EinrichtungenResponse
     * @return die Einrichtungen
     */
    List<RehaEinrichtung> toEinrichtungenAlle(
            List<EinrichtungResponse> smpEinrichtungenResponseAlle);

    /**
     * Mappt EinrichtungResponse in RehaEinrichtung.
     *
     * @param smpEinrichtungResponseAlle die EinrichtungResponse
     * @return die Einrichtung
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "id", target = "smpEinrichtungsId")
    @Mapping(source = "angebote", target = "angebote", qualifiedByName = "toAngeboteAlle")
    @Mapping(target = "distanz", ignore = true)
    @Mapping(target = "distanzVersicherter", ignore = true)
    @Mapping(target = "email", ignore = true)
    @Mapping(target = "postanschrift", ignore = true)
    @Mapping(target = "telefonnummer", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    RehaEinrichtung toEntityAlle(EinrichtungResponse smpEinrichtungResponseAlle);

    /**
     * Mappt Smp Angebote in Angebote.
     *
     * @param smpAngeboteAlle die Smp Angebote
     * @return die Angebote
     */
    @Named("toAngeboteAlle")
    List<Angebot> toAngeboteAlle(
            List<de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.Angebot> smpAngeboteAlle);

    /**
     * Mappt Smp Angebot in Angebot.
     *
     * @param smpAngebotAlle die Smp Angebot
     * @return die Angebot
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "id", target = "smpAngebotId")
    @Mapping(target = "adresse", ignore = true)
    @Mapping(target = "anzahlTrainingseinheiten", ignore = true)
    @Mapping(target = "dauer", ignore = true)
    @Mapping(target = "dauerTrainingseinheiten", ignore = true)
    @Mapping(target = "distanz", ignore = true)
    @Mapping(target = "distanzVersicherter", ignore = true)
    @Mapping(target = "durchfuehrungsart", ignore = true)
    @Mapping(target = "freiePlaetzeWert", ignore = true)
    @Mapping(target = "postanschrift", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    Angebot toAngebot(
            de.deutscherv.rvsm.fa.fit.selbstmeldeportal.model.Angebot smpAngebotAlle);

    /**
     * Mappt EinrichtungenResponseExtended in RehaEinrichtung.
     *
     * @param smpEinrichtungenResponseExtended die EinrichtungenResponseExtended
     * @return die Einrichtungen
     */
    List<RehaEinrichtung> toEinrichtungen(
            List<EinrichtungResponseExtended> smpEinrichtungenResponseExtended);

    /**
     * Mappt EinrichtungResponseExtended in RehaEinrichtung.
     *
     * @param smpEinrichtungResponseExtended die EinrichtungResponseExtended
     * @return die Einrichtung
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "angebote", target = "angebote", qualifiedByName = "toAngebote")
    @Mapping(source = "id", target = "smpEinrichtungsId")
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    RehaEinrichtung toEntity(EinrichtungResponseExtended smpEinrichtungResponseExtended);

    /**
     * Mappt AngeboteExtended in Angebote.
     *
     * @param smpAngeboteExtended die AngeboteExtended
     * @return die Angebote
     */
    @Named("toAngebote")
    List<Angebot> toAngebote(List<AngebotExtended> smpAngeboteExtended);

    /**
     * Mappt AngebotExtended in Angebot.
     *
     * @param angebotExtended die AngebotExtended
     * @return die Angebot
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "id", target = "smpAngebotId")
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    Angebot toAngebot(AngebotExtended angebotExtended);

    /**
     * Mappt Adresse in EinrichtungAnschrift.
     *
     * @param adresse die Adresse
     * @return die EinrichtungAnschrift
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "adressZusatz", target = "adresszusatz")
    @Mapping(source = "nr", target = "hausnummer")
    @Mapping(source = "plz", target = "plz")
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    EinrichtungAnschrift toEinrichtungAnschrift(Adresse adresse);

    /**
     * Mappt String in eine Zahl.
     *
     * @param string mit Zahl
     * @return Integerwert der Zahl
     */
    default Integer toInteger(final String string) {
        return StringUtils.isEmpty(string) ? null : Integer.parseInt(string);
    }
}