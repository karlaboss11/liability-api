package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.exceptions.PapierantragValidierungException;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlercodeDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.ServiceUnavailableException;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * Prüft eingehende Papieranträge auf ihre Validität.
 */
@Slf4j
@AllArgsConstructor
@ApplicationScoped
public class PapierantragValidierungImpl implements PapierantragValidierung {

    private static final String FELD_ANTRAGSDATUM = "antragsdatum";
    private static final String FELD_EINGANGSDATUM = "eingangsdatum";

    private JsonWebToken jwt;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final PapierantragsPruefung papierantragsPruefung;
    private final AntragRepository antragRepository;

    /**
     * Test, validiere PapierantragDto.
     *
     * @param papierantragDto Papierantrag
     */
    @Override
    public void validiere(@Nonnull final PapierantragDto papierantragDto) {
        validiereJsonSchema(papierantragDto);
        validiereVorgangskennung(papierantragDto);
        validiereAufgabenId(papierantragDto);
        validiereFelder(papierantragDto);
        validiereAntragsUndEingangsDatum(papierantragDto);
    }

    /**
     * Test, validiere Papierantragentwurf.
     *
     * @param papierantragDto Papierantrag
     */
    @Override
    public void validiereEntwurf(@Nonnull final PapierantragDto papierantragDto) {
        validiereVsnr(papierantragDto);
        validiereJsonSchema(papierantragDto);
        validiereVorgangskennung(papierantragDto);
        validiereAufgabenId(papierantragDto);
    }

    private void validiereVsnr(final PapierantragDto papierantragDto) {
        if (Optional.of(papierantragDto)
            .map(PapierantragDto::getVersicherter)
            .map(StammdatenDto::getVsnr)
            .filter(StringUtils::isNotBlank)
            .isEmpty()) {
            throw new PapierantragValidierungException("Entwurf konnte nicht gespeichert werden, "
                + "da keine VSNR angegeben wurde.");
        }
    }

    private record FehlerDtoMeldungPaar(FehlerDto dto, String meldung) {
        static FehlerDtoMeldungPaar of(final FehlerDto links, final String rechts) {
            return new FehlerDtoMeldungPaar(links, rechts);
        }
    }

    private static Optional<FehlerDtoMeldungPaar> antragsDatumNachEingangsDatumFehler(final LocalDate antragsDatum,
        final LocalDate eingangsDatum) {
        if (antragsDatum.isAfter(eingangsDatum)) {
            return Optional.of(FehlerDtoMeldungPaar.of(
                new FehlerDto().feld(FELD_ANTRAGSDATUM).code(FehlercodeDto.FELD_UNGUELTIG),
                "Das Antragsdatum darf nicht nach dem Eingangsdatum liegen. ")
            );
        }
        return Optional.empty();
    }

    private static Optional<FehlerDtoMeldungPaar> datumLiegtInZukunftFehler(final LocalDate datum,
        final String feldName) {
        if (datum.isAfter(LocalDate.now())) {
            return Optional.of(FehlerDtoMeldungPaar.of(
                new FehlerDto().feld(feldName).code(FehlercodeDto.FELD_UNGUELTIG),
                "Datum darf nicht in der Zukunft liegen. ")
            );
        }
        return Optional.empty();
    }

    /**
     * Prüft Antrags- und Eingangsdatum eines Papierantrags. Regeln: - Die Daten dürfen nicht in der Zukunft liegen - Die Daten dürfen nicht
     * mehr als 10 Jahre zurückliegen - Die Eingabe eines ungültigen Datums muss verhindert werden - Das Antragsdatum darf nicht nach dem
     * Eingangsdatum liegen
     *
     * @param papierantragDto das eingehende PapierantragsDto
     */
    private void validiereAntragsUndEingangsDatum(@Nonnull final PapierantragDto papierantragDto) {
        final LocalDate antragsDatum = Optional.of(papierantragDto).map(PapierantragDto::getAntrag)
            .map(AntragDto::getAntragsdatum).orElseThrow(
                getPapierantragValidierungExceptionSupplier(FELD_ANTRAGSDATUM, papierantragDto));
        final LocalDate eingangsdatum = Optional.of(papierantragDto).map(PapierantragDto::getAntrag)
            .map(AntragDto::getEingangsdatum).orElseThrow(
                getPapierantragValidierungExceptionSupplier(FELD_EINGANGSDATUM, papierantragDto));

        final StringBuilder fehlerMeldung = new StringBuilder();
        final Set<FehlerDto> fehlerDtos = new LinkedHashSet<>();

        datumLiegtInZukunftFehler(antragsDatum, FELD_ANTRAGSDATUM).ifPresent(fehler -> {
            fehlerDtos.add(fehler.dto());
            fehlerMeldung.append(fehler.meldung());
        });
        datumLiegtMehrAls10JahreZurueckFehler(antragsDatum, FELD_ANTRAGSDATUM).ifPresent(fehler -> {
            fehlerDtos.add(fehler.dto());
            fehlerMeldung.append(fehler.meldung());
        });
        datumLiegtInZukunftFehler(eingangsdatum, FELD_EINGANGSDATUM).ifPresent(fehler -> {
            fehlerDtos.add(fehler.dto());
            fehlerMeldung.append(fehler.meldung());
        });
        datumLiegtMehrAls10JahreZurueckFehler(eingangsdatum, FELD_EINGANGSDATUM).ifPresent(fehler -> {
            fehlerDtos.add(fehler.dto());
            fehlerMeldung.append(fehler.meldung());
        });
        antragsDatumNachEingangsDatumFehler(antragsDatum, eingangsdatum).ifPresent(fehler -> {
            fehlerDtos.add(fehler.dto());
            fehlerMeldung.append(fehler.meldung());
        });

        if (!fehlerDtos.isEmpty()) {
            throw new PapierantragValidierungException(String.format(
                "Prüfung des Papierantrags fehlerhaft. %s AntragsDatum [%s] EingangsDatum [%s] "
                    + "DRV-ID [%s], VSNR [%s], UUID [%s]",
                fehlerMeldung,
                antragsDatum,
                eingangsdatum,
                GET_DRV_ID_AUS_JWT.apply(jwt),
                papierantragDto.getVersicherter().getVsnr(),
                papierantragDto.getAntrag().getUuid()),
                fehlerDtos.stream().toList());
        }

    }

    private Supplier<PapierantragValidierungException> getPapierantragValidierungExceptionSupplier(final String feldEingangsdatum,
        final PapierantragDto papierantragDto) {
        return () -> new PapierantragValidierungException(String.format(
            "Prüfung des Papierantrags fehlerhaft. Das Datum muss gesetzt sein. %s "
                + "[null] DRV-ID [%s], VSNR [%s], UUID [%s]",
            feldEingangsdatum,
            GET_DRV_ID_AUS_JWT.apply(jwt),
            papierantragDto.getVersicherter().getVsnr(),
            papierantragDto.getAntrag().getUuid()),
            List.of(new FehlerDto().code(FehlercodeDto.FELD_LEER).feld(feldEingangsdatum)));
    }

    private static Optional<FehlerDtoMeldungPaar> datumLiegtMehrAls10JahreZurueckFehler(final LocalDate datum,
        final String feldName) {
        if (datum.isBefore(LocalDate.now().minusYears(10))) {
            return Optional.of(FehlerDtoMeldungPaar.of(
                new FehlerDto().feld(feldName).code(FehlercodeDto.FELD_UNGUELTIG),
                "Datum darf nicht mehr als 10 Jahre zurück liegen. ")
            );
        }
        return Optional.empty();
    }

    /**
     * Validiert die Werte in den Datenfelden des Papierantrags.
     *
     * @param papierantragDto das eingehende PapierantragsDto
     */
    private void validiereFelder(final PapierantragDto papierantragDto) {
        try {
            final List<FehlerDto> pruefungsFehler = papierantragsPruefung.pruefePapierAntrag(
                papierantragDto);
            if (!pruefungsFehler.isEmpty()) {
                throw new PapierantragValidierungException(String.format(
                    "Prüfung des Papierantrags fehlerhaft. DRV-ID [%s], VSNR [%s], UUID [%s]",
                    GET_DRV_ID_AUS_JWT.apply(jwt), papierantragDto.getVersicherter().getVsnr(),
                    papierantragDto.getAntrag().getUuid()),
                    pruefungsFehler);
            }
        } catch (final NoSuchFieldException | SecurityException | StammdatenException e) {
            throw new ServiceUnavailableException(String.format(
                "Fehler in der Antragspruefung. DRV-ID [%s], VSNR [%s], UUID [%s]",
                GET_DRV_ID_AUS_JWT.apply(jwt),
                papierantragDto.getVersicherter().getVsnr(),
                papierantragDto.getAntrag().getUuid()));
        }
    }

    /**
     * Validiert, ob eine AufgabenID für die Aufgabe zur Erfassung eines Papierantrags übergeben wurde.
     *
     * @param papierantragDto das eingehende PapierantragsDto
     */
    private void validiereAufgabenId(final PapierantragDto papierantragDto) {
        if (papierantragDto.getAufgabenId() == null) {
            throw new PapierantragValidierungException(
                "Papierantrag konnte nicht erstellt werden. Keine AufgabenID übergeben.",
                List.of(new FehlerDto().feld("aufgid").code(FehlercodeDto.FELD_LEER)));
        }
    }

    /**
     * Validiert, ob eine noch nicht belegte Vorgangskennung übergeben wurde.
     *
     * @param papierantragDto das eingehende PapierantragsDto
     */
    private void validiereVorgangskennung(final PapierantragDto papierantragDto) {
        if (papierantragDto.getVorgangsId() == null) {
            throw new PapierantragValidierungException(
                "Papierantrag konnte nicht erstellt werden. Keine VorgangsID übergeben.",
                List.of(new FehlerDto().feld("vogid").code(FehlercodeDto.FELD_LEER)));
        }

        if (antragRepository.istVorgangsIdBelegt(papierantragDto.getVorgangsId())) {
            throw new PapierantragValidierungException(String.format("Papierantrag konnte nicht erstellt werden. "
                    + "Für die VorgangsID [%s] existiert bereits ein Antrag in der Datenbank.",
                papierantragDto.getVorgangsId()),
                List.of(new FehlerDto().feld("vogid").code(FehlercodeDto.FELD_UNGUELTIG)));
        }
    }

    /**
     * Validiert, ob das PapierantragsDto die OpenApi-Spezifikation erfüllt.
     *
     * @param papierantragDto das eingehende PapierantragsDto
     */
    private void validiereJsonSchema(final PapierantragDto papierantragDto) {
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, papierantragDto)) {
            throw new PapierantragValidierungException(
                "Papierantrag konnte nicht erstellt werden. Schema-Validierung fehlgeschlagen.");
        }
    }
}
