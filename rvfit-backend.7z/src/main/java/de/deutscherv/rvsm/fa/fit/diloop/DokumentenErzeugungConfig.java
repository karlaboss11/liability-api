package de.deutscherv.rvsm.fa.fit.diloop;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.Getter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Dokumenterzeugung-Konfiguration.
 */
@ApplicationScoped
@Getter
public class DokumentenErzeugungConfig {

    @ConfigProperty(name = "dokumentenerzeugung.default-mail")
    private String mailTo;

    @ConfigProperty(name = "dokumentenerzeugung.vorlagen-id.ablehnung")
    private String vorlagenIdBescheidAblehnung;

    @ConfigProperty(name = "dokumentenerzeugung.vorlagen-id.bewilligung")
    private String vorlagenIdBescheidBewilligung;

    @ConfigProperty(name = "dokumentenerzeugung.vorlagen-id.bewilligungUnterschiedlicheEinrichtungen")
    private String vorlagenIdBescheidBewilligungUnterschiedlicheEinrichtungen;

    @ConfigProperty(name = "dokumentenerzeugung.vorlagen-id.sachverhaltsaufklaerung")
    private String vorlagenIdSachverhaltsaufklaerung;

    @ConfigProperty(name = "dokumentenerzeugung.default-aigr")
    private String defaultAigr;

    @ConfigProperty(name = "dokumentenerzeugung.calling-system.name")
    private String callingSystemName;

    @ConfigProperty(name = "dokumentenerzeugung.calling-system.version")
    private String callingSystemVersion;

}
