package de.deutscherv.rvsm.fa.fit.papierantraege.service;

/**
 * Mapper AntragFeld.
 */
public enum AntragFeldMapper {

    /**
     * VORNAME.
     **/
    VORNAME("vorname"),
    /**
     * NACHNAME.
     **/
    NACHNAME("nachname"),
    /**
     * NAMENSZUSATZ.
     **/
    NAMENSZUSATZ("namenszusatz"),
    /**
     * FRUEHERERNAME.
     **/
    FRUEHERERNAME("frueherername"),
    /**
     * GEBURTSNAME.
     **/
    GEBURTSNAME("geburtsname"),
    /**
     * GEBURTSDATUM.
     **/
    GEBURTSDATUM("geburtsdatum"),
    /**
     * GEBURTSORT.
     **/
    GEBURTSORT("geburtsort"),
    /**
     * GEBURTSLAND.
     **/
    GEBURTSLAND("geburtland"),
    /**
     * STRASSE.
     **/
    STRASSE("strasse"),
    /**
     * HAUSNUMMER.
     **/
    HAUSNUMMER("hausnummer"),
    /**
     * PLZ.
     **/
    PLZ("plz"),
    /**
     * WOHNORT.
     **/
    WOHNORT("wohnort"),
    /**
     * LAND.
     **/
    LAND("land"),
    /**
     * STAATSANGEHOERIGKEIT.
     **/
    STAATSANGEHOERIGKEIT("staatsangehoerigkeit"),
    /**
     * BEMERKUNGEN.
     **/
    BEMERKUNGEN("bemerkungen"),
    /**
     * TELEFON.
     **/
    TELEFON("telefon"),
    /**
     * FAX.
     **/
    FAX("fax"),
    /**
     * GESCHLECHT.
     **/
    GESCHLECHT("geschlecht"),
    /**
     * GROSSDRUCK.
     **/
    GROSSDRUCK("grossdruck"),
    /**
     * KURZSCHRIFT.
     **/
    KURZSCHRIFT("kurzschrift"),
    /**
     * VOLLSCHRIFT.
     **/
    VOLLSCHRIFT("vollschrift"),
    /**
     * BEMERKUNG.
     */
    BEMERKUNG("bemerkung")
    ;


    private final String feldName;

    /**
     * Konstruktor.
     * @param feldName zu setzender Feldname
     */
    AntragFeldMapper(final String feldName) {
        this.feldName = feldName;
    }

    /**
     * Lies Feldname.
     * @return Feldname.
     */
    public String getFeldName() {
        return this.feldName;
    }
}
