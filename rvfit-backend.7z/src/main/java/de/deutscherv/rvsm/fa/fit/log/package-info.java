/**
 * Beinhaltet die Klassen zur fachlichen Protokollierung.
 */
package de.deutscherv.rvsm.fa.fit.log;
