package de.deutscherv.rvsm.fa.fit.stammdaten.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.model.GeburtsdatumStatus;
import de.deutscherv.rvsm.fa.fit.exceptions.MapperException;
import de.deutscherv.rvsm.fa.fit.openapi.model.ArtZugaenglichkeitDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.AnschriftUtils;
import de.deutscherv.rvsm.fa.fit.util.GeburtsdatumUtils;
import java.time.LocalDate;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

/**
 * Mapper Stammdaten.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface StammdatenMapper {

    /**
     * Mappt ein KontoDto in eine Stammdaten Entity.
     *
     * @param kontoDto das KontoDto, das zur Stammdaten Entity gemappt werden soll
     * @return die Stammdaten Entity
     */
    default Stammdaten toStammdatenFromKontoDto(final KontoDto kontoDto) {
        final Stammdaten stammdaten =
                toEntity(toStammdatenDtoFromPersonDtoList(kontoDto.getPersonen()));
        stammdaten.setVsnr(kontoDto.getVersicherungsnummer());
        stammdaten.setKtan(kontoDto.getKtan());
        return stammdaten;
    }

    /**
     * Mappt ein KontoDto in ein StammdatenDto.
     *
     * @param kontoDto das KontoDto, das zum StammdatenDto gemappt werden soll
     * @return das StammdatenDto
     */
    default StammdatenDto toStammdatenDtoFromKontoDto(final KontoDto kontoDto) {
        final StammdatenDto stammdatenDto =
                toStammdatenDtoFromPersonDtoList(kontoDto.getPersonen());
        stammdatenDto.setVsnr(kontoDto.getVersicherungsnummer());
        return stammdatenDto;
    }

    /**
     * Mapping Liste Personendaten zu StammdatenDto.
     *
     * @param personDtoList Liste Personendaten
     * @return StammdatenDto
     */
    default StammdatenDto toStammdatenDtoFromPersonDtoList(final List<PersonDto> personDtoList) {
        try {
            return toStammdatenDtoFromPersonDto(personDtoList.getFirst());
        } catch (final ArrayIndexOutOfBoundsException aioobe) {
            throw new MapperException("Kein PersonDto-Objekt in Liste gefunden", aioobe);
        }
    }

    /**
     * Mapping PersonDto zu StammdatenDto.
     *
     * @param personDto PersonDto
     * @return StammdatenDto
     */
    @Mapping(target = "nachname", source = "name")
    @Mapping(target = "strasse", source = "anschrift.strasseHausnummer", qualifiedByName = "stammdatenStrasseFromString")
    @Mapping(target = "hausnummer", source = "anschrift.strasseHausnummer", qualifiedByName = "stammdatenHausnummerFromString")
    @Mapping(target = "plz", source = "anschrift.postleitzahl")
    @Mapping(target = "wohnort", source = "anschrift.wohnort")
    @Mapping(target = "land", source = "anschrift.laenderschluessel", defaultValue = "000")
    @Mapping(target = "geburtsland", source = "laenderschluesselGeburtsort")
    @Mapping(target = "telefax", source = "fax")
    @Mapping(target = "geschlecht", source = "geschlecht", qualifiedByName = "stammdatenDtoGeschlechtFromPersonDtoGeschlecht")
    @Mapping(target = "fruehererName", source = "herkunftGeburtsname") // ??
    @Mapping(target = "artZugaenglichkeit", source = "artZugaenglichkeit", qualifiedByName = "stammdatenDtoArtZugaenglichkeitFromPersonDto")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "vsnr", ignore = true)
    StammdatenDto toStammdatenDtoFromPersonDto(PersonDto personDto);

    /**
     * Mappt Stammdaten in ein Stammdaten DTO.
     *
     * @param entity die Stammdaten
     * @return das DTO
     */
    @Mapping(target = "geburtsdatum", source = "entity", qualifiedByName = "stammdatenGeburtsdatumToString")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "telefon", ignore = true)
    @Mapping(target = "telefax", ignore = true)
    @Mapping(target = "geburtsname", ignore = true)
    @Mapping(target = "fruehererName", ignore = true)
    @Mapping(target = "artZugaenglichkeit", ignore = true)
    StammdatenDto toDto(Stammdaten entity);

    /**
     * Mappt das Geburtsdatum mit GeburutsdatumStatus in einen String.
     * @param entity StammdatenEntity
     * @return Geburtsdatum als String
     */
    @Named("stammdatenGeburtsdatumToString")
    static String stammdatenGeburtsdatumToString(final Stammdaten entity) {
        return GeburtsdatumUtils.getGeburtsdatumAsString(entity.getGeburtsdatum(), entity.getGeburtsdatumStatus());
    }

    /**
     * Mappt ein Stammdaten DTO in Stammdaten.
     *
     * @param dto das DTO
     * @return die Stammdaten
     */
    @Mapping(target = "geburtsdatum", source = "geburtsdatum", qualifiedByName = "stammdatenGeburtsdatumFromString")
    @Mapping(target = "geburtsdatumStatus", source = "geburtsdatum", qualifiedByName = "stammdatenGeburtsdatumStatusfromString")
    @Mapping(target = "uuid", ignore = true)
    @Mapping(target = "antragId", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    Stammdaten toEntity(StammdatenDto dto);

    /**
     * Mappt String mit dem Geburtsdatum zu einem LocalDate. Falls Monat und/oder Tag den Wert "00" haben wird jeweils "01" eingetragen.
     *
     * @param geburtsdatum String mit dem Datum
     * @return Geburtsdatum als LocalDate.
     */
    @Named("stammdatenGeburtsdatumFromString")
    static LocalDate stammdatenGeburtsdatumFromString(final String geburtsdatum) {
        return GeburtsdatumUtils.getGeburtsdatumAsLocalDate(geburtsdatum);
    }

    /**
     * Abhaengig davon ob  das Datum ok ist oder Monat und/oder Tag "00" ist wird das Kennzeichen gesetzt.
     *
     * @param geburtsdatum Geburtsdatum als Text
     * @return zu setzendes Kennzeichen
     */
    @Named("stammdatenGeburtsdatumStatusfromString")
    static GeburtsdatumStatus stammdatenGeburtsdatumStatusfromString(final String geburtsdatum) {
        return GeburtsdatumUtils.detectGeburtsdatumStatus(geburtsdatum);
    }


    /**
     * Liest aus einem String mit Strasse und Hausnummer die Strasse.
     *
     * @param strassUndHausnummer Text mit Strasse und Hausnummer
     * @return Strasse
     */
    @Named("stammdatenStrasseFromString")
    static String stammdatenStrasseFromString(final String strassUndHausnummer) {
        return AnschriftUtils.getStrasse(strassUndHausnummer);
    }

    /**
     * Liest aus einem String mit Strasse und Hausnummer die Hausnummer.
     *
     * @param strassUndHausnummer Text mit Strasse und Hausnummer
     * @return Hausnummer
     */
    @Named("stammdatenHausnummerFromString")
    static String stammdatenHausnummerFromString(final String strassUndHausnummer) {
        return AnschriftUtils.getHausnummer(strassUndHausnummer);
    }

    /**
     * Mapping des Geschlechts aus PersonDto in StammdatenDto.
     *
     * @param geschlecht Geschlecht aus PersonDto
     * @return Geschlecht für StammdatenDto
     */
    @Named("stammdatenDtoGeschlechtFromPersonDtoGeschlecht")
    static StammdatenDto.GeschlechtEnum stammdatenDtoGeschlechtFromPersonDtoGeschlecht(
            final PersonDto.GeschlechtEnum geschlecht) {
        return switch (geschlecht) {
            case DIVERS -> StammdatenDto.GeschlechtEnum.D;
            case WEIBLICH -> StammdatenDto.GeschlechtEnum.W;
            case MAENNLICH -> StammdatenDto.GeschlechtEnum.M;
            case UNBESTIMMT -> StammdatenDto.GeschlechtEnum.X;
        };
    }

    /**
     * Mapping des ArtZugaenglichkeit (Sehbehinderung) aus PersonDto in StammdatenDto.
     *
     * @param artZugaenglichkeit ArtZugaenglichkeit aus PersonDto
     * @return Geschlecht für StammdatenDto
     */
    @Named("stammdatenDtoArtZugaenglichkeitFromPersonDto")
    static ArtZugaenglichkeitDto stammdatenDtoArtZugaenglichkeitFromPersonDto(
            final PersonDto.ArtZugaenglichkeitEnum artZugaenglichkeit) {
        if (artZugaenglichkeit == null) {
            return null;
        }
        return switch (artZugaenglichkeit) {
            case GRUNDSTELLUNG -> null;
            case BRAILLE_KURZSCHRIFT -> ArtZugaenglichkeitDto.BRAILLE_KURZSCHRIFT;
            case BRAILLE_VOLLSCHRIFT -> ArtZugaenglichkeitDto.BRAILLE_VOLLSCHRIFT;
            case GROSSDRUCK -> ArtZugaenglichkeitDto.GROSSDRUCK;
            case CD_ROM -> ArtZugaenglichkeitDto.CD_ROM;
            case HOERMEDIUM -> ArtZugaenglichkeitDto.HOERMEDIUM;
        };
    }
}
