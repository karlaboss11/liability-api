/**
 * Beinhaltet Klassen, die sich mit der Verarbeitung von Anträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.verarbeitung;
