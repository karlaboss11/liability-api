package de.deutscherv.rvsm.fa.fit.security;

import io.quarkus.security.identity.SecurityIdentity;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Optional;
import org.eclipse.microprofile.jwt.Claim;

/**
 * Liefert Informationen (Claims) zum eingeloggten Benutzer.
 */
@RequestScoped
public class UserService {

    private final String drvId;
    private final String clientId;
    private final String mandant;
    private final SecurityIdentity securityIdentity;

    /**
     * Konstruktor.
     *
     * @param drvId DRV-ID
     * @param clientId          Client-ID
     * @param mandant Mandant
     * @param securityIdentity Security-Identiy
     */
    @Inject
    public UserService(@Claim("drvid") final String drvId,
            @Claim("client_id") final String clientId,
            @Claim("drv_mandant") final String mandant,
            final SecurityIdentity securityIdentity) {
        this.drvId = drvId;
        this.clientId = clientId;
        this.mandant = mandant;
        this.securityIdentity = securityIdentity;
    }

    /**
     * Gibt den Claim {@code 'drvid'} des aktuellen Benutzers zurück.
     *
     * @return Optional<String>
     */
    public Optional<String> getCurrentDrvId() {
        return Optional.ofNullable(drvId);
    }

    /**
     * Liefert alle relevanten Rollen eines angemeldeten Nutzers als zusammengesetzten String zurück.
     *
     * @return String
     */
    public String getCurrentRoles() {
        final List<String> rollen = securityIdentity.getRoles().stream().sorted().toList();

        final StringBuilder builder = new StringBuilder();

        for (final String rolle : rollen) {
            builder.append(rolle);
            builder.append(" ");
        }

        return builder.toString().trim();
    }

    /**
     * Gibt den Claim {@code 'client_id'} des aktuellen Benutzers zurück.
     *
     * @return String
     */
    public String getCurrentClientId() {
        return Optional.ofNullable(clientId).orElse("-");
    }

    /**
     * Gibt den Claim {@code 'drv_mandant'} des aktuellen Benutzers zurück.
     *
     * @return Optional<String>
     */
    public Optional<String> getCurrentDrvMandant() {
        return Optional.ofNullable(mandant);
    }
}