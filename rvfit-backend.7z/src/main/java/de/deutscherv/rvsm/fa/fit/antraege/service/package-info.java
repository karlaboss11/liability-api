/**
 * Beinhaltet Servcies, die sich mit Anträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.antraege.service;
