package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.LaenderUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisNichtErfuelltAussteuern;

/**
 * Regelpruefung - Staatsangehoerigkeit.
 */
@Singleton
public class StaatsangehoerigkeitRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "Es liegt eine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vor.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.AUSSTEUERN, "Es konnte nicht ermittelt werden, ob eine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vorliegt.",
            RegelUtils.NICHT_ERFUELLT_AUSSTEUERN, "Es liegt keine EU/EWR/Schweizer/Türkische Staatsangehörigkeit vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_STAATSANGEHOERIGKEIT;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (kontext.getStammdaten() == null
                || kontext.getStammdaten().getStaatsangehoerigkeit() == null) {
            return ergebnisAussteuernKeineDaten(this);
        }

        final var land = kontext.getStammdaten().getStaatsangehoerigkeit();
        if (LaenderUtils.isAussteuern(land)) {
            return ergebnisAussteuern(this);

        }

        if (LaenderUtils.isEuPlus(land)) {
            return ergebnisErfuellt(this);

        }

        return ergebnisNichtErfuelltAussteuern(this);

    }
}
