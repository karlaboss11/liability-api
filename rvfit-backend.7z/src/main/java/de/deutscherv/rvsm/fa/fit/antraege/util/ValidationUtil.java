package de.deutscherv.rvsm.fa.fit.antraege.util;

import de.deutscherv.anzeigetool.utils.AnzeigetoolException;
import de.deutscherv.anzeigetool.utils.MarshallerUtils;
import de.deutscherv.anzeigetool.xmldr.XmlDr;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import java.util.List;
import lombok.Getter;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * ValidationUtil.
 */
@UtilityClass
@Slf4j
public class ValidationUtil {

    private static final String ANZEIGETOOL_METADATEN_52 = "anzeigetool/metadaten_v52.xml";
    private static final String ANZEIGETOOL_METADATEN_53 = "anzeigetool/metadaten_v53.xml";

    @Getter
    private static List<String> metadatenVersionen;

    static {
        try {
            metadatenVersionen = List.of(loadVersionFromMetadaten(ANZEIGETOOL_METADATEN_52),
                    loadVersionFromMetadaten(ANZEIGETOOL_METADATEN_53));
        } catch (final AnzeigetoolException e) {
            LOG.atWarn().setCause(e)
                    .log("Antragsversion kann wegen fehlerhaften Metadaten nicht geprueft werden");
        }
    }

    private static String loadVersionFromMetadaten(String path) throws AnzeigetoolException {
        final var metadatenInput = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream(path);
        assert metadatenInput != null;
        final var metadaten = (XmlDr) MarshallerUtils.unmarshal(metadatenInput, XmlDr.class);
        return metadaten.getDsversion();
    }

    /**
     * Bestimmt den Metadaten-Pfad zur angegebenen Antragsversion.
     * @param version die Antragsversion
     * @return der Metadaten-Pfad
     */
    public static String getMetadatenFromVersion(Long version) {
        if (version == null) {
            return null;
        }
        
        return switch (version.intValue()) {
            case 52 -> ANZEIGETOOL_METADATEN_52;
            case 53 -> ANZEIGETOOL_METADATEN_53;
            default -> null;
        };
    }

    /**
     * Prüft, ob die Version des Antrags mit der Version aus den aktuellen Metadaten übereinstimmt.
     *
     * @param antrag der Antrag
     */
    public static void pruefeAntragsVersion(final Antragsdaten antrag) {
        final List<String> metadatenVersionen = getMetadatenVersionen();
        final String antragsVersion = antrag.getSteuerdaten().getVersion();

        if (antragsVersion == null || !metadatenVersionen.contains(antragsVersion)) {
            LOG.atWarn().addArgument(metadatenVersionen).addArgument(antragsVersion)
                    .log("Falsche Antragsversion: Erwartete {} aber bekam {}");
        }
    }

}
