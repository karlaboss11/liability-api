/**
 * Beinhaltet Klassen, die sich mit dem Mapping von Einrichtungen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.einrichtungen.mapper;
