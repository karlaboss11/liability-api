package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Kontoinformation;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnis;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.kontoInformationenVorhanden;

/**
 * Regelpruefung - Wartezeitpruefung.
 */
@Singleton
public class WartezeitpruefungRegel extends BasisRegel {

    private static final String NICHT_ERFUELLT_AUSSTEUERN_KEIN_DATEN = "NICHT_ERFUELLT_AUSSTEUERN_KEIN_DATEN";
    private static final String NICHT_ERFUELLT_AUSSTEUERN_WARTEZEITPRUEFUNG = "NICHT_ERFUELLT_AUSSTEUERN_WARTEZEITPRUEFUNG";
    private static final Map<String, String> REGEL_ERGENIS_DETAIL =
            Map.of(
                    RegelUtils.ERFUELLT, "Wartezeitprüfung ist erfüllt!",
                    RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor",
                    RegelUtils.AUSSTEUERN, "Wartezeitprüfung ist nicht erfüllt, wegen Wartezeitfehler",
                    NICHT_ERFUELLT_AUSSTEUERN_KEIN_DATEN, "Es liegen keine vollstaendigen Daten der Wartezeitberechnung vor",
                    NICHT_ERFUELLT_AUSSTEUERN_WARTEZEITPRUEFUNG, "Wartezeitprüfung ist nicht erfüllt!");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_WARTEZEITPRUEFUNG;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (!kontoInformationenVorhanden(kontext)) {
            return ergebnisAussteuernKeineDaten(this);
        }
        final Kontoinformation kontoinformation =
                kontext.getAntrag().getKontoinformationen().getFirst();
        final Boolean wartezeitfehler = kontoinformation.getWartezeitfehler();
        final Integer wartezeit6in24m = kontoinformation.getWartezeit6in24m();
        final Integer wartezeit180m = kontoinformation.getWartezeit180m();

        if (Boolean.FALSE.equals(wartezeitfehler) && Objects.nonNull(wartezeit6in24m)
                && Objects.nonNull(wartezeit180m) && (wartezeit6in24m >= 6 || wartezeit180m >= 180)) {
            return ergebnisErfuellt(this);
        }
        if (Objects.isNull(kontoinformation.getWartezeitfehler())) {
            return ergebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN, getRegelName(),
                    getRegelDetail(NICHT_ERFUELLT_AUSSTEUERN_KEIN_DATEN)
                            .orElse(NICHT_ERFUELLT_AUSSTEUERN_KEIN_DATEN));
        }
        if (Boolean.FALSE.equals(wartezeitfehler) && Objects.nonNull(wartezeit6in24m)
                && Objects.nonNull(wartezeit180m) && wartezeit6in24m < 6 && wartezeit180m < 180) {
            return ergebnis(PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
                    getRegelName(), getRegelDetail(NICHT_ERFUELLT_AUSSTEUERN_WARTEZEITPRUEFUNG)
                            .orElse(NICHT_ERFUELLT_AUSSTEUERN_WARTEZEITPRUEFUNG));
        }
        return ergebnisAussteuern(this);
    }
}
