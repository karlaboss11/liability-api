package de.deutscherv.rvsm.fa.fit.azk;

import de.deutscherv.rvsm.fa.fit.security.JwtOidcFilter;
import de.deutscherv.rvsm.fa.fit.azk.openapi.api.AzkApi;
import de.deutscherv.rvsm.fa.fit.azk.openapi.model.PruefungRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Client für die AZK.
 */
@ApplicationScoped
@RegisterRestClient(configKey = "azk")
@RegisterProvider(JwtOidcFilter.class)
@Path("/azk/atad")
public interface AzkClient extends AzkApi {

    @Override
    @POST
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    Response pruefeATAD(
        @HeaderParam("drv-mandant") @Pattern(regexp = "^(\\d{2})$") @Size(min = 2, max = 2)
        @Parameter(description = "KTAN des Traegers") String drvMandant,
        @Valid PruefungRequestDto pruefungRequestDto);

}
