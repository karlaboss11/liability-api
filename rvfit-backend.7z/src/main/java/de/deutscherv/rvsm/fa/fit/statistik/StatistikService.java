package de.deutscherv.rvsm.fa.fit.statistik;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragStatusService;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.aufgaben.utils.AufgabenUtils;
import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import de.deutscherv.rvsm.fa.fit.exceptions.StatistikBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierAntragEinrichtungUtil;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.AntragserfassungDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.BescheidDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.BescheidResponseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.ErfassungResponseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikKonstanten;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikTyp;
import de.deutscherv.rvsm.fa.fit.statistik.util.StatistikUtil;
import de.deutscherv.rvsm.fa.fit.util.Json;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.repository.VerarbeitungsstatusRepository;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.resteasy.reactive.ClientWebApplicationException;
import org.jboss.resteasy.reactive.client.impl.ClientResponseImpl;
import org.jboss.resteasy.reactive.common.jaxrs.ResponseImpl;

/**
 * Statistikservice.
 */
@Slf4j
@ApplicationScoped
public class StatistikService {

    private static final String PERSISTIERE_ANTRAG_IN_DB = "Persistiere Antrag [{}] in DB";

    // kein AF oder nicht exakt 6 Ziffern
    private static final Pattern KEIN_AF_FEHLER = Pattern.compile("^(?!.*AF)(?!.*\\b\\d{6}\\b).+$");

    private final StatistikClient statistikClient;
    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final AntragRepository antragRepository;
    private final VerarbeitungsstatusRepository verarbeitungsstatusRepository;
    private final AntragStatusService antragStatusService;

    private final BestandsfehlerRepository bestandsfehlerRepository;
    private final AufgabeService aufgabeService;
    private final ExceptionHandler exceptionHandler;
    private final PapierAntragEinrichtungUtil antragEinrichtungUtil;

    /**
     * Konstruktor.
     *
     * @param statistikClient               Statistik-Client
     * @param jwt                           JSON-Web-Token
     * @param drvMandant                    DRV-Mandate
     * @param rvfitLogger                   rvFit-Logger
     * @param rVFitJsonSchemaValidator      rvFit-JSON-Schema-Validator
     * @param antragRepository              Antrag-Repository
     * @param verarbeitungsstatusRepository Verarbeitungsstatus-Repository
     * @param antragStatusService           Antragstatus-Service
     * @param aufgabeService                Aufgabe-Service
     * @param bestandsfehlerRepository      Bestandsfehler-Repository
     * @param exceptionHandler              Exception-Handler
     * @param antragEinrichtungUtil         Antrag-Einrichtung-Util
     */
    @Inject
    public StatistikService(@RestClient final StatistikClient statistikClient,
        final JsonWebToken jwt,
        final DrvMandant drvMandant,
        final RvfitLogger rvfitLogger,
        final RVFitJsonSchemaValidator rVFitJsonSchemaValidator,
        final AntragRepository antragRepository,
        final VerarbeitungsstatusRepository verarbeitungsstatusRepository,
        final AntragStatusService antragStatusService,
        final AufgabeService aufgabeService,
        final BestandsfehlerRepository bestandsfehlerRepository,
        final ExceptionHandler exceptionHandler,
        final PapierAntragEinrichtungUtil antragEinrichtungUtil) {
        this.statistikClient = statistikClient;
        this.jwt = jwt;
        this.drvMandant = drvMandant;
        this.rvfitLogger = rvfitLogger;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.antragRepository = antragRepository;
        this.verarbeitungsstatusRepository = verarbeitungsstatusRepository;
        this.antragStatusService = antragStatusService;
        this.aufgabeService = aufgabeService;
        this.bestandsfehlerRepository = bestandsfehlerRepository;
        this.exceptionHandler = exceptionHandler;
        this.antragEinrichtungUtil = antragEinrichtungUtil;
    }

    /**
     * Erfasst eine Statistik und speichert den eAntrag oder den Papierantrag mit dem Status STATISTIK_ERFASST in DB.
     *
     * @param antrag          der eAntrag oder der Papierantrag
     * @param papierantragDto der PapierantragDto
     */
    @Transactional
    public void createStatistikErfassung(final Antrag antrag,
        final Optional<PapierantragDto> papierantragDto) {
        LOG.atInfo().log("Statistikerfassung wird durchgeführt");

        Antrag papierAntragMitEinrichtung = null;
        if (papierantragDto.isPresent()) {
            // Erfassungsaufgaben nur notwendig wenn aus PuR über Absprunglink erfolgt (VorgangsID
            // und AufgabenID != null)
            final boolean presentVorgangsID = papierantragDto.map(PapierantragDto::getVorgangsId).isPresent();
            final boolean presentAufgabenID = papierantragDto.map(PapierantragDto::getAufgabenId).isPresent();
            if (presentVorgangsID && presentAufgabenID) {
                final Aufgabe erfassungsAufgabe = Aufgabe.builder()
                    .aufgabenArt(AufgabenArt.ANTRAGSERFASSUNG).transaktionId(UUID.randomUUID())
                    .vomAufgabenId(papierantragDto.get().getAufgabenId())
                    .datumErstellung(LocalDateTime.now()).build();
                antrag.addAufgabe(erfassungsAufgabe);

                aufgabeService.schliesseAufgabePapierantragErfasst(erfassungsAufgabe,
                    papierantragDto.get().getAufgabenId());

                rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                    Ereignistext.AUFGABE_GESCHLOSSEN,
                    EreignisFreitext.AUFGABE_GESCHLOSSEN, AufgabenArt.ANTRAGSERFASSUNG.name(),
                    antrag, erfassungsAufgabe, jwt, drvMandant));
            }
            papierAntragMitEinrichtung = antragEinrichtungUtil.getAntragMitEinrichtung(papierantragDto.get(), antrag);
        }
        try {
            createStatistikAntragserfassung(
                papierantragDto.isPresent() ? papierAntragMitEinrichtung : antrag);
        } catch (final StatistikException e) {
            exceptionHandler.handleExceptionForRetry(e, antrag,
                "Fehler beim Senden der Statistik eAntrag [statistikService.createStatistikAntragserfassung(antrag)"
                    + " in createStatistikAntragserfassung]");
            throw e;
        }

        antragStatusService.setAntragStatus(antrag, AntragStatus.STATISTIK_ERFASST);
        LOG.atDebug().addArgument(antrag).log(PERSISTIERE_ANTRAG_IN_DB);

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
            Ereignistext.STATISTIK_GEBILDET, EreignisFreitext.STATISTIK_GEBILDET_ERFASSUNG,
            null, antrag, null, jwt, null));
    }

    /**
     * Statistik für die Antragserfassung wird erstellt.
     *
     * @param antrag erfasster Antrag.
     * @return <code>true</code>, falls die Statistik erfolgreich geschrieben wurde, ansonsten <code>false</code>
     * @throws StatistikException Fehler beim Erstellen der Statistik
     */
    @RequiresMandant
    public boolean createStatistikAntragserfassung(final Antrag antrag) throws StatistikException {
        final AntragserfassungDto antragserfassungDto = new AntragserfassungDto();
        antragserfassungDto.setHeader(StatistikUtil.createKopf(antrag));
        antragserfassungDto.setREQUESTFESTERTEIL(StatistikUtil.createFesterTeil(StatistikTyp.ANTRAGSERFASSUNG));
        antragserfassungDto
            .setREQUESTVARIABLERTEIL(StatistikUtil.createRequestVariablerTeilAntragserfassungDto(antrag));

        bestandsfehlerRepository.schliesseAlleBestandsfehlerZuAntrag(antrag.getUuid());

        try (Response response = statistikClient.createStatistikAntragserfassung(antrag.getKtan(),
            antragserfassungDto)) {

            if (response.getStatus() != (Status.CREATED.getStatusCode())) {
                LOG.atError().addArgument(antrag::getUuid)
                    .addArgument(response::getStatus)
                    .addArgument(Json.objectToJson(antragserfassungDto))
                    .log("Fehler bei Statistik Antragserfassung: UUID [{}], Serverstatus: [{}], DTO: [{}]");
                throw new StatistikException(StatistikKonstanten.SERVERFEHLER + response.getStatus());
            }

            final ErfassungResponseDto erfassungResponseDto = response.readEntity(ErfassungResponseDto.class);
            if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.STATISTIK,
                erfassungResponseDto)) {
                throw new IllegalArgumentException(
                    "Keine valide Erfassung angegeben: " + erfassungResponseDto);
            }

            final boolean statistikErfolg = Optional.ofNullable(erfassungResponseDto.getStatistikErfolg()).orElse(true);
            if (!statistikErfolg) {
                handleBestandsFehler(antrag, erfassungResponseDto);
                throw new StatistikBestandsFehlerException(antrag, "", erfassungResponseDto);
            }

            LOG.atDebug().addArgument(erfassungResponseDto.toString()).log("Antwort Json: [{}]");
            antrag.setAtad(Integer.parseInt(erfassungResponseDto.getATAD()));
            antrag.setMsnr(Integer.parseInt(erfassungResponseDto.getMSNR()));

            antragRepository.merge(antrag);

            LOG.atDebug().addArgument(response::getStatus).addArgument(antrag::getKtan)
                .addArgument(antrag::getVsnr).addArgument(antrag::getUuid).log(
                    "AntragserfassungDto wurde versendet. Serverstatus [{}], Ktan [{}], Vsnr [{}], UUID [{}]");

        } catch (final ClientWebApplicationException clientWebApplicationException) {
            final FehlerEintragDto fehlerEintragDto = extrahiereErfassungFehlercodeDto(clientWebApplicationException);
            if (fehlerEintragDto != null) {

                final String statuscode = fehlerEintragDto.getStatuscode();
                // nicht-AF-Fehler
                if (statuscode != null && KEIN_AF_FEHLER.matcher(statuscode).matches()) {
                    throwStatistikException(antrag, clientWebApplicationException);
                }

                handleBestandsFehler(antrag, fehlerEintragDto);

                throw new StatistikBestandsFehlerException(antrag, "Fehler beim Schreiben der Statistik Antragserfassung.",
                    fehlerEintragDto);
            }
            throwStatistikException(antrag, clientWebApplicationException);
        } catch (WebApplicationException | ProcessingException e) {
            throwStatistikException(antrag, e);
        }

        final Aufgabe erfassungsAufgabe = AufgabenUtils.getAufgabeMitAufgabenArtFromAntrag(antrag, AufgabenArt.ANTRAGSERFASSUNG);
        EreignisTyp ereignisTyp = EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL;
        if (antrag.getAntragsart() == AntragsArt.PAPIERANTRAG) {
            ereignisTyp = EreignisTyp.NACHRICHTEN_AUSGANG_USER;
        }
        rvfitLogger
            .sendeFachprotokollEreignis(LogUtils.getFachereignis(ereignisTyp,
                Ereignistext.STATISTIK_GEBILDET, EreignisFreitext.STATISTIK_GEBILDET_ERFASSUNG,
                null, antrag, erfassungsAufgabe, jwt, drvMandant));
        return true;
    }

    /**
     * Statistik wird erstellt.
     *
     * @param antrag                     der Antrags
     * @param erledigungVorRegelPruefung Ob der Antrag vor der Regelprüfung erledigt wurde.
     */
    public void createStatistik(final Antrag antrag, final boolean erledigungVorRegelPruefung) {
        createStatistik(antrag, getArt(antrag), erledigungVorRegelPruefung);
    }

    /**
     * Statistik wird erstellt.
     *
     * @param antrag                     der Antrags
     * @param erledigungsArt             die Erledigungsart des Antrags
     * @param erledigungVorRegelPruefung Ob der Antrag vor der Regelprüfung erledigt wurde.
     */
    public void createStatistik(final Antrag antrag, final Art erledigungsArt,
        final boolean erledigungVorRegelPruefung) {
        validiereVoraussetzungenStatistikErledigung(antrag, erledigungVorRegelPruefung);

        LOG.atDebug().addArgument(antrag.getUuid())
            .log("Es wird Ein Statistikeintrag für den Antrag erstellt. UUID [{}]");

        final boolean statistikErfolg = createStatistikAbschluss(antrag, erledigungsArt, erledigungVorRegelPruefung);
        LOG.atInfo()
            .addArgument(statistikErfolg ? "war erfolgreich" : "ist fehlgeschlagen")
            .addArgument(antrag.getKtan())
            .addArgument(antrag.getVsnr())
            .addArgument(antrag.getUuid())
            .log("Die Statistik-Abschluss Anfrage {}! KTAN [{}], VSNR [{}], UUID [{}]");

        if (statistikErfolg) {
            aktualisiereStatusFuerStatistikAbschlussErfolg(antrag);
        } else {
            aktualisiereStatusFuerStatistikAbschlussFehler(antrag);
        }

        LOG.atInfo().addArgument(antrag::getStatus).log("Antrag hat den Status [{}]");
    }

    /**
     * Statistik wird erstellt.
     *
     * @param antrag                     der Antrags
     * @param erledigungsArt             die Erledigungsart des Antrags
     * @param erledigungVorRegelPruefung Ob der Antrag vor der Regelprüfung erledigt wurde.
     * @return true wenn der Abschluss fehlerfrei durchgefuehrt wurde.
     */
    private boolean createStatistikAbschluss(final Antrag antrag, final Art erledigungsArt,
        final boolean erledigungVorRegelPruefung) {
        final Art art = Optional.ofNullable(erledigungsArt).orElseGet(() -> getArt(antrag));

        final BescheidDto bescheidDto = new BescheidDto();
        bescheidDto.setHeader(StatistikUtil.createKopf(antrag));
        bescheidDto.setREQUESTFESTERTEIL(StatistikUtil.createFesterTeil(StatistikTyp.BESCHEIDDATEN));
        bescheidDto
            .setREQUESTVARIABLERTEIL(StatistikUtil.createRequestVariablerTeilBescheid(antrag, art, erledigungVorRegelPruefung));

        bestandsfehlerRepository.schliesseAlleBestandsfehlerZuAntrag(antrag.getUuid());

        try (Response response = statistikClient.createStatistikBescheid(antrag.getKtan(), bescheidDto)) {
            LOG.atInfo().addArgument(response::getStatus)
                .addArgument(antrag::getKtan)
                .addArgument(antrag::getVsnr)
                .addArgument(antrag::getUuid)
                .addArgument(asString(bescheidDto))
                .log("StatistikBescheidDto wurde versendet. Serverstatus [{}], Ktan [{}], Vsnr [{}], UUID [{}], DTO [{}]");
            final BescheidResponseDto bescheidResponseDto = response.readEntity(BescheidResponseDto.class);
            if (!bescheidResponseDto.getStatistikErfolg()) {
                handleBestandsFehler(antrag, bescheidResponseDto);
                throw new StatistikBestandsFehlerException(antrag, "Bestandsfehler (FE)", bescheidResponseDto);
            } else {
                rvfitLogger
                    .sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.BESCHEID_ERTEILT,
                        Ereignistext.VORGANG_STATISTISCH_ERFASST, EreignisFreitext.ANTRAG_BESCHIEDEN,
                        null, antrag, null, jwt, drvMandant));
                return true;
            }
        } catch (final ClientWebApplicationException clientWebApplicationException) {
            final FehlerEintragDto fehlerEintragDto = extrahiereAbschlussFehlercodeDto(clientWebApplicationException);

            if (fehlerEintragDto != null) {
                final String statuscode = fehlerEintragDto.getStatuscode();

                // nicht-AF-Fehler
                if (statuscode != null && KEIN_AF_FEHLER.matcher(statuscode).matches()) {
                    throwStatistikException(antrag, clientWebApplicationException);
                }

                handleBestandsFehler(antrag, fehlerEintragDto);

                throw new StatistikBestandsFehlerException(antrag, "Bestandsfehler (AF)", fehlerEintragDto);
            }
            throwStatistikException(antrag, clientWebApplicationException);
        } catch (WebApplicationException | ProcessingException e) {
            throwStatistikException(antrag, e);
        }
        return true;
    }

    private static void throwStatistikException(Antrag antrag, RuntimeException e) {
        LOG.atError().addArgument(e.getMessage()).addArgument(antrag::getKtan)
            .addArgument(antrag::getVsnr).addArgument(antrag::getUuid).log(
                "Serverfehler bei Statistik Bescheid. Exceptionmeldung: [{}], Ktan [{}], Vsnr [{}], UUID [{}]");
        throw new StatistikException(StatistikKonstanten.SERVERFEHLER + e.getMessage());
    }

    private static FehlerEintragDto extrahiereAbschlussFehlercodeDto(ClientWebApplicationException clientWebApplicationException) {
        return Optional.ofNullable(clientWebApplicationException.getResponse())
            .map(ClientResponseImpl.class::cast)
            .filter(ResponseImpl::hasEntity)
            .map(clientResponse -> {
                try {
                    final BescheidResponseDto bescheidResponseDto = clientResponse.readEntity(BescheidResponseDto.class);
                    return bescheidResponseDto.getRvSystemFehler().stream()
                        .filter(f -> f.getStatuscode().contains("AF")).findFirst().orElse(null);
                } catch (Exception e) {
                    return null;
                }
            }).orElse(null);
    }

    private static FehlerEintragDto extrahiereErfassungFehlercodeDto(ClientWebApplicationException clientWebApplicationException) {
        return Optional.ofNullable(clientWebApplicationException.getResponse())
            .map(ClientResponseImpl.class::cast)
            .filter(ResponseImpl::hasEntity)
            .map(clientResponse -> {
                try {
                    final ErfassungResponseDto erfassungResponseDto = clientResponse.readEntity(ErfassungResponseDto.class);
                    return erfassungResponseDto.getRvSystemFehler().stream()
                        .filter(f -> f.getStatuscode() != null).findFirst().orElse(null);
                } catch (Exception e) {
                    return null;
                }
            }).orElse(null);
    }

    private void handleBestandsFehler(final Antrag antrag, final BescheidResponseDto bescheidResponseDto) {
        bescheidResponseDto.getRvSystemFehler()
            .forEach(fehlerEintragDto -> handleBestandsFehler(antrag, fehlerEintragDto));
    }

    private void handleBestandsFehler(final Antrag antrag, final ErfassungResponseDto erfassungResponseDto) {
        erfassungResponseDto.getRvSystemFehler()
            .forEach(fehlerEintragDto -> handleBestandsFehler(antrag, fehlerEintragDto));
    }

    private void handleBestandsFehler(final Antrag antrag, final FehlerEintragDto fehlerEintragDto) {
        final Bestandsfehler bestandsfehler = new Bestandsfehler();
        bestandsfehler.setAntragId(antrag.getUuid());
        bestandsfehler.setBestandsfehlercode(fehlerEintragDto.getStatuscode());
        bestandsfehlerRepository.persist(bestandsfehler);
    }

    private static String asString(final BescheidDto bescheidDto) {
        try {
            return Json.objectToJson(bescheidDto);
        } catch (final RvfitException e) {
            return bescheidDto.toString();
        }
    }

    private Art getArt(final Antrag antrag) throws StatistikException {
        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusRepository.findByAntragId(antrag.getUuid());

        if (verarbeitungsstatus.isEmpty()) {
            if (automatischeBewilligung(antrag)) {
                return Art.BEWILLIGUNG;
            }
            if (automatischeAblehnung(antrag)) {
                return Art.ABLEHNUNG;
            }
            LOG.atWarn().addArgument(antrag::getKtan).addArgument(antrag::getVsnr)
                .addArgument(antrag::getUuid).log(
                    "Kein Verabeitungsstatus zu Antrag gefunden.  Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new StatistikException(
                "Kein Verarbeitungsstatus zur AntragsID " + antrag.getUuid() + " gefunden.");
        }
        return verarbeitungsstatus.get().getArt();
    }

    private static boolean automatischeBewilligung(@Nonnull final Antrag antrag) {
        return antrag.getAntragPruefergebnisse().stream().map(AntragPruefergebnis::getErgebnis)
            .allMatch(p -> p.equals(PruefErgebnis.ERFUELLT));
    }

    private static boolean automatischeAblehnung(@Nonnull final Antrag antrag) {
        return !PruefergebnisUtils.personendatenabgleichFailed(antrag) && antrag.getAntragPruefergebnisse().stream()
            .map(AntragPruefergebnis::getErgebnis)
            .anyMatch(p -> p.equals(PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN));
    }

    /**
     * Wenn der Antrag vor der Regelprüfung erledigt wird dürfen keine Prüfergebnisse vorhanden sein. Ansonsten müssen Prüfergebnisse
     * vorliegen.
     *
     * @param antrag                     der Antrag
     * @param erledigungVorRegelPruefung <code>true</code>, falls der Antrag vor der Regelprüfung erledigt wird,
     *                                   ansonsten <code>false</code>
     */
    private static void validiereVoraussetzungenStatistikErledigung(final Antrag antrag,
        final boolean erledigungVorRegelPruefung) {
        final boolean pruefergebnisseSindVorhanden = Objects.nonNull(antrag.getAntragPruefergebnisse())
            && !antrag.getAntragPruefergebnisse().isEmpty();
        final boolean darfStatistikSchreiben = pruefergebnisseSindVorhanden || erledigungVorRegelPruefung;

        if (!darfStatistikSchreiben) {
            LOG.atDebug().addArgument(antrag.getKtan()).addArgument(antrag.getVsnr())
                .addArgument(antrag.getUuid())
                .log("Antrag enthält keine Pruefergebnisse. Ktan [{}], Vsnr [{}], UUID [{}]");
            throw new StatistikException(
                antrag.getUuid().toString() + " enthält keine Pruefergebnisse");
        }
    }

    /**
     * Aktualisiert den Antragsstatus im Fehlerfall.
     *
     * @param antrag der Antrag
     */
    private static void aktualisiereStatusFuerStatistikAbschlussFehler(final Antrag antrag) {
        if (antrag.getStatus() != AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT) {
            antrag.setStatus(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN);
        }
    }

    /**
     * Aktualisiert den Antragsstatus im Erfolgsfall.
     *
     * @param antrag der Antrag
     */
    private static void aktualisiereStatusFuerStatistikAbschlussErfolg(final Antrag antrag) {
        if (antrag.getStatus() == AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT) {
            antrag.setStatus(AntragStatus.STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN);
        } else {
            antrag.setStatus(AntragStatus.STATISTIK_ABGESCHLOSSEN);
        }
    }
}
