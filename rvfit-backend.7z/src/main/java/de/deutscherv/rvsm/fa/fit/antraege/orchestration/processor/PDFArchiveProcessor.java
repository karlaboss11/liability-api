package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * PDFArchiveProcessor.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class PDFArchiveProcessor implements Processor {
    private final AntragService antragService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        antragService.createPdfArchiv(antrag);
    }
}

