package de.deutscherv.rvsm.fa.fit.rvpur.mapper;

import de.deutscherv.rvsm.fa.fit.rvpur.model.RvPurRequest;
import de.deutscherv.rvsm.fa.fit.rvpur.model.RvPurResponse;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangRequestDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import java.util.Arrays;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

/**
 * RvPurMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR,
        uses = {RvPurStammdatenMapper.class }, imports = { Arrays.class })
public interface RvPurMapper {

    /**
     * Mappt RvPurRequest zu rvSystem Bestand VorgangRequestDto.
     *
     * @param rvPurRequest die RvPurRequest.
     * @return die VorgangRequestDto.
     */
    @Mapping(target = "removeDokumenteItem", ignore = true)
    VorgangRequestDto toVorgangRequestDto(RvPurRequest rvPurRequest);

    /**
     * Mappt VorgangResponseDto aus rvSystem Bestand in Entity.
     *
     * @param vorgangResponseDto die VorgangResponseDto.
     * @return die Entity.
     */
    RvPurResponse toRvPurResponse(VorgangResponseDto vorgangResponseDto);
}
