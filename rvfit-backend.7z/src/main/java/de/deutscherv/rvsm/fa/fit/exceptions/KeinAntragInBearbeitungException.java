package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * Exception für den Fall, dass zu einer gegebenen ID kein Antrag gefunden wurde.
 */
public class KeinAntragInBearbeitungException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor für die Exception.
     *
     * @param uuid die UUID des gesuchten Antrags
     */
    public KeinAntragInBearbeitungException(final String uuid) {
        super(uuid);
    }
}
