package de.deutscherv.rvsm.fa.fit.papierantraege;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.papierantraege.service.PapierAntraegeService;
import de.deutscherv.rvsm.fa.fit.verarbeitung.mapper.ArtMapper;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import de.deutscherv.rvsm.fa.fit.openapi.api.PapierantraegeApi;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VerarbeitungsartDto;
import de.deutscherv.rvsm.fa.fit.util.TimeoutFallbackHandler;
import jakarta.annotation.security.RolesAllowed;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_BST;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_EF;
import static java.util.Objects.isNull;

/**
 * API Papierantraege.
 */
@Slf4j
@RequiredArgsConstructor
@SecurityRequirement(name = "keycloak")
@ApplicationScoped
@Path("/papierantraege")
public class PapierAntraegeApiImpl implements PapierantraegeApi {

    private final JsonWebToken jwt;
    private final PapierAntraegeService papierAntraegeService;
    private final AntragService antragService;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final ArtMapper artMapper;

    /**
     * Papierantrag erstellen.
     */
    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @RequiresMandant
    public Response createPapierantrag(@Valid @NotNull final PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantrag(papierantragDto))
                .build();
    }

    /**
     * Papierantragsentwurf erstellen.
     */
    @Override
    @RequiresMandant
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @POST
    @Path("/entwurf")
    @Consumes({ "application/json" })
    @Produces({ "application/json", "application/problem+json" })
    public Response createPapierantragEntwurf(
        @Valid @NotNull final PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantragEntwurf(papierantragDto))
                .build();
    }

    /**
     * Papierantragsentwuft anhand der Versicherungsnr. lesen.
     */
    @Override
    @RequiresMandant
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @Timeout(value =  20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    @GET
    @Path("/entwurf/{vsnr}")
    @Produces({ "application/json", "application/problem+json" })
    public Response getPapierantragEntwurfByVsnr(final String vsnr) {
        LOG.atDebug().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vsnr)
            .log("Suche Papierantragsentwurf mit VSNR. DrvId [{}] Vsnr [{}]");

        final PapierantragDto papierantragDto =
                papierAntraegeService.getPapierantragEntwurfByVsnr(vsnr);

        if (isNull(papierantragDto)) {
            return Response.status(HttpStatus.SC_NOT_FOUND).build();
        }
        return Response.ok(papierantragDto).build();
    }

    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST})
    @RequiresMandant
    @POST
    @Path("/erledigung-auf-andere-art-und-weise")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response verarbeitePapierantragErledigungAufAndereArtUndWeise(
            @Valid @NotNull final PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantragErledigungAufAndereArtUndWeise(papierantragDto))
                .build();
    }

    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST})
    @RequiresMandant
    @POST
    @Path("/weiterbearbeitung-in-rvdialog-ohne-erfassung")
    @Consumes({ "application/json" })
    @Produces({ "application/json", "application/problem+json" })
    public Response verarbeitePapierantragOhneErfassungWeiterbearbeitungInRvDialog(@Valid @NotNull PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantragOhneErfassungInRvDialogWeiterbearbeitungInRvDialog(papierantragDto))
                .build();
    }

    @Override
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST})
    @RequiresMandant
    @POST
    @Path("/ruecknahme")
    @Consumes({ "application/json" })
    @Produces({ "application/json", "application/problem+json" })
    public Response verarbeitePapierantragRuecknahme(@Valid @NotNull final PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantragRuecknahme(papierantragDto))
                .build();
    }

    @Override
    @RequiresMandant
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @POST
    @Path("/weiterbearbeitung-in-rvdialog")
    @Consumes({ "application/json" })
    @Produces({ "application/json", "application/problem+json" })
    public Response verarbeitePapierantragWeiterbearbeitungInRvDialog(
        @Valid @NotNull final PapierantragDto papierantragDto) {
        return Response.status(HttpStatus.SC_CREATED)
                .entity(papierAntraegeService.createPapierantragWeiterbearbeitungInRvDialog(papierantragDto))
                .build();
    }

    /**
     * Papierantragsentwuft anhand der UUID lesen.
     */
    @Override
    @RequiresMandant
    @RolesAllowed({RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    public Response getPapierantragEntwurfByUuid(final String uuid) {
        LOG.atDebug().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid)
            .log("Suche Papierantragsentwurf mit UUID. DrvId [{}] UUID [{}]");
        final PapierantragDto papierantragDto =
                papierAntraegeService.getPapierantragEntwurfByUuid(UUID.fromString(uuid));

        if (isNull(papierantragDto)) {
            return Response.status(HttpStatus.SC_NOT_FOUND).build();
        }

        LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid)
            .log("Papierantragsentwurf gefunden. DrvId [{}] Vsnr [{}]");
        return Response.ok(papierantragDto).build();
    }

    /**
     * Gibt die Verarbeitungsart für einen Antrag mit der VorgangsId zurück.
     *
     * @param vorgangsId des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF})
    @RequiresMandant
    @Produces({ "application/json", "application/problem+json" })
    public Response getVerarbeitungsartByVorgangsId(String vorgangsId) {
        final Antrag antrag = antragService.getAntragByVorgangskennung(vorgangsId);

        if (isNull(antrag)) {
            return Response.ok(null).build();
        }

        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusService.getVerarbeitungsstatusFallsAbgeschlossen(
                antrag.getUuid());

        if (verarbeitungsstatus.isPresent()) {
            return Response.ok(artMapper.toDto(verarbeitungsstatus.get().getArt())).build();

        } else {
            if(antrag.getStatus().equals(AntragStatus.ENTWURF)) {
                return Response.ok(null).build();
            }

            return Response.ok(VerarbeitungsartDto.ArtEnum.IN_BEARBEITUNG).build();
        }
    }
}
