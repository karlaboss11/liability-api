package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.VerarbeitungsService;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum automatischen Bescheiderstellung.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class AutomatischeBescheiderstellungsProcessor implements Processor {

    private final FehlerRepository fehlerRepository;
    private final VerarbeitungsService verarbeitungsService;
    private final AntragRepository antragRepository;
    @Override
    public void process(final Exchange exchange) throws Exception {

        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        try {

            verarbeitungsService.verarbeiteAutomatischFallsBewilligungOderAblehnung(antrag);
            antrag = antragRepository.merge(antrag);
            antragRepository.flush();
            exchange.getMessage().setBody(antrag);
        } catch (final Exception e) {
            LOG.atInfo().addArgument("Fehler bei der automatischen Bescheiderstellung:")
                    .addArgument(antrag.getUuid())
                    .addArgument(e.getMessage())
                    .log("{} UUID [{}] Exception [{}]");
            fehlerRepository.persistiereFehlerFuerAntrag(antrag);
            exchange.setRouteStop(true);
        }

    }

}