package de.deutscherv.rvsm.fa.fit.antraege.model;

/**
 * Enum für die Art des rvFit-Antrags.
 */
public enum AntragsArt {
    /**
     * Antrag wurde über eAntrag gestellt.
     */
    E_ANTRAG,

    /**
     * Antrag wurde als Papierantrag gestellt.
     */
    PAPIERANTRAG
}
