package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Abgleich der Stammdaten mit den Versichertendaten aus dem Antrag.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class PersonendatenableichProcessor implements Processor {

    private static final String DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB = "Delete Pruefergebnisse [{}] des Antrags von DB";
    private final EntityManager entityManager;
    private final AntragService antragService;
    private final StammdatenService stammdatenService;
    private final ExceptionHandler exceptionHandler;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final var uuid = exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, UUID.class);
        final Antrag antrag = antragService.getAntragByUuid(uuid);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        Stammdaten stammdaten = null;
        try {
            stammdaten = stammdatenService.getStammdatenByVsnr(antrag);
        } catch (final StammdatenBestandsFehlerException e) {
            exchange.getMessage().setHeader(RVFitCamelHeader.STAMMDATEN_BESTANDSFEHLER, e);
            exchange.setRouteStop(true);
            return;
        } catch (final Exception e) {
            exchange.setProperty(Exchange.EXCEPTION_CAUGHT, e);
            exchange.getMessage().setBody(antrag);
            exceptionHandler.process(exchange);
            return;
        }

        if (!isGleichStammdaten(antrag.getVersichertenStammdaten().getFirst(), stammdaten)) {
            updateVersicherterStammdaten(antrag, stammdaten);
            deleteAlleRegelnAusserPersonendatenabgleich(antrag);
            entityManager.merge(antrag);
            entityManager.flush();
            exchange.getMessage().setHeader("stammdatenUpdated", true);
        } else {
            exchange.getMessage().setHeader("stammdatenUpdated", false);
        }
        exchange.getMessage().setBody(antrag);
    }

    /**
     * Vergleich ob die Stammdaten mit den Versichertedaten aus dem Antrag uebereinstimmen.
     * @param versicherterStammdaten Daten des Versicherten aus dem Antrag
     * @param stammdaten Stammdaten des Versicherten
     * @return true wenn die Daten identisch sind.
     */
    @Transactional
    public boolean isGleichStammdaten(final Stammdaten versicherterStammdaten,
            final Stammdaten stammdaten) {
        return Objects.equals(versicherterStammdaten.getGeburtsdatum(),
                stammdaten.getGeburtsdatum())
                && Objects.equals(versicherterStammdaten.getHausnummer(), stammdaten.getHausnummer())
                && Objects.equals(versicherterStammdaten.getLand(), stammdaten.getLand())
                && Objects.equals(versicherterStammdaten.getNachname(), stammdaten.getNachname())
                && Objects.equals(versicherterStammdaten.getPlz(), stammdaten.getPlz())
                && Objects.equals(versicherterStammdaten.getStaatsangehoerigkeit(),
                stammdaten.getStaatsangehoerigkeit())
                && Objects.equals(versicherterStammdaten.getStrasse(), stammdaten.getStrasse())
                && Objects.equals(versicherterStammdaten.getVorname(), stammdaten.getVorname())
                && Objects.equals(versicherterStammdaten.getVsnr(), stammdaten.getVsnr())
                && Objects.equals(versicherterStammdaten.getWohnort(), stammdaten.getWohnort());
    }

    /**
     * Versichertenstammdaten werden aktualisiert.
     * @param antrag betroffener Antrag
     * @param stammdaten die geschrieben werden
     */
    @Transactional
    public void updateVersicherterStammdaten(final Antrag antrag, final Stammdaten stammdaten) {
        final Stammdaten versicherterStammdaten = antrag.getVersichertenStammdaten().getFirst();
        versicherterStammdaten.setGeburtsdatum(stammdaten.getGeburtsdatum());
        versicherterStammdaten.setHausnummer(stammdaten.getHausnummer());
        versicherterStammdaten.setLand(stammdaten.getLand());
        versicherterStammdaten.setNachname(stammdaten.getNachname());
        versicherterStammdaten.setPlz(stammdaten.getPlz());
        versicherterStammdaten.setStaatsangehoerigkeit(stammdaten.getStaatsangehoerigkeit());
        versicherterStammdaten.setStrasse(stammdaten.getStrasse());
        versicherterStammdaten.setVorname(stammdaten.getVorname());
        versicherterStammdaten.setVsnr(stammdaten.getVsnr());
        versicherterStammdaten.setWohnort(stammdaten.getWohnort());
    }

    /**
     * Enfernt alle Regeln Prüfergebnisse außer Personendatenabgleich für einen Antrag.
     *
     * @param antrag der Antrags
     */
    private void deleteAlleRegelnAusserPersonendatenabgleich(final Antrag antrag) {
        LOG.atDebug().log(
                "Service check checkPersonendatenabgleich: Die Anspruchspruefung des Antrags wird berechnet");

        List<AntragPruefergebnis> antragPruefergebnisse = antrag.getAntragPruefergebnisse();
        antragPruefergebnisse.removeIf(ap -> Objects.isNull(ap.getRegelName())
                || ap.getRegelName().equals(RegelName.REGEL_BEMERKUNG)
                || PruefergebnisUtils.EINRICHTUNG_REGELN.contains(ap.getRegelName())
                || PruefergebnisUtils.ANSPRUCHSVORAUSSETZUNG_REGELN.contains(ap.getRegelName()));

        LOG.atDebug().addArgument(RegelName.REGEL_BEMERKUNG)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
        LOG.atDebug().addArgument(PruefergebnisUtils.EINRICHTUNG_REGELN)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
        LOG.atDebug().addArgument(PruefergebnisUtils.ANSPRUCHSVORAUSSETZUNG_REGELN)
                .log(DELETE_PRUEFERGEBNISSE_DES_ANTRAGS_VON_DB);
    }
}
