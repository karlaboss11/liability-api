package de.deutscherv.rvsm.fa.fit.rvpur;

import de.deutscherv.rvsm.fa.fit.security.JwtOidcFilter;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangRequestDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Client fuer das rvSystemBestand-Gateway.
 */
@ApplicationScoped
@RegisterRestClient(configKey = "rvpur")
@RegisterProvider(JwtOidcFilter.class)
@Path("/sendungsservice")
public interface RvPurClient {

    /**
     * Sucht Vorgaenge.
     *
     * @param ktan              KTAN
     * @param vorgangsKennungen nach denen gesucht wird.
     * @return gefundene Vorgannge
     */
    @POST
    @Path("/{ktan}/vorgaenge")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    Response sucheVorgaenge(@PathParam("ktan") String ktan, @Valid @NotNull List<String> vorgangsKennungen);

    /**
     * Uebernahme Seundung 2127.
     *
     * @param ktan              KTAN
     * @param vorgangRequestDto VorgangRequestDto
     * @return VorgangResponsDto
     */
    @POST
    @Consumes((MediaType.APPLICATION_JSON))
    @Produces((MediaType.APPLICATION_JSON))
    @Path("/{ktan}/uebernehmeSendung2127")
    VorgangResponseDto uebernehmeSendung2127(@PathParam("ktan") String ktan,
            VorgangRequestDto vorgangRequestDto);

}
