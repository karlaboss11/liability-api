package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum Laden eines Antrags in Bearbeitung.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class AntragInBearbeitungEnricher implements Processor {

    private final AntragService antragService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        final Antrag antrag = antragService.sucheAntragInBearbeitungMitUuid(uuid);
        exchange.getMessage().setBody(antrag);
    }
}
