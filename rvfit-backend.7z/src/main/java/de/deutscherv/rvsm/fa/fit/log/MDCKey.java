package de.deutscherv.rvsm.fa.fit.log;

/**
 * Enum für MDC Keys.
 */
public enum MDCKey {

    /**
     * Der Key, unter dem im MDC hinterlegt wird, für welchen DRV-Mandanten die Aktion durchgeführt wird.
     */
    DRV_MANDANT("drv_mandant"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, für welcher Session ID die Aktion durchgeführt wird.
     */
    SESSION_ID("session-id"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, für welche JMS Message ID die Aktion durchgeführt wird.
     */
    JMS_MESSAGE_ID("jms-message-id"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, für welche Correlation ID die Aktion durchgeführt wird.
     */
    HEADER_CORRELATION_ID("X-Correlation-ID"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, im Kontext welchen Nutzers die Aktion durchgeführt wird.
     */
    USER_ID("user-id"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, im Kontext welcher Versicherungsnummer die Aktion durchgeführt wird.
     */
    VSNR("vsnr"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, im Kontext welcher VorgangsId die Aktion durchgeführt wird.
     */
    VORGANGS_ID("vorgangsId"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, ob erfolgtes Ereignis sicherheitsrelevant ist.
     */
    SECURITY_LEVEL("security-level"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, von welcher IP die Anfrage stammt.
     */
    SOURCE_IP("source-ip"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, ob die Aktion erfolgreich war.
     */
    EVENT_SUCCESS("event-success"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, welche Rollen der Nutzer hat.
     */
    USER_ROLES("user-roles"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, im Kontext welchen Clients die Aktion durchgeführt wird.
     */
    CLIENT_ID("client-id"),

    /**
     * Der Key, unter dem im MDC hinterlegt wird, welchen Status Code die Antwort an den Aufrufer haben wird.
     */
    STATUS_CODE("statusCode");

    private final String value;

    MDCKey(final String value) {
        this.value = value;
    }

    /**
     * Liefert den Wert zu einem Key.
     *
     * @return geliefewrter Wert
     */
    public String valueOf() {
        return this.value;
    }
}