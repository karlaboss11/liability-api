package de.deutscherv.rvsm.fa.fit.health;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.Date;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Liveness;

/**
 * LivenessCheck.
 */
@Liveness
@ApplicationScoped
public class LivenessCheck implements HealthCheck {

    @Override
    public HealthCheckResponse call() {
        return HealthCheckResponse.named("rvFit Service Liveness Check")
                .withData("time", String.valueOf(new Date())).up().build();
    }

}
