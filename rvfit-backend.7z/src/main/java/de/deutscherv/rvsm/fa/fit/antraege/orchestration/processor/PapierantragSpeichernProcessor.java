package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Processor um den Status des Antrags zu aktualisieren.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragSpeichernProcessor implements Processor {

    /**
     * Routennamen zum Papierantrag speichern.
     */
    public static final String DIRECT_PAPIERANTRAG_SPEICHERN = "direct:papierantragSpeichern";

    private final AntragRepository antragRepository;
    private final RvfitLogger rvfitLogger;
    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;

    @Override
    public void process(final Exchange exchange) {
        Antrag antrag = Optional.of(exchange)
                .map(Exchange::getMessage)
                .map(msg -> msg.getBody(Antrag.class))
                .orElseThrow(NullPointerException::new);

        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        antrag.setStatus(AntragStatus.PAPIERANTRAG_GESPEICHERT);
        antrag.setStatus(AntragStatus.VORGANG_ERZEUGT);
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
        
        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
                EreignisTyp.ZWISCHENEREIGNIS_USER,
                Ereignistext.ANTRAGSDATEN_GESPEICHERT,
                EreignisFreitext.PAPIERANTRAG_GESPEICHERT,
                null,
                antrag,
                null,
                jwt,
                drvMandant
        ));
    }

}
