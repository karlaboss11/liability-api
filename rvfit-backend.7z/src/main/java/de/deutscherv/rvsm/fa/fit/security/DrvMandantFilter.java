package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * DrvMandantFilter.
 */
@Provider
@RequiredArgsConstructor
@Slf4j
public class DrvMandantFilter implements ContainerRequestFilter, ContainerResponseFilter {

    private static final String DRV_MANDANT_SCOPE_KEY = DrvMandantFilter.class.getSimpleName() + "_SCOPE_KEY";

    // früher KtanContext
    private final DrvMandant mandantholder;

    private final JsonWebToken jwt;
    @Context
    private final ResourceInfo resourceInfo;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        LOG.warn("DrvMandantFilter");

        Optional.ofNullable(requestContext.getHeaders().getFirst("drv_mandant"))
                .ifPresent(mandantholder::setInScope);
        if(Optional.of(requestContext)
                   .map(ContainerRequestContext::getUriInfo)
                   .map(UriInfo::getPath)
                   .map(path -> path.startsWith("/cron") || path.startsWith("/ping"))
                   .orElse(false)){
            return;
        }
        LOG.warn("KTAN:" + JwtUtils.GET_KTAN.apply(jwt, mandantholder));
        Optional.ofNullable(resourceInfo.getResourceMethod().getAnnotation(RequiresMandant.class))
                .or(() -> Optional.ofNullable(resourceInfo.getResourceClass().getAnnotation(RequiresMandant.class)))
                .ifPresent(annotation -> {
                    final String mandant = JwtUtils.GET_KTAN.apply(jwt, mandantholder);
                    requestContext.setProperty(DRV_MANDANT_SCOPE_KEY, mandantholder.setInScope(mandant));
                });
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        if (requestContext.getProperty(DRV_MANDANT_SCOPE_KEY) instanceof AutoCloseable closeable) {
            try {
                closeable.close();
            } catch (Exception e) {
                throw new InternalServerErrorException(e);
            }
        }
    }

}