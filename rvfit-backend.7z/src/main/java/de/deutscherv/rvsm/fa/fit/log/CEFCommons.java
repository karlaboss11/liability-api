package de.deutscherv.rvsm.fa.fit.log;

import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import lombok.Getter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * CEF-Commons.
 */
@ApplicationScoped
public class CEFCommons {

    @Getter
    @ConfigProperty(name = "cef.destination-host-name")
    private String destinationHostName;

    @Getter
    @ConfigProperty(name = "cef.destination-service-name")
    private String destinationServiceName;

    /**
     * Liefert die AntwortDto-Nachricht aus dem Response-Kontext.
     * @param responseContext zu lesende Response
     * @return ermittelte Nachricht.
     */
    public String getMessage(final ContainerResponseContext responseContext) {
        if (responseContext.getEntity() instanceof AntwortDto antwortDto) {
            return antwortDto.getNachricht();
        }
        return null;
    }

    /**
     * Liefert die RequestURL aus dem Request-Kontext.
     * @param requestContext zu lesender Request.
     * @return ermittelte URL
     */
    public String getRequestUrl(ContainerRequestContext requestContext) {
        return requestContext.getUriInfo().getRequestUri().toString();
    }
}
