package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.BescheidResponseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.ErfassungResponseDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.FehlerEintragDto;
import java.util.List;
import lombok.Getter;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * Exception für den Fall, dass zu ein Bestandsfehler zurückgeliefert wurde.
 */
@Getter
public class StatistikBestandsFehlerException extends BestandsfehlerException {

    private final transient BestandsfehlerDto bestandsfehlerDto;

    /**
     * Konstruktor für die Exception.
     * @param antrag betroffener Antrag
     * @param message die Fehlernachricht
     */
    public StatistikBestandsFehlerException(final Antrag antrag, final String message) {
        super(antrag, message);
        this.bestandsfehlerDto = new BestandsfehlerDto();
        this.bestandsfehlerDto.setVsnr(antrag.getVsnr());
        this.bestandsfehlerDto.setVorname(antrag.getVorname());
        this.bestandsfehlerDto.setName(antrag.getNachname());
    }

    /**
     * Konstruktor.
     * @param antrag betroffener Antrag
     * @param message Fehlermeldung
     * @param fehlerEintragDto FehlerEintragDto
     */
    public StatistikBestandsFehlerException(final Antrag antrag, final String message, final FehlerEintragDto fehlerEintragDto) {
        this(antrag, message);

        boolean isRvSystemFehler = NumberUtils.isDigits(fehlerEintragDto.getStatuscode());

        if (isRvSystemFehler) {
            bestandsfehlerDto.setRvSystemFehlerCodes(List.of("FE" + fehlerEintragDto.getStatuscode()));
        } else {
            UnerwartererFehlerDto unerwartererFehler = new UnerwartererFehlerDto();
            unerwartererFehler.setFehlercode(fehlerEintragDto.getStatuscode());
            bestandsfehlerDto.setUnerwartererFehler(unerwartererFehler);
        }
    }

    /**
     * Konstruktor.
     * @param antrag betroffener Antrag
     * @param message Fehlermeldung
     * @param bescheidResponseDto BescheidResponseDto
     */
    public StatistikBestandsFehlerException(final Antrag antrag, final String message, final BescheidResponseDto bescheidResponseDto) {
        this(antrag, message);
        bestandsfehlerDto.setRvSystemFehlerCodes(bescheidResponseDto.getRvSystemFehler().stream()
                .map(this::getFeFehlerFormat).toList());
    }

    /**
     * Konstruktor.
     * @param antrag betroffener Antrag
     * @param message Fehlermeldung
     * @param erfassungResponseDto ErfassungResponseDto
     */
    public StatistikBestandsFehlerException(final Antrag antrag, final String message, final ErfassungResponseDto erfassungResponseDto) {
        this(antrag, message);
        bestandsfehlerDto.setRvSystemFehlerCodes(erfassungResponseDto.getRvSystemFehler().stream()
                .map(this::getFeFehlerFormat).toList());
    }

    private String getFeFehlerFormat(final FehlerEintragDto fehlerCode) {
        return String.format("FE%s", fehlerCode.getStatuscode());
    }
}
