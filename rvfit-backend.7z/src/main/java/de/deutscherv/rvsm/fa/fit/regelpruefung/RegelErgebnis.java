package de.deutscherv.rvsm.fa.fit.regelpruefung;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Object um das Ergebnis einer Regelprüfung zu transportieren. */
@Data
@NoArgsConstructor
@SuppressWarnings("java:S1068")
public class RegelErgebnis {

    /**
     * Regeln Detail Texts der Regel Gesamtergebnisse.
     */
    private static final EnumMap<PruefErgebnis, String> GESAMT_DETAIL = new EnumMap<>(Map.of(
            PruefErgebnis.ERFUELLT, "Regelprüfung erfolgreich, alle Bedingungungen sind erfüllt!",
            PruefErgebnis.AUSSTEUERN,
            "Regelprüfung konnte in mindestens einem Fall nicht durchgeführt werden und erfordert manuelle Bearbeitung!",
            PruefErgebnis.NICHT_ERFUELLT_AUSSTEUERN,
            "Regelprüfung in mindestens einem Fall negativ und erfordert manuelle Bearbeitung!",
            PruefErgebnis.NICHT_ERFUELLT_ABLEHNEN,
            "Regelprüfung in mindestens einem Fall negativ, der zur direkten Ablehnung führt!"));

    private PruefErgebnis pruefErgebnis;

    /** ergebnis betrifft welche regel? null für das Gesamtergebnis. */
    private RegelName regelName;

    /** Detailinformationen bei Ablehnung, vor allem nötig bei komplexen Regeln. */
    private String detail;

    /**
     * wenn dieses Ergebnis die Summe von Teilergebnissen ist, dann sind die Teilergebnisse hier gespeichert.
     */
    private List<RegelErgebnis> detailErgebnisse;

    /**
     * Konstruktor.
     *
     * @param pruefErgebnis Das Prüfergebnis
     * @param detail        ein Text, der die Details beschreibt
     */
    public RegelErgebnis(final PruefErgebnis pruefErgebnis, final String detail) {
        this.pruefErgebnis = pruefErgebnis;
        this.detail = detail;
    }

    /**
     * Konstruktor.
     *
     * @param pruefErgebnis Das Prüfergebnis
     * @param regelName     Der Name der Regel
     * @param detail        ein Text, der die Details beschreibt
     */
    public RegelErgebnis(final PruefErgebnis pruefErgebnis, final RegelName regelName,
            final String detail) {
        this.pruefErgebnis = pruefErgebnis;
        this.regelName = regelName;
        this.detail = detail;
    }

    /**
     * Liefert den Text zu einem Pruefergebnis.
     * @param pruefErgebnis betroffenes Pruefergebnis
     * @return Text zum Pruefergebnis.
     */
    public static String getGesamtDetail(final PruefErgebnis pruefErgebnis) {
        return GESAMT_DETAIL.get(pruefErgebnis);
    }
}
