package de.deutscherv.rvsm.fa.fit.util;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Stellt Methoden zur Erstellung/Verwendung von Metriken, zur Überwachung der Fehler Status zur Verfuegung.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class FehlerMetricUtil {

    private static final String METRIK_NAME = "erzeugte_fehlereintraege";

    private final MeterRegistry registry;

    private final ConcurrentHashMap<String, AtomicLong> gaugeMap = new ConcurrentHashMap<>();

    /**
     * Aktualisiert die Fehler Metrik oder erstellt sie, fuer einen neuen Fehler.
     *
     * @param ktan      Der Mandant des Antrags
     * @param antragsId Die UUID des Antrags
     * @param retries   Die aktuelle Anzahl der Retries
     */
    public void updateSingleFehlerMetrik(final String ktan, final String antragsId, final long retries) {
        final String key = ktan + ":" + antragsId;

        final AtomicLong gauge = gaugeMap.computeIfAbsent(key, k -> {
            LOG.atDebug().addArgument(antragsId).log("Erstelle Fehler Metrik fuer Antrags ID: [{}]");
            Tags tags = Tags.of("ktan", ktan, "antragsId", antragsId);
            AtomicLong counter = new AtomicLong(0L);
            Gauge.builder(METRIK_NAME, counter, AtomicLong::get)
                .tags(tags)
                .register(registry);
            return counter;
        });

        gauge.set(retries);
    }

    /**
     * Loescht die Fehler Metrik fuer einen Antrag.
     *
     * @param ktan      Der Mandant des Antrags
     * @param antragsId Die UUID des Antrags
     */
    public void deleteSingleFehlerMetrik(final String ktan, final String antragsId) {
        LOG.atDebug().addArgument(antragsId).log("Entferne Fehler Metrik fuer Antrags ID: [{}]");
        final Tags tags = Tags.of("ktan", ktan, "antragsId", antragsId);
        final Meter meter = registry.find(METRIK_NAME).tags(tags).meter();
        if (meter != null) {
            registry.remove(meter);
        }
    }
}
