package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART;

/**
 * Processor um den Status Status ohne Versand zu setzen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SaveVerarbeitungsStatusOhneVersandProcessor implements Processor {

    private final VerarbeitungsstatusService verarbeitungsstatusService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Art erledigungsArt = exchange.getProperty(PROPERTY_ERLEDIGUNGSART, Art.class);
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        verarbeitungsstatusService.saveVerarbeitungsstatusOhneVersand(uuid, erledigungsArt);
    }
}
