package de.deutscherv.rvsm.fa.fit.einrichtungen.repository;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;

/**
 * Repository RehaEinrichtung.
 */
@ApplicationScoped
public class RehaEinrichtungRepository {

    private final EntityManager entityManager;

    /**
     * Konstruktor.
     *
     * @param entityManager Entity-Manager
     */
    public RehaEinrichtungRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /**
     * Loeschen einer Reha-Einrichtung.
     *
     * @param aktuelleEinrichtung die geloescht werden soll.
     */
    public void delete(final RehaEinrichtung aktuelleEinrichtung) {
        entityManager.remove(aktuelleEinrichtung);
    }

}
