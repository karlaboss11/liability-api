package de.deutscherv.rvsm.fa.fit.util;

/**
 * Enthaelt die Stringformatierung der Zahlenwerte mit fuehrenden Nullen. Sowohl fuer Statistikparameter (Infos befinden sich auf folgender
 * Seite:
 * <a href="https://rvwiki.drv.drv/x/QvskK"> Datenmapping Gateway Antrags- und
 * Erledigungsdaten</a> als auch für allgemeine Formate die in rvSystem:Bestand notwendig sind
 */
public enum DRVStringFormat {

    /**
     * Massnahmenummer (zahlenreihe-zweistellig).
     */
    MSNR("%02d"),
    /**
     * Arbeitsgruppe (zahlenreihe-vierstellig).
     */
    ATAD("%04d"),
    /**
     * Massnahmenummer der vorherigen Leistung (zahlenreihe-zweistellig).
     */
    VOMSMSNR("%02d"),
    /**
     * Anzahl bewilligte Tage, Wochen, Monate (zahlenreihe-dreistellig).
     */
    DA731("%03d"),
    /**
     * Anzahl der bewilligten Behandlungstage (zahlenreihe-dreistellig).
     */
    ZLHBTG("%03d");

    /**
     * String mit Formatinformationen.
     */
    public final String stringFormat;

    /**
     * Konstruktor mit Formatinformationen.
     *
     * @param stringFormat Formatdefinition
     */
    DRVStringFormat(final String stringFormat) {
        this.stringFormat = stringFormat;
    }

    /**
     * Formatiert einen Integer-Wert in einen entsprechend formatierten String.
     *
     * @param value ein Integer-Wert
     * @return ein formatierter String
     */
    public String format(final Integer value) {
        return String.format(stringFormat, value);
    }
}
