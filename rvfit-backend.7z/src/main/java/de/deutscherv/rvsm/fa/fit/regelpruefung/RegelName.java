package de.deutscherv.rvsm.fa.fit.regelpruefung;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * RegelName.
 */
@Getter
@AllArgsConstructor
public enum RegelName {

    /**
     * Immer Erfüllt. EVORVF1-4
     */
    REGEL_ERFUELLT(0),

    /**
     * Immer aussteuern. EVORVF1-4
     */
    REGEL_AUSSTEUERN(1),

    /**
     * Nie Erfüllt. EVORVF1-4
     */
    REGEL_NICHTERFUELLT(2),

    /**
     * Gibt immer Nicht Erfüllt Ablehnen zurück. EVORVF1-539
     */
    REGEL_NICHTERFUELLT_ABLEHNEN(3),

    /**
     * Prüft ob Vsnr der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_VSNR(4),

    /**
     * Prüft ob Nachname der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_NACHNAME(5),

    /**
     * Prüft ob Vorname der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_VORNAME(6),

    /**
     * Prüft ob Geburtsdatum der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_GEBURTSDATUM(7),

    /**
     * Prüft ob Strasse der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_STRASSE(8),

    /**
     * Prüft ob Hausnummer der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_HAUSNUMMER(9),

    /**
     * Prüft ob Plz der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_PLZ(10),

    /**
     * Prüft ob Wohnort der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_WOHNORT(11),

    /**
     * Prüft ob Land der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_LAND(12),

    /**
     * Prüft ob Staatsangehoerigkeit der Stammdaten im Antrag mit denen aus dem Konto übereinstimmen. EVORVF1-675
     */
    REGEL_ABGLEICH_STAATSANGEHOERIGKEIT(13),

    /**
     * Prüft die Staatsangehörigkeit des Versicherten. EVORVF1-490
     */
    REGEL_STAATSANGEHOERIGKEIT(14),

    /**
     * Prüft, ob die Einrichtungen vollständig sind. EVORVF1-177
     */
    REGEL_EINRICHTUNGANGEBOTEINDEUTIG(15),

    /**
     * Prüft, ob pro Einrichtung und Phase nur ein Angebot existiert. EVORVF1-275
     */
    REGEL_EINRICHTUNGDURCHFUEHRUNGSARTEINDEUTIG(16),

    /**
     * Prüft, ob die Einrichtung freie Plätze hat. EVORVF1-274
     */
    REGEL_EINRICHTUNGFREIEPLAETZE(17),

    /**
     * Prüft, ob alle Phasen von der gleichen Eirnichtung stammen. EVORVF1-178
     */
    REGEL_EINRICHTUNGVORHANDENUNDIDENTISCH(18),

    /**
     * Prüft, ob ein Antrag auf Altersrente existiert. EVORVF1-549
     */
    REGEL_ANTRAGALTERSRENTE(19),

    /**
     * Prüft, ob ein Antrag auf EM Renter vorliegt. EVORVF1-549
     */
    REGEL_ANTRAGEMRENTE(20),

    /**
     * Prüft, ob der Versicherte verbeamtet mit Vollbezügen ist. EVORVF1-549
     */
    REGEL_BEAMTENEIGENSCHAFT_BEZUEGE(21),

    /**
     * Prüft, ob der Versicherte verbeamtet mit Anwärterschaft ist. EVORVF1-746
     */
    REGEL_BEAMTENEIGENSCHAFT_ANWARTSCHAFT(22),

    /**
     * Prüft, ob ein laufender Bezug einer Altersrente Rente besteht. EVORVF1-549
     */
    REGEL_BEZUGALTERSRENTE(23),

    /**
     * Prüft, ob ein laufender Bezug einer EM Rente besteht. EVORVF1-549
     */
    REGEL_BEZUGEMRENTE(24),

    /**
     * Prüft, ob ein laufender Reha Antrag vorliegt. EVORVF1-549
     */
    REGEL_LAUFENDERREHAANTRAG(25),

    /**
     * Prüft auf Maßnahmearten und -datum.
     */
    REGEL_MASSNAHME(26),

    /**
     * Prüft Wartezeiten. EVORVF1-71
     */
    REGEL_WARTEZEITPRUEFUNG(27),

    /**
     * Prüft, ob ein Widerspruchsverfahren läuft. EVORVF1-549
     */
    REGEL_WIDERSPRUCHSVERFAHREN(28),

    /**
     * Prüft ob eine aktive Beschäftigung vorliegt. EVORVF1-757
     */
    REGEL_AKTIVEBESCHAEFTIGUNG(29),

    /**
     * Prüft ob eine Altersteilzeit vorliegt. EVORVF1-768
     */
    REGEL_ALTERSTEILZEIT(30),

    /**
     * Prüft ob ein Aufenthalt außerhalb von Deutschland vorliegt. EVORVF1-777
     */
    REGEL_AUFENTHALT(31),

    /**
     * Prüft ob die Einrichtung >50 km von PLZ des Versicherten entfernt ist. EVORVF1-489
     */
    REGEL_EINRICHTUNG_DISTANZ(32),

    /**
     * Prüft ob ein Bemerkung im Antrag eingetragen ist.
     */
    REGEL_BEMERKUNG(33),

    /**
     * Prüft ob die AUTOMATISCHE Einrichtungsprüfung ENABLED/DISABLED ist.
     * Gesteuert über ENV-Properties Einstellung
     */
    REGEL_AUTO_EINRICHTUNG_ENABLED(34),

    /**
     * Prüft, ob zu einem eAntrag ein digitaler Anhang hinzugefügt wurde.
     */
    REGEL_DIGITALER_ANHANG(35);

    private final long id;
}
