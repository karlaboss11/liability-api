package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.fa.fit.exceptions.NichtAutorisiertException;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.util.Optional;
import java.util.function.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Filter, der Prüft ob die benötigten Claims im JWT richtig gesetzt sind.
 *
 * @author U38322
 */
@Provider
@Slf4j
@Priority(Priorities.AUTHORIZATION)
public class JwtValidationFilter implements ContainerRequestFilter {

    private final JsonWebToken jwt;
    private final HttpServletRequest request;
    private final boolean disableAuthorization;
    private final String user;
    private final String name;
    private final String vorname;
    private final String nachname;

    /**
     * Konstruktor.
     *
     * @param jwt                  JSON-Web-Token
     * @param request              Anfrage
     * @param disableAuthorization true wenn Authorization disabled ist
     * @param drvid                DRV-ID
     * @param name                 Name
     * @param vorname              Vorname
     * @param nachname             Nachname
     */
    @Inject
    public JwtValidationFilter(final JsonWebToken jwt,
            final HttpServletRequest request,
            @ConfigProperty(name = "disable.authorization", defaultValue = "false") final boolean disableAuthorization,
            @ConfigProperty(name = "jwt.feld.user.name") final String drvid,
            @ConfigProperty(name = "jwt.feld.name.name") final String name,
            @ConfigProperty(name = "jwt.feld.vorname.name") final String vorname,
            @ConfigProperty(name = "jwt.feld.nachname.name") final String nachname) {
        this.jwt = jwt;
        this.request = request;
        this.disableAuthorization = disableAuthorization;
        this.user = drvid;
        this.name = name;
        this.vorname = vorname;
        this.nachname = nachname;
    }

    @Override
    public void filter(final ContainerRequestContext ctx) throws IOException {
        if (disableAuthorization) {
            return;
        }
        if(Optional.ofNullable(ctx)
                   .map(ContainerRequestContext::getUriInfo)
                   .map(UriInfo::getPath)
                   .map(path -> path.startsWith("/cron") || path.startsWith("/ping"))
                   .orElse(false)){
            return;
        }
        if (claimMissing(user)) {
            abortRequest(user);
            return;
        }

        if (claimMissing(vorname)) {
            abortRequest(vorname);
            return;
        }

        if (claimMissing(nachname)) {
            abortRequest(nachname);
            return;
        }

        if (claimMissing(name)) { // mind JwtValidationFilterTest
            abortRequest(name);
        }

    }

    private boolean claimMissing(final String claim) {
        return jwt.claim(claim).map(String.class::cast).filter(Predicate.not(String::isEmpty))
                .isEmpty();
    }

    private void abortRequest(final String feld) {
        throw new NichtAutorisiertException(JwtValidationFilter.class.getName(),
                request.getRemoteAddr(), "Der Claim [" + feld + "] fehlt im übergebenen Token.");
    }

}