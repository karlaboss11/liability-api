package de.deutscherv.rvsm.fa.fit.jms;

/**
 * Definition von Konstanten.
 */
public class DRVHeader {
    /**
     * Nutzdaten Id zur Identifikation im Nutzdaten Service.
     */
    public static final String ANTRAG_NUTZDATENID = "rvfit_nutzdaten_id";
    /**
     * Schlüssel, in der der DrvMandant hinterlegt ist.
     */
    public static final String MANDANT_PROPERTY_KEY = "drv_mandant";
    /**
     * uuid zur Identifikation und Tracing von eAntraegen (MessageId des SPoC).
     */
    public static final String UUID_PROPERTY_KEY = "rvfit_uuid";
    /**
     * Durchgaengige Correlation Id.
     */
    public static final String CORRELATION_ID = "correlation_id";

    private DRVHeader() {
        throw new UnsupportedOperationException();
    }

}
