package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.util.PKOGenerator;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.Year;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum Erzeugen einer Vorgangskennung.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class VorgangskennungProcessor implements Processor {

    private final AntragRepository antragRepository;

    @Override
    public void process(Exchange exchange) {
        synchronized (this) {
            final var antrag = exchange.getMessage().getBody(Antrag.class);
            if (Objects.isNull(antrag.getVorgangskennung())) {
                final int currentYear = Year.now().getValue() % 100;
                final Optional<String> lastVorgangskennung = antragRepository.getLastInsertedVorgangskennung();
                if (lastVorgangskennung.isPresent() && Integer.parseInt(lastVorgangskennung.get().substring(1, 3)) != currentYear) {
                    antragRepository.createNewYearVorgangskennungSequence();
                }
                final String vorgangskennung = PKOGenerator.generateVorgangskennung(PKOGenerator.Type.V,
                        antragRepository.getVorgangskennungNextSequence(currentYear), currentYear);
                LOG.atInfo().addArgument(antrag.getUuid()).addArgument(vorgangskennung)
                        .log("Vorgangskennung wird erstellt: UUID [{}] Vorgangskennung [{}]");
                antrag.setVorgangskennung(vorgangskennung);
                antragRepository.merge(antrag);
                antragRepository.flush();
            }
            exchange.getMessage().setBody(antrag);
        }
    }
}
