package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.statistik.repository.BestandsfehlerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor um alle Bestandsfehler eines Antrags zu schliessen.SchliessePurAufgabeProcessor.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SchliesseBestandsfehlerProcessor implements Processor {

    private final BestandsfehlerRepository bestandsfehlerRepository;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        bestandsfehlerRepository.schliesseAlleBestandsfehlerZuAntrag(uuid);
    }
}
