package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlercodeDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import jakarta.enterprise.context.ApplicationScoped;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Pruefung des Papierantrags.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class PapierantragsPruefung {
    /**
     * Pruefe papier antrag.
     *
     * @param antragDto the antrag dto
     * @return the list
     * @throws StammdatenException Problem bei den Stammdaten
     * @throws NoSuchFieldException Fehlendes Feld
     * @throws SecurityException Security-Problem
     */
    public List<FehlerDto> pruefePapierAntrag(final PapierantragDto antragDto)
            throws NoSuchFieldException, SecurityException, StammdatenException {
        final List<FehlerDto> fehlerListe = new ArrayList<>();

        LOG.atDebug().addArgument(antragDto::getId)
                .log("Validierungsprüfung Papierantrag für Antrag ID: [{}]");

        // Versicherter - VSNR
        final String patternVSNR = "\\d{8}[a-zA-Z]\\d{3}";
        if (StringUtils.isBlank(antragDto.getVersicherter().getVsnr())) {
            LOG.atInfo().addArgument(antragDto::getId)
                    .log("Feld VSNR blank - Aufnahme in Fehlerliste (bei Antrag ID: {})");
            fehlerListe.add(new FehlerDto().code(FehlercodeDto.FELD_LEER).feld("VSNR"));

            return fehlerListe;

        } else if (!antragDto.getVersicherter().getVsnr().matches(patternVSNR)) {
            LOG.atInfo().addArgument(antragDto::getId)
                    .addArgument(antragDto.getVersicherter().getVsnr()).log(
                            "Feld VSNR im falschen Aufbau - Aufnahme in Fehlerliste (bei Antrag ID: {}, Vsnr [{}])");
            fehlerListe.add(new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld("VSNR"));

            return fehlerListe;
        }

        /*
         * PRÜFUNG PFLICHTFELDER!
         */

        // Eingangsdatum
        addFehlerFeldWhenNull("eingangsdatum", antragDto, fehlerListe, "EINGANGSDATUM");

        // Antragsdatum
        addFehlerFeldWhenNull("antragsdatum", antragDto, fehlerListe, "ANTRAGSDATUM");


        addFehlerFeldWhenBlank("vorname", antragDto, fehlerListe, "VORNAME");

        addFehlerFeldWhenBlank("nachname", antragDto, fehlerListe, "NACHNAME");

        addFehlerFeldWhenBlank("geburtsdatum", antragDto, fehlerListe, "GEBURTSDATUM");

        addFehlerFeldWhenBlank("strasse", antragDto, fehlerListe, "STRASSE");

        // Plz
        if (antragDto.getAntrag().getPlz().length() > 10) {
            final Field plz = antragDto.getAntrag().getClass()
                    .getDeclaredField(AntragFeldMapper.PLZ.getFeldName());

            LOG.atInfo().addArgument(antragDto::getId)
                    .addArgument(antragDto.getVersicherter().getVsnr())
                    .log("Feld PLZ - falsche Länge - "
                            + "Aufnahme in Fehlerliste (bei Antrag ID: [{}], Vsnr [{}])");
            fehlerListe
                    .add(new FehlerDto().code(FehlercodeDto.FELD_UNGUELTIG).feld(plz.getName()));

        }

        // Wohnort
        addFehlerFeldWhenBlank("wohnort", antragDto, fehlerListe, "WOHNORT");

        /*
         * Prüfung sonstiger Felder (keine Pflichtfelder)
         */

        // Bemerkungsfeld (begrenzte Zeichenanzahl)
        final int maxCharsBemerkungen = 10650;
        if (StringUtils.length(antragDto.getAntrag().getBemerkungen()) > maxCharsBemerkungen) {

            LOG.atInfo().addArgument(maxCharsBemerkungen)
                    .addArgument(antragDto::getId)
                    .addArgument(antragDto.getVersicherter().getVsnr())
                    .log("Feld 'BEMERKUNGEN' - falsche Länge (> {} Zeichen) - "
                            + "Aufnahme in Fehlerliste (bei Antrag ID: [{}], Vsnr [{}])");
            fehlerListe.add(new FehlerDto().code(FehlercodeDto.FELD_LAENGE).feld("BEMERKUNGEN"));
        }

        LOG.atDebug().addArgument(antragDto::getId).addArgument(fehlerListe)
                .addArgument(antragDto.getVersicherter().getVsnr())
                .log("Validierungsprüfung Papierantrag für Antrag ID: [{}] abgeschlossen. "
                        + "Fehlerliste: [{}], Vsnr [{}]");

        return fehlerListe;
    }

    /**
     * Pruefe vsnr valide.
     *
     * @param vsnr Versicherungsnr
     * @return true - Versicherungsnr. ist valide
     */
    public boolean isVsnrValid(final String vsnr) {

        final String patternVSNR = "\\d{8}[a-zA-Z]\\d{3}";

        if (StringUtils.isBlank(vsnr)) {
            LOG.atDebug().log("Feld VSNR is blank");
            return false;
        } else if (!vsnr.matches(patternVSNR)) {
            LOG.atDebug().addArgument(vsnr).log("Feld VSNR im falschen Aufbau. Vsnr [{}]");
            return false;
        }

        return true;
    }

    /**
     * Adds the fehler feld when null.
     *
     * @param feld        the feld
     * @param antragDto   the antrag dto
     * @param fehlerListe the fehler liste
     * @param fehlerFeld  the fehler feld
     */
    private void addFehlerFeldWhenNull(final String feld, final PapierantragDto antragDto,
            final List<FehlerDto> fehlerListe, final String fehlerFeld) {
        boolean feldIsBlank = false;

        switch (feld) {
            case "eingangsdatum":
                feldIsBlank = Objects.isNull(antragDto.getAntrag().getEingangsdatum());
                break;
            case "antragsdatum":
                feldIsBlank = Objects.isNull(antragDto.getAntrag().getAntragsdatum());
                break;
            default:
        }
        if (feldIsBlank) {
            LOG.atDebug().addArgument(feld).addArgument(antragDto::getId)
                    .addArgument(antragDto.getVersicherter().getVsnr())
                    .log("Feld [{}] null - Aufnahme in Fehlerliste (bei Antrag ID: [{}], Vsnr [{}])");
            fehlerListe.add(new FehlerDto().code(FehlercodeDto.FELD_LEER).feld(fehlerFeld));
        }
    }

    /**
     * Adds the fehler feld when blank.
     *
     * @param feld        the feld
     * @param antragDto   the antrag dto
     * @param fehlerListe the fehler liste
     * @param fehlerFeld  the fehler feld
     */
    private void addFehlerFeldWhenBlank(final String feld, final PapierantragDto antragDto,
            final List<FehlerDto> fehlerListe, final String fehlerFeld) {
        boolean feldIsBlank = false;

        switch (feld) {
            case "vorname":
                feldIsBlank = StringUtils.isBlank(antragDto.getAntrag().getVorname());
                break;
            case "nachname":
                feldIsBlank = StringUtils.isBlank(antragDto.getAntrag().getNachname());
                break;
            case "geburtsdatum":
                feldIsBlank = antragDto.getAntrag().getGeburtsdatum() == null
                        || StringUtils.isBlank(antragDto.getAntrag().getGeburtsdatum());
                break;
            case "strasse":
                feldIsBlank = StringUtils.isBlank(antragDto.getAntrag().getStrasse());
                break;
            case "wohnort":
                feldIsBlank = StringUtils.isBlank(antragDto.getAntrag().getWohnort());
                break;
            default:
        }
        if (feldIsBlank) {
            LOG.atDebug().addArgument(feld).addArgument(antragDto::getId)
                    .addArgument(antragDto.getVersicherter().getVsnr())
                    .log("Feld [{}] blank - Aufnahme in Fehlerliste (bei Antrag ID: [{}], Vsnr [{}])");
            fehlerListe.add(new FehlerDto().code(FehlercodeDto.FELD_LEER).feld(fehlerFeld));
        }
    }
}
