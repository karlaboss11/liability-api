package de.deutscherv.rvsm.fa.fit.kontoinformation.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

/**
 * KontoinformationResponse Dto. <a href="https://rvwiki.drv.drv/x/d9HrHw">...</a>
 *
 * @author V215169
 */
@Data
@Builder
public class KontoinformationResponse {

    private String vsnr;
    private Integer wartezeit6in24m;
    private Integer wartezeit180m;
    private Boolean wartezeitfehler;
    private String antragRehaMsat;
    private String antragRehaArt;
    private String massnahmeRehaElat;
    private LocalDate massnahmeRehaKobs;
    private String antragRenteLeat;
    private String bezugRenteLeat;
    private String antragRenteTlrt;
    private String bezugRenteTlrt;
    private String bezugRenteProzent;
    private Boolean beamteneigenschaft;
    private Boolean rechtsbehelfRente;
    private Boolean rechtsbehelfReha;
    private String beschaeftigungGruppe;
    private String beschaeftigungGrund;
    private LocalDate beschaeftigungKobs;
    private String altersteilzeitGruppe;
    private String altersteilzeitGrund;
    private LocalDate altersteilzeitKobs;
    private Boolean selbstaendigkeit;
    private List<FehlerEintrag> rvSystemFehler;
    private String unerwarteterFehler;
}
