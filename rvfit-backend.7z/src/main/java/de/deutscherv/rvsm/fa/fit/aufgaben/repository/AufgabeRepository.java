package de.deutscherv.rvsm.fa.fit.aufgaben.repository;

import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * Aufgabe-Repository.
 */
@RequiredArgsConstructor
@ApplicationScoped
public class AufgabeRepository {

    private final EntityManager entityManager;

    /**
     * Persistieren einer neuen Aufgabe.
     * @param aufgabe Aufgabe.
     */
    public void persist(final Aufgabe aufgabe) {
        entityManager.persist(aufgabe);
    }

    /**
     * Persisitieren einer geaenderten Aufgabe.
     * @param aufgabe Aufgabe
     */
    public void merge(final Aufgabe aufgabe) {
        entityManager.merge(aufgabe);
    }

    /**
     * Suchern einer Aufgabe mit ihrer UUid.
     * @param uuid mit der selektiert wird.
     * @return selektierte Aufgabe.
     */
    public Aufgabe find(final UUID uuid) {
        return entityManager.find(Aufgabe.class, uuid);
    }

}
