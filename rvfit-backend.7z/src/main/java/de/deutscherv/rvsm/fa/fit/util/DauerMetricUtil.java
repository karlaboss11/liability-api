package de.deutscherv.rvsm.fa.fit.util;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.Timer;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;

/**
 * Stellt Methoden zur Steuerung von Timer Metriken zur Verfuegung.
 */

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class DauerMetricUtil {

    private final MeterRegistry registry;

    private final ConcurrentHashMap<String, Timer.Sample> timerMap = new ConcurrentHashMap<>();

    /**
     * Startet eine Timer Metrik, mit den uebergebenen Parametern.
     *
     * @param name     Name der Metrik
     * @param exchange Exchange aus dem die Tags gelesen werden
     */
    public void startTimerMetric(final String name, final Exchange exchange) {
        final Optional<Tags> tags = Optional.ofNullable(extrahiereTagsAusExchange(exchange));

        if (tags.isEmpty()) {
            LOG.atDebug().addArgument(name).log("Timer Metrik kann nicht gestartet werden, kein Tag gefunden: [{}]");
            return;
        }

        Timer timer = registry.find(name).tags(tags.get()).timer();

        if (timer == null) {
            LOG.atDebug().addArgument(name).log("Erstelle Timer Metrik: [{}]");
            Timer.builder(name)
                .tags(tags.get())
                .register(registry);
        }
        Timer.Sample sample = Timer.start(registry);
        timerMap.put(name, sample);
    }

    /**
     * Stoppt eine Timer Metrik, mit den uebergebenen Parametern.
     *
     * @param name     Name der Metrik
     * @param exchange Exchange aus dem die Tags gelesen werden
     */
    public void stopTimerMetric(final String name, final Exchange exchange) {
        final Optional<Tags> tags = Optional.ofNullable(extrahiereTagsAusExchange(exchange));

        if (tags.isEmpty()) {
            LOG.atDebug().addArgument(name).log("Timer Metrik kann nicht gestoppt werden, kein Tag gefunden: [{}]");
            return;
        }

        final Timer timer = registry.find(name).tags(tags.get()).timer();

        if (timer != null && timerMap.containsKey(name)) {
            LOG.atDebug().addArgument(name).log("Stoppe Timer Metrik: [{}]");
            Timer.Sample sample = timerMap.remove(name);
            sample.stop(timer);
        } else {
            LOG.atDebug().addArgument(name).log("Timer Metrik kann nicht gestoppt werden, da sie nicht gefunden wurde: [{}]");
        }
    }

    private Tags extrahiereTagsAusExchange(final Exchange exchange) {
        final Optional<Object> rvfitUuid = Optional.ofNullable(exchange.getMessage().getHeader("rvfit_uuid"));
        final Optional<Object> traceparent = Optional.ofNullable(exchange.getMessage().getHeader("traceparent"));
        final Optional<Object> ktan = Optional.ofNullable(exchange.getMessage().getHeader("drv_mandant"));

        final Tags tags;
        if (rvfitUuid.isPresent() && ktan.isPresent()) {
            tags = Tags.of("ktan", ktan.get().toString(), "rvfitUuid", rvfitUuid.get().toString());
        } else if (traceparent.isPresent() && ktan.isPresent()) {
            tags = Tags.of("ktan", ktan.get().toString(), "traceparent", traceparent.get().toString());
        } else {
            return null;
        }
        return tags;
    }
}
