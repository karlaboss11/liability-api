package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * EingabevalidierungException.
 */
public class EingabevalidierungException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param resource  Quellestring
     * @param userIdent User
     * @param message   Fehlernachricht
     */
    public EingabevalidierungException(final String resource, final String userIdent,
            final String message) {
        super(resource, userIdent, message);
    }

}
