package de.deutscherv.rvsm.fa.fit.fehler.orchestration;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.util.FehlerMetricUtil;
import jakarta.enterprise.context.RequestScoped;
import jakarta.transaction.Transactional;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.spi.ErrorHandler;

/**
 * ExceptionHandler.
 */
@Slf4j
@RequiredArgsConstructor
@RequestScoped
public class ExceptionHandler implements ErrorHandler {

    private final FehlerMetricUtil fehlerMetricUtil;
    private final DrvMandant drvMandant;
    private final FehlerRepository fehlerRepository;

    /**
     * Behandelt Exceptions, die auftreten und speichert sowohl die Fehlermeldung als auch die UUID des Antrags im Fehler-Repository.
     *
     * @param e       Die aufgetreten Exception
     * @param antrag  Der Antrag
     * @param message Die Fehlermeldung
     */
    @RequiresMandant
    public void handleExceptionForRetry(final Exception e, final Antrag antrag, final String message) {
        MDCUtils.setFailed();
        String nachricht = message + ": " + e.getMessage();
        LOG.atError().setCause(e).addArgument(antrag.getUuid()).log(nachricht + ": UUID [{}]");

        fehlerRepository.persist(
                Fehler.builder()
                        .status(antrag.getStatus())
                        .antragId(antrag.getUuid())
                        .build());
        fehlerRepository.flush();
    }

    @Override
    public void process(final Exchange exchange) throws Exception {
        final var antrag = exchange.getMessage().getBody(Antrag.class);

        try (AutoCloseable ignore = drvMandant.setInScope(
            Optional.ofNullable(exchange.getProperty(DRVHeader.MANDANT_PROPERTY_KEY, String.class))
                .orElseGet(antrag::getKtan))) {

            Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

            final var message = exchange.getMessage().getHeader(RVFitCamelHeader.ERROR_MESSAGE, "", String.class);
            final var fehler = exchange.getProperty(RVFitCamelHeader.RVFIT_FEHLER, Fehler.class);

            LOG.atWarn().setMessage("Bei der Verarbeitung der Exchange {} ist ein Fehler aufgetreten")
                .addArgument(exchange).setCause(exception).log();

            if (fehler != null) {
                if (antrag.getStatus() == fehler.getStatus()) {
                    LOG.atWarn().setMessage("Es gab bereits einen Fehler {}")
                        .addArgument(fehler).setCause(exception).log();
                    increaseFehler(fehler);
                    fehlerMetricUtil.updateSingleFehlerMetrik(antrag.getKtan(), antrag.getUuid().toString(), fehler.getRetries());
                } else { //neuer Fehler
                    fehlerRepository.delete(fehler); //lösche alten
                    handleExceptionForRetry(exception, antrag, message); // mach neu
                    fehlerMetricUtil.updateSingleFehlerMetrik(antrag.getKtan(), antrag.getUuid().toString(), 0L);
                }

            } else {
                handleExceptionForRetry(exception, antrag, message);
                fehlerMetricUtil.updateSingleFehlerMetrik(antrag.getKtan(), antrag.getUuid().toString(), 0L);
            }
        }
        exchange.setRouteStop(true);
    }

    /**
     * Erhoeht die Anzahl Versuche einen Fehler zu bearbeiten um eins.
     * @param fehler zu bearbeitender Fehler
     */
    @Transactional
    void increaseFehler(final Fehler fehler) {
        fehler.setRetries(fehler.getRetries()+1);
        LOG.atWarn().setMessage("Fehler jetzt: {}").addArgument(fehler).log();
        fehlerRepository.merge(fehler);
        fehlerRepository.flush();
    }
}
