package de.deutscherv.rvsm.fa.fit.einrichtungen.mapper;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.openapi.model.EinrichtungAnschriftAutovervollstaendigungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.EinrichtungAnschriftDto;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

/**
 * EinrichtungAnschriftMapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface EinrichtungAnschriftMapper {

    /**
     * Mappt eine Anschrift in ein DTO.
     *
     * @param entity die Anschrift
     * @return das DTO
     */
    @Mapping(source = "uuid", target = "id")
    @Mapping(source = "adresszusatz", target = "adresszusatz")
    EinrichtungAnschriftDto toDto(EinrichtungAnschrift entity);

    /**
     * Mappt ein Anschrift DTO in eine Anschrift.
     *
     * @param dto das DTO
     * @return die Anschrift
     */
    @Mapping(source = "id", target = "uuid")
    @Mapping(source = "adresszusatz", target = "adresszusatz")
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    @InheritInverseConfiguration
    EinrichtungAnschrift toEntity(EinrichtungAnschriftDto dto);

    /**
     * Mappt eine Anschrift in ein Autovervollstaendigung DTO.
     *
     * @param entity die Anschrift
     * @return das DTO
     */
    EinrichtungAnschriftAutovervollstaendigungDto toAutovervollstaendigungDto(
            EinrichtungAnschrift entity);
}
