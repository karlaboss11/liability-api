package de.deutscherv.rvsm.fa.fit.statistik.repository;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.statistik.model.Bestandsfehler;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Repository Bestandsfehler.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class BestandsfehlerRepository {

    private static final String ANTRAG_ID = "antragId";
    private final EntityManager entityManager;

    /**
     * Persistiere neuen Bestandsfehler.
     * @param bestandsfehler zu persisitierender Bestandsfehler
     */
    public void persist(final Bestandsfehler bestandsfehler) {
        entityManager.persist(bestandsfehler);
    }

    /**
     * Persistiere geaenderten Bestandsfehler.
     * @param bestandsfehler zu persisitierender Bestandsfehler
     */
    public void merge(final Bestandsfehler bestandsfehler) {
        entityManager.merge(bestandsfehler);
    }

    /**
     * Finde nicht geloeschte Bestandsfehler zu Antrag.
     * @param antragId ID des betroffenen Antrags
     * @return Bestandsfehlerliste.
     */
    @RequiresMandant
    public List<Bestandsfehler> findByAntragUuidNotDeleted(final UUID antragId) {
        final TypedQuery<Bestandsfehler> query = entityManager.createQuery(
                """
                        SELECT b FROM Bestandsfehler b
                        WHERE b.antragId = :antragId
                        AND b.deleted IS NULL
                        """,
                Bestandsfehler.class);

        query.setParameter(ANTRAG_ID, antragId);

        return query.getResultStream().toList();
    }

    /**
     * Schliesse alle Bestandsfehler zu Antrag.
     * @param antragId ID des betroffenen Antrags.
     */
    @Transactional
    @RequiresMandant
    public void schliesseAlleBestandsfehlerZuAntrag(final UUID antragId) {
        int anzahlAktualisiert = entityManager.createQuery("""
                        UPDATE Bestandsfehler b
                        SET b.deleted = :now
                        WHERE b.antragId = :antragId
                        """)
                .setParameter("now", LocalDateTime.now())
                .setParameter(ANTRAG_ID, antragId)
                .executeUpdate();
        entityManager.flush();
        LOG.atInfo()
                .addArgument(anzahlAktualisiert)
                .addArgument(antragId)
                .log("Bestandsfehler aus Tabelle als erledigt markiert: {} UUID [{}]");
    }

    /**
     * Enternde alle Fehler fuer einen Antrag.
     * @param antrag betroffener Antrag
     */
    @RequiresMandant
    public void entferneAlleFehlerFuerAntrag(final Antrag antrag) {
        entityManager.createQuery("""
                        DELETE FROM Bestandsfehler b
                        WHERE b.antragId = :antragId
                        """)
                .setParameter(ANTRAG_ID, antrag.getUuid())
                .executeUpdate();
    }
}
