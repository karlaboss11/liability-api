package de.deutscherv.rvsm.fa.fit.einrichtungen.mapper;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseDto;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.Objects;

/**
 * Angebot-Mapper.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR,
        uses = {EinrichtungAnschriftMapper.class})
public interface AngebotMapper {

    /**
     * To dto.
     *
     * @param entity the entity
     * @return the phase dto
     */
    @Mapping(source = "smpAngebotId", target = "selbstmeldeportalId")
    @Mapping(source = "phase", target = "name")
    @Mapping(source = "freiePlaetzeWert", target = "freiePlaetze", qualifiedByName = "toFreiePlaetze")
    @Mapping(target = "text", ignore = true)
    @Mapping(target = "id", ignore = true)
    PhaseDto toDto(Angebot entity);

    /**
     * Bestimmt die FreiePlaetze aus FreiePlaetzeWert.
     *
     * @param freiePlaetzeWert die FreiePlaetzeWert
     * @return die FreiePlaetze
     */
    @Named("toFreiePlaetze")
    static String toFreiePlaetze(final Integer freiePlaetzeWert) {
        if (Objects.isNull(freiePlaetzeWert)) {
            return null;
        }
        return switch (freiePlaetzeWert) {
            case -2 -> "Angebot pausiert";
            case -1 -> "Auf Anfrage";
            case 0 -> "Keine freien Plätze";
            case 1 -> "1 - 3 freie Plätze";
            case 4 -> "mehr als 3 freie Plätze";
            default -> throw new IllegalArgumentException("Unexpected value: " + freiePlaetzeWert);
        };
    }

    /**
     * To entity.
     *
     * @param dto the dto
     * @return the phase
     */
    @Mapping(target = "uuid", ignore = true)
    @Mapping(source = "freiePlaetze", target = "freiePlaetzeWert", qualifiedByName = "toFreiePlaetzeWert")
    @Mapping(target = "distanz", ignore = true)
    @Mapping(target = "distanzVersicherter", ignore = true)
    @Mapping(target = "ktan", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "lastModified", ignore = true)
    @InheritInverseConfiguration
    Angebot toEntity(PhaseDto dto);

    /**
     * Bestimmt die FreiePlaetzeWert aus FreiePlaetze.
     *
     * @param freiePlaetze die FreiePlaetze
     * @return die FreiePlaetzeWert
     */
    @Named("toFreiePlaetzeWert")
    static Integer toFreiePlaetzeWert(final String freiePlaetze) {
        if (Objects.isNull(freiePlaetze)) {
            return null;
        }
        return switch (freiePlaetze) {
            case "Angebot pausiert" -> -2;
            case "Auf Anfrage" -> -1;
            case "Keine freien Plätze" -> 0;
            case "1 - 3 freie Plätze" -> 1;
            case "mehr als 3 freie Plätze" -> 4;
            default -> throw new IllegalArgumentException("Unexpected value: " + freiePlaetze);
        };
    }
}
