/**
 * Beinhaltet Mapper für das Selbstmeldeportal.
 */
package de.deutscherv.rvsm.fa.fit.selbstmeldeportal.mapper;
