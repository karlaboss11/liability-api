/**
 * Beinhaltet JPA Entities für die Verarbeitung von Anträgen.
 */
package de.deutscherv.rvsm.fa.fit.verarbeitung.model;
