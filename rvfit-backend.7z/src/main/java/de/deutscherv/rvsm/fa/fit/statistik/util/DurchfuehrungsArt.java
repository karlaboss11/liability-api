package de.deutscherv.rvsm.fa.fit.statistik.util;

import de.deutscherv.rvsm.fa.fit.exceptions.MapperException;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import java.util.function.Function;
import lombok.Getter;

/**
 * <a href="https://rvwiki.drv.drv/x/QvskK">Datenmapping Statistikdaten</a>.
 */
public enum DurchfuehrungsArt {
    /**
     * Keine.
     */
    KEINE(p -> "0", "KEINE"),
    /**
     * Stationär.
     */
    STATIONAER(p -> "1", "stationär"),
    /**
     * Ambulant (ganztägig).
     */
    GANZTAEGIG_AMBULANT(p -> "2", "Ambulant (ganztägig)"),
    /**
     * Ambulant.
     */
    AMBULANT(p -> "3", "Ambulant"),
    /**
     * Online. (Je nach Phase werden hier unterschiedliche Werte zurückgegeben)
     */
    ONLINE(p -> switch (p) {
        case STARTPHASE, AUFFRISCHUNG -> "2";
        case TRAININGSPHASE -> "3";
    }, "online");

    private final Function<PhaseEnumDto, String> zahlWertFunktion;

    @Getter
    private final String bezeichnung;

    DurchfuehrungsArt(final Function<PhaseEnumDto, String> zahlWertFunktion,
            final String bezeichnung) {
        this.zahlWertFunktion = zahlWertFunktion;
        this.bezeichnung = bezeichnung;
    }

    /**
     * Liefert die Durchfuehrungsart anhand der Bezeichnung.
     *
     * @param bezeichnung zu untersuchende Bezeichznung
     * @return ermittelte Durchfuehrungsart
     */
    public static DurchfuehrungsArt fuerBezeichnung(final String bezeichnung) {
        for (final DurchfuehrungsArt value : values()) {
            if (value.bezeichnung.equalsIgnoreCase(bezeichnung)) {
                return value;
            }
        }
        throw new MapperException(
                String.format("Keine Durchführungsart gefunden für %s", bezeichnung));
    }

    /**
     * Liefert den Zahlwert zur Phase.
     *
     * @param phase zu untersuchende Phase
     * @return ermittelte Zahlwert
     */
    public String getZahlWert(final PhaseEnumDto phase) {
        return zahlWertFunktion.apply(phase);
    }

}
