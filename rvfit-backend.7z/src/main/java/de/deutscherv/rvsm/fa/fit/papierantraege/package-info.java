/**
 * Beinhaltet Servcies, die sich mit Papieranträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.papierantraege;
