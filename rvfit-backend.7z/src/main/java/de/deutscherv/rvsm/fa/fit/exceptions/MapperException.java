package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * MapperException.
 */
public class MapperException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Feherlnachricht
     * @param cause   Fehlergrund
     */
    public MapperException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht.
     */
    public MapperException(final String message) {
        super(message);
    }
}