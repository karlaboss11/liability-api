package de.deutscherv.rvsm.fa.fit.security;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.exceptions.KtanException;

import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static java.util.function.Predicate.not;

/**
 * Klasse mit statischen Methoden zur Mandantenpruefung.
 *
 * @author V215169
 */
public class JwtUtils {

    /**
     * DRV-Mandant.
     */
    public static final String DRV_MANDANT =
        ConfigProvider.getConfig().getValue("jwt.feld.ktan.name", String.class);
    /**
     * DRV-ID.
     */
    public static final String DRV_ID =
        ConfigProvider.getConfig().getValue("jwt.feld.user.name", String.class);

    /**
     * Methode zur KTAN Extraktion aus Jwt or KtanContext.
     */
    public static final BiFunction<JsonWebToken, DrvMandant, String> GET_KTAN =
        (jwt, drvMandant) -> Optional.ofNullable(drvMandant).map(x -> x.getOrElse(""))
            .filter(not(String::isBlank))
            .or(() -> jwt.claim(DRV_MANDANT).map(String.class::cast))
            .orElseThrow(() -> new KtanException("Keine KTAN gefunden, Zugriff verweigert"));

    /**
     * Methode zur DRVID Extraktion aus JWT.
     */
    public static final Function<JsonWebToken, String> GET_DRV_ID_AUS_JWT =
        jwt -> jwt.claim(DRV_ID).map(String.class::cast).orElse("DRV701000000000");

    private JwtUtils() {
    }

    /**
     * Methode zur Ermittlung, ob JWT von einem User vorhanden ist.
     *
     * @param jwt Der JsonWebToken
     * @return true wenn der JWT von einem User mit Drv-ID ist
     */
    public static boolean isJwtVonUser(JsonWebToken jwt) {
        return jwt.claim(DRV_ID).isPresent();
    }
}
