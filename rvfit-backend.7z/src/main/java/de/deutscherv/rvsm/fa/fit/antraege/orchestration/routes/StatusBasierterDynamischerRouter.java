package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.fehler.model.Fehler;
import de.deutscherv.rvsm.fa.fit.fehler.repository.FehlerRepository;
import de.deutscherv.rvsm.fa.fit.util.DauerMetricUtil;
import de.deutscherv.rvsm.fa.fit.util.FehlerMetricUtil;
import de.deutscherv.rvsm.fa.fit.util.MetricNames;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Body;
import org.apache.camel.Consume;
import org.apache.camel.DynamicRouter;
import org.apache.camel.Exchange;
import org.apache.camel.Header;
import org.apache.commons.collections.CollectionUtils;

import static de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus.STATISTIK_ABGESCHLOSSEN;

/**
 * Führt basierend auf dem Antragsstatus ein dynamisches Routing durch.
 * <p>
 * Achtung: Einmal rein geschickt wird solange geroutet, bis entweder ein Fehler auftritt oder ein Endzustand erreicht wird.
 */
@ApplicationScoped
@Slf4j
public class StatusBasierterDynamischerRouter {

    private final FehlerMetricUtil fehlerMetricUtil;
    private final FehlerRepository fehlerRepository;
    private final DauerMetricUtil dauerMetricUtil;

    /**
     * Required Args Konstruktor des StatusBasierterDynamischerRouter.
     *
     * @param fehlerMetricUtil Nutzklasse zum steuern von Fehlermetriken
     * @param fehlerRepository Repository zum Handling von Fehler DB Entities
     * @param dauerMetricUtil Nutzklasse zum steuern von Dauer-/Timermetriken
     */
    @Inject
    public StatusBasierterDynamischerRouter(final FehlerMetricUtil fehlerMetricUtil, final FehlerRepository fehlerRepository,
        final DauerMetricUtil dauerMetricUtil) {
        this.fehlerMetricUtil = fehlerMetricUtil;
        this.fehlerRepository = fehlerRepository;
        this.dauerMetricUtil = dauerMetricUtil;
    }

    /**
     * Anhand des aktuellen Status des Antrags wird die nachfolgende Route ermittelt.
     * @param antrag betroffener Antrag
     * @param fehler Fehlerzustand
     * @param exchange Nachricht
     * @return nachfolgende Route
     */
    @Consume(RouteNames.RVFIT_STATUS_BASED_ROUTING)
    @DynamicRouter
    public String statusBasiertesRouting(@Body final Antrag antrag,
                                         @Header(RVFitCamelHeader.RVFIT_FEHLER) final Fehler fehler, final Exchange exchange) {

        if (Objects.nonNull(fehler) || antrag.getStatus() == STATISTIK_ABGESCHLOSSEN) {
            fehlerHandling(antrag, fehler, exchange);
        }

        final String nachfolgendeRoute = RvFitRouting.routingSlip(antrag);
        if (nachfolgendeRoute == null) {
            if (antrag.getAntragsart() == AntragsArt.E_ANTRAG) {
                dauerMetricUtil.stopTimerMetric(MetricNames.E_ANTRAG_DAUER.getName(), exchange);
            } else {
                dauerMetricUtil.stopTimerMetric(MetricNames.PAPIERANTRAG_DAUER.getName(), exchange);
            }
        }

        return nachfolgendeRoute;
    }

    /**
     * Bei einem neuen Status werden die Fehler gelöscht..
     * @param antrag betroffener Antrag
     * @param fehler Fehlerzustand
     * @param exchange Nachricht
     */
    @Transactional
    @RequiresMandant
    void fehlerHandling(final Antrag antrag, final Fehler fehler, final Exchange exchange) {
        final var antragStatus = antrag.getStatus();

        LOG.atDebug()
                .setMessage("Fehlerhandling beim Routing für Fehler: {}")
                .addArgument(fehler).log();

        if (STATISTIK_ABGESCHLOSSEN.equals(antragStatus)) {
            final List<Fehler> uebrigeFehler = fehlerRepository.findByAntrag(antrag);
            if (CollectionUtils.isNotEmpty(uebrigeFehler)) {
                // Am Ende alle löschen
                fehlerMetricUtil.deleteSingleFehlerMetrik(antrag.getKtan(), antrag.getUuid().toString());
                fehlerRepository.deleteAll(uebrigeFehler);
                fehlerRepository.flush();
                exchange.getMessage().removeHeader(RVFitCamelHeader.RVFIT_FEHLER);
            }
            return;
        }
        //Lösche den Fehler, falls sich der Status geändert hat
        final Optional<Fehler> optionalFehler = Optional.ofNullable(fehler)
                .filter(f -> !f.getStatus().equals(antragStatus));
        optionalFehler.ifPresent(
                f -> fehlerRepository.findByAntrag(antrag).stream().filter(fehler1 -> fehler1.getStatus().equals(f.getStatus()))
                        .forEach(feh -> {
                            fehlerMetricUtil.deleteSingleFehlerMetrik(antrag.getKtan(), antrag.getUuid().toString());
                            fehlerRepository.delete(feh);
                            fehlerRepository.flush();
                            exchange.getMessage().removeHeader(RVFitCamelHeader.RVFIT_FEHLER);
                        }));
    }
}
