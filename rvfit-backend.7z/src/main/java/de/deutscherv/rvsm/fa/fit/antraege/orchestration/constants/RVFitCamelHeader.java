package de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants;


import java.util.Set;
import lombok.experimental.UtilityClass;

/**
 * RVFitCamelHeader.
 */
@UtilityClass
public class RVFitCamelHeader {
    /**
     * UUID, welche zur Identifikation und zum Tracing der Anträge genutzt wird.
     */
    public static final String ANTRAG_UUID = "rvfit_uuid";
    /**
     * beinhalet Fehler, falls der Antrag aus der Fehlerbehandlung erneut angestoßen wurde..
     */
    public static final String RVFIT_FEHLER = "rvfit_fehler";
    /**
     * Kann das XML des Eantrags beinhalten, wenn noch nicht im Antrag gespeichert.
     */
    public static final String EANTRAG_XML = "eantrag_xml";

    /**
     * Kann das Antragsdaten Objekt beingalten, das aus dem eAntrag XML deserialisiert wurde.
     */
    public static final String ANTRAGSDATEN = "antragsdaten";

    /**
     * beinhaltet eventuelle Fehlernachrichten.
     */
    public static final String ERROR_MESSAGE = "error_msg";
    /**
     * Die VorgangsId zu einem rvPuR-Vorgang.
     */
    public static final String PUR_VORGANGS_ID = "pur_vorgangs_id";
    /**
     * Die AufgabenId zu einer Aufgabe in rvPuR.
     */
    public static final String PUR_AUFGABEN_ID = "pur_aufgaben_id";
    /**
     * wird gesetzt um das Ergebnis der Dokumentenerzeugung weiter zu geben.
     */
    public static final String VERSANDERGEBNIS = "doe_versandergebnis";
    /**
     * Kann mit einem {@link de.deutscherv.rvsm.fa.fit.log.model.Fachereignis} gesetzt werden um die Fachprotokoll Route aufzurufen
     * und zu versenden.
     */
    public static final String FACHEREIGNIS = "rvfit_fachereignis";
    /**
     * Kann mit einer {@link de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException} gesetzt werden um diese am Ende
     * der Route korrekt zu behandeln.
     */
    public static final String STAMMDATEN_BESTANDSFEHLER = "rvfit_stmamdaten_bestandsfehler";
    /**
     * Kann mit einer {@link de.deutscherv.rvsm.fa.fit.exceptions.StatistikBestandsFehlerException} gesetzt werden um diese am Ende
     * der Route korrekt zu behandeln.
     */
    public static final String STATISTIK_BESTANDSFEHLER = "rvfit_statistik_bestandsfehler";
    /**
     * Kann mit einer {@link de.deutscherv.rvsm.fa.fit.exceptions.KontoinformationBestandsFehlerException} gesetzt werden um diese
     * am Ende der Route korrekt zu behandeln.
     */
    public static final String KONTOINFORMATION_BESTANDSFEHELR = "rvfit_kontoinformation_bestandsfehler";
    /**
     * Property für die Erledigungsart eines RV Fit-Antrags.
     */
    public static final String PROPERTY_ERLEDIGUNGSART = "rvfit_erledigungsart";
    /**
     * Property für ein Flag das angibt, ob eine Erledigung vor Regelprüfung durchgeführt werden soll.
     */
    public static final String PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG = "rvfit_erledigung_vor_regelpruefung";

    /**
     * Wird gesetzt um festzulegen, welche Art von Erledigung ohne Bescheid für einen Antrag ausgewählt wurde.
     */
    public static final String ERLEDIGUNG_OHNE_BESCHEID_ART = "rvfit_erledigung_ohne_bescheid_art";
    /**
     * Property für eine offene Aufgabe in PuR, die für die Sendung ans Fachprotokoll benötigt wird.
     */
    public static final String PROPERTY_OFFENE_AUFGABE = "rvfit_offene_aufgabe";

    /**
     * Property für die ID der Start- und Auffrischungseinrichtung.
     */
    public static final String REHA_EINRICHTUNG_STARTAUF_ID = "rvfit_einrichtung_startauf";

    /**
     * Property für die ID der Trainingsseinrichtung.
     */
    public static final String REHA_EINRICHTUNG_TRAINING_ID = "rvfit_einrichtung_training";

    /**
     * Alle Bestandsfehler Header.
     */
    public static final Set<String> BESTANDSFEHLER_HEADER = Set.of(
        STAMMDATEN_BESTANDSFEHLER,
        STATISTIK_BESTANDSFEHLER,
        KONTOINFORMATION_BESTANDSFEHELR
    );
}
