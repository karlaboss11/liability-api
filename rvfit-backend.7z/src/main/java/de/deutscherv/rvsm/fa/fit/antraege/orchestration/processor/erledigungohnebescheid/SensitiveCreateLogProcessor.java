package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor um in das Log zu schreiben.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class SensitiveCreateLogProcessor implements Processor {

    private final AntragService antragService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        antragService.sensitiveCreateLog(
                UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class)));
    }
}
