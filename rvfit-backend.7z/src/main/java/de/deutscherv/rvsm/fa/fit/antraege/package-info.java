/**
 * Beinhaltet Klassen, die sich mit Anträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.antraege;
