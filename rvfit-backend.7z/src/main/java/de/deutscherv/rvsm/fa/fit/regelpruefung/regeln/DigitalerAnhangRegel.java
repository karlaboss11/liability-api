package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuern;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisAussteuernKeineDaten;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * Informationen zu Regeln fuer digitalem Anhang.
 */
@Singleton
public class DigitalerAnhangRegel extends BasisRegel {

    private static final Map<String, String> REGEL_ERGEBNIS_DETAIL = Map.of(
            RegelUtils.ERFUELLT, "Es liegen keine Anlagen zum Antrag vor.",
            RegelUtils.AUSSTEUERN_KEINE_DATEN, "Es liegen keine vollstaendigen Daten vor.",
            RegelUtils.AUSSTEUERN, "Es liegen Anlagen zum Antrag vor.");

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_DIGITALER_ANHANG;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGEBNIS_DETAIL.get(regelErgebnis));
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (Objects.isNull(kontext.getAntrag())) {
            return ergebnisAussteuernKeineDaten(this);
        }

        if (kontext.getAntrag().isHatDigitalenAnhang()) {
            return ergebnisAussteuern(this);
        }

        return ergebnisErfuellt(this);
    }
}
