package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import lombok.Getter;

/**
 * Bestandsfehler Exception.
 */
@Getter
public abstract class BestandsfehlerException extends RvfitException {

    private final transient VersichertenInfo versichertenInfo;

    /**
     * Konstruktor.
     * @param antrag betroffener Antrag
     * @param message Fehlernachtricht
     */
    protected BestandsfehlerException(final Antrag antrag, final String message) {
        super(message);
        this.versichertenInfo = new VersichertenInfo(antrag.getVsnr(), antrag.getVorname(), antrag.getNachname());
    }

    /**
     * Record mit Versichterninfo.
     * @param vsnr Versicherungsnr
     * @param vorname Vorname
     * @param nachname Nachname
     */
    public record VersichertenInfo(String vsnr, String vorname, String nachname) {
    }
}
