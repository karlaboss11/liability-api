package de.deutscherv.rvsm.fa.fit.antraege.service;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Antragstatus-Service.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class AntragStatusService {

    private final AntragRepository antragRepository;

    /**
     * Setzt den status eines Antrags.
     *
     * @param antrag      der Antrag
     * @param neuerStatus der neue Status
     * @return persistierten Antrag
     * @throws UnsupportedOperationException wenn der Status nicht auf den derzeitigen Status im Antrag folgen kann.
     * @see de.deutscherv.rvsm.fa.fit.util.StatusValidator#isReihenfolge(AntragStatus, AntragStatus)
     */
    @Transactional
    public Antrag setAntragStatus(final Antrag antrag, final AntragStatus neuerStatus) {
        LOG.atDebug().addArgument(antrag.getUuid()).addArgument(antrag.getStatus())
            .addArgument(neuerStatus.name())
            .log("Antrag Status update: Antrag UUID [{}], old Status [{}], new Status [{}]");
        antrag.setStatus(neuerStatus);
        Antrag res = antragRepository.merge(antrag);
        antragRepository.flush();
        return res;
    }
}
