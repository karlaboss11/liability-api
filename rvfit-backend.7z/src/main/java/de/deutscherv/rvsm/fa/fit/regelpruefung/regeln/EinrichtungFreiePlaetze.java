package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto.AUFFRISCHUNG;
import static de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto.STARTPHASE;
import static de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto.TRAININGSPHASE;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils.angeboteAnhandPlaetzeVorhanden;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils.eindeutigeAngeboteVorhanden;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils.keineEinrichtungenVorhanden;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungAussteuernAngebotPausiert;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungAussteuernAufAnfrage;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisEinrichtungAussteuernKeineFreiePlaetze;
import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnisErfuellt;

/**
 * The Regel Class EinrichtungFreiePlaetze.
 */
@Singleton
public class EinrichtungFreiePlaetze extends BasisRegel {

    private static final Map<String, String> REGEL_ERGENIS_DETAIL = Map.of(RegelUtils.ERFUELLT,
            "Die Einrichtungen der Start- und Trainingsphase haben freie Plätze.",
            RegelUtils.AUSSTEUERN_KEINE_FREIE_PLAETZE,
            "Die Einrichtung der Start- oder Trainingsphase hat keine freien Plätze.",
            RegelUtils.AUSSTEUERN_AUF_ANFRAGE,
            "Die Einrichtung der Start- oder Trainingsphase hat freie Plätze nur auf Anfrage.",
            RegelUtils.AUSSTEUERN_ANGEBOT_PAUSIERT,
            "Die Einrichtung der Start- oder Trainingsphase hat nur ein pausiertes Angebot.");

    /**
     * Gets the regel name.
     *
     * @return the regel name
     */
    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_EINRICHTUNGFREIEPLAETZE;
    }

    /**
     * Gets the regel detail.
     *
     * @param regelErgebnis the regel ergebnis
     * @return the regel detail
     */
    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(REGEL_ERGENIS_DETAIL.get(regelErgebnis));
    }

    /**
     * Pruefe regel.
     *
     * @param kontext the kontext
     * @return the RegelErgebnis list
     */
    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        if (keineEinrichtungenVorhanden(kontext.getAntrag())) {
            return new ArrayList<>();
        }
        //training
        final boolean hatTrainingMitFreienplaetze =
                eindeutigeAngeboteVorhanden(TRAININGSPHASE, kontext.getTrainingsphaseEinrichtungen());
        final boolean hatTrainingMitKeinenFreienPlaetzen =
                angeboteAnhandPlaetzeVorhanden(TRAININGSPHASE, 0,
                        kontext.getTrainingsphaseEinrichtungen());
        final boolean hatTrainingAufAnfrageAngebote =
                angeboteAnhandPlaetzeVorhanden(TRAININGSPHASE, -1,
                        kontext.getTrainingsphaseEinrichtungen());
        final boolean hatTrainingPausierteAngebote = angeboteAnhandPlaetzeVorhanden(TRAININGSPHASE, -2,
                kontext.getTrainingsphaseEinrichtungen());

        // Start
        final boolean hatStartAngeboteMitFreienPlaetzen
                = eindeutigeAngeboteVorhanden(STARTPHASE, kontext.getStartphaseEinrichtungen());
        final boolean hatAuffrischungMitFreienPlaetzen
                = eindeutigeAngeboteVorhanden(AUFFRISCHUNG, kontext.getAuffrishungsphaseEinrichtungen());
        final boolean hatStartPausiertAngebote = angeboteAnhandPlaetzeVorhanden(STARTPHASE, -2,
                kontext.getStartphaseEinrichtungen());
        final boolean hatAuffrischungPausiertAngebote = angeboteAnhandPlaetzeVorhanden(AUFFRISCHUNG, -2,
                kontext.getAuffrishungsphaseEinrichtungen());
        final boolean hatStartAufAnfrageAngebote = angeboteAnhandPlaetzeVorhanden(
                STARTPHASE, -1, kontext.getStartphaseEinrichtungen());

        final boolean hatAuffrischungAufAnfrageAngebote =
                angeboteAnhandPlaetzeVorhanden(AUFFRISCHUNG, -1,
                        kontext.getAuffrishungsphaseEinrichtungen());
        final boolean hatStartKeineFreiePlaetzeAngebote =
                angeboteAnhandPlaetzeVorhanden(STARTPHASE, 0,
                        kontext.getStartphaseEinrichtungen());
        final boolean hatAuffrischungKeineFreiePlaetzeAngebote =
                angeboteAnhandPlaetzeVorhanden(AUFFRISCHUNG, 0,
                        kontext.getAuffrishungsphaseEinrichtungen());

        final boolean freiePlaeze = hatStartAngeboteMitFreienPlaetzen
                && hatAuffrischungMitFreienPlaetzen
                && hatTrainingMitFreienplaetze;
        final boolean aufAnfrage = hatStartAufAnfrageAngebote
                || hatAuffrischungAufAnfrageAngebote
                || hatTrainingAufAnfrageAngebote;
        final boolean keineFreienPlaetze = hatStartKeineFreiePlaetzeAngebote
                || hatAuffrischungKeineFreiePlaetzeAngebote
                || hatTrainingMitKeinenFreienPlaetzen;
        final boolean pausierteAngebote = hatStartPausiertAngebote
                || hatAuffrischungPausiertAngebote
                || hatTrainingPausierteAngebote;

        return ueberpruefePhase(freiePlaeze, aufAnfrage, keineFreienPlaetze, pausierteAngebote);

    }

    private List<RegelErgebnis> ueberpruefePhase(final boolean hatFreiePlaetze, final boolean hatAufAnfrageAngebote,
            final boolean hatKeineFreienPlaetze, final boolean hatpausierteAngebote) {
        if (hatFreiePlaetze) {
            return ergebnisErfuellt(this);
        }
        if (hatAufAnfrageAngebote) {
            return ergebnisEinrichtungAussteuernAufAnfrage(this);
        }
        if (hatKeineFreienPlaetze) {
            return ergebnisEinrichtungAussteuernKeineFreiePlaetze(this);
        }
        if (hatpausierteAngebote) {
            return ergebnisEinrichtungAussteuernAngebotPausiert(this);
        }
        // Kein Training Angebot wurde gefunden
        return ergebnisErfuellt(this);
    }

}
