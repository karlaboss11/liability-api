package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.SchliesseStatistikAbProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.AntragInBearbeitungEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.AntragToAntragDtoMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.ErledigungVorRegelpruefungEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.FachprotokollBearbeitungAbgeschlossenProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.FachprotokollStatistikGebildetProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SaveVerarbeitungsStatusOhneVersandProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SchliesseBestandsfehlerProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SchliessePurAufgabeProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SensitiveCreateLogProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SetzeStatusAufBescheidAbgeschlossenProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SetzeStatusAufStatistikAbgeschlossenProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.SetzeStatusAufStatistikErfasstProcessor;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID_WEITERBEARBEITUNG_IN_RV_DIALOG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SETZE_STATUS_STATISTIK_ABGESCHLOSSEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_SETZE_STATUS_STATISTIK_ERFASST;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.RVFIT_STATUS_BASED_ROUTING;

/**
 * Routen für die Erledigung eines Antrags ohne Bescheid.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class ErledigungOhneBescheidRoutes extends RouteBuilder {


    private final AntragInBearbeitungEnricher antragInBearbeitungEnricher;
    private final SensitiveCreateLogProcessor sensitiveCreateLogProcessor;
    private final ErledigungVorRegelpruefungEnricher erledigungVorRegelpruefungEnricher;
    private final SetzeStatusAufBescheidAbgeschlossenProcessor setzeStatusAufBescheidAbgeschlossenProcessor;
    private final FachprotokollBearbeitungAbgeschlossenProcessor fachprotokollBearbeitungAbgeschlossenProcessor;
    private final SaveVerarbeitungsStatusOhneVersandProcessor saveVerarbeitungsStatusOhneVersandProcessor;
    private final SchliessePurAufgabeProcessor schliessePurAufgabeProcessor;
    private final SchliesseStatistikAbProcessor statistikAbschliessenProcessor;
    private final FachprotokollStatistikGebildetProcessor fachprotokollStatistikGebildetProcessor;
    private final AntragToAntragDtoMapper antragToAntragDtoMapper;
    private final SetzeStatusAufStatistikAbgeschlossenProcessor setzeStatusAufStatistikAbgeschlossenProcessor;
    private final SetzeStatusAufStatistikErfasstProcessor setzeStatusAufStatistikErfasstProcessor;
    private final SchliesseBestandsfehlerProcessor schliesseBestandsfehlerProcessor;

    @Override
    public void configure() throws Exception {

        from(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .routeId(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .process(sensitiveCreateLogProcessor)
                .process(antragInBearbeitungEnricher)
                .process(erledigungVorRegelpruefungEnricher)
                .process(schliesseBestandsfehlerProcessor)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN)
                .process(setzeStatusAufStatistikAbgeschlossenProcessor)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS);

        from(DIRECT_ERLEDIGUNG_OHNE_BESCHEID)
                .routeId(DIRECT_ERLEDIGUNG_OHNE_BESCHEID)
                .process(sensitiveCreateLogProcessor)
                .process(antragInBearbeitungEnricher)
                .process(erledigungVorRegelpruefungEnricher)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN)
                .to(RVFIT_STATUS_BASED_ROUTING)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS);

        from(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN)
                .routeId(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_AUFGABE_SCHLIESSEN)
                .transacted()
                .choice()
                .when(simple("${body.status} != 'AUFGABE_ABGESCHLOSSEN'"))
                .process(setzeStatusAufBescheidAbgeschlossenProcessor)
                .process(fachprotokollBearbeitungAbgeschlossenProcessor)
                .process(saveVerarbeitungsStatusOhneVersandProcessor)
                .process(schliessePurAufgabeProcessor)
                .endChoice()
                .end();

        from(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN)
                .routeId(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN)
                .transacted()
                .process(statistikAbschliessenProcessor);

        from(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS)
                .routeId(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS)
                .transacted()
                .process(fachprotokollStatistikGebildetProcessor)
                .process(antragToAntragDtoMapper);

        from(DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID)
                .routeId(DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID)
                .process(sensitiveCreateLogProcessor)
                .to(DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_STATISTIK_SCHREIBEN)
                .to(RVFIT_STATUS_BASED_ROUTING)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS);

        from(DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN)
                .routeId(DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN)
                .transacted()
                .to(DIRECT_EXTRACT_MANDANT)
                .process(setzeStatusAufBescheidAbgeschlossenProcessor)
                .process(fachprotokollBearbeitungAbgeschlossenProcessor);

        from(DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .routeId(DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .process(sensitiveCreateLogProcessor)
                .to(DIRECT_PAPIERANTRAG_ERFASSEN_FACHPROTOKOLL_BEARBEITUNG_ABGESCHLOSSEN)
                .to(DIRECT_SETZE_STATUS_STATISTIK_ABGESCHLOSSEN)
                .to(DIRECT_ERLEDIGUNG_OHNE_BESCHEID_FACHPROTOKOLL_ABSCHLUSS);

        from(DIRECT_SETZE_STATUS_STATISTIK_ABGESCHLOSSEN)
                .routeId(DIRECT_SETZE_STATUS_STATISTIK_ABGESCHLOSSEN)
                .transacted()
                .process(setzeStatusAufStatistikAbgeschlossenProcessor);

        from(DIRECT_SETZE_STATUS_STATISTIK_ERFASST)
                .routeId(DIRECT_SETZE_STATUS_STATISTIK_ERFASST)
                .transacted()
                .process(setzeStatusAufStatistikErfasstProcessor);
    }

}
