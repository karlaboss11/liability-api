package de.deutscherv.rvsm.fa.fit.verarbeitung.repository;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;

/**
 * Repository Verarbeitungsstatus.
 */
@RequiredArgsConstructor
@ApplicationScoped
public class VerarbeitungsstatusRepository {

    private final EntityManager entityManager;

    /**
     * Liefert den Verarbeitungsstatus eines Antrags.
     *
     * @param antragUuid      die UUID des Antrags
     * @param mitAntragStatus optional mehrere AntragsStatus. Falls gesetzt, werden nur Anträge mit einem entsprechenden Status
     *                        zurückgegeben
     * @return Ein Optional mit dem Verarbeitungsstatus eines Antrags
     */
    public Optional<Verarbeitungsstatus> findByAntragId(final UUID antragUuid, final AntragStatus... mitAntragStatus) {
        if (mitAntragStatus != null && mitAntragStatus.length > 0) {
            return findByAntragIdMitAntragStatus(antragUuid, mitAntragStatus);
        }

        final TypedQuery<Verarbeitungsstatus> query = entityManager.createQuery(
                "select vs from Verarbeitungsstatus vs where vs.antragId = :antragUuid",
                Verarbeitungsstatus.class);

        query.setParameter("antragUuid", antragUuid);

        return query.getResultStream().findFirst();
    }

    private Optional<Verarbeitungsstatus> findByAntragIdMitAntragStatus(final UUID antragUuid, final AntragStatus... mitAntragStatus) {
        final TypedQuery<Verarbeitungsstatus> query = entityManager.createQuery(
                """
                        SELECT v FROM Antrag a
                        LEFT JOIN Verarbeitungsstatus v on a.uuid = v.antragId
                        WHERE a.uuid = :antragUuid
                            AND a.status IN :antragStatus
                        """,
                Verarbeitungsstatus.class);

        query.setParameter("antragUuid", antragUuid);
        query.setParameter("antragStatus", Arrays.asList(mitAntragStatus));

        return query.getResultStream().findFirst();
    }

    /**
     * Ausstehende Aenderungen werden auf die DB geschrieben.
     */
    @RequiresMandant
    public void flush() {
        entityManager.flush();
    }

    /**
     * Speichert einen Verarbeitungsstatus in der Datenbank.
     *
     * @param verarbeitungsstatus zu persistierender Verarbeitungsstatus
     */
    @RequiresMandant
    @Transactional
    public void persist(final Verarbeitungsstatus verarbeitungsstatus) {
        entityManager.persist(verarbeitungsstatus);
    }

    /**
     * Persistiert einen neuen Verarbeitungsstatus.
     * @param verarbeitungsstatus zu persistierender Verarbeitungsstatus
     */
    @RequiresMandant
    @Transactional
    public void merge(final Verarbeitungsstatus verarbeitungsstatus) {
        entityManager.merge(verarbeitungsstatus);
    }

    /**
     * Speichert einen Verarbeitungsstatus in der Datenbank. Synchronisiert den Persistenz-Kontext mit der darunterliegenden Datenbank.
     *
     * @param verarbeitungsstatus zu persistierender Verarbeitungsstatus
     */
    @RequiresMandant
    @Transactional
    public void persistAndFlush(final Verarbeitungsstatus verarbeitungsstatus) {
        entityManager.persist(verarbeitungsstatus);
        entityManager.flush();
    }

}
