package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader.PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG;

/**
 * Processor um einen Antrag ohne Bescheid auf andere Art und Weise zu erledigen.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragErledigungAufAndereArtUndWeiseProcessor implements Processor {
    /**
     * Routenname für die Erledigung eines Papierantrags auf andere Art und Weise.
     */
    public static final String DIRECT_PAPIERANTRAG_VERARBEITE_ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE =
            "direct:papierantragVerarbeiteErledigungAufAndereArtUndWeise";

    @Override
    public void process(final Exchange exchange) {
        final UUID uuid = UUID.fromString(exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAG_UUID, String.class));
        LoggingUtils.logProcessorUuid(exchange.getFromRouteId(), getClass().getSimpleName(), uuid);

        exchange.setProperty(PROPERTY_ERLEDIGUNGSART,Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE);
        exchange.setProperty(PROPERTY_ERLEDIGUNG_VOR_REGELPRUEFUNG, true);
    }
}
