package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Processor zum Schliessen der Aufgabe nach Antragserfassung.
 */

@ApplicationScoped
@RequiredArgsConstructor
public class PapierantragSchliesseAufgabeProcessor implements Processor {

    /**
     * Routennamen zum Schliessen der Aufgabe nach Antragserfassung.
     */
    public static final String DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN = "direct:papierantragAufgabeSchliessen";

    private final AufgabeService aufgabeService;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        final String aufgabenId = exchange.getMessage().getHeader(RVFitCamelHeader.PUR_AUFGABEN_ID, String.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);

        final Aufgabe erfassungsAufgabe = Aufgabe.builder()
                .aufgabenArt(AufgabenArt.ANTRAGSERFASSUNG).transaktionId(UUID.randomUUID())
                .vomAufgabenId(aufgabenId)
                .datumErstellung(LocalDateTime.now()).build();
        antrag.addAufgabe(erfassungsAufgabe);

        aufgabeService.schliesseAufgabePapierantragErfasst(erfassungsAufgabe, aufgabenId);
    }
}
