package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragStatusService;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.aufgaben.service.AufgabeService;
import de.deutscherv.rvsm.fa.fit.aufgaben.utils.AufgabenUtils;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.StammdatenBestandsFehlerException;
import de.deutscherv.rvsm.fa.fit.exceptions.annotation.ExceptionPersist;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.FehlerEintragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.EinrichtungsdatenUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelEngine;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import de.deutscherv.rvsm.fa.fit.regelpruefung.model.Regel;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.regelpruefung.repository.RegelRepository;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalService;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenService;
import de.deutscherv.rvsm.fa.fit.stammdaten.model.Stammdaten;
import de.deutscherv.rvsm.fa.fit.util.StatusValidator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;

/**
 * Service rund um die Pruefergenisse.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class PruefergebnisService {

    private static final String PERSISTIERE_ANTRAG_IN_DB = "Persistiere Antrag [{}] in DB";
    private static final String RESOURCE_NAME = PruefergebnisService.class.getName();

    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;
    private final AntragRepository antragRepository;
    private final RegelRepository regelRepository;
    private final AntragStatusService antragStatusService;
    private final AufgabeService aufgabeService;
    private final SelbstmeldeportalService selbstmeldeportalService;
    private final AntragService antragService;
    private final AntragMapper antragMapper;
    private final RegelEngine engine;
    private final FluentProducerTemplate producerTemplate;
    private final StammdatenService stammdatenService;

    /**
     * Speichert ein Prüfergebnis für einen Antrag.
     *
     * @param antrag        der Antrag
     * @param regelErgebnis das Ergebnis
     * @return Antrag zu den Pruefergebnissen
     */
    @Transactional
    public Antrag speicherePruefergebnis(final Antrag antrag, final RegelErgebnis regelErgebnis) {
        final AntragPruefergebnis pruefergebnis = new AntragPruefergebnis();
        pruefergebnis.setBegruendung(regelErgebnis.getDetail());
        pruefergebnis.setErgebnis(regelErgebnis.getPruefErgebnis());
        pruefergebnis.setParentUuid(null);
        pruefergebnis.setRegelName(null);
        pruefergebnis.setRegelId(null);
        pruefergebnis.setPrioritaet(null);
        pruefergebnis.setKtan(antrag.getKtan());
        antrag.addAntragPruefergebnis(pruefergebnis);

        if (Objects.nonNull(regelErgebnis.getDetailErgebnisse())
            && !regelErgebnis.getDetailErgebnisse().isEmpty()) {
            verkettePruefergebnisse(pruefergebnis, regelErgebnis, antrag);
        }
        LOG.atDebug().addArgument(antrag.getUuid()).addArgument(antrag.getKtan())
            .addArgument(pruefergebnis.getUuid()).log(
                "Das erste Pruefergbnis fuer den Antrag wurde gespeichert. Antrag uuid [{}], KTAN [{}],  "
                    + "AntragPruefergebnis ID [{}] ");
        final var updatedAntrag = antragRepository.merge(antrag);
        antragRepository.flush();
        return updatedAntrag;
    }

    /**
     * Aktualisiert das RegelErgebnis eines Antrags.
     *
     * @param antrag           der Antrags
     * @param regelName        der RegelName
     * @param newPruefErgebnis das neue PruefErgebnis zur Regel
     * @param begruendung      die Begründung
     */
    @Transactional
    public void updateRegelErgebnis(final Antrag antrag, final RegelName regelName,
        final PruefErgebnis newPruefErgebnis, final String begruendung) {

        LOG.atInfo().addArgument(antrag.getUuid()).addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
            .addArgument(antrag.getVsnr())
            .log("Lese Pruefergebnis anhand der Antrags. Antrag UUID [{}], KTAN [{}], VSNR [{}]");

        StatusValidator.canModify(antrag.getStatus().name(), RESOURCE_NAME,
            GET_DRV_ID_AUS_JWT.apply(jwt));
        LOG.atDebug().addArgument(antrag.getUuid()).log(
            "Service update Regel Ergebnis: Das Regel Prüfergebnis wird upgedated. Antrag UUID [{}]");
        final AntragPruefergebnis currentRegelPruefergebnis = PruefergebnisUtils.getCurrentAntragPruefergebnisByRegelName(antrag,
            regelName);
        final AntragPruefergebnis parentPruefergebnis = PruefergebnisUtils.getParentRegelAntragPruefergebnis(antrag);
        final List<AntragPruefergebnis> pruefergebnisseByRegelName = PruefergebnisUtils.getAntragPruefergebnisseByRegelName(antrag,
            regelName);
        if (pruefergebnisseByRegelName.size() == 1) {
            final AntragPruefergebnis initialRegelPruefergebnis = pruefergebnisseByRegelName.getFirst();
            final AntragPruefergebnis newRegelPruefergebnis = AntragPruefergebnis.builder()
                .parentUuid(initialRegelPruefergebnis.getParentUuid())
                .ergebnis(initialRegelPruefergebnis.getErgebnis()).regelName(regelName)
                .begruendung(begruendung).prioritaet(initialRegelPruefergebnis.getPrioritaet())
                .regelId(initialRegelPruefergebnis.getRegelId())
                .anmerkung(initialRegelPruefergebnis.getAnmerkung())
                .ktan(initialRegelPruefergebnis.getKtan()).build();
            newRegelPruefergebnis.setErgebnis(newPruefErgebnis);
            newRegelPruefergebnis.setBegruendung(begruendung);
            antrag.addAntragPruefergebnis(newRegelPruefergebnis);
        } else {
            currentRegelPruefergebnis.setErgebnis(newPruefErgebnis);
            currentRegelPruefergebnis.setBegruendung(begruendung);
        }
        parentPruefergebnis.setErgebnis(
            PruefergebnisUtils.getNewParentErgebnis(antrag, regelName, newPruefErgebnis));

        antragRepository.merge(antrag);
        LOG.atDebug().addArgument(antrag).log(PERSISTIERE_ANTRAG_IN_DB);

        LOG.atDebug().log(
            "Antrag guuid [{}]: [{}] Pruefergenis fuer den Antrag wurde auf [{}] geaendert",
            antrag.getUuid(), regelName, newPruefErgebnis);
        rvfitLogger.sendeFachprotokollEreignis(
            LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_USER,
                Ereignistext.ANSPRUCHSPRUEFUNG_ANGEPASST, EreignisFreitext.ANSPRUCHSPRUEFUNG_ANGEPASST,
                regelName.name(), antrag, null, jwt, drvMandant));
    }

    /**
     * Setzt das RegelErgebnis einer bestimmten Regel zu einem Antrag zurück.
     *
     * @param antrag       der Antrag
     * @param regelNameStr der Name der Regel, für die das Ergebnis zurückgesetzt wird
     */
    @Transactional
    public void resetRegelErgebnis(final Antrag antrag, final String regelNameStr) {

        LOG.atInfo().addArgument(antrag.getUuid()).addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
            .addArgument(antrag.getVsnr())
            .log("Setze Regelergenis zurück. Antrag UUID [{}], KTAN [{}], VSNR [{}]");

        StatusValidator.canModify(antrag.getStatus().name(), RESOURCE_NAME,
            GET_DRV_ID_AUS_JWT.apply(jwt));
        LOG.atDebug().addArgument(antrag.getUuid()).log(
            "Service reset Regel Ergebnis: Das Regel Prüfergebnis wird zurückgesetzt. Antrag UUID [{}]");
        final RegelName regelName = RegelName.valueOf(regelNameStr);
        final List<AntragPruefergebnis> pruefergebnisse = PruefergebnisUtils.getAntragPruefergebnisseByRegelName(antrag, regelName);
        if (pruefergebnisse.size() == 2) {
            final AntragPruefergebnis currentRegelPruefergebnis = PruefergebnisUtils.getCurrentAntragPruefergebnisByRegelName(antrag,
                regelName);
            currentRegelPruefergebnis.setBegruendung(null);
            if (pruefergebnisse.get(0).getCreated().isBefore(pruefergebnisse.get(1).getCreated())) {
                currentRegelPruefergebnis.setErgebnis(pruefergebnisse.getFirst().getErgebnis());
            } else {
                currentRegelPruefergebnis.setErgebnis(pruefergebnisse.get(1).getErgebnis());
            }
            antragRepository.merge(antrag);
            LOG.atDebug().addArgument(antrag).log(PERSISTIERE_ANTRAG_IN_DB);

            LOG.atDebug().log(
                "Antrag guuid [{}]: [{}] Pruefergenis fuer den Antrag wurde auf [{}] geaendert",
                antrag.getUuid(), regelName, currentRegelPruefergebnis.getErgebnis());
        }

        rvfitLogger.sendeFachprotokollEreignis(
            LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_USER,
                Ereignistext.ANSPRUCHSPRUEFUNG_ANGEPASST, EreignisFreitext.ANSPRUCHSPRUEFUNG_ZURUECKGESETZT,
                regelNameStr, antrag, null, jwt, drvMandant));
    }

    /**
     * Bestimmt die Einrichtung zu einer AngebotsId aus dem Selbstmeldeportal. In der Einrichtung ist nur das Angebot enthalten, das der
     * übergebenen Id entspricht.
     *
     * @param plzVersicherter die PLZ der versicherten Person
     * @param angebotId       die Angebots-Id
     * @return die Einrichtung
     */
    List<RehaEinrichtung> einrichtungenBySmpAngebotId(final String plzVersicherter, final Long angebotId) {
        final var einrichtung = selbstmeldeportalService.getEinrichtungByAngebotId(plzVersicherter, angebotId);
        einrichtung.ifPresent(e -> e.getAngebote()
            .removeIf(angebot -> !Objects.equals(angebot.getSmpAngebotId(), angebotId)));
        return einrichtung.stream().toList();
    }

    /**
     * Führt die Anspruchsprüfung für einen Antrag durch.
     *
     * @param antrag der Antrag
     * @return der Antrag
     */
    public Antrag checkAnspruchspruefung(final Antrag antrag) {
        LOG.atDebug().addArgument(antrag.getUuid()).log(
            "Service check Anspruchspruefung: Die Anspruchspruefung des Antrags wird berechnet. Antrag UUID [{}]");

        final RegelErgebnis regelErgebnis = berechnePruefergebnis(antrag);

        final var updatedAntrag = speicherePruefergebnis(antrag, regelErgebnis);

        erstelleAufgabenZumPruefergebnis(updatedAntrag, regelErgebnis);

        antragRepository.merge(updatedAntrag);

        LOG.atDebug().addArgument(updatedAntrag).log(PERSISTIERE_ANTRAG_IN_DB);

        antragService.createPdfArchiv(updatedAntrag);

        return antrag;
    }

    /**
     * Berechne das Gesamtergebnis.
     *
     * @param antrag der Antrag
     * @return regelErgebnis Das Gesamtergebnis
     */
    @ActivateRequestContext
    public RegelErgebnis berechnePruefergebnis(final Antrag antrag) {

        final RegelKontext regelKontext = baueRegelKontext(antrag);

        final List<RegelName> anspruchspruefungRegeln = new ArrayList<>();
        final List<Regel> regeln = regelRepository.findByKtanAndAktiv(null, true);
        regeln.forEach(r -> anspruchspruefungRegeln.add(r.getName()));
        final RegelErgebnis regelErgebnis = engine.check(anspruchspruefungRegeln, regelKontext);
        if (PruefergebnisUtils.personendatenabgleichFailed(regelErgebnis)) {
            LOG.atInfo().addArgument(antrag.getUuid()).addArgument(
                    Optional.ofNullable(regelKontext.getStammdaten())
                        .map(Stammdaten::getVsnr)
                        .orElse(""))
                .log(
                    "Personendatenabgleich fehlgeschlagen. Speichere Stammdaten zum Antrag. Antrag UUID: [{}], VSNR: [{}]");
            antrag.addVersicherte(regelKontext.getStammdaten());
            rvfitLogger
                .sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                    Ereignistext.PERSONENDATEN_GESPEICHERT, EreignisFreitext.PERSONENDATEN_GESPEICHERT, null,
                    antrag, null, jwt, drvMandant));
        }

        erstelleFachprotokollEreignisseFuerPruefungen(antrag, regelErgebnis);

        return regelErgebnis;

    }

    private RegelKontext baueRegelKontext(final Antrag antrag) {
        final Stammdaten stammdaten = Optional.of(antrag.getVersichertenStammdaten())
            .filter(Predicate.not(List::isEmpty)).map(List::getFirst)
            .orElseGet(() -> stammdatenService.getStammdatenByVsnr(antrag));
        if (antrag.getVersichertenStammdaten().isEmpty()) {
            antrag.getVersichertenStammdaten().add(stammdaten);
            antragRepository.merge(antrag);
        }
        final CompletableFuture<List<RehaEinrichtung>> start = CompletableFuture.supplyAsync(
            () -> fetchEinrichtungenForStartphase(antrag, stammdaten.getPlz()));
        final CompletableFuture<List<RehaEinrichtung>> auffrischung = CompletableFuture.supplyAsync(
            () -> fetchEinrichtungenForAuffrischung(antrag, stammdaten.getPlz()));
        final CompletableFuture<List<RehaEinrichtung>> training = CompletableFuture.supplyAsync(
            () -> fetchEinrichtungenForTrainingsphase(antrag, stammdaten.getPlz()));
        final CompletableFuture<Void> combinedFuture
            = CompletableFuture.allOf(start, auffrischung, training);
        try {
            combinedFuture.get(20, TimeUnit.SECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            throw new RuntimeException(e); //Quickfix, korrektes Errorhandling wünschenswert
        }
        final List<RehaEinrichtung> startEinrichtungen = start.join();
        final List<RehaEinrichtung> auffrischungEinrichtungen = auffrischung.join();
        final List<RehaEinrichtung> trainingEinrichtungen = training.join();
        return new RegelKontext(antrag, stammdaten, startEinrichtungen,
            auffrischungEinrichtungen, trainingEinrichtungen);
    }

    /**
     * Lies Einrichtungen zur Startphase.
     *
     * @param antrag          betroffener Antrag
     * @param plzVersicherter PLZ des Versicherten
     * @return Liste der gefundenen Einrichtungen
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Einrichtungen für Startphase")
    @ActivateRequestContext
    public List<RehaEinrichtung> fetchEinrichtungenForStartphase(final Antrag antrag,
        final String plzVersicherter) {
        return antrag.getAngebotStartSmpId() != null
            ? einrichtungenBySmpAngebotId(antrag.getPlz(), antrag.getAngebotStartSmpId())
            : EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.STARTPHASE, antrag),
                selbstmeldeportalService.getEinrichtungen(antrag.getPlz(), plzVersicherter, null, 1000, 2, null));
    }

    /**
     * Lies Einrichtungen zur Auffrischungsphase.
     *
     * @param antrag          betroffener Antrag
     * @param plzVersicherter PLZ des Versicherten
     * @return Liste der gefundenen Einrichtungen
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Einrichtungen für Auffrischung")
    @ActivateRequestContext
    public List<RehaEinrichtung> fetchEinrichtungenForAuffrischung(final Antrag antrag,
        final String plzVersicherter) {
        return antrag.getAngebotAufSmpId() != null
            ? einrichtungenBySmpAngebotId(antrag.getPlz(), antrag.getAngebotAufSmpId())
            : EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.AUFFRISCHUNG, antrag),
                selbstmeldeportalService.getEinrichtungen(antrag.getPlz(), plzVersicherter, null, 1000, 3, null));
    }

    /**
     * Lies Einrichtungen zur Trainingssphase.
     *
     * @param antrag          betroffener Antrag
     * @param plzVersicherter PLZ des Versicherten
     * @return Liste der gefundenen Einrichtungen
     */
    @ExceptionPersist(message = "Fehler beim Abrufen der Einrichtungen für Trainingsphase")
    @ActivateRequestContext
    public List<RehaEinrichtung> fetchEinrichtungenForTrainingsphase(final Antrag antrag,
        final String plzVersicherter) {
        return antrag.getAngebotTrainingSmpId() != null
            ? einrichtungenBySmpAngebotId(antrag.getPlz(), antrag.getAngebotTrainingSmpId())
            : EinrichtungsdatenUtils.getEinrichtungenFromAngebot(
                EinrichtungsdatenUtils.getAngebot(PhaseEnumDto.TRAININGSPHASE, antrag),
                selbstmeldeportalService.getEinrichtungen(antrag.getPlz(), plzVersicherter, null, 1000, 4, null));
    }

    /**
     * Prüft, ob die Personendaten gleich sind.
     *
     * @param uuid die Antrags UUID
     * @return {@code true}, wenn die Personendaten von rvDialog nicht zustimmen.
     */
    @Transactional
    public StatusCodeAntwortPair checkPersonendatenabgleich(final UUID uuid) {
        LOG.atDebug().log(
            "Service check checkPersonendatenabgleich: Die Anspruchspruefung des Antrags wird berechnet");

        final Exchange exchange = producerTemplate.withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid)
            .to(RouteNames.DIRECT_PERSONENDATENABGLEICH).send();
        final Exception exception = Optional.of(exchange)
            .map(Exchange::getMessage)
            .map(msg -> msg.getHeader(RVFitCamelHeader.STAMMDATEN_BESTANDSFEHLER))
            .map(Exception.class::cast)
            .orElseGet(() -> exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class));
        if (exception != null) {
            if (exception instanceof StammdatenBestandsFehlerException stammdatenBestandsFehlerException) {
                return new StatusCodeAntwortPair(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
                    new AntwortDto()
                        .code(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode())
                        .nachricht(exception.getMessage())
                        .bestandsfehler(toBestandsfehler(stammdatenBestandsFehlerException)));
            } else {
                return new StatusCodeAntwortPair(Response.Status.BAD_GATEWAY.getStatusCode(), null);
            }
        }

        final boolean stammdatenUpdated = Optional.of(exchange)
            .map(Exchange::getMessage)
            .map(msg -> msg.getHeader("stammdatenUpdated"))
            .map(Boolean.class::cast).orElse(false);
        if (stammdatenUpdated) {
            return new StatusCodeAntwortPair(Response.Status.OK.getStatusCode(),
                new AntwortDto()
                    .code(Response.Status.OK.getStatusCode())
                    .nachricht("Personendaten wurden abgeglichen"));
        }

        return new StatusCodeAntwortPair(Response.Status.NOT_MODIFIED.getStatusCode(), null);
    }

    private BestandsfehlerDto toBestandsfehler(final StammdatenBestandsFehlerException exception) {
        final FehlerEintragDto fehlerEintragDto = exception.getFehlerEintragDto();
        final UnerwartererFehlerDto unerwartererFehlerDto = new UnerwartererFehlerDto();
        unerwartererFehlerDto.fehlercode(fehlerEintragDto.getStatuscode());

        final BestandsfehlerDto bestandsfehlerDto = new BestandsfehlerDto();
        bestandsfehlerDto.setUnerwartererFehler(unerwartererFehlerDto);
        bestandsfehlerDto.setName(exception.getVersichertenInfo().nachname());
        bestandsfehlerDto.setVorname(exception.getVersichertenInfo().vorname());
        bestandsfehlerDto.setVsnr(exception.getVersichertenInfo().vsnr());
        return bestandsfehlerDto;
    }

    /**
     * Aktualisierung der Antragsdaten mit den Personendaten aus rvDialog.
     *
     * @param uuid die UUID zur identifizierung des Antrags.
     * @return ein Antrags DTO.
     */
    public AntragDto aktualisierungAntragsdaten(final UUID uuid) {

        final Antrag antrag = producerTemplate.withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid)
            .to(RouteNames.DIRECT_AKTUALISIEREANTRAGSDATEN)
            .send().getMessage()
            .getBody(Antrag.class);

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_USER,
            Ereignistext.ANTRAGSDATEN_GESPEICHERT, EreignisFreitext.ANTRAGSDATEN_UBERSCHRIEBEN,
            null, antrag, null, jwt, drvMandant));

        return antragMapper.toDto(antrag);
    }

    /**
     * Mappt den RegelNamen zu der Priorität der Regel.
     *
     * @param regel der RegelName
     * @return die Regelpriorität
     */
    private Long getRegelPrioritaet(final RegelName regel) {
        return Optional.ofNullable(regelRepository.findByRegelName(regel))
            .flatMap(regeln -> regeln.stream().findFirst()).map(Regel::getPrioritaet).orElse(1L);
    }

    /**
     * Verkettet die Prüfergebnisse.
     *
     * @param pruefergebnisParent Das Parentergebnis
     * @param regelErgebnis       Das Gesamtergebnis
     * @param antrag              der Antrag
     */
    private void verkettePruefergebnisse(final AntragPruefergebnis pruefergebnisParent,
        final RegelErgebnis regelErgebnis, final Antrag antrag) {
        for (final RegelErgebnis ergebnis : regelErgebnis.getDetailErgebnisse()) {
            final AntragPruefergebnis pruefergebnis = new AntragPruefergebnis();
            pruefergebnis.setBegruendung(ergebnis.getDetail());
            pruefergebnis.setErgebnis(ergebnis.getPruefErgebnis());
            pruefergebnis.setRegelName(ergebnis.getRegelName());
            pruefergebnis.setParentUuid(pruefergebnisParent.getUuid());
            pruefergebnis.setRegelId(ergebnis.getRegelName().getId());
            pruefergebnis.setPrioritaet(getRegelPrioritaet(ergebnis.getRegelName()));
            pruefergebnis.setKtan(antrag.getKtan());
            antrag.addAntragPruefergebnis(pruefergebnis);
        }
    }

    /**
     * Erstellt Aufgaben, basierend auf dem Pruefergebnis.
     *
     * @param antrag        Der Antrag, der geprueft wurde
     * @param regelErgebnis Das Gesamtergebnis
     */
    public void erstelleAufgabenZumPruefergebnis(final Antrag antrag,
        final RegelErgebnis regelErgebnis) {
        final boolean personendatenabgleichFailed = PruefergebnisUtils.personendatenabgleichFailed(regelErgebnis);
        final boolean anspruchsvorausetzungFailed = PruefergebnisUtils.anspruchsvorausetzungFailed(regelErgebnis);
        final boolean einrichtungspruefungFailed = PruefergebnisUtils.einrichtungspruefungFailed(regelErgebnis);
        final boolean hatBemerkung = regelErgebnis.getDetailErgebnisse().stream()
            .anyMatch(regelErgebnis1 -> RegelName.REGEL_BEMERKUNG.equals(regelErgebnis1.getRegelName())
                && !PruefErgebnis.ERFUELLT.equals(regelErgebnis1.getPruefErgebnis()));
        final boolean hatDigitalenAnhang = regelErgebnis.getDetailErgebnisse().stream()
            .anyMatch(regelErgebnis1 -> RegelName.REGEL_DIGITALER_ANHANG.equals(regelErgebnis1.getRegelName())
                && !PruefErgebnis.ERFUELLT.equals(regelErgebnis1.getPruefErgebnis()));

        final boolean darfPersonenDatenAufgabeSchliessen =
            anspruchsvorausetzungFailed || einrichtungspruefungFailed || hatBemerkung || hatDigitalenAnhang;
        LOG.atDebug().addArgument(personendatenabgleichFailed)
            .addArgument(anspruchsvorausetzungFailed)
            .addArgument(einrichtungspruefungFailed)
            .addArgument(hatBemerkung)
            .addArgument(hatDigitalenAnhang)
            .log("personendatenabgleichFailed: [{}], anspruchsvorausetzungFailed: [{}],"
                + " einrichtungspruefungFailed: [{}], hatBemerkung: [{}],  hatDigitalenAnhang: [{}]");
        LOG.atDebug().addArgument(regelErgebnis.getDetailErgebnisse().size())
            .log("Anzahl an Regeln: [{}]");
        if (bearbeiteAufgabePersondendatenabgeleich(antrag, personendatenabgleichFailed, darfPersonenDatenAufgabeSchliessen)) {
            return;
        }
        if (bearbeiteAufgabeEinrichtungUndAnspruch(antrag, anspruchsvorausetzungFailed,
            einrichtungspruefungFailed)) {
            return;
        }
        if (bearbeiteAufgabeAnspruchsvorausetzung(antrag, anspruchsvorausetzungFailed)) {
            return;
        }

        if (bearbeiteAufgabeEinrichtungspruefung(antrag, einrichtungspruefungFailed)) {
            return;
        }

        // Bemerkungsaufgabe erzeugen wenn Personendatenprüfung, Anspruchsprüfung und Einrichtungsprüfung ist erfüllt
        // und eine Bemerkung im Antrag angegeben ist
        if (bearbeiteAufgabeBemerkungOderDigitalerAnhang(antrag, hatBemerkung || hatDigitalenAnhang)) {
            return;
        }

        if (automatischVerarbeiten(antrag)) {
            antrag.setStatus(AntragStatus.AUTOMATISCH);
        }
    }

    private static boolean automatischVerarbeiten(final Antrag antrag) {
        return antrag.getAufgaben().stream()
            .filter(aufgabe -> aufgabe.getAufgabenArt() != AufgabenArt.ANTRAGSERFASSUNG)
            .filter(aufgabe -> aufgabe.getAufgabenArt() != AufgabenArt.BESTANDSFEHLER)
            .filter(aufgabe -> aufgabe.getAufgabenArt() != AufgabenArt.DOPPELVERGABE)
            .toList().isEmpty();
    }

    /**
     * Eine Aufgabe wird angelegt oder auf erledigt gesetzt.
     *
     * @param antrag                             betroffener Antra
     * @param personendatenabgleichFailed        true Personendatenabgleich war fehlerhaft
     * @param darfPersonendatenAufgabeSchliessen true wenn die Aufgabe geschlossen werden darf
     * @return true - Aufgabe wurde bearbeitet
     */
    public boolean bearbeiteAufgabePersondendatenabgeleich(final Antrag antrag,
        final boolean personendatenabgleichFailed, final boolean darfPersonendatenAufgabeSchliessen) {
        final Optional<Aufgabe> aufgabe = getAufgabe(antrag, AufgabenArt.PERSONENDATENABGLEICH);
        if (aufgabe.isPresent() && !personendatenabgleichFailed && darfPersonendatenAufgabeSchliessen) {
            aufgabeService.purAufgabeSchliessen(antrag);
        } else if (aufgabe.isEmpty() && personendatenabgleichFailed) {
            // Neue Aufgabe anlegen
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.PERSONENDATENABGLEICH);
            antragStatusService.setAntragStatus(antrag,
                AntragStatus.PERSONENDATEN_AUFGABE_ERSTELLT);
            return true;
        } else {
            return aufgabe.isPresent() && personendatenabgleichFailed;
        }
        return false;
    }

    /**
     * Eine Aufgabe fuer Einrichtung- und Anspruchspruefung wird angelegt oder auf erledigt gesetzt.
     *
     * @param antrag                      betroffener Antra
     * @param anspruchsvorausetzungFailed true Anspruchsvoraussetzung war fehlerhaft
     * @param einrichtungspruefungFailed  true Einrichtungspruefung war fehlerhaft
     * @return true - Aufgabe wurde bearbeitet
     */
    public boolean bearbeiteAufgabeEinrichtungUndAnspruch(final Antrag antrag,
        final boolean anspruchsvorausetzungFailed, final boolean einrichtungspruefungFailed) {
        final Optional<Aufgabe> aufgabe = getAufgabe(antrag, AufgabenArt.EINRICHTUNGENUNDANSPRUCH);
        if (aufgabe.isPresent() && !(anspruchsvorausetzungFailed && einrichtungspruefungFailed)) {
            aufgabeService.purAufgabeSchliessen(antrag);
        } else if (aufgabe.isEmpty()
            && (anspruchsvorausetzungFailed && einrichtungspruefungFailed)) {
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.EINRICHTUNGENUNDANSPRUCH);
            antragStatusService.setAntragStatus(antrag,
                AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
            return true;
        }
        return false;
    }

    /**
     * Eine Aufgabe wird angelegt oder auf erledigt gesetzt.
     *
     * @param antrag                      betroffener Antra
     * @param anspruchsvorausetzungFailed true Anspruchsvoraussetzung war fehlerhaft
     * @return true - Aufgabe wurde bearbeitet
     */
    public boolean bearbeiteAufgabeAnspruchsvorausetzung(final Antrag antrag,
        final boolean anspruchsvorausetzungFailed) {
        final Optional<Aufgabe> aufgabe = getAufgabe(antrag, AufgabenArt.ANSPRUCHSVORAUSSETZUNG);
        if (aufgabe.isPresent() && !anspruchsvorausetzungFailed) {
            aufgabeService.purAufgabeSchliessen(antrag);
        } else if (aufgabe.isEmpty() && anspruchsvorausetzungFailed) {
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.ANSPRUCHSVORAUSSETZUNG);
            antragStatusService.setAntragStatus(antrag,
                AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
            if (antrag.getStatus() != AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT) {
                antragStatusService.setAntragStatus(antrag,
                    AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
            }
            return true;
        }
        return false;
    }

    /**
     * Eine Aufgabe wird angelegt oder auf erledigt gesetzt.
     *
     * @param antrag                     betroffener Antrag.
     * @param einrichtungspruefungFailed true - Einrichtungspruefung war fehlerhaft
     * @return true wenn die Aufgabe angelegt wurde.
     */
    public boolean bearbeiteAufgabeEinrichtungspruefung(final Antrag antrag,
        final boolean einrichtungspruefungFailed) {

        final Optional<Aufgabe> aufgabe = getAufgabe(antrag, AufgabenArt.EINRICHTUNGSWAHL);
        if (aufgabe.isPresent() && !einrichtungspruefungFailed) {
            aufgabeService.purAufgabeSchliessen(antrag);
        } else if (aufgabe.isEmpty() && einrichtungspruefungFailed) {
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.EINRICHTUNGSWAHL);
            antragStatusService.setAntragStatus(antrag,
                AntragStatus.ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT);
            return true;
        }
        return false;
    }

    /**
     * Eine Aufgabe fuer Bemerkungsfeldprüfung oder digitalen Anhang wird angelegt oder auf erledigt gesetzt.
     *
     * @param antrag                          betroffener Antrag
     * @param hatBemerkungOderDigitalenAnhang true wenn Bemerkung oder digitaler Anhang vorhanden
     * @return <code>false</code>, falls die Aufgabe wurde bearbeitet und geschlossen wurde, ansonsten <code>true</code>
     */
    public boolean bearbeiteAufgabeBemerkungOderDigitalerAnhang(final Antrag antrag, final boolean hatBemerkungOderDigitalenAnhang) {

        final Optional<Aufgabe> aufgabe = getAufgabe(antrag, AufgabenArt.BEMERKUNG_ODER_ANHANG_VORHANDEN);

        if (aufgabe.isPresent()) {
            aufgabeService.purAufgabeSchliessen(antrag);
            return false;
        }

        if (hatBemerkungOderDigitalenAnhang) {
            aufgabeService.erstellePurAufgabe(antrag, AufgabenArt.BEMERKUNG_ODER_ANHANG_VORHANDEN);
            antragStatusService.setAntragStatus(antrag, AntragStatus.BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT);
            return true;
        }

        return false;
    }

    /**
     * Sucht nach einer bestehenden Aufgabe.
     *
     * @param antrag      Antrag mit den zu durchsuchenden Aufgaben
     * @param aufgabenArt Welche Aufgabenart soll gesucht werden
     * @return gefundene Aufgabe
     */
    private Optional<Aufgabe> getAufgabe(final Antrag antrag, final AufgabenArt aufgabenArt) {
        final List<Aufgabe> aufgaben = antrag.getAufgaben();
        if (aufgaben != null) {
            return aufgaben.stream().filter(p -> p.getAufgabenArt().equals(aufgabenArt))
                .findFirst();
        }
        return Optional.empty();
    }

    /**
     * Erstellt die Fachprotokoll-Ereignisse für alle Regelprüfungen.
     *
     * @param antrag        Antrag, zu dem Fachprotokoll-Ereignisse erstellt werden
     * @param regelErgebnis Regelergebnis zu dem Antrag
     */
    private void erstelleFachprotokollEreignisseFuerPruefungen(final Antrag antrag, final RegelErgebnis regelErgebnis) {
        final boolean isPersonendatenAbgleichAussteuern = PruefergebnisUtils.personendatenabgleichFailed(regelErgebnis);
        final boolean isPersonendatenAbgleichAufgabe = Optional.ofNullable(AufgabenUtils.getOffeneAufgabeFromAntrag(antrag))
            .map(Aufgabe::getAufgabenArt)
            .filter(AufgabenArt.PERSONENDATENABGLEICH::equals)
            .isPresent();

        EreignisFreitext ereignisFreitextPersonendaten = EreignisFreitext.PERSONENDATEN_PRUEFUNG_ERFUELLT_MASCHINELL;
        if (isPersonendatenAbgleichAufgabe && !isPersonendatenAbgleichAussteuern) {
            ereignisFreitextPersonendaten = EreignisFreitext.PERSONENDATEN_PRUEFUNG_ERFUELLT_USER;
        } else if (isPersonendatenAbgleichAussteuern) {
            ereignisFreitextPersonendaten = EreignisFreitext.PERSONENDATEN_PRUEFUNG_AUSSTEUERN_MASCHINELL;
        }
        rvfitLogger.sendeFachprotokollEreignis(
            LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                Ereignistext.PERSONENDATEN_PRUEFUNG_DURCHGEFUEHRT, ereignisFreitextPersonendaten,
                null, antrag, null, jwt, drvMandant));

        // Erstelle nur Fachprotokoll-Ereignisse für die anderen Prüfungen
        // 1) Beim initialen Durchlauf der Prüfungen
        // 2) Wenn der manuelle Personendatenabgleich erfolgreich war
        if (!isPersonendatenAbgleichAufgabe || !isPersonendatenAbgleichAussteuern) {
            erstelleFachprotokollEreignisseFuerAEBPruefung(antrag, regelErgebnis);
        }
    }

    /**
     * Erstellt die Fachprotokoll-Ereignisse für die Anspruchs-, Einrichtungs- und Bemerkungsfeldprüfung.
     *
     * @param antrag        Antrag, zu dem Fachprotokoll-Ereignisse erstellt werden
     * @param regelErgebnis Regelergebnis zu dem Antrag
     */
    private void erstelleFachprotokollEreignisseFuerAEBPruefung(final Antrag antrag, final RegelErgebnis regelErgebnis) {
        final boolean isAnspruchAussteuern = PruefergebnisUtils.anspruchsvorausetzungFailed(regelErgebnis);
        final boolean isEinrichtungAussteuern = PruefergebnisUtils.einrichtungspruefungFailed(regelErgebnis);
        final boolean isAnspruchAblehnen = PruefergebnisUtils.anspruchsvorausetzungAblehnen(regelErgebnis);
        final boolean isBemerkungAussteuern = Optional.ofNullable(PruefergebnisUtils
                .getCurrentAntragPruefergebnisByRegelName(antrag, RegelName.REGEL_BEMERKUNG))
            .map(AntragPruefergebnis::getErgebnis)
            .filter(PruefErgebnis.AUSSTEUERN::equals)
            .isPresent();

        EreignisFreitext ereignisFreitextAnspruch = EreignisFreitext.ANSPRUCHS_PRUEFUNG_ERFUELLT_MASCHINELL;
        if (isAnspruchAussteuern) {
            ereignisFreitextAnspruch = EreignisFreitext.ANSPRUCHS_PRUEFUNG_AUSSTEUERN_MASCHINELL;
        } else if (isAnspruchAblehnen) {
            ereignisFreitextAnspruch = EreignisFreitext.ANSPRUCHS_PRUEFUNG_ABLEHNEN_MASCHINELL;
        }
        rvfitLogger.sendeFachprotokollEreignis(
            LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                Ereignistext.ANSPRUCHS_PRUEFUNG_DURCHGEFUEHRT, ereignisFreitextAnspruch,
                null, antrag, null, jwt, drvMandant));

        EreignisFreitext ereignisFreitextEinrichtung = EreignisFreitext.EINRICHTUNGS_PRUEFUNG_ERFUELLT_MASCHINELL;
        if (isEinrichtungAussteuern) {
            ereignisFreitextEinrichtung = EreignisFreitext.EINRICHTUNGS_PRUEFUNG_AUSSTEUERN_MASCHINELL;
        }
        rvfitLogger.sendeFachprotokollEreignis(
            LogUtils.getFachereignis(EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
                Ereignistext.EINRICHTUNGS_PRUEFUNG_DURCHGEFUEHRT, ereignisFreitextEinrichtung,
                null, antrag, null, jwt, drvMandant));

        EreignisFreitext ereignisFreitextBemerkung = EreignisFreitext.BEMERKUNG_PRUEFUNG_ERFUELLT_MASCHINELL;
        if (isBemerkungAussteuern) {
            ereignisFreitextBemerkung = EreignisFreitext.BEMERKUNG_PRUEFUNG_AUSSTEUERN_MASCHINELL;
        }
        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(
            EreignisTyp.ZWISCHENEREIGNIS_MASCHINELL,
            Ereignistext.BEMERKUNG_PRUEFUNG_DURCHGEFUEHRT,
            ereignisFreitextBemerkung,
            null, antrag, null, jwt, drvMandant));
    }

    /**
     * Record mit dem Status zu einem Objekt.
     *
     * @param statusCode Status
     * @param object     bearbeitetes Object
     */
    public record StatusCodeAntwortPair(int statusCode, Object object) {
    }

}
