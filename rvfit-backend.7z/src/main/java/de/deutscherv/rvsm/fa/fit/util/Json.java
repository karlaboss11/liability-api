package de.deutscherv.rvsm.fa.fit.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import java.util.Set;
import lombok.experimental.UtilityClass;

/**
 * Diese Hilfsklasse dient für allgemeine Aufgaben rund um json.
 */
@UtilityClass
public class Json {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    static {
        OBJECT_MAPPER.registerModule(new JavaTimeModule());
    }

    /**
     * Gibt den Wert des Objekts als JSON-String zurueck.
     *
     * @param object das Objekt, das als JSON ausgegeben werden soll
     * @return den JSON-Wert des Objekts oder null, falls eine JsonProcessingException geworfen wird
     */
    public static String objectToJson(final Object object) {
        try {
            return OBJECT_MAPPER.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RvfitException("Fehler beim Parsen eines Objekts", e) {
            };
        }
    }

    /**
     * Anonymisiert gezielt bestimmte Felder im JSON (inkl. seiner Kind-Nodes).
     *
     * @param json              Eingangs-JSON als String
     * @param fieldsToAnonymize Set von Feldnamen, die anonymisiert werden sollen
     * @return anonymisiertes JSON als String
     */
    public static String anonymizeJsonFields(final String json, final Set<String> fieldsToAnonymize) {
        try {
            final JsonNode root = OBJECT_MAPPER.readTree(json);
            final JsonNode anonymized = anonymizeRecursive(root, fieldsToAnonymize);

            return OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(anonymized);
        } catch (Exception e) {
            throw new RvfitException("Fehler beim Anonymisieren der JSON", e) {
            };
        }
    }

    private static JsonNode anonymizeRecursive(final JsonNode node, final Set<String> fieldsToAnonymize) {
        if (node == null || node.isNull()) {
            return node;
        }

        if (node.isObject()) {
            final ObjectNode out = OBJECT_MAPPER.createObjectNode();
            node.fieldNames().forEachRemaining(field -> {
                final JsonNode child = node.get(field);
                if (fieldsToAnonymize.contains(field)) {
                    out.set(field, anonymizeWholeSubtree(child));
                } else {
                    out.set(field, anonymizeRecursive(child, fieldsToAnonymize));
                }
            });
            return out;
        }

        if (node.isArray()) {
            final ArrayNode out = OBJECT_MAPPER.createArrayNode();
            node.forEach(field -> out.add(anonymizeRecursive(field, fieldsToAnonymize)));
            return out;
        }

        return node;
    }

    private static JsonNode anonymizeWholeSubtree(final JsonNode node) {
        if (node == null || node.isNull()) {
            return NullNode.getInstance();
        }

        if (node.isObject()) {
            final ObjectNode out = OBJECT_MAPPER.createObjectNode();
            node.fieldNames().forEachRemaining(field -> out.set(field, anonymizeWholeSubtree(node.get(field))));
            return out;
        }

        if (node.isArray()) {
            final ArrayNode out = OBJECT_MAPPER.createArrayNode();
            node.forEach(field -> out.add(anonymizeWholeSubtree(field)));
            return out;
        }

        if (node.isTextual() && node.asText().isEmpty()) {
            return node;
        }

        return TextNode.valueOf("*****");
    }
}
