package de.deutscherv.rvsm.fa.fit.regelpruefung;

import java.util.List;
import java.util.Optional;

/** Allgemeines Interface zur Implementierung der Regel. */
public interface Regel {

    /**
     * Gibt den Namen der Regel zurück.
     *
     * @return der Name der Regel
     */
    RegelName getRegelName();

    /**
     * Gibt den Detail der Regel zurück.
     *
     * @param regelErgebnis Name der Regel
     * @return das Ergebnis der Prüfung Detail der Regel
     */
    Optional<String> getRegelDetail(String regelErgebnis);

    /**
     * pruefe eine Regel basierend auf dem Daten dieses Kontext Objektes.
     *
     * @param kontext der Kontext für die Prüfung
     * @return das Ergebnis der Prüfung
     */
    List<RegelErgebnis> pruefeRegel(RegelKontext kontext);

}
