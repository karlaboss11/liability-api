package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;
import java.io.Serializable;
import lombok.Getter;

/**
 * RvfitException.
 */
public abstract class RvfitException extends RuntimeException implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @Getter
    private final String resource;
    @Getter
    private final String userIdent;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     */
    protected RvfitException(final String message) {
        super(message);
        resource = null;
        userIdent = null;
    }

    /**
     * Konstruktor.
     *
     * @param cause Fehlergrund.
     */
    protected RvfitException(final Throwable cause) {
        super(cause);
        resource = null;
        userIdent = null;
    }

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Fehlergrund
     */
    protected RvfitException(final String message, final Throwable cause) {
        super(message, cause);
        resource = null;
        userIdent = null;
    }

    /**
     * Konstruktor.
     *
     * @param resource  Quelle
     * @param userIdent ID des Users
     * @param message   Fehlernachricht
     */
    protected RvfitException(final String resource, final String userIdent, final String message) {
        super(message);
        this.resource = resource;
        this.userIdent = userIdent;
    }

    /**
     * Konstruktor.
     *
     * @param resource  Quelle
     * @param userIdent ID des Susers
     * @param message   Fehlernachricht
     * @param cause     Fehlergrund
     */
    protected RvfitException(final String resource, final String userIdent, final String message, final Throwable cause) {
        super(message, cause);
        this.resource = resource;
        this.userIdent = userIdent;
    }
}
