package de.deutscherv.rvsm.fa.fit.rvpur;

import de.deutscherv.anzeigetool.facade.PuRDokument;
import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.exceptions.RvPurClientException;
import de.deutscherv.rvsm.fa.fit.exceptions.annotation.ExceptionPersist;
import de.deutscherv.rvsm.fa.fit.rvpur.mapper.RvPurMapper;
import de.deutscherv.rvsm.fa.fit.rvpur.model.RvPurRequest;
import de.deutscherv.rvsm.fa.fit.rvpur.model.RvPurResponse;
import de.deutscherv.rvsm.fa.fit.rvpur.util.PDFUtil;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.DokumentDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangRequestDto;
import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.VorgangResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 * Service rvPuR.
 */
@Slf4j
@ApplicationScoped
public class RvPurService {

    private static final String G0180 = "G0180";
    private final RvPurClient rvPurClient;
    private final JsonWebToken jwt;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final RvPurMapper rvPurMapper;
    private final DrvMandant drvMandant;
    private final RvfitLogger rvfitLogger;

    /**
     * Konstruktor.
     *
     * @param rvPurClient              rvPuR-Client
     * @param jwt                      JSON-Web-Token
     * @param rVFitJsonSchemaValidator rvFit-JSON-Schema-Validotor
     * @param rvPurMapper              rvPuR-Mapper
     * @param drvMandant               DRV-Mandant
     * @param rvfitLogger              rvFit-Logger
     */
    @Inject
    public RvPurService(@RestClient final RvPurClient rvPurClient, final JsonWebToken jwt,
            final RVFitJsonSchemaValidator rVFitJsonSchemaValidator,
            final RvPurMapper rvPurMapper, final DrvMandant drvMandant,
            final RvfitLogger rvfitLogger) {
        this.rvPurClient = rvPurClient;
        this.jwt = jwt;
        this.rVFitJsonSchemaValidator = rVFitJsonSchemaValidator;
        this.rvPurMapper = rvPurMapper;
        this.drvMandant = drvMandant;
        this.rvfitLogger = rvfitLogger;
    }

    /**
     * Ruft das Bestandgateway auf und gibt eine RvPurResponseEntity zurück.
     *
     * @param rvPurRequest Anfrage an rvPuR
     * @return RvPurResponse
     */
    public RvPurResponse getRvPurResponseEntity(final RvPurRequest rvPurRequest) {
        final VorgangRequestDto map = rvPurMapper.toVorgangRequestDto(rvPurRequest);
        final VorgangResponseDto vorgangResponseDto = rufeRvPurSendungServiceAb(map);
        return getRvPurResponse(vorgangResponseDto);
    }

    /**
     * Anfrage an den rvPur-Sendungs-Service-AB.
     *
     * @param vorgangRequestDto Vorgangsrequest-DTO
     * @return VorgangRespons-DTO
     */
    public VorgangResponseDto rufeRvPurSendungServiceAb(final VorgangRequestDto vorgangRequestDto) {
        final String ktan = JwtUtils.GET_KTAN.apply(jwt, drvMandant);
        final VorgangResponseDto vorgangResponseDto = rvPurClient.uebernehmeSendung2127(ktan, vorgangRequestDto);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RVPUR, vorgangResponseDto)) {
            throw new IllegalArgumentException(
                    "Keine valide RvPur Vorgang Response angegeben: " + vorgangResponseDto);
        }
        return vorgangResponseDto;
    }

    /**
     * Pruefe rvPuR-Vorgangserzeugung.
     *
     * @param ktan              KTAN
     * @param vorgangsKennungen List der Vorgangskennungen.
     * @return Liste der gefundenen Vorgaenge
     */
    public List<String> pruefeRvPurVorgangsErzeugung(final String ktan, final List<String> vorgangsKennungen) {
        try (final Response response = rvPurClient.sucheVorgaenge(ktan, vorgangsKennungen)) {
            return List.of(response.readEntity(String[].class));
        }
    }

    private RvPurResponse getRvPurResponse(VorgangResponseDto r) {
        LOG.atDebug().addArgument(r).log("mapRvPurResponse [{}]");
        if (r.getFehlerFeld().isBlank()) {
            return rvPurMapper.toRvPurResponse(r);
        } else {
            LOG.atWarn().addArgument(r).addArgument(r.getFehlerFeld())
                    .log("mapRvPurResponse [{}], FehlerFeld [{}]");
            throw new RvPurClientException("Mapping fehlgeschlagen: " + r.getFehlerFeld(), null);
        }
    }

    /**
     * Ruft den rvPur-Service an, um für einen Antrag einen Vorgang zu senden.
     *
     * @param antrag der Antrag, für den ein Vorgang gesendet werden soll
     */
    @ExceptionPersist(message = "Fehler beim Erzeugen der rvPuR-Vorgang")
    public void sendeRvPurVorgang(final Antrag antrag) {
        final VorgangRequestDto vorgangRequestDto = new VorgangRequestDto();
        final StammdatenDto stammdatenDto = new StammdatenDto();
        stammdatenDto.setHerkunft("32");
        stammdatenDto.setVsnr(antrag.getVsnr());
        stammdatenDto.setVerweisIOID(antrag.getUuid().toString().replace("-", ""));
        stammdatenDto.setVorgangskennung(antrag.getVorgangskennung());
        stammdatenDto.setNtsc("000");
        stammdatenDto.setSessionId(antrag.getUuid().toString().replace("-", ""));
        vorgangRequestDto.setStammdaten(stammdatenDto);

        for (PuRDokument puRDokument : PDFUtil.createPuRDokumente(antrag)) {
            boolean istHauptdokument = istHauptdokument(puRDokument);
            final DokumentDto dokumentDto = new DokumentDto();
            dokumentDto.setDatensatz(antrag.getXml().getBytes(StandardCharsets.UTF_8));
            dokumentDto.setHauptdokument(istHauptdokument);
            dokumentDto.setFormularnummer(puRDokument.getVordruck());
            final String dokumentIoid = istHauptdokument ?
                    antrag.getUuid().toString().replace("-", "") :
                    UUID.randomUUID().toString().replace("-", "");
            dokumentDto.setDokumentIoid(dokumentIoid);
            dokumentDto.setAnhang(null);
            dokumentDto.setPdf(puRDokument.getBytes());
            dokumentDto.setAqat(puRDokument.getAqat());
            vorgangRequestDto.addDokumenteItem(dokumentDto);
        }

        rufeRvPurSendungServiceAb(vorgangRequestDto);

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                Ereignistext.VORGANG_ERZEUGT,
                EreignisFreitext.VORGANG_ERZEUGT, null,
                antrag, null, jwt, drvMandant));

    }

    private boolean istHauptdokument(final PuRDokument puRDokument) {
        final String formularNummer = puRDokument.getVordruck();
        if (formularNummer == null) {
            return false;
        }
        return formularNummer.startsWith(G0180);
    }

}
