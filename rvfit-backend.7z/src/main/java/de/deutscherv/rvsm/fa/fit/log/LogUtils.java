package de.deutscherv.rvsm.fa.fit.log;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.utils.AufgabenUtils;
import de.deutscherv.rvsm.fa.fit.log.model.Fachereignis;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.qs.fap.async.model.AufgabeDTO;
import de.deutscherv.rvsm.qs.fap.async.model.AusloesendePersonDTO;
import de.deutscherv.rvsm.qs.fap.async.model.AusloeserDTO;
import de.deutscherv.rvsm.qs.fap.async.model.VorgangDTO;
import jakarta.annotation.Nonnull;
import java.util.List;
import java.util.Objects;
import lombok.experimental.UtilityClass;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * LogUtils.
 */
@UtilityClass
public class LogUtils {
    private static final List<EreignisTyp> NICHT_MASCHINELLE_EREIGNISSE = List.of(
        EreignisTyp.NACHRICHTEN_EINGANG_USER,
        EreignisTyp.NACHRICHTEN_AUSGANG_USER,
        EreignisTyp.ZWISCHENEREIGNIS_USER,
        EreignisTyp.ENDEREIGNIS_USER
    );

    private static final String AUSLOESER_ITP_NAME =
        ConfigProvider.getConfig().getConfigValue("fap.ausloeser.itpname").getValue();
    private static final String RV_FIT = "fit";

    /**
     * Erstellen eines Fachereignisses.
     *
     * @param ereignisTyp           Ereignistyp nach BPMN-Konvention
     * @param ereignistext          Ereignistext nach BPMN-Konvention
     * @param ereignisFreitext      Ereignistext mit spezifischeren Informationen
     * @param ereignisFreitextGrund Optionaler variabler Teil von ereignisFreitext
     * @param antrag                Antrag, dessen Bearbeitung zu dem Fachereignis führt
     * @param aufgabe               Aufgabe, under der der Antrag bearbeitet wird
     * @param jwt                   Jwt-Token
     * @param drvMandant            Betroffener DRV-Mandant
     * @return Fachereignis
     */
    public static Fachereignis getFachereignis(@Nonnull final EreignisTyp ereignisTyp,
        @Nonnull final Ereignistext ereignistext, @Nonnull final EreignisFreitext ereignisFreitext,
        final String ereignisFreitextGrund,
        @Nonnull final Antrag antrag, Aufgabe aufgabe,
        @Nonnull final JsonWebToken jwt, final DrvMandant drvMandant) {

        if (aufgabe == null) {
            aufgabe = AufgabenUtils.getOffeneAufgabeFromAntrag(antrag);
        }

        return new Fachereignis(antrag.getVsnr(), "VSNR", ereignistext.getText(), ereignisTyp,
            ereignisFreitext.getText(ereignisFreitextGrund),
            getAufgabeDTO(ereignisTyp, aufgabe), getVorgangDTO(antrag),
            getAusloeserDTO(ereignisTyp, drvMandant, jwt), jwt, drvMandant);
    }

    /**
     * Liefere Fachereignis ohne Antrag.
     *
     * @param ereignisTyp      Ereignistyp nach BPMN-Konvention
     * @param ereignisText     Ereignistext nach BPMN-Konvention
     * @param ereignisFreitext Ereignistext mit spezifischeren Informationen
     * @param vsnr             Versicherungsnummer
     * @param jwt              Jwt-Token
     * @param drvMandant       Betroffener DRV-Mandant
     * @return Fachereignis
     */
    public static Fachereignis getFachereignisOhneAntrag(
        @Nonnull final EreignisTyp ereignisTyp,
        @Nonnull final Ereignistext ereignisText,
        @Nonnull final EreignisFreitext ereignisFreitext,
        @Nonnull final String vsnr,
        @Nonnull final JsonWebToken jwt,
        @Nonnull final DrvMandant drvMandant) {

        return new Fachereignis(
            vsnr,
            "VSNR",
            ereignisText.getText(),
            ereignisTyp,
            ereignisFreitext.getText((Object) null),
            null,
            getVorgangDTOohneAntrag(),
            getAusloeserDTO(ereignisTyp, drvMandant, jwt),
            jwt,
            drvMandant
        );
    }

    private static AufgabeDTO getAufgabeDTO(final EreignisTyp ereignisTyp,
        final Aufgabe aufgabe) {
        if (isMaschinell(ereignisTyp) || Objects.isNull(aufgabe)) {
            return null;
        }
        return new AufgabeDTO().id(aufgabe.getTransaktionId().toString())
            .aufgabenArt(aufgabe.getAufgabenArt().toString());
    }

    private static VorgangDTO getVorgangDTO(final Antrag antrag) {
        return new VorgangDTO().id(antrag.getUuid().toString()).vorgangsArt(RV_FIT);
    }

    private static VorgangDTO getVorgangDTOohneAntrag() {
        return new VorgangDTO().id("KEINE_ANTRAGSID_VORHANDEN").vorgangsArt(RV_FIT);
    }

    private static AusloeserDTO getAusloeserDTO(final EreignisTyp ereignisTyp, final DrvMandant drvMandant, final JsonWebToken jwt) {
        if (isMaschinell(ereignisTyp) || isTechUser(jwt)) {
            return new AusloeserDTO().itpName(AUSLOESER_ITP_NAME);
        }
        return new AusloeserDTO().itpName(AUSLOESER_ITP_NAME).ausloesendePerson(new AusloesendePersonDTO()
            .organisationseinheit(JwtUtils.GET_KTAN.apply(jwt, drvMandant)).drvId(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt)));
    }

    private static boolean isMaschinell(final EreignisTyp ereignisTyp) {
        return !NICHT_MASCHINELLE_EREIGNISSE.contains(ereignisTyp);
    }

    private static boolean isTechUser(final JsonWebToken jwt) {
        final String drvId = JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt);
        return !drvId.matches("^DRV\\d{2}[0-9A-Za-z]{10}$");
    }
}
