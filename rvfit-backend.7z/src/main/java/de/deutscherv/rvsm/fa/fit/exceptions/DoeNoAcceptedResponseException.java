package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * DoeNoAcceptedResponseException.
 */
public class DoeNoAcceptedResponseException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     * @param message Fehlernachricht.
     */
    public DoeNoAcceptedResponseException(String message) {
        super(message);
    }
}
