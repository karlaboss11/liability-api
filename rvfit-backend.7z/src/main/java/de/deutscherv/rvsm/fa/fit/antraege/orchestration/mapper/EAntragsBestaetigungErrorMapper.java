package de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.EantragsBestaetigungMapper;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import jakarta.enterprise.context.Dependent;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Mappen des Fehlers bei der Bestaetigung eine eAntrags.
 */
@Dependent
@RequiredArgsConstructor
public class EAntragsBestaetigungErrorMapper implements Processor {

    private final EantragsBestaetigungMapper mapper;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final var antragsdaten = exchange.getMessage().getHeader(RVFitCamelHeader.ANTRAGSDATEN, Antragsdaten.class);
        final var bestaetigungDTO = mapper.antragsdatenToEantragsBestaetigung(antragsdaten);

        bestaetigungDTO.geteAntragDaten().setFehlerNummer("tbd");
        bestaetigungDTO.geteAntragDaten().setFehlerText("tbd");

        exchange.getMessage().setBody(bestaetigungDTO);
    }

}
