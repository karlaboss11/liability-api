package de.deutscherv.rvsm.fa.fit.kontoinformation;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO das den Statuscode und die Nachricht enthaelt.
 */
@NoArgsConstructor
@Data
public class FehlerEintragDto {
    
    private String statuscode;
    private String message;

}
