package de.deutscherv.rvsm.fa.fit.statistik;

import de.deutscherv.rvsm.fa.fit.security.JwtOidcFilter;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.api.StatistikApi;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.AntragserfassungDto;
import de.deutscherv.rvsm.fa.fit.statistik.openapi.model.BescheidDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * Client fuer das rvSystemBestand-Gateway.
 */
@ApplicationScoped
@RegisterRestClient(configKey = "statistik")
@RegisterProvider(JwtOidcFilter.class)
@Path("/statistik")
public interface StatistikClient extends StatistikApi {

    @Override
    @POST
    @Path("/antragserfassung")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    Response createStatistikAntragserfassung(
            @HeaderParam("drv-mandant") @Parameter(description = "KTAN des Traegers") @NotNull @Size(min = 2, max = 2) String drvMandant,
            @Valid @NotNull AntragserfassungDto antragserfassungDto);

    @Override
    @POST
    @Path("/bescheid")
    @Consumes({ "application/json" })
    Response createStatistikBescheid(
            @HeaderParam("drv-mandant") @Parameter(description = "KTAN des Traegers") @NotNull @Size(min = 2, max = 2) String drvMandant,
            @Valid @NotNull BescheidDto bescheidDto);
}
