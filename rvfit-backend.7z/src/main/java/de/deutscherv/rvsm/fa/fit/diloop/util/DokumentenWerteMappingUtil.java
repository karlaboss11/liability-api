package de.deutscherv.rvsm.fa.fit.diloop.util;

import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.UnvollstaendigeStammdatenException;
import de.deutscherv.rvsm.fa.fit.openapi.model.KontoDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PersonDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.util.LandIsoCodes;
import de.drv.rvevo.shared.api.doe.model.AdresseDTO;
import de.drv.rvevo.shared.api.doe.model.LandDTO;
import de.drv.rvevo.shared.api.doe.model.NatuerlichePersonDTO;
import jakarta.annotation.Nonnull;
import java.text.NumberFormat;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static de.deutscherv.rvsm.fa.fit.util.LandIsoCodes.OHNE_ANGABE;
import static de.deutscherv.rvsm.fa.fit.util.LandIsoCodes.STAATENLOS;
import static de.deutscherv.rvsm.fa.fit.util.LandIsoCodes.UNBEKANNTES_AUSLAND;
import static de.deutscherv.rvsm.fa.fit.util.LandIsoCodes.UNGEKLAERT;
import static java.util.function.Predicate.not;

/**
 * DokumentenWerteMappingUtil.
 */
public class DokumentenWerteMappingUtil {

    private static final String STRING_STRING_PLATZHALTER = "%s %s";
    private static final String NAECHSTE_ZEILE = "\n";
    /**
     * Menge von Länderkennzeigen, die keinen gueltigen ISO-Code haben und deswegen nicht in der DoE verarbeitet werden können. In diesen
     * Fällen wird <code>null</code> zurückgegeben.
     */
    private static final Set<LandIsoCodes> LAENDER_KENNZEICHEN_OHNE_GUELTIGEN_ISO_CODE =
        Set.of(UNBEKANNTES_AUSLAND, STAATENLOS, UNGEKLAERT, OHNE_ANGABE);

    /**
     * Sonarqube: Utility classes should not have a public or default constructor.
     */
    private DokumentenWerteMappingUtil() {
    }

    /**
     * Erstellt ein Objekt NatuerlichePerson aus den Antragsdaten.
     *
     * @param konto Die Kontoinformationen zum Antrag
     * @return Ein Array mit der NatuerlichenPerson
     */
    public static List<NatuerlichePersonDTO> mapZuNatuerlichePersonDto(final KontoDto konto) {
        final ValidesKonto validesKonto = validiereKonto(konto);
        final PersonDto versicherter = validesKonto.person();

        final NatuerlichePersonDTO natuerlichePerson = new NatuerlichePersonDTO();
        natuerlichePerson.setAdresse(getAdresse(validesKonto));
        natuerlichePerson.setAnrede(mapPersonZuAnrede(versicherter));
        natuerlichePerson.setNachname(versicherter.getName());
        natuerlichePerson.setVorname(versicherter.getVorname());
        natuerlichePerson.setTitel(versicherter.getTitel());
        natuerlichePerson.setNamenszusatz(versicherter.getNamenszusatz());
        natuerlichePerson.setVorsatzwort(versicherter.getVorsatzwort());
        natuerlichePerson.seteMail(versicherter.getMail());
        natuerlichePerson.setGeburtsdatum(versicherter.getGeburtsdatum());
        natuerlichePerson.setRollen(List.of("Versicherter"));

        return List.of(natuerlichePerson);
    }

    private static AdresseDTO getAdresse(final ValidesKonto konto) {
        final PersonDto versicherter = konto.person();
        final PersonAnschriftDto anschrift = konto.anschrift();

        final AdresseDTO adresse = new AdresseDTO();
        adresse.setAdressat(String.format(STRING_STRING_PLATZHALTER, versicherter.getVorname(),
            versicherter.getName()));
        adresse.setStrasseHausnummer(Optional.of(anschrift).map(PersonAnschriftDto::getStrasseHausnummer).orElse(""));
        adresse.setPlz(Optional.of(anschrift).map(PersonAnschriftDto::getPostleitzahl).orElse(""));
        adresse.setOrt(Optional.of(anschrift).map(PersonAnschriftDto::getWohnort).orElse(""));
        adresse.setLand(getLand(anschrift.getLaenderschluessel()));
        adresse.setAnschriftenzusatz(anschrift.getAnschriftenzusatz());
        adresse.setTelefon(versicherter.getTelefon());
        adresse.setEpostfach(mapArtDerZustellungZuEPostfach(versicherter));
        adresse.setEzustellung(mapArtDerZugaenglichkeitZuEZustellung(versicherter));
        return adresse;
    }

    private static ValidesKonto validiereKonto(final KontoDto konto) {
        final PersonDto versicherter = konto.getPersonen().stream().findFirst()
            .orElseThrow(() -> new UnvollstaendigeStammdatenException("Konto enthält keine Person."));
        final PersonAnschriftDto anschrift = Optional.of(versicherter).map(PersonDto::getAnschrift)
            .orElseThrow(() -> new UnvollstaendigeStammdatenException("Keine Anschrift für versicherte Person hinterlegt."));
        return new ValidesKonto(versicherter, anschrift);
    }

    /**
     * Record fuer validaten Konto.
     *
     * @param person    DTO der Person
     * @param anschrift DTO mit der Personenanschrift
     */
    private record ValidesKonto(PersonDto person, PersonAnschriftDto anschrift) {
    }

    /**
     * Erstellt ein LandDTO aus einem übergebenen Ländercode im NTSC-Format. Der Wert der Ausgabe wird im Format ISO-3166-1-Alpha-3
     * übergeben. Wirft eine Exception, falls <code>null</code> oder ein andere ungültiger NTSC-Wert übergeben wird. Für die Fälle 996-999
     * (UNBEKANNTES_AUSLAND, STAATENLOS, UNGEKLAERT, OHNE_ANGABE) wird
     * <code>null</code> zurückgegeben.
     *
     * @param ntscLaenderCode der NTSC-Ländercode
     * @return ein LandDTO, mit dem entsprechenden Wert des Landes im Format ISO-3166-1-Alpha-3
     */
    public static LandDTO getLand(final String ntscLaenderCode) {
        if (ntscLaenderCode == null) {
            throw new StammdatenException("Keine Länderkennzeichen hinterlegt.");
        }

        final LandIsoCodes landEnum = LandIsoCodes.findeLandFuerCode(ntscLaenderCode, LandIsoCodes.Typ.NTSC)
            .orElseThrow(() ->
                new StammdatenException("Kein Land gefunden fuer Code: " + ntscLaenderCode));

        return Optional.of(landEnum)
            .filter(not(LAENDER_KENNZEICHEN_OHNE_GUELTIGEN_ISO_CODE::contains))
            .map(LandIsoCodes::getIso31661Alpha3)
            .map(isoAlpha3Wert -> {
                LandDTO landDTO = new LandDTO();
                landDTO.setWert(isoAlpha3Wert);
                landDTO.setTyp(LandDTO.TypEnum.ISO_3166_1_ALPHA_3);
                return landDTO;
            })
            .orElse(null);
    }

    /**
     * Mappt aus PersondDTO in Anrede.
     *
     * @param person aus der die Anrede ermittelt
     * @return ermittelte Anrede
     */
    public static String mapPersonZuAnrede(@Nonnull final PersonDto person) {
        final PersonDto.AnredeEnum anrede = Optional.of(person).map(PersonDto::getAnrede).orElse(
            PersonDto.AnredeEnum.NEUTRALE_ANREDE);
        return switch (anrede) {
            case HERR -> "Herr";
            case FRAU, FRAEULEIN -> "Frau";
            case NEUTRALE_ANREDE -> "neutral";
            default -> "";
        };
    }

    /**
     * Mappt ArtZugaenglichkeit aus Modern in für Diloop notwendiges Feld/Format 'EZustellung'.
     *
     * @param person PersonDto.
     * @return String EZustellung aus ArtDerZugaenglichkeit
     */
    public static String mapArtDerZugaenglichkeitZuEZustellung(PersonDto person) {
        final PersonDto.ArtZugaenglichkeitEnum artZugaenglichkeit = Optional.of(person).map(PersonDto::getArtZugaenglichkeit).orElse(
            PersonDto.ArtZugaenglichkeitEnum.GRUNDSTELLUNG);
        return switch (artZugaenglichkeit) {
            case GROSSDRUCK -> "01";
            case BRAILLE_KURZSCHRIFT -> "02";
            case BRAILLE_VOLLSCHRIFT -> "03";
            case CD_ROM -> "13";
            case HOERMEDIUM -> "22";
            default -> "";
        };
    }

    /**
     * Mappt ArtZugaenglichkeit aus Modern in für Diloop notwendiges Feld/Format 'EPostfach'.
     *
     * @param person PersonDto.
     * @return String EPostfach aus ArtDerZustellung
     */
    public static String mapArtDerZustellungZuEPostfach(PersonDto person) {
        final PersonDto.ArtZustellungEnum artZustellung = Optional.of(person).map(PersonDto::getArtZustellung).orElse(
            PersonDto.ArtZustellungEnum.GRUNDSTELLUNG);
        return (artZustellung == PersonDto.ArtZustellungEnum.E_POSTFACH ? "1" : "");
    }

    /**
     * Erstellt einen Adressen-String fuer eine Reha-Einrichtung.
     *
     * @param rehaEinrichtung Die Reha-Einrichtung, fuer die die Adresse ausgegeben werden soll
     * @return Adresse der Reha-Einrichtung als ein String
     */
    public static String erstelleAdressenString(final RehaEinrichtung rehaEinrichtung) {
        final EinrichtungAnschrift adresseRehaEinrichtung = rehaEinrichtung.getAdresse();
        final NumberFormat integerInstance = NumberFormat.getIntegerInstance();
        integerInstance.setMinimumIntegerDigits(5);
        integerInstance.setGroupingUsed(false);

        return rehaEinrichtung.getName() + NAECHSTE_ZEILE +
            String.format(STRING_STRING_PLATZHALTER,
                adresseRehaEinrichtung.getStrasse().trim(),
                adresseRehaEinrichtung.getHausnummer()) + NAECHSTE_ZEILE + String.format(STRING_STRING_PLATZHALTER,
            adresseRehaEinrichtung.getPlz(),
            adresseRehaEinrichtung.getOrt());
    }

    /**
     * Erstellt einen Adressen-String fuer eine Person.
     *
     * @param person Die Person, fuer die die Adresse ausgegeben werden soll
     * @return Adresse der Person als ein String
     */
    public static String erstelleAdressenString(final PersonDto person) {
        final PersonAnschriftDto anschrift = person.getAnschrift();
        final NumberFormat integerInstance = NumberFormat.getIntegerInstance();
        integerInstance.setMinimumIntegerDigits(5);
        integerInstance.setGroupingUsed(false);

        final String anschriftenzusatz = anschrift.getAnschriftenzusatz() != null ? anschrift.getAnschriftenzusatz()
            + NAECHSTE_ZEILE : "";
        final String land = Optional.ofNullable(getLand(anschrift.getLaenderschluessel())).map(LandDTO::toString)
            .map(s -> s.replace("_", " ")).orElse("");
        return person.getVorname() + " " + person.getName() + NAECHSTE_ZEILE
            + anschrift.getStrasseHausnummer().trim() + NAECHSTE_ZEILE
            + String.format("%s", anschriftenzusatz) + String.format(STRING_STRING_PLATZHALTER,
            anschrift.getPostleitzahl(),
            anschrift.getWohnort()) + land;
    }

}
