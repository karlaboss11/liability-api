package de.deutscherv.rvsm.fa.fit.regelpruefung;

import java.util.List;

/**
 * LaenderUtils.
 */
public class LaenderUtils {

    /**
     * Länderschlüssel für Deutschland.
     */
    private static final String LAENDERSCHLUESSEL_DEUTSCHLAND = "000";

    /**
     * Länderschlüssel für EU, EWR, Schweiz und Türkei.
     */
    private static final List<String> LAENDERSCHLUESSEL_EU_PLUS =
        List.of("151", "124", "125", "130", "181", "164", "126", "127", "128", "129", "000", "134",
            "165", "136", "135", "137", "139", "141", "142", "143", "145", "148", "149", "152",
            "153", "154", "155", "131", "161", "158", "157", "163");

    /**
     * Länderschlüssel für unbekannt, staatenlos, ungeklärt und ohne Angabe.
     */
    private static final List<String> LAENDERSCHLUESSE_AUSSTEUERN =
        List.of("996", "997", "998", "999");

    private LaenderUtils() {
    }

    /**
     * Test ob es sich um Deutschland handelt.
     *
     * @param land zu testendes Land.
     * @return true wenn es Deutschland ist.
     */
    public static boolean isDeutschland(final String land) {
        return LAENDERSCHLUESSEL_DEUTSCHLAND.equals(land);
    }

    /**
     * Test ob es sich um ein EU-Plus-Land handelt.
     *
     * @param land zu testendes Land
     * @return true wenn es ein EU-Plus-Land ist.
     */
    public static boolean isEuPlus(final String land) {
        return LAENDERSCHLUESSEL_EU_PLUS.contains(land);
    }

    /**
     * Test ob es sich um ein ausgeschlossenes Land handelt.
     *
     * @param land zu testendes Land
     * @return true wenn das Land ausgeschlossen ist
     */
    public static boolean isAussteuern(final String land) {
        return LAENDERSCHLUESSE_AUSSTEUERN.contains(land);
    }
}
