package de.deutscherv.rvsm.fa.fit.exceptions;

import de.deutscherv.rvsm.fa.fit.azk.AzkException;
import de.deutscherv.rvsm.fa.fit.log.MDCUtils;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BestandsfehlerDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.UnerwartererFehlerDto;
import de.deutscherv.rvsm.fa.fit.selbstmeldeportal.SelbstmeldeportalClientException;
import de.deutscherv.rvsm.fa.fit.stammdaten.StammdatenException;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.verarbeitung.VerarbeitungsstatusUpdateException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;

/**
 * RvfitExceptionMapper.
 */
@Provider
@Slf4j
public class RvfitExceptionMapper implements ExceptionMapper<RvfitException> {

    private static final int HTTP_STATUS_LOCKED = 423;
    private static final String EXCEPTION_LOG_PLACEHOLDER = ": [{}]";
    private static final String UNERWARTETER_FEHLER_NACHRICHT =
        "Ein unerwarteter Fehler ist aufgetreten";
    private static final String NOT_FOUND_NACHRICHT =
        "Es wurde versucht, auf eine Ressource zuzugreifen, die nicht autorisiert war";
    private static final String KONTOINFORMATION_FEHLER_NACHRICHT =
        "Ein Fehler bei der Verarbeitung der Kontoinformationen ist aufgetreten";
    private static final String SELBSTMELDEPORTAL_FEHLER =
        "Fehler bei der Verbindung zum Selbstmeldeportal";
    private static final String RVPUR_FEHLER = "Fehler bei der Verbindung zum RvPur";
    private static final String KTAN_EXCEPTION = "Fehler beim Auslesen der KTAN";
    private static final String MAPPER_FEHLER = "Fehler beim Mappen von Daten";
    private static final String STAMMDATEN_FEHLER = "Fehler beim Verarbeiten von Stammdaten";
    private static final String DOE_FEHLER = "Fehler bei der Verbindung zur Dokumentenerzeugung";
    private static final String ANTRAG_LOCK_EXCEPTION = "Fehler beim Locken eines Antrags";
    private static final String UNVOLLSTAENDIGE_STAMMDATEN_EXCEPTION = "Unvollständige Stammdaten der versicherten Person";
    private static final String STAMMDATEN_GESPERRT = "Stammdaten sind gesperrt";
    private static final String STATISTIK_FEHLER = "Fehler beim Verarbeiten der Statistik";
    private static final String KEIN_ANTRAG_GEFUNDEN = "Es wurde kein Antrag in Bearbeitung zur ID %s gefunden.";
    private static final String PAPIERANTRAG_VALIDIERUNG_FEHLER = "Validierungsfehler beim Papierantrag.";
    private static final String VERBARBEITUNGSSTATUS_UPDATE_FEHLERMELDUNG =
        "Beim speichern des neuen Verarbeitungsstatus ist ein fehler aufgetreten";

    private static final Map<Class<? extends RvfitException>, Function<RvfitException, Response>> EXCEPTION_MAPPING;

    static {
        Map<Class<? extends RvfitException>, Function<RvfitException, Response>> exceptionMapping = new HashMap<>();
        exceptionMapping.put(StatistikException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(STATISTIK_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY).entity(
                    new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode()).nachricht(STATISTIK_FEHLER))
                .build();
        });

        exceptionMapping.put(UnvollstaendigeStammdatenException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(UNVOLLSTAENDIGE_STAMMDATEN_EXCEPTION + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                .entity(new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode())
                    .nachricht(UNVOLLSTAENDIGE_STAMMDATEN_EXCEPTION)).build();
        });

        exceptionMapping.put(AntragLockException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(ANTRAG_LOCK_EXCEPTION + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                .entity(new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode())
                    .nachricht(ANTRAG_LOCK_EXCEPTION)).build();
        });

        exceptionMapping.put(DokumentenErzeugungsException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(DOE_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(
                    new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode()).nachricht(DOE_FEHLER))
                .build();
        });

        exceptionMapping.put(StammdatenException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(STAMMDATEN_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY).entity(
                    new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode()).nachricht(STAMMDATEN_FEHLER))
                .build();
        });

        exceptionMapping.put(MapperException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(MAPPER_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY).entity(
                    new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode()).nachricht(MAPPER_FEHLER))
                .build();
        });

        exceptionMapping.put(KtanException.class, exception -> {
            LOG.atWarn().addArgument(exception.getMessage())
                .log(KTAN_EXCEPTION + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.UNAUTHORIZED).entity(
                    new AntwortDto().code(Status.UNAUTHORIZED.getStatusCode()).nachricht(KTAN_EXCEPTION))
                .build();
        });

        exceptionMapping.put(RvPurClientException.class, exception -> {
            LOG.atWarn().addArgument(exception).log(RVPUR_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY).entity(
                    new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode()).nachricht(RVPUR_FEHLER))
                .build();
        });

        exceptionMapping.put(SelbstmeldeportalClientException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(ANTRAG_LOCK_EXCEPTION + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY)
                .entity(new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode())
                    .nachricht(ANTRAG_LOCK_EXCEPTION)).build();
        });

        exceptionMapping.put(KontoGesperrtException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(STAMMDATEN_GESPERRT + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(HTTP_STATUS_LOCKED)
                .entity(new AntwortDto().code(HTTP_STATUS_LOCKED)
                    .nachricht(STAMMDATEN_GESPERRT)).build();
        });

        exceptionMapping.put(AzkException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(SELBSTMELDEPORTAL_FEHLER + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.FORBIDDEN)
                .entity(new AntwortDto().code(Status.FORBIDDEN.getStatusCode())
                    .nachricht(String.format("%s, Details: %s", SELBSTMELDEPORTAL_FEHLER, exception.getMessage()))).build();
        });

        exceptionMapping.put(KontoinformationException.class, exception -> {
            LOG.atWarn().addArgument(exception)
                .log(KONTOINFORMATION_FEHLER_NACHRICHT + EXCEPTION_LOG_PLACEHOLDER);
            return Response.status(Status.BAD_GATEWAY)
                .entity(new AntwortDto().code(Status.BAD_GATEWAY.getStatusCode())
                    .nachricht(KONTOINFORMATION_FEHLER_NACHRICHT))
                .build();
        });

        exceptionMapping.put(EingabevalidierungException.class, exception -> {
            LOG.atWarn().addArgument(exception::getResource).addArgument(exception::getUserIdent)
                .addArgument(exception).log("input_validation_fail [{}] | [{}]: [{}]");
            return Response
                .status(Status.BAD_REQUEST).entity(new AntwortDto()
                    .code(Status.BAD_REQUEST.getStatusCode()).nachricht(exception.getMessage()))
                .build();
        });

        exceptionMapping.put(NichtAutorisiertException.class, exception -> {
            LOG.atError().addArgument(exception::getResource).addArgument(exception::getUserIdent)
                .addArgument(exception).log("authz_fail [{}] | [{}]: [{}]");
            return Response
                .status(Status.UNAUTHORIZED).entity(new AntwortDto()
                    .code(Status.UNAUTHORIZED.getStatusCode()).nachricht(NOT_FOUND_NACHRICHT))
                .build();
        });

        exceptionMapping.put(KontoinformationBestandsFehlerException.class, exception -> Response
            .status(Status.INTERNAL_SERVER_ERROR).entity(toBestandsfehlerDto((KontoinformationBestandsFehlerException) exception))
            .build());

        exceptionMapping.put(StammdatenBestandsFehlerException.class, exception -> Response
            .status(Status.INTERNAL_SERVER_ERROR).entity(toBestandsfehlerDto((StammdatenBestandsFehlerException) exception))
            .build());

        exceptionMapping.put(KeinAntragInBearbeitungException.class, exception -> {
            final String nachricht = String.format(KEIN_ANTRAG_GEFUNDEN, exception.getMessage());
            LOG.atError()
                .setCause(exception)
                .log(nachricht);
            return Response
                .status(Status.NOT_FOUND).entity(new AntwortDto()
                    .code(Status.NOT_FOUND.getStatusCode()).nachricht(nachricht))
                .build();
        });

        exceptionMapping.put(PapierantragValidierungException.class, exception -> {
            final PapierantragValidierungException papierantragValidierungException = (PapierantragValidierungException) exception;
            LOG.atError()
                .setCause(papierantragValidierungException)
                .addArgument(papierantragValidierungException::getMessage)
                .log(PAPIERANTRAG_VALIDIERUNG_FEHLER);
            return Response
                .status(Status.BAD_REQUEST)
                .entity(papierantragValidierungException.getFehlerListe())
                .build();
        });

        exceptionMapping.put(StatistikBestandsFehlerException.class, exception -> {
            final StatistikBestandsFehlerException statistikBestandsFehlerException = (StatistikBestandsFehlerException) exception;
            return Response
                .status(Status.INTERNAL_SERVER_ERROR)
                .entity(statistikBestandsFehlerException.getBestandsfehlerDto())
                .build();
        });

        exceptionMapping.put(VerarbeitungsstatusUpdateException.class, exception -> {
            LOG.atError().setCause(exception)
                .log(VERBARBEITUNGSSTATUS_UPDATE_FEHLERMELDUNG);
            return Response
                .status(Status.INTERNAL_SERVER_ERROR)
                .entity(new AntwortDto()
                    .code(Status.INTERNAL_SERVER_ERROR.getStatusCode()).nachricht(VERBARBEITUNGSSTATUS_UPDATE_FEHLERMELDUNG))
                .build();
        });

        EXCEPTION_MAPPING = Map.copyOf(exceptionMapping);
    }

    @Override
    public Response toResponse(final RvfitException exception) {
        MDCUtils.setFailed();

        var function = EXCEPTION_MAPPING.getOrDefault(exception.getClass(), ex -> {
            LOG.atWarn().addArgument(ex.getMessage())
                .log("sys_crash" + EXCEPTION_LOG_PLACEHOLDER + ": "
                    + UNERWARTETER_FEHLER_NACHRICHT);
            // all other errors -> 500
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                .entity(new AntwortDto().code(Status.INTERNAL_SERVER_ERROR.getStatusCode())
                    .nachricht(UNERWARTETER_FEHLER_NACHRICHT))
                .build();
        });
        return function.apply(exception);
    }

    /**
     * Erstellt fuer die verschiedenen abgeleiteten Exeception von BestandfehlerExceptions das BestandsfehlerDto.
     *
     * @param exception fuer die das BestandsfehlerDto erzeugt wird.
     * @return erstellter BestandsfehlerDto
     */
    private static BestandsfehlerDto createBestandsfehlerDto(final BestandsfehlerException exception) {
        final BestandsfehlerDto bestandsfehlerDto = new BestandsfehlerDto();
        final BestandsfehlerException.VersichertenInfo versichertenInfo = exception.getVersichertenInfo();
        bestandsfehlerDto.setVorname(versichertenInfo.vorname());
        bestandsfehlerDto.setName(versichertenInfo.nachname());
        bestandsfehlerDto.setVsnr(versichertenInfo.vsnr());

        return bestandsfehlerDto;
    }

    /**
     * Fuegt dem BestandsfehlerDto das UnerwarteteFehlerDto aus einer StammdatenBestandsFehlerException zu.
     *
     * @param stammdatenBestandsFehlerException aus dem das UnerwarteteFehlerDto ermittelt wird
     * @return erstellte BestandsfehlerDto
     */
    private static final BestandsfehlerDto toBestandsfehlerDto(final StammdatenBestandsFehlerException stammdatenBestandsFehlerException) {
        final UnerwartererFehlerDto unerwartererFehlerDto = new UnerwartererFehlerDto();
        unerwartererFehlerDto.setFehlercode(stammdatenBestandsFehlerException.getFehlerEintragDto().getStatuscode());

        final BestandsfehlerDto bestandsfehlerDto = createBestandsfehlerDto(stammdatenBestandsFehlerException);
        bestandsfehlerDto.setUnerwartererFehler(unerwartererFehlerDto);

        return bestandsfehlerDto;
    }

    /**
     * Fuegt dem BestandsfehlerDto das UnerwarteteFehlerDto aus einer KontoinformationBestandsFehlerException zu.
     *
     * @param kontoinformationBestandsFehlerException aus dem das UnerwarteteFehlerDto ermittelt wird
     * @return erstellte BestandsfehlerDto
     */
    private static final BestandsfehlerDto toBestandsfehlerDto(
        final KontoinformationBestandsFehlerException kontoinformationBestandsFehlerException) {
        final UnerwartererFehlerDto unerwartererFehlerDto = new UnerwartererFehlerDto();
        unerwartererFehlerDto.setFehlercode(kontoinformationBestandsFehlerException.getFehlerEintragDto().getStatuscode());

        final BestandsfehlerDto bestandsfehlerDto = createBestandsfehlerDto(kontoinformationBestandsFehlerException);
        bestandsfehlerDto.setUnerwartererFehler(unerwartererFehlerDto);

        return bestandsfehlerDto;

    }

}
