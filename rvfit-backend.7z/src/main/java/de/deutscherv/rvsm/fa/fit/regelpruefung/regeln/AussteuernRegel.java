package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;

import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelKontext;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import jakarta.inject.Singleton;

import java.util.List;
import java.util.Optional;

import static de.deutscherv.rvsm.fa.fit.regelpruefung.RegelUtils.ergebnis;

/** Regelimplementierung für Tests: diese Regel gibt immer AUSSTEUERN zurück. */
@Singleton
public class AussteuernRegel extends BasisRegel {

    @Override
    public RegelName getRegelName() {
        return RegelName.REGEL_AUSSTEUERN;
    }

    @Override
    public Optional<String> getRegelDetail(final String regelErgebnis) {
        return Optional.ofNullable(regelErgebnis);
    }

    @Override
    public List<RegelErgebnis> pruefeRegel(final RegelKontext kontext) {
        return ergebnis(PruefErgebnis.AUSSTEUERN, getRegelName(),
                "Diese Regel wird immer AUSSTEUERN liefern.");
    }
}
