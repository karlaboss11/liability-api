/**
 * Beinhaltet die einzelnen Regeln.
 */
package de.deutscherv.rvsm.fa.fit.regelpruefung.regeln;
