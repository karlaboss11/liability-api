package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.log.EreignisFreitext;
import de.deutscherv.rvsm.fa.fit.log.EreignisTyp;
import de.deutscherv.rvsm.fa.fit.log.Ereignistext;
import de.deutscherv.rvsm.fa.fit.log.LogUtils;
import de.deutscherv.rvsm.fa.fit.log.RvfitLogger;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.jwt.JsonWebToken;

/**
 * Processor um das Fachprotokoll fuer die gebildiete Statistik zu schreiben.
 */
@ApplicationScoped
@RequiredArgsConstructor
public class FachprotokollStatistikGebildetProcessor implements Processor {

    private final RvfitLogger rvfitLogger;
    private final JsonWebToken jwt;
    private final DrvMandant drvMandant;

    @Override
    public void process(final Exchange exchange) throws Exception {
        final Antrag antrag = exchange.getMessage().getBody(Antrag.class);
        final Aufgabe offeneAufgabe = exchange.getProperty(RVFitCamelHeader.PROPERTY_OFFENE_AUFGABE, Aufgabe.class);

        rvfitLogger.sendeFachprotokollEreignis(LogUtils.getFachereignis(EreignisTyp.NACHRICHTEN_AUSGANG_MASCHINELL,
                Ereignistext.STATISTIK_GEBILDET, EreignisFreitext.STATISTIK_GEBILDET_ERLEDIGUNG,
                null, antrag, offeneAufgabe, jwt, drvMandant));
    }
}
