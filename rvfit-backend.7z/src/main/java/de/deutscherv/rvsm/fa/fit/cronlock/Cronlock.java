package de.deutscherv.rvsm.fa.fit.cronlock;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

/**
 * Entity Cronlock.
 */
@Entity
@Table(name = "cronlock")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cronlock {

    @Id
    @Column
    private String cronname;
    @CreationTimestamp
    @Column(updatable = false, nullable = false)
    private LocalDateTime created;
}
