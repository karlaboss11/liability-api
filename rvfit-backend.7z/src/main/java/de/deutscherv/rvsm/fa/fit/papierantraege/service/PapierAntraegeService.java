package de.deutscherv.rvsm.fa.fit.papierantraege.service;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.PapierantragRoutes;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragsArt;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.Aufgabe;
import de.deutscherv.rvsm.fa.fit.aufgaben.model.AufgabenArt;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.EinrichtungAnschrift;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.exceptions.PapierantragValidierungException;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.EinrichtungAnschriftDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PapierantragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.StammdatenDto;
import de.deutscherv.rvsm.fa.fit.stammdaten.mapper.StammdatenMapper;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.annotation.Nonnull;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePropertyKey;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.RuntimeExchangeException;
import org.eclipse.microprofile.jwt.JsonWebToken;

import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_DRV_ID_AUS_JWT;
import static de.deutscherv.rvsm.fa.fit.security.JwtUtils.GET_KTAN;

/**
 * Papierantraege-Service.
 */
@Slf4j
@RequiredArgsConstructor
@ApplicationScoped
public class PapierAntraegeService {

    private final AntragRepository antragRepository;
    private final AntragMapper antragMapper;
    private final StammdatenMapper stammdatenMapper;
    private final PapierantragsPruefung papierantragsPruefung;
    private final JsonWebToken jwt;
    private final RVFitJsonSchemaValidator rvFitJsonSchemaValidator;
    private final FluentProducerTemplate producerTemplate;
    private final DrvMandant drvMandant;

    /**
     * Erstellt einen Papierantrag aus dem übergebenen DTO.
     *
     * @param papierantragDto das Papierantrag-Datentransferobjekt
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantrag(final PapierantragDto papierantragDto) {
        return createPapierantrag(papierantragDto, PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG);
    }

    /**
     * Erstellt den Entwurf eines Papierantrags aus dem übergebenen DTO.
     *
     * @param papierantragDto das Papierantrag-Datentransferobjekt
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantragEntwurf(final PapierantragDto papierantragDto) {
        return createPapierantrag(papierantragDto, PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_ENTWURF);
    }

    /**
     * Erstellt einen Papierantrag ohne Regelprüfung aus dem übergebenen DTO und erledigt diesen auf
     * andere Art und Weise.
     *
     * @param papierantragDto das Papierantrag-Datentransferobjekt
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantragErledigungAufAndereArtUndWeise(
            final PapierantragDto papierantragDto) {
        return createPapierantragOhneRegelpruefungUndVerarbeiteOhneBescheid(papierantragDto,
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_UND_ERLEDIGE_AUF_ANDERE_ART_UND_WEISE, Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE);
    }

    /**
     * Erstellt einen Papierantrag ohne Regelprüfung aus dem übergebenen DTO und erledigt diesen wegen Rücknahme.
     *
     * @param papierantragDto das Papierantrag-Datentransferobjekt
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantragRuecknahme(
            final PapierantragDto papierantragDto) {
        return createPapierantragOhneRegelpruefungUndVerarbeiteOhneBescheid(papierantragDto,
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_RUECKNAHME, Art.RUECKNAHME);
    }

    /**
     * Erstellt einen Papierantrag ohne Regelprüfung aus dem übergebenen DTO und erledigt diesen zur Weiterbearbeitung in RV Dialog.
     *
     * @param papierantragDto das Papierantrag-Datentransferobjekt
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantragWeiterbearbeitungInRvDialog(
            final PapierantragDto papierantragDto) {
        return createPapierantragOhneRegelpruefungUndVerarbeiteOhneBescheid(papierantragDto,
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG,
                Art.WEITERBEARBEITUNG_IN_RVDIALOG);
    }

    /**
     * Erstelle einen Papierantrag ohne Erfassung zur Weiterbearbeitung in rvDialog.
     * @param papierantragDto betroffener Papierantrag
     * @return erstelltes PapierantragDto
     */
    public PapierantragDto createPapierantragOhneErfassungInRvDialogWeiterbearbeitungInRvDialog(
            final PapierantragDto papierantragDto
    ){
        return createPapierantragOhneRegelpruefungUndVerarbeiteOhneBescheid(papierantragDto,
                PapierantragRoutes.DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG,
                Art.WEITERBEARBEITUNG_IN_RVDIALOG);
    }

    private PapierantragDto createPapierantragOhneRegelpruefungUndVerarbeiteOhneBescheid(
            final PapierantragDto papierantragDto, final String routeName, final Art erledigungsArt) {
        LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                .addArgument(routeName)
                .addArgument(papierantragDto.getVersicherter().getVsnr())
                .addArgument(papierantragDto.getAntrag().getUuid()).log(
                        "Erstelle und erledige Papierantrag ohne Bescheid anhand des übergebenen DTOs."
                                + " Route: [{}] DrvId [{}], VSNR [{}], UUID [{}]");

        return withCamelExceptionHandling(() -> {
            Exchange send = producerTemplate.withBody(papierantragDto)
                    .withHeader(DRVHeader.MANDANT_PROPERTY_KEY, GET_KTAN.apply(jwt, drvMandant))
                    .withHeader(RVFitCamelHeader.ERLEDIGUNG_OHNE_BESCHEID_ART, erledigungsArt)
                    .to(routeName).send();

            pruefeUndWirfExceptions(send);

            if (send.getMessage().getBody() instanceof AntragDto antragDto) {
                papierantragDto.setAntrag(antragDto);
            } else if (send.getMessage().getBody() instanceof Antrag antrag) {
                papierantragDto.setAntrag(antragMapper.toDto(antrag));
            }
            return papierantragDto;
        });
    }

    private static void pruefeUndWirfExceptions(final Exchange send) {
        final Exception exception = Optional.of(send).map(Exchange::getException)
                .orElseGet(() -> Optional.of(send)
                        .map(Exchange::getAllProperties)
                        .map(ap -> ap.get(ExchangePropertyKey.EXCEPTION_CAUGHT.getName()))
                        .filter(Exception.class::isInstance)
                        .map(Exception.class::cast)
                        .orElse(null));
        if (exception == null) {
            return;
        }

        if (exception instanceof PapierantragValidierungException papierantragValidierungException) {
            throw papierantragValidierungException;
        }
        if (exception instanceof StatistikException statistikException) {
            throw statistikException;
        }
        if (exception instanceof NotFoundException notFoundException) {
            throw notFoundException;
        }
    }

    private PapierantragDto createPapierantrag(final PapierantragDto papierantragDto, final String routeName) {
        LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                .addArgument(routeName)
                .addArgument(papierantragDto.getVersicherter().getVsnr())
                .addArgument(papierantragDto.getAntrag().getUuid()).log(
                        "Erstelle Papierantrag anhand des übergebenen DTOs. Route: [{}] DrvId [{}], VSNR [{}], UUID [{}]");

        return withCamelExceptionHandling(() -> {
            final Antrag antrag = producerTemplate.withBody(papierantragDto)
                    .withHeader(DRVHeader.MANDANT_PROPERTY_KEY, GET_KTAN.apply(jwt, drvMandant))
                    .to(routeName)
                    .request(Antrag.class);
            papierantragDto.getAntrag().setUuid(antrag.getUuid().toString());
            return papierantragDto;
        });
    }

    private PapierantragDto withCamelExceptionHandling(final Supplier<PapierantragDto> function) {
        try {
            return function.get();
        } catch (final CamelExecutionException camelExecutionException) {
            final Exception cause = Optional.of(camelExecutionException).map(RuntimeExchangeException::getExchange)
                    .map(Exchange::getException)
                    .orElse(camelExecutionException);
            if (cause instanceof RuntimeException runtimeException) {
                throw runtimeException;
            }
            throw camelExecutionException;
        }
    }

    /**
     * Prueft ob das PapierantragDTO valide ist.
     *
     * @param papierantragDto das geprueft wird
     * @return true falls valide
     */
    public boolean isPapierantragDtoValid(PapierantragDto papierantragDto) {
        if (papierantragDto == null) {
            LOG.atInfo().log(
                    "Erstellen PapierantragEntwurf fehlgeschlagen - übergebenes papierantragDto gleich null.");
            return false;
        }
        if (!rvFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, papierantragDto)) {
            throw new IllegalArgumentException(
                    "Kein valider Entwurf für einen Papierantrag angegeben: " + papierantragDto);
        }
        LOG.atWarn().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                .addArgument(papierantragDto.getVersicherter().getVsnr())
                .addArgument(papierantragDto.getAntrag().getUuid()).log(
                        "Erstelle Papierantrag anhand des übergebenen DTOs. DrvId [{}], Vsnr [{}], UUID [{}]");

        if (!papierantragsPruefung.isVsnrValid(papierantragDto.getVersicherter().getVsnr())) {
            LOG.atWarn().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt))
                    .addArgument(papierantragDto.getVersicherter().getVsnr())
                    .addArgument(papierantragDto.getAntrag().getUuid())
                    .log("Erstellen PapierantragEntwurf fehlgeschlagen - "
                            + "übergebenes papierantragDto mit invalider VSNR. DrvId [{}], Vsnr [{}], UUID [{}]");
            return false;
        }
        return true;
    }

    /**
     * Sucht einen Papierantrag mit der übergebenen UUID.
     *
     * @param guuid die UUID zum Papierantrag
     * @return den PapierantragDto des Papierantrags zur übergebenen UUID
     */
    @Transactional
    public PapierantragDto getPapierantragEntwurfByUuid(final UUID guuid) {
        final Antrag papierantrag = antragRepository.findByUuid(guuid).orElse(null);
        if (Objects.isNull(papierantrag)) {
            LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(guuid)
                    .log("Keinen Papierantragsentwurf zur UUID gefunden. DrvId [{}] Vsnr [{}]");
            return null;
        }
        if (!papierantrag.getAntragsart().equals(AntragsArt.PAPIERANTRAG)) {
            LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(guuid)
                    .log("Keinen Papierantragsentwurf zur UUID gefunden. DrvId [{}] Vsnr [{}]");
            return null;
        }
        if (!papierantrag.getStatus().equals(AntragStatus.ENTWURF)) {
            return null;
        }

        final PapierantragDto papierantragDto = new PapierantragDto();
        papierantragDto.setAntrag(antragMapper.toDto(papierantrag));
        return papierantragDto;
    }

    /**
     * Sucht einen Papierantrag mit der übergebenen vsnr.
     *
     * @param vsnr die vsnr zum Papierantrag
     * @return the PapierantragDto des Papierantrags zur übergebenen vsnr
     */
    @Transactional
    public PapierantragDto getPapierantragEntwurfByVsnr(final String vsnr) {
        final Antrag papierantrag = antragRepository.findPapierantragEntwurfByVsnr(vsnr);
        if (Objects.isNull(papierantrag)) {
            LOG.atInfo().addArgument(GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(vsnr)
                    .log("Keinen Antragsentwurf zur VSNR gefunden. DrvId [{}] Vsnr [{}]");
            return null;
        }

        final PapierantragDto papierantragDto = new PapierantragDto();
        papierantragDto.setAntrag(getAntragDto(papierantrag));
        papierantragDto.setVorgangsId(papierantrag.getVorgangskennung());
        papierantragDto.setAufgabenId(getAntragsErfassungAufgabenId(papierantrag));

        papierantragDto.setEinrichtung1(getEinrichtungsDto(papierantrag.getEinrichtungStartObjekt()));
        papierantragDto.setEinrichtung2(getEinrichtungsDto(papierantrag.getEinrichtungTrainingObjekt()));

        papierantragDto.setVersicherter(getStammdatenDto(papierantrag));

        return papierantragDto;
    }

    private AntragDto getAntragDto(final Antrag antrag) {
        final AntragDto antragDto = antragMapper.toDto(antrag);
        antragDto.setEinrichtungStartObjekt(null);
        antragDto.setEinrichtungAufObjekt(null);
        antragDto.setEinrichtungTrainingObjekt(null);
        return antragDto;
    }

    private StammdatenDto getStammdatenDto(@Nonnull final Antrag antrag) {
        return Optional.of(antrag)
                .map(Antrag::getVersichertenStammdaten)
                .orElseGet(Collections::emptyList)
                .stream()
                .findFirst()
                .map(stammdatenMapper::toDto)
                .orElse(null);
    }

    private RehaEinrichtungDto getEinrichtungsDto(final RehaEinrichtung rehaEinrichtungEntity) {
        return Optional.ofNullable(rehaEinrichtungEntity).map(entity -> {
            RehaEinrichtungDto dto = new RehaEinrichtungDto();
            dto.setSelbstmeldeportalId(entity.getSmpEinrichtungsId());
            dto.setName(entity.getName());
            dto.setAdresse(Optional.of(entity)
                    .map(RehaEinrichtung::getAdresse).map(this::getAnschriftDto).orElse(null));
            return dto;
        }).orElse(null);
    }

    private EinrichtungAnschriftDto getAnschriftDto(final EinrichtungAnschrift rehaEinrichtungAnschrift) {
        final EinrichtungAnschriftDto anschriftDto = new EinrichtungAnschriftDto();
        anschriftDto.setPlz(rehaEinrichtungAnschrift.getPlz());
        anschriftDto.setOrt(rehaEinrichtungAnschrift.getOrt());
        anschriftDto.setStrasse(rehaEinrichtungAnschrift.getStrasse());
        anschriftDto.setHausnummer(rehaEinrichtungAnschrift.getHausnummer());
        return anschriftDto;
    }

    private String getAntragsErfassungAufgabenId(final Antrag antrag) {
        return Optional.of(antrag).map(Antrag::getAufgaben).orElseGet(Collections::emptyList).stream()
                .filter(a -> AufgabenArt.ANTRAGSERFASSUNG.equals(a.getAufgabenArt()))
                .findFirst()
                .map(Aufgabe::getVomAufgabenId)
                .orElse(null);
    }

}
