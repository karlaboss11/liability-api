/**
 * Beinhaltet custom Exceptions Klassen.
 */
package de.deutscherv.rvsm.fa.fit.exceptions;
