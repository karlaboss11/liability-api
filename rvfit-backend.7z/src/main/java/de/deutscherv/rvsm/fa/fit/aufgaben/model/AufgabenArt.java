package de.deutscherv.rvsm.fa.fit.aufgaben.model;

/**
 * Enum für die Arten von Aufgaben, die RVFit anlegt.
 *
 * @author U38322
 */
public enum AufgabenArt {

    /**
     * Aufgabe für Aussteuern bei Personendatenabgleich.
     */
    PERSONENDATENABGLEICH("RVFIT-PP-DURCH-SB"),

    /**
     * Aufgabe für manuelle Einrichtungsauswahl und Aussteuern bei Anspruchsvorraussetzungspruefung.
     */
    EINRICHTUNGENUNDANSPRUCH("RVFIT-APEP-DURCH-SB"),

    /**
     * Aufgabe für manuelle Einrichtungsauswahl.
     */
    EINRICHTUNGSWAHL("RVFIT-EP-DURCH-SB"),

    /**
     * Aufgabe für Aussteuern bei Anspruchsvorraussetzungspruefung.
     */
    ANSPRUCHSVORAUSSETZUNG("RVFIT-AP-DURCH-SB"),

    /**
     * Aufgabe für Aussteuern bei Personendatenabgleich.
     */
    ANTRAGSERFASSUNG("RVFIT-AE-DURCH-SB"),

    /**
     * Aufgabe für Aussteuern bei Doppelvergabe.
     */
    DOPPELVERGABE("RVFIT-DV-DURCH-SB"),

    /**
     * Aufgabe für Aussteuern bei Bemerkung.
     */
    BEMERKUNG_ODER_ANHANG_VORHANDEN("RVFIT-BE-DURCH-SB"),

    /**
     * Aufgabe für Aufgaben Bestandsfehler.
     */
    BESTANDSFEHLER("RVFIT-FE-DURCH-SB");

    /**
     * Wert.
     */
    public final String value;

    /**
     * Konstruktor.
     *
     * @param value zu setzender Wert.
     */
    AufgabenArt(String value) {
        this.value = value;
    }
}
