package de.deutscherv.rvsm.fa.fit.statistik;

import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import lombok.extern.slf4j.Slf4j;

/**
 * StatistikException.
 */
@Slf4j
public class StatistikException extends RvfitException {

    /**
     * Konstrukotr.
     *
     * @param message Fehlernachricht
     */
    public StatistikException(final String message) {
        super(message);
    }

    /**
     * Konstruktor.
     *
     * @param message   Fehlernachricht
     * @param throwable Fehlergrund
     */
    public StatistikException(final String message, final Throwable throwable) {
        super(message, throwable);
    }

}