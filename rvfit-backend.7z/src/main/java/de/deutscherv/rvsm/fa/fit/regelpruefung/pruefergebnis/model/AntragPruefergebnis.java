package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model;

import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.RegelName;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * JPA Entity für Prüfergebnisse.
 */
@Entity
@Table(name = "pruefergebnis")
@Cacheable
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AntragPruefergebnis {

    /** technische id des Pruefergebnis. */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID uuid;

    @Column(name = "antrag_id")
    private UUID antragId;

    @Column(name = "parent_uuid")
    private UUID parentUuid;

    @Enumerated(EnumType.STRING)
    private PruefErgebnis ergebnis;

    @Enumerated(EnumType.STRING)
    @Column(name = "regel_name")
    private RegelName regelName;

    @Column
    private String begruendung;

    @Column(name = "prioritaet")
    private Long prioritaet;

    @Column(name = "regel_id")
    private Long regelId;

    @Column(name = "anmerkung")
    private String anmerkung;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime created;

    @UpdateTimestamp
    @Column(name = "last_modified")
    private LocalDateTime lastModified;

    @Column(name = "ktan")
    private String ktan;
}
