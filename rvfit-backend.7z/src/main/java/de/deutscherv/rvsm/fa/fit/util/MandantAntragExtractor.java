package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.MandantExtractor;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;

/**
 * MandantAntragExtractor.
 */
public class MandantAntragExtractor implements MandantExtractor<Antrag> {
    @Override
    public String getMandant(Antrag antrag) {
        return antrag.getKtan();
    }

    @Override
    public Class<Antrag> carrierType() {
        return Antrag.class;
    }
}