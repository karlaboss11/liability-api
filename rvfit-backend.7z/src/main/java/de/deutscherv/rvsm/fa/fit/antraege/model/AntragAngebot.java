package de.deutscherv.rvsm.fa.fit.antraege.model;

import org.apache.commons.lang3.StringUtils;

/**
 * Record mit Adressdaten fuer Angebot und Antrag.
 * @param name Name
 * @param ort  Ort
 * @param plz  Postleitzahl
 * @param strasse Strassenname
 */
public record AntragAngebot(String name, String ort, String plz, String strasse) {

    /**
     * Prüft, ob die Freitextfelder im Angebot gesetzt sind.
     *
     * @return {@code true}, wenn ein alle Freitextfelder gesetzt sind
     */
    public boolean freitextFelderGesetzt() {
        return StringUtils.isNotBlank(name)
                && StringUtils.isNotBlank(ort)
                && StringUtils.isNotBlank(plz)
                && StringUtils.isNotBlank(strasse);
    }

}
