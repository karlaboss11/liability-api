package de.deutscherv.rvsm.fa.fit.exceptions;

import java.io.Serial;

/**
 * KontoinformationsException.
 */
public class KontoinformationException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     */
    public KontoinformationException(final String message) {
        super(message);
    }

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     * @param cause   Grund des Fehlers
     */
    public KontoinformationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
