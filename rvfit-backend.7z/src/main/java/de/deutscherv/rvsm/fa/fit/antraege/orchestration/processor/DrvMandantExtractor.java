package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.ba.multitenants.runtime.DrvMandant;
import de.deutscherv.rvsm.fa.fit.jms.DRVHeader;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.EventNotifierSupport;

/**
 * Ein Camel-{@link Processor}, der den Mandanten aus dem Nachrichtenheader extrahiert und in der Exchange-Property
 * {@value DRVHeader#MANDANT_PROPERTY_KEY} bereitstellt. Die {@link jakarta.enterprise.context.RequestScoped} Bean {@link DrvMandant} wird
 * ebenfalls befüllt.
 */
@ApplicationScoped
@Slf4j
public class DrvMandantExtractor extends EventNotifierSupport implements Processor {

    /**
     * Mandant Scope Property Key.
     */
    public static final String MANDANT_SCOPE_PROPERTY_KEY = "$" + DrvMandantExtractor.class.getSimpleName() + ".scope";

    private final DrvMandant mandantHolder;

    /**
     * Constructor.
     *
     * @param mandantHolder DrvMandant
     */
    @Inject
    public DrvMandantExtractor(final DrvMandant mandantHolder) {
        this.mandantHolder = mandantHolder;
        setIgnoreCamelContextEvents(true);
        setIgnoreRouteEvents(true);
        setIgnoreServiceEvents(true);
        setIgnoreExchangeAsyncProcessingStartedEvents(true);
        setupIgnore(true);
        setIgnoreExchangeEvents(false);
        setIgnoreExchangeCompletedEvent(false);
        setIgnoreExchangeFailedEvents(false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEnabled(final CamelEvent event) {
        return event.getType() == CamelEvent.Type.ExchangeCompleted || event.getType() == CamelEvent.Type.ExchangeFailed;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void process(final Exchange exchange) {
        Optional.ofNullable(exchange.getMessage().getHeader(DRVHeader.MANDANT_PROPERTY_KEY))
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .ifPresentOrElse(mandant -> {
                    LOG.atInfo().setMessage("Setze Mantdanten auf [{}]").addArgument( mandant).log();
                    exchange.setProperty(DRVHeader.MANDANT_PROPERTY_KEY, mandant);
                    exchange.setProperty(MANDANT_SCOPE_PROPERTY_KEY, mandantHolder.setInScope(mandant));
                }, () -> {
                    throw new UnsupportedOperationException();
                });

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notify(final CamelEvent event) throws Exception {
        final CamelEvent.ExchangeEvent exchangeEvent = (CamelEvent.ExchangeEvent) event;
        final Exchange ex = exchangeEvent.getExchange();
        final AutoCloseable property = ex.getProperty(MANDANT_SCOPE_PROPERTY_KEY, AutoCloseable.class);
        if (property != null) {
            property.close();
        }
    }
}
