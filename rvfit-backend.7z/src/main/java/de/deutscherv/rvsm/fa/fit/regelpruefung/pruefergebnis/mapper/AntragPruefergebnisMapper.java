package de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.mapper;

import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.model.AntragPruefergebnis;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragPruefergebnisDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PruefergebnisDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.PruefErgebnis;
import de.deutscherv.rvsm.fa.fit.regelpruefung.mapper.RegelNameMapper;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

/**
 * Mapper fuer Pruefergebnisse.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR,
        uses = { RegelNameMapper.class } )
public interface AntragPruefergebnisMapper {

    /**
     * Mappt ein Prüfergebnis in ein DTO.
     *
     * @param entity das Prüfergebnis
     * @return das DTO
     */
    @Mapping(source = "uuid", target = "id")
    @Mapping(source = "parentUuid", target = "parentId")
    @Mapping(source = "ergebnis", target = "ergebnis")
    @Mapping(source = "regelName", target = "regelName")
    PruefergebnisDto toDto(AntragPruefergebnis entity);

    /**
     * Mappt ein Prüfergebnis DTO in ein Prüfergebnis.
     *
     * @param dto das DTO
     * @return das Prüfergebnis
     */
    @Mapping(source = "id", target = "uuid")
    @Mapping(source = "parentId", target = "parentUuid")
    @Mapping(source = "regelName", target = "regelName")
    @Mapping(target = "antragId", ignore = true)
    @InheritInverseConfiguration
    AntragPruefergebnis toEntity(PruefergebnisDto dto);

    /**
     * Mappt ein PruefErgebnis Enum in ein AntragPruefErgebnisDto Enum.
     *
     * @param ergebnis ein PruefErgebnis Enum
     * @return ein AntragPruefergebnisDto
     */
    @ValueMapping(source = "NICHT_ERFUELLT_AUSSTEUERN", target = "NICHT_ERFUELLT_AUSSTEUERN")
    @ValueMapping(source = "NICHT_ERFUELLT_ABLEHNEN", target = "NICHT_ERFUELLT_ABLEHNEN")
    AntragPruefergebnisDto mapPruefergebnis(PruefErgebnis ergebnis);

    /**
     * Mappt ein AntragPruefErgebnisDto Enum in ein PruefErgebnis Enum.
     *
     * @param ergebnis ein AntragPruefErgebnisDto
     * @return ein PruefErgebnis
     */
    @ValueMapping(source = "NICHT_ERFUELLT_AUSSTEUERN", target = "NICHT_ERFUELLT_AUSSTEUERN")
    PruefErgebnis mapErgebnis(AntragPruefergebnisDto ergebnis);
}
