package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.mapper.EantragsBestaetigungMapper;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitXmlMarshaller;
import de.deutscherv.rvsm.fa.fit.antragsdaten50.Antragsdaten;
import de.deutscherv.rvsm.fa.fit.rvfit.spocadapter.async.model.EantragsBestaetigungDTO;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 * Ruf {@link de.deutscherv.rvsm.fa.fit.antraege.service.AntragService} um eAntrag in {@link EantragsBestaetigungDTO} umzuwandeln.
 * Verarbeitet die Exception und fügt {@link EantragsBestaetigungDTO} hinzu.
 */
@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class VerarbeiteEAntragExceptionHandlerProcess implements Processor {

    private static final RVFitXmlMarshaller MARSHALLER = new RVFitXmlMarshaller();

    private final EantragsBestaetigungMapper eantragsBestaetigungMapper;

    @Override
    public void process(Exchange exchange) throws Exception {
        final var antragsdaten = MARSHALLER.unmarshall(Antragsdaten.class, exchange.getMessage().getBody(String.class));
        LoggingUtils.logProcessorAntragsdaten(exchange.getFromRouteId(), getClass().getSimpleName(), antragsdaten);

        final EantragsBestaetigungDTO antragsbestaetigung =
            eantragsBestaetigungMapper.antragsdatenToEantragsBestaetigung(antragsdaten);
        final var exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        LOG.atInfo().addArgument(exception)
            .log("Der EAntragsBestaetigungDTO wirft eine Exception: [{}]");

        antragsbestaetigung.geteAntragDaten().setFehlerNummer(exception.getClass().toString());
        antragsbestaetigung.geteAntragDaten().setFehlerText(Arrays.toString(exception.getStackTrace()));

        exchange.getMessage().setBody(antragsbestaetigung);
    }
}

