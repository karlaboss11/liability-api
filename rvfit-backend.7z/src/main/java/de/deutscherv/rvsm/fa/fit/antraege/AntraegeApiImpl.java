package de.deutscherv.rvsm.fa.fit.antraege;

import de.deutscherv.rvsm.ba.multitenants.runtime.interceptor.RequiresMandant;
import de.deutscherv.rvsm.fa.fit.antraege.mapper.AntragMapper;
import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.RestServiceClient;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames;
import de.deutscherv.rvsm.fa.fit.antraege.service.AntragService;
import de.deutscherv.rvsm.fa.fit.antraege.service.EinrichtungenUpdateService;
import de.deutscherv.rvsm.fa.fit.antraege.util.RVFitJsonSchemaValidator;
import de.deutscherv.rvsm.fa.fit.azk.AzkService;
import de.deutscherv.rvsm.fa.fit.diloop.DokumentendatenService;
import de.deutscherv.rvsm.fa.fit.exceptions.DoeNoAcceptedResponseException;
import de.deutscherv.rvsm.fa.fit.exceptions.KontoGesperrtException;
import de.deutscherv.rvsm.fa.fit.openapi.api.AntraegeApi;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntwortDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.BewilligungsdatenDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.PruefergebnisUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.RehaEinrichtungUpdateDto;
import de.deutscherv.rvsm.fa.fit.openapi.model.VersandErgebnisDto;
import de.deutscherv.rvsm.fa.fit.regelpruefung.mapper.RegelNameMapper;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.mapper.AntragPruefergebnisMapper;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.service.PruefergebnisService;
import de.deutscherv.rvsm.fa.fit.security.JwtUtils;
import de.deutscherv.rvsm.fa.fit.util.FreitextAblehnungValidator;
import de.deutscherv.rvsm.fa.fit.util.TimeoutFallbackHandler;
import de.deutscherv.rvsm.fa.fit.verarbeitung.mapper.ArtMapper;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Verarbeitungsstatus;
import de.deutscherv.rvsm.fa.fit.verarbeitung.service.VerarbeitungsstatusService;
import de.drv.rvevo.shared.api.doe.model.AuftragsStatusDTO;
import jakarta.annotation.security.RolesAllowed;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.FluentProducerTemplate;
import org.apache.commons.lang3.NotImplementedException;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.RVFIT_STATUS_BASED_ROUTING;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_BST;
import static de.deutscherv.rvsm.fa.fit.util.Rollen.RVSM_QSTT_PR_FIT_EF;
import static de.deutscherv.rvsm.fa.fit.util.StatusValidator.isOpenedStatus;

/**
 * Implementierung der API-Endpunkte von rvFit fuer eAntraege.
 */
@Slf4j
@SecurityRequirement(name = "keycloak")
@RequiredArgsConstructor
@ApplicationScoped
@Path("/antraege")
public class AntraegeApiImpl implements AntraegeApi {

    private final JsonWebToken jwt;
    private final RVFitJsonSchemaValidator rVFitJsonSchemaValidator;
    private final AntragService antragService;
    private final PruefergebnisService pruefergebnisService;
    private final EinrichtungenUpdateService einrichtungenUpdateService;
    private final DokumentendatenService dokumentendatenService;
    private final VerarbeitungsstatusService verarbeitungsstatusService;
    private final ArtMapper artMapper;
    private final AntragPruefergebnisMapper antragPruefergebnisMapper;
    private final RegelNameMapper regelNameMapper;
    private final AzkService azkService;
    private final FluentProducerTemplate producerTemplate;
    private final AntragMapper antragMapper;
    private final FreitextAblehnungValidator freitextAblehnungValidator;

    /**
     * Erneuter Versuch.
     *
     * @param uuid des Antrags
     * @return OK
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response erneuterVersuch(final UUID uuid) {
        antragService.starteErneutenVersuch(uuid);
        return Response.ok().build();
    }

    /**
     * Response mit OK mit Bestandsfehler.
     *
     * @param antragUuid des Antrags
     * @return Response mit Bestandsfehler
     */
    @RequiresMandant
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @Override
    public Response getBestandsfehler(final UUID antragUuid) {
        antragService.checkKontoGesperrt(antragUuid, false);

        final Antrag antrag = antragService.getAntragByUuid(antragUuid);

        if (antrag.getAtad() != null) {
            azkService.pruefeZugriff(antragUuid);
        }

        return Response.ok(antragService.getBestandsfehlerDto(antrag)).build();
    }

    /**
     * Antrag wird mit UUID gelesen.
     *
     * @param uuid des zu lesenden Antrags.
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    @Timeout(value = 20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response getByUuid(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        try {
            final AntragDto antragDto = antragService.mapToAntragDto(antragService.getAntragByUuid(uuid));

            if (isOpenedStatus(antragDto.getStatus())) {
                return Response.ok(antragDto).build();
            } else {
                return Response.status(Status.NOT_FOUND).entity(new AntwortDto().code(Status.NOT_FOUND.getStatusCode())
                        .nachricht("Der Antrag konnte anhand der UUID nicht gefunden werden"))
                    .build();
            }
        } catch (final KontoGesperrtException kontoGesperrtException) {
            antragService.sendeWeiterbearbeitungInDialog(uuid);
            throw kontoGesperrtException;
        }

    }

    /**
     * Es erfolgt ein Abgleich der Personendaten.
     *
     * @param uuid des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    @Timeout(value = 20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response getPersonendatenabgleich(final UUID uuid) {
        LOG.atWarn().addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid)
            .log("sensitive_read:[{} | {}]: Gleiche Personendaten ab für Antrag mit UUID.");
        azkService.pruefeZugriff(uuid);
        final PruefergebnisService.StatusCodeAntwortPair responseRecord = pruefergebnisService.checkPersonendatenabgleich(uuid);
        return Response.status(responseRecord.statusCode()).entity(responseRecord.object()).build();
    }

    /**
     * Aktualisiere Antragsdaten.
     *
     * @param uuid des Antrags
     * @return Response mit aktualisierten Antragsdaten
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response aktualisierungAntragsdaten(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        final AntragDto entity = pruefergebnisService.aktualisierungAntragsdaten(uuid);
        antragService.checkKontoGesperrt(uuid, true);
        return Response.ok(entity).build();
    }

    /**
     * Response Verarbeitungsart.
     *
     * @param uuid des Antrags
     * @return Response OK mit Verarbeitungsart
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response getVerarbeitungsart(final UUID uuid) {
        azkService.pruefeZugriff(uuid);

        final Optional<Verarbeitungsstatus> verarbeitungsstatus = verarbeitungsstatusService.getVerarbeitungsstatusFallsAbgeschlossen(uuid);

        if (verarbeitungsstatus.isPresent()) {
            return Response.ok(artMapper.toDto(verarbeitungsstatus.get().getArt())).build();
        } else {
            return Response.ok(null).build();
        }
    }

    /**
     * Es erfolgt ein Update einer Einrichtung in einer Phase.
     *
     * @param uuid                          des Antrags
     * @param phase                         in der die Einrichtung geaendert werden soll
     * @param rehaEinrichtungPhaseUpdateDto neue Einrichtung
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response updateEinrichtungByPhase(final UUID uuid, final String phase,
        @Valid @NotNull final RehaEinrichtungUpdateDto rehaEinrichtungPhaseUpdateDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, rehaEinrichtungPhaseUpdateDto)) {
            throw new IllegalArgumentException("Keine valide RehaEinrichtung angegeben: " + rehaEinrichtungPhaseUpdateDto);
        }
        LOG.atInfo()
            .addArgument(phase)
            .addArgument(rehaEinrichtungPhaseUpdateDto)
            .addArgument(uuid)
            .addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt))
            .log("Aktualisiere Einrichtung bei Phase [{}], anhand des DTO's: [{}], Antrag UUDD [{}], KTAN [{}]");

        einrichtungenUpdateService.updateEinrichtungByPhase(uuid, phase, rehaEinrichtungPhaseUpdateDto);

        return Response.ok(new AntwortDto().code(Status.OK.getStatusCode()).nachricht("Einrichtungen wurden updated")).build();
    }

    /**
     * Ein eAntrag wird gespeichert.
     *
     * @param body Enthaelt die XML des eAntrags
     * @return das AntragDto
     */
    @Override
    @RequiresMandant
    public Response setEantrag(@Valid @NotNull final String body) {
        throw new UnsupportedOperationException();
    }

    /**
     * Es erfolgt ein Update auf das Regelergebnis.
     *
     * @param uuid                   des Antrags*
     * @param pruefergebnisUpdateDto zukuenftiges Regelergebnis
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response updateRegelErgebnis(final UUID uuid, @Valid @NotNull final PruefergebnisUpdateDto pruefergebnisUpdateDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, pruefergebnisUpdateDto)) {
            throw new IllegalArgumentException("Kein valides Pruefergebnis angegeben: " + pruefergebnisUpdateDto);
        }

        pruefergebnisService.updateRegelErgebnis(antragService.getAntragByUuid(uuid),
            regelNameMapper.toEntity(pruefergebnisUpdateDto.getRegelName()),
            antragPruefergebnisMapper
                .mapErgebnis(pruefergebnisUpdateDto.getAntragPruefergebnis()),
            pruefergebnisUpdateDto.getBegruendung());

        return Response.ok().build();
    }

    /**
     * Regelergebnisse werden zurueckgesetzt.
     *
     * @param uuid         des Antrags
     * @param regelNameStr Regel die zurueckgesetzt wird
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response resetRegelErgebnis(final UUID uuid, @Valid @NotNull final String regelNameStr) {
        azkService.pruefeZugriff(uuid);
        pruefergebnisService.resetRegelErgebnis(antragService.getAntragByUuid(uuid), regelNameStr);

        return Response.ok().build();
    }

    /**
     * Dokumentendaten werden gesendet.
     *
     * @param uuid                des Antrags
     * @param dokumentenklasseDto DokumentenklasseDto mit Informationen zum zu erstellenden Dokument.
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    @Timeout(value = 20000)
    @Fallback(value = TimeoutFallbackHandler.class, applyOn = TimeoutException.class)
    public Response postDokumentendaten(final UUID uuid, @Valid @NotNull final DokumentenklasseDto dokumentenklasseDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, dokumentenklasseDto)) {
            throw new IllegalArgumentException("Keine validen Dokumentendaten angegeben: " + dokumentenklasseDto);
        }

        if (!freitextAblehnungValidator.isValid(uuid, dokumentenklasseDto)) {
            throw new IllegalArgumentException("Kein valider Freitext für Ablehnung angegeben: " + dokumentenklasseDto);
        }

        LOG.atInfo()
            .addArgument(uuid)
            .addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt))
            .log("Setze Regelergebnis zurück. Antrag UUID [{}], KTAN [{}]");

        final AuftragsStatusDTO auftragsStatusDTO;
        try {
            auftragsStatusDTO = dokumentendatenService.getDokumentendaten(antragService.getAntragByUuid(uuid), dokumentenklasseDto, false);
        } catch (final DoeNoAcceptedResponseException e) {
            LOG.atError().setCause(e).log("DoE konnte das Dokument nicht erzeugen");
            return Response.status(Status.SERVICE_UNAVAILABLE).entity(new AntwortDto().code(Status.SERVICE_UNAVAILABLE.getStatusCode())
                .nachricht("DoE kann den Bescheid nicht erstellen")).build();
        }
        return Response.ok(auftragsStatusDTO).build();
    }

    /**
     * Dokumentenerzeugung für Bewilligung wird initiert.
     *
     * @param uuid                 UUID des Antrags.
     * @param bewilligungsdatenDto BewilligungsdatenDto mit zusatzinformationen für den Bewilligungsbescheid.
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response postDokumentenerzeugungBewilligung(final UUID uuid, @Valid @NotNull final BewilligungsdatenDto bewilligungsdatenDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, bewilligungsdatenDto)) {
            throw new IllegalArgumentException("Keine valide Bewilligungsdaten angegeben: " + bewilligungsdatenDto);
        }
        LOG.atInfo().addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt)).addArgument(uuid)
            .log("[{} | UUID {}]: Initiiere Dokumentenerzeugung BEWILLIGUNG.");

        final AuftragsStatusDTO auftragsStatusDTO;
        try {
            auftragsStatusDTO = dokumentendatenService.getDokumentendatenBewilligung(antragService.getAntragByUuid(uuid),
                bewilligungsdatenDto,
                false);
        } catch (DoeNoAcceptedResponseException e) {
            LOG.atError().setCause(e).log("Doe hat konnte das Dokument nicht erzeugen");
            return Response.status(Status.SERVICE_UNAVAILABLE).entity(new AntwortDto().code(Status.SERVICE_UNAVAILABLE.getStatusCode())
                .nachricht("Doe ist kann den Bescheid nicht erstellen")).build();
        }
        return Response.ok(auftragsStatusDTO).build();
    }

    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response getDokumentendaten(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        LOG.atInfo().addArgument(uuid).addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt))
            .log("Liefer Dokumentendaten zurück. Antrag UUID [{}], KTAN [{}]");

        final AuftragsStatusDTO auftragStatus = dokumentendatenService.getAuftragStatus(uuid);

        return Response.ok(auftragStatus).build();
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Sachverhaltsaufklärung.
     *
     * @param uuid               des Antrags
     * @param versandErgebnisDto das Ergebnis aus dem Versand eines Dokuments
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response verarbeiteSachverhaltsaufklaerung(final UUID uuid, @Valid @NotNull final VersandErgebnisDto versandErgebnisDto) {
        azkService.pruefeZugriff(uuid);
        LOG.atWarn().addArgument(uuid).addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt)).log(
            "Aktuell existiert keine Implementierung des Endpunkts /antraege/<UUID>/sachverhaltsaufklaerung. Antrag UUID [{}], KTAN "
                + "[{}]");
        throw new NotImplementedException(String.format(
            "Aktuell existiert keine Implementierung des Endpunkts /antraege/%s/sachverhaltsaufklaerung", uuid.toString()));
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Ablehnung.
     *
     * @param uuid               des Antrags
     * @param versandErgebnisDto das Ergebnis aus dem Versand eines Dokuments
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF })
    @RequiresMandant
    public Response verarbeiteAblehnung(final UUID uuid, @Valid @NotNull final VersandErgebnisDto versandErgebnisDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, versandErgebnisDto)) {
            throw new IllegalArgumentException("Kein valides Versandergebnis der Antragsablehnung angegeben: " + versandErgebnisDto);
        }
        final Antrag antragVersandVerarbeitet = antragService.verarbeiteMitVersandergebnis(uuid, versandErgebnisDto, Art.ABLEHNUNG);

        antragService.protokolliereFachereignisAntragBeschieden(antragVersandVerarbeitet);

        final Antrag antragAbschluss = producerTemplate.withBody(antragVersandVerarbeitet)
            .to(RVFIT_STATUS_BASED_ROUTING)
            .request(Antrag.class);
        return Response.ok(antragMapper.toDto(antragAbschluss)).build();
    }

    /**
     * Test Verarbeite Bearbeitung in rvDialog.
     *
     * @param uuid des Antrags
     * @return OK mit AntragDto
     */
    @Override
    @RequiresMandant
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    public Response verarbeiteBearbeitungInRvDialog(final UUID uuid) {
        LOG.atInfo().addArgument(JwtUtils.GET_DRV_ID_AUS_JWT.apply(jwt))
            .addArgument(uuid).log(
                "Sende Antrag zur Weiterbearbeitung in rvDialog. DrvId [{}], UUID [{}]");

        final Exchange send = antragService.sendeWeiterbearbeitungInDialog(uuid);
        return getOkResponseWithAntragDto(send);
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Bewilligung.
     *
     * @param uuid               des Antrags
     * @param versandErgebnisDto das Ergebnis aus dem Versand eines Dokuments
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST, RVSM_QSTT_PR_FIT_EF })
    @RequiresMandant
    public Response verarbeiteBewilligung(final UUID uuid, @Valid @NotNull final VersandErgebnisDto versandErgebnisDto) {
        azkService.pruefeZugriff(uuid);
        if (!rVFitJsonSchemaValidator.isValid(RestServiceClient.RESTAPI, versandErgebnisDto)) {
            throw new IllegalArgumentException("Kein valides Versandergebnis der Antragsbewilligung angegeben: " + versandErgebnisDto);
        }
        final Antrag antragVersandVerarbeitet = antragService.verarbeiteMitVersandergebnis(uuid, versandErgebnisDto, Art.BEWILLIGUNG);

        antragService.protokolliereFachereignisAntragBeschieden(antragVersandVerarbeitet);

        final Antrag antragAbschluss = producerTemplate.withBody(antragVersandVerarbeitet)
                .to(RVFIT_STATUS_BASED_ROUTING)
                .request(Antrag.class);
        return Response.ok(antragMapper.toDto(antragAbschluss)).build();
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Erledigung auf andere Art und Weise.
     *
     * @param uuid des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response verarbeiteErledigungAufAndereArtUndWeise(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        final Exchange send = producerTemplate
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString())
            .withExchangeProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE)
            .to(RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID).send();

        if (send.isFailed() && send.getException() instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }
        return getOkResponseWithAntragDto(send);
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Rücknahme.
     *
     * @param uuid des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response verarbeiteRuecknahme(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        final Exchange send = producerTemplate
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString())
            .withExchangeProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, Art.RUECKNAHME)
            .to(RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID).send();

        if (send.isFailed() && send.getException() instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }
        return getOkResponseWithAntragDto(send);
    }

    /**
     * Es erfolgt ein Update des Verarbeitungsstatus zur Stornierung.
     *
     * @param uuid des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response verarbeiteStornierung(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        final Exchange send = producerTemplate
            .withHeader(RVFitCamelHeader.ANTRAG_UUID, uuid.toString())
            .withExchangeProperty(RVFitCamelHeader.PROPERTY_ERLEDIGUNGSART, Art.STORNO)
            .to(RouteNames.DIRECT_ERLEDIGUNG_OHNE_BESCHEID).send();

        if (send.isFailed() && send.getException() instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }

        return getOkResponseWithAntragDto(send);
    }

    /**
     * Der Antrag wird bei einer Doppelvergabe in rvSystem:modern weiterverarbeitet.
     *
     * @param uuid des Antrags
     */
    @Override
    @RolesAllowed({ RVSM_QSTT_PR_FIT_BST })
    @RequiresMandant
    public Response verarbeiteDoppelvergabe(final UUID uuid) {
        azkService.pruefeZugriff(uuid);
        antragService.verarbeiteDoppelvergabe(uuid);
        return Response.ok().build();
    }

    private Response getOkResponseWithAntragDto(final Exchange exchange) {
        if (exchange.getMessage().getBody() instanceof AntragDto antragDto) {
            return Response.ok(antragDto).build();
        } else {
            final Antrag antrag = exchange.getMessage().getBody(Antrag.class);
            AntragDto antragDto = antragMapper.toDto(antrag);
            return Response.ok(antragDto).build();
        }
    }
}
