package de.deutscherv.rvsm.fa.fit.log;

/**
 * Enum mit Ereignistexten fuer Fachereignisse.
 * <a href="https://rvwiki.drv.drv/x/74lmHw">Dokumentation Fachprotokoll</a>
 */
public enum Ereignistext {

    /**
     * Antrag eingegangen.
     */
    ANTRAG_EINGEGANGEN("RV Fit-Antrag eingegangen"),

    /**
     * Antrag erfasst.
     */
    ANTRAGSDATEN_GESPEICHERT("RV Fit-Antragsdaten gespeichert"),

    /**
     * Papierantrag zwischengespeichert.
     */
    ANTRAGSDATEN_ZWISCHENGESPEICHERT("RV Fit-Antragsdaten zwischengespeichert"),

    /**
     * Personendaten eingegangen.
     */
    PERSONENDATEN_EINGEGANGEN("Personendaten eingegangen"),

    /**
     * Kontoinformation eingegangen.
     */
    KONTOINFORMATION_EINGEGANGEN("Kontoinformationsdaten eingegangen"),

    /**
     * Einrichtungsdaten eingegangen.
     */
    EINRICHTUNGSDATEN_EINGEGANGEN("Einrichtungsdaten eingegangen"),

    /**
     * Personendaten gespeichert.
     */
    PERSONENDATEN_GESPEICHERT("Personendaten gespeichert"),

    /**
     * Kontoinformation gespeichert.
     */
    KONTOINFORMATION_GESPEICHERT("Kontoinformationsdaten gespeichert"),

    /**
     * Einrichtungsdaten gespeichert.
     */
    EINRICHTUNGSDATEN_GESPEICHERT("Einrichtungsdaten gespeichert"),

    /**
     * Bearbeitung abgeschlossen durch weitere Aktionen.
     */
    BEARBEITUNG_ABGESCHLOSSEN("Bearbeitung abgeschlossen"),

    /**
     * Personendatenprüfung durchgeführt.
     */
    PERSONENDATEN_PRUEFUNG_DURCHGEFUEHRT("Personendatenprüfung durchgeführt"),

    /**
     * Anspruchsprüfung durchgeführt.
     */
    ANSPRUCHS_PRUEFUNG_DURCHGEFUEHRT("Anspruchsprüfung durchgeführt"),

    /**
     * Einrichtungsprüfung durchgeführt.
     */
    EINRICHTUNGS_PRUEFUNG_DURCHGEFUEHRT("Einrichtungsprüfung durchgeführt"),

    /**
     * Prüfung ob Doppelvergabe vorliegt durchgeführt.
     */
    DOPPELVERGABE_PRUEFUNG_DURCHGEFUEHRT("Doppelvergabeprüfung durchgeführt"),

    /**
     * Prüfung ob Bemerkungsfeld leer durchgeführt.
     */
    BEMERKUNG_PRUEFUNG_DURCHGEFUEHRT("Bemerkungsfeldprüfung durchgeführt"),

    /**
     * Bescheid versendet.
     */
    ANTRAG_BESCHIEDEN("RV Fit-Antrag beschieden"),

    /**
     * Statistik gebildet.
     */
    STATISTIK_GEBILDET("Statistik gebildet"),

    /**
     * Antragsdaten aus dem Backend aufgerufen.
     */
    ANTRAGSDATEN_UEBERMITTELT("RV Fit-Antragsdaten übermittelt"),

    /**
     * Dokument zur Sachverhaltsaufklärung erstellt und versendet.
     */
    SACHVERHALTAUFKLAERUNG_DOKUMENT_ERSTELLT("Sachverhaltsaufklärungsdokument erstellt"),

    /**
     * Regelergebnis der Anspruchsprüfung geändert.
     */
    ANSPRUCHSPRUEFUNG_ANGEPASST("Anspruchsprüfungsdaten geändert"),

    /**
     * Einrichtungsprüfung manuell angepasst.
     */
    EINRICHTUNGSPRUEFUNG_ANGEPASST("Einrichtungsdaten geändert"),

    /**
     * Vorgang erzeugt.
     */
    VORGANG_ERZEUGT("Vorgang erstellt"),

    /**
     * Vorgang statistisch erfasst.
     */
    VORGANG_STATISTISCH_ERFASST("Vorgang statistisch erfasst"),

    /**
     * Aufgabe erzeugt.
     */
    AUFGABE_ERZEUGT("Aufgabe erstellt"),

    /**
     * Aufgabe geschlossen.
     */
    AUFGABE_GESCHLOSSEN("Aufgabe geschlossen");

    private final String text;

    Ereignistext(final String text) {
        this.text = text;
    }

    /**
     * Text für ENUM.
     *
     * @return Text
     */
    public String getText() {
        return text;
    }

}
