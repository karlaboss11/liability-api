/**
 * Beinhaltet JPA Entities für Regeln.
 */
package de.deutscherv.rvsm.fa.fit.regelpruefung.model;
