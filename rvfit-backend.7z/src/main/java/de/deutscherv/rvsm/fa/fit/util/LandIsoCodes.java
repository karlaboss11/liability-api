package de.deutscherv.rvsm.fa.fit.util;

import jakarta.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;

/**
 * Enum fuer alle Laender und deren Laendercodes nach: - NTSC - EUROSTAT - ISO 3166-1 alpha-2 - ISO 3166-1 alpha-3 - ISO 3166-1 numerisch.
 */
@Getter
public enum LandIsoCodes {

    /**
     * Andorra.
     */
    ANDORRA("123", "AD", "AD", "AND", "020"),

    /**
     * Vereinigte Arabische Emirate.
     */
    VEREINIGTE_ARABISCHE_EMIRATE("469", "AE", "AE", "ARE", "784"),

    /**
     * Afghanistan.
     */
    AFGHANISTAN("423", "AF", "AF", "AFG", "004"),

    /**
     * Antigua und Barbuda.
     */
    ANTIGUA_UND_BARBUDA("320", "AG", "AG", "ATG", "028"),

    /**
     * Anguilla.
     */
    ANGUILLA("310", "AI", "AI", "AIA", "660"),

    /**
     * Albanien.
     */
    ALBANIEN("121", "AL", "AL", "ALB", "008"),

    /**
     * Armenien.
     */
    ARMENIEN("422", "AM", "AM", "ARM", "051"),

    /**
     * Angola.
     */
    ANGOLA("223", "AO", "AO", "AGO", "024"),

    /**
     * Argentinien.
     */
    ARGENTINIEN("323", "AR", "AR", "ARG", "032"),

    /**
     * Amerikanisch Samoa.
     */
    AMERIKANISCH_SAMOA("517", "AS", "AS", "ASM", "016"),

    /**
     * Österreich.
     */
    OESTERREICH("151", "AT", "AT", "AUT", "040"),

    /**
     * Australien.
     */
    AUSTRALIEN("523", "AU", "AU", "AUS", "036"),

    /**
     * Aruba.
     */
    ARUBA("311", "AW", "AW", "ABW", "533"),

    /**
     * Aserbaidschan.
     */
    AZERBAIDJAN("425", "AZ", "AZ", "AZE", "031"),

    /**
     * Bosnien and Herzegowina.
     */
    BOSNIEN_UND_HERZEGOWINA("122", "BA", "BA", "BIH", "070"),

    /**
     * Barbados.
     */
    BARBADE("322", "BB", "BB", "BRB", "052"),

    /**
     * Bangladesch.
     */
    BANGLADESH("460", "BD", "BD", "BGD", "050"),

    /**
     * Belgien.
     */
    BELGIEN("124", "BE", "BE", "BEL", "056"),

    /**
     * Burkina Faso.
     */
    BURKINA_FASO("258", "BF", "BF", "BFA", "854"),

    /**
     * Bulgarien.
     */
    BULGARIEN("125", "BG", "BG", "BGR", "100"),

    /**
     * Bahrain.
     */
    BAHRAIN("424", "BH", "BH", "BHR", "048"),

    /**
     * Burundi.
     */
    BURUNDI("291", "BI", "BI", "BDI", "108"),

    /**
     * Benin.
     */
    BENIN("229", "BJ", "BJ", "BEN", "204"),

    /**
     * St. Barthelemy.
     */
    SAINT_BARTHELEMY("329", "BL", "BL", "BLM", "652"),

    /**
     * Bermuda.
     */
    BERMUDA("312", "BM", "BM", "BMU", "060"),

    /**
     * Brunei Darussalam.
     */
    BRUNEI("429", "BN", "BN", "BRN", "096"),

    /**
     * Bolivien.
     */
    BOLIVIEN("326", "BO", "BO", "BOL", "068"),

    /**
     * Bonaire, Saba und St. Eustatius.
     */
    KARIBISCHE_NIEDERLANDE("344", "BQ", "BQ", "BES", "535"),

    /**
     * Brasilien.
     */
    BRASILIEN("327", "BR", "BR", "BRA", "076"),

    /**
     * Bahamas.
     */
    BAHAMAS("324", "BS", "BS", "BHS", "044"),

    /**
     * Bhutan.
     */
    BHUTAN("426", "BT", "BT", "BTN", "064"),

    /**
     * Botsuana.
     */
    BOTSWANA("227", "BW", "BW", "BWA", "072"),

    /**
     * Weißrussalnd.
     */
    WEISSRUSSLAND("169", "BY", "BY", "BLR", "112"),

    /**
     * Belize.
     */
    BELIZE("330", "BZ", "BZ", "BLZ", "084"),

    /**
     * Kanada.
     */
    KANADA("348", "CA", "CA", "CAN", "124"),

    /**
     * Kokosinseln.
     */
    KOKOSINSELN("512", "CC", "CC", "CCK", "166"),

    /**
     * Demokratische Republik Kongo.
     */
    DEMOKRATISCHE_REPUBLIK_KONGO("246", "CD", "CD", "COD", "180"),

    /**
     * Zentralafrikanische Republik.
     */
    ZENTRALAFRIKANISCHE_REPUBLIK("289", "CF", "CF", "CAF", "140"),

    /**
     * Kongo.
     */
    REPUBLIK_KONGO("245", "CG", "CG", "COG", "178"),

    /**
     * Schweiz.
     */
    SCHWEIZ("158", "CH", "CH", "CHE", "756"),

    /**
     * Côte d'Ivoire.
     */
    ELFENBEINKUESTE("231", "CI", "CI", "CIV", "384"),

    /**
     * Cookinseln.
     */
    COOKINSELN("527", "CK", "CK", "COK", "184"),

    /**
     * Chile.
     */
    CHILE("332", "CL", "CL", "CHL", "152"),

    /**
     * Kamerun.
     */
    KAMERUN("262", "CM", "CM", "CMR", "120"),

    /**
     * China.
     */
    VOLKSREPUBLIK_CHINA("479", "CN", "CN", "CHN", "156"),

    /**
     * Kolumbien.
     */
    KOLUMBIEN("349", "CO", "CO", "COL", "170"),

    /**
     * Costa Rica.
     */
    COSTA_RICA("334", "CR", "CR", "CRI", "188"),

    /**
     * Kuba.
     */
    KUBA("351", "CU", "CU", "CUB", "192"),

    /**
     * Cabo Verde.
     */
    KAP_VERDE("242", "CV", "CV", "CPV", "132"),

    /**
     * Curacao.
     */
    CURACAO("321", "CW", "CW", "CUW", "531"),

    /**
     * Weihnachtsinsel.
     */
    WEIHNACHTSINSEL("521", "CX", "CX", "CXR", "162"),

    /**
     * Zypern.
     */
    ZYPERN("181", "CY", "CY", "CYP", "196"),

    /**
     * Tschechische Republik.
     */
    TSCHECHIEN("164", "CZ", "CZ", "CZE", "203"),

    /**
     * Deutschland.
     */
    DEUTSCHLAND("000", "DE", "DE", "DEU", "276"),

    /**
     * Dschibuti.
     */
    DSCHIBUTI("230", "DJ", "DJ", "DJI", "262"),

    /**
     * Dänemark.
     */
    DAENEMARK("126", "DK", "DK", "DNK", "208"),

    /**
     * Dominica.
     */
    DOMINICA("333", "DM", "DM", "DMA", "212"),

    /**
     * Dominikanische Republik.
     */
    DOMINIKANISCHE_REPUBLIK("335", "DO", "DO", "DOM", "214"),

    /**
     * Algerien.
     */
    ALGERIEN("221", "DZ", "DZ", "DZA", "012"),

    /**
     * Ecuador.
     */
    ECUADOR("336", "EC", "EC", "ECU", "218"),

    /**
     * Estland.
     */
    ESTLAND("127", "EE", "EE", "EST", "233"),

    /**
     * Ägypten.
     */
    AEGYPTEN("287", "EG", "EG", "EGY", "818"),

    /**
     * Griechenland.
     */
    GRIECHENLAND("134", "EL", "GR", "GRC", "300"),

    /**
     * Eritrea.
     */
    ERITREA("224", "ER", "ER", "ERI", "232"),

    /**
     * Spanien.
     */
    SPANIEN("161", "ES", "ES", "ESP", "724"),

    /**
     * Äthiopien.
     */
    AETHIOPIEN("225", "ET", "ET", "ETH", "231"),

    /**
     * Finnland.
     */
    FINNLAND("128", "FI", "FI", "FIN", "246"),

    /**
     * Fidschi.
     */
    FIDSCHI("526", "FJ", "FJ", "FJI", "242"),

    /**
     * Falklandinseln.
     */
    FALKLANDINSELN("314", "FK", "FK", "FLK", "238"),

    /**
     * Mikronesien.
     */
    MIKRONESIEN("545", "FM", "FM", "FSM", "583"),

    /**
     * Färöer.
     */
    FAEROEER("182", "FO", "FO", "FRO", "234"),

    /**
     * Frankreich.
     */
    FRANKREICH("129", "FR", "FR", "FRA", "250"),

    /**
     * Gabun.
     */
    GABUN("236", "GA", "GA", "GAB", "266"),

    /**
     * Grenada.
     */
    GRENADA("340", "GD", "GD", "GRD", "308"),

    /**
     * Georgien.
     */
    GEORGIEN("430", "GE", "GE", "GEO", "268"),

    /**
     * Französisch-Guayana.
     */
    FRANZOESISCH_GUAYANA("315", "GF", "GF", "GUF", "254"),

    /**
     * Guernsey.
     */
    GUERNESEY("113", "GG", "GG", "GGY", "831"),

    /**
     * Ghana.
     */
    GHANA("238", "GH", "GH", "GHA", "288"),

    /**
     * Gibraltar.
     */
    GIBRALTAR("112", "GI", "GI", "GIB", "292"),

    /**
     * Grönland.
     */
    GROENLAND("342", "GL", "GL", "GRL", "304"),

    /**
     * Gambia.
     */
    GAMBIA("237", "GM", "GM", "GMB", "270"),

    /**
     * Guinea.
     */
    GUINEA("261", "GN", "GN", "GIN", "324"),

    /**
     * Guadeloupe.
     */
    GUADELOUPE("317", "GP", "GP", "GLP", "312"),

    /**
     * Äquatorialguinea.
     */
    AEQUATORIALGUINEA("274", "GQ", "GQ", "GNQ", "226"),

    /**
     * Südgeorgien (u. d. südlichen Sandwichinseln).
     */
    SUEDGEORGIEN_UND_DIE_SUEDLICHEN_SANDWICHINSELN("518", "GS", "GS", "SGS", "239"),

    /**
     * Guatemala.
     */
    GUATEMALA("345", "GT", "GT", "GTM", "320"),

    /**
     * Guam.
     */
    GUAM("529", "GU", "GU", "GUM", "316"),

    /**
     * Guinea-Bissau.
     */
    GUINEA_BISSAU("259", "GW", "GW", "GNB", "624"),

    /**
     * Guyana.
     */
    GUYANA("328", "GY", "GY", "GUY", "328"),

    /**
     * Hongkong.
     */
    HONG_KONG("411", "HK", "HK", "HKG", "344"),

    /**
     * Honduras.
     */
    HONDURAS("347", "HN", "HN", "HND", "340"),

    /**
     * Kroatien.
     */
    KROATIEN("130", "HR", "HR", "HRV", "191"),

    /**
     * Haiti.
     */
    HAITI("346", "HT", "HT", "HTI", "332"),

    /**
     * Ungarn.
     */
    UNGARN("165", "HU", "HU", "HUN", "348"),

    /**
     * Indonesien.
     */
    INDONESIEN("437", "ID", "ID", "IDN", "360"),

    /**
     * Irland.
     */
    IRLAND("135", "IE", "IE", "IRL", "372"),

    /**
     * Israel.
     */
    ISRAEL("441", "IL", "IL", "ISR", "376"),

    /**
     * Insel Man.
     */
    INSEL_MAN("115", "IM", "IM", "IMN", "833"),

    /**
     * Indien.
     */
    INDIEN("436", "IN", "IN", "IND", "356"),

    /**
     * Tschagosinseln.
     */
    BRITISCHES_TERRITORIUM_IM_INDISCHEN_OZEAN("413", "IO", "IO", "IOT", "086"),

    /**
     * Irak.
     */
    IRAK("438", "IQ", "IQ", "IRQ", "368"),

    /**
     * Iran.
     */
    IRAN("439", "IR", "IR", "IRN", "364"),

    /**
     * Island.
     */
    ISLAND("136", "IS", "IS", "ISL", "352"),

    /**
     * Italien.
     */
    ITALIEN("137", "IT", "IT", "ITA", "380"),

    /**
     * Jersey.
     */
    JERSEY("114", "JE", "JE", "JEY", "832"),

    /**
     * Jamaika.
     */
    JAMAIKA("355", "JM", "JM", "JAM", "388"),

    /**
     * Jordanien.
     */
    JORDANIEN("445", "JO", "JO", "JOR", "400"),

    /**
     * Japan.
     */
    JAPAN("442", "JP", "JP", "JPN", "392"),

    /**
     * Kenia.
     */
    KENIA("243", "KE", "KE", "KEN", "404"),

    /**
     * Kirgisistan.
     */
    KIRGISISTAN("450", "KG", "KG", "KGZ", "417"),

    /**
     * Kambodscha.
     */
    KAMBODSCHA("446", "KH", "KH", "KHM", "116"),

    /**
     * Kiribati.
     */
    KIRIBATI("530", "KI", "KI", "KIR", "296"),

    /**
     * Komoren.
     */
    KOMOREN("244", "KM", "KM", "COM", "174"),

    /**
     * St. Kitts und Nevis.
     */
    SAINT_KITTS_AND_NEVIS("370", "KN", "KN", "KNA", "659"),

    /**
     * Korea (Demokratische VR).
     */
    NORDKOREA("434", "KP", "KP", "PRK", "408"),

    /**
     * Korea (Republik).
     */
    SUEDKOREA("467", "KR", "KR", "KOR", "410"),

    /**
     * Kuwait.
     */
    KUWEIT("448", "KW", "KW", "KWT", "414"),

    /**
     * Kaimaninseln.
     */
    KAIMANINSELN("318", "KY", "KY", "CYM", "136"),

    /**
     * Kasachstan.
     */
    KAZAKCHSTAN("444", "KZ", "KZ", "KAZ", "398"),

    /**
     * Laos.
     */
    LAOS("449", "LA", "LA", "LAO", "418"),

    /**
     * Libanon.
     */
    LIBANON("451", "LB", "LB", "LBN", "422"),

    /**
     * St. Lucia.
     */
    SAINT_LUCIA("366", "LC", "LC", "LCA", "662"),

    /**
     * Liechtenstein.
     */
    LIECHTENSTEIN("141", "LI", "LI", "LIE", "438"),

    /**
     * Sri Lanka.
     */
    SRI_LANKA("431", "LK", "LK", "LKA", "144"),

    /**
     * Liberia.
     */
    LIBERIA("247", "LR", "LR", "LBR", "430"),

    /**
     * Lesotho.
     */
    LESOTHO("226", "LS", "LS", "LSO", "426"),

    /**
     * Litauen.
     */
    LITAUEN("142", "LT", "LT", "LTU", "440"),

    /**
     * Luxemburg.
     */
    LUXEMBURG("143", "LU", "LU", "LUX", "442"),

    /**
     * Lettland.
     */
    LETTLAND("139", "LV", "LV", "LVA", "428"),

    /**
     * Libyen.
     */
    LIBYEN("248", "LY", "LY", "LBY", "434"),

    /**
     * Marokko.
     */
    MAROKKO("252", "MA", "MA", "MAR", "504"),

    /**
     * Monaco.
     */
    MONACO("147", "MC", "MC", "MCO", "492"),

    /**
     * Moldau, Republik.
     */
    MOLDAWIEN("146", "MD", "MD", "MDA", "498"),

    /**
     * Montenegro.
     */
    MONTENEGRO("140", "ME", "ME", "MNE", "499"),

    /**
     * St. Martin (franz. Teil).
     */
    SAINT_MARTIN("331", "MF", "MF", "MAF", "534"),

    /**
     * Madagaskar.
     */
    MADAGASKAR("249", "MG", "MG", "MDG", "450"),

    /**
     * Marshallinseln.
     */
    MARSHALLINSELN("544", "MH", "MH", "MHL", "584"),

    /**
     * Nordmazedonien Mazedonien.
     */
    MAZEDONIEN("144", "MK", "MK", "MKD", "807"),

    /**
     * Mali.
     */
    MALI("251", "ML", "ML", "MLI", "466"),

    /**
     * Myanmar.
     */
    MYANMAR("427", "MM", "MM", "MMR", "104"),

    /**
     * Mongolei.
     */
    MONGOLEI("457", "MN", "MN", "MNG", "496"),

    /**
     * Macau.
     */
    MACAU("412", "MO", "MO", "MAC", "446"),

    /**
     * Nördliche Marianen.
     */
    NOERDLICHE_MARIANEN("514", "MP", "MP", "MNP", "580"),

    /**
     * Martinique.
     */
    MARTINIQUE("319", "MQ", "MQ", "MTQ", "474"),

    /**
     * Mauretanien.
     */
    MAURITANIA("239", "MR", "MR", "MRT", "478"),

    /**
     * Montserrat.
     */
    MONTSERRAT("339", "MS", "MS", "MSR", "500"),

    /**
     * Malta.
     */
    MALTA("145", "MT", "MT", "MLT", "470"),

    /**
     * Mauritius.
     */
    MAURITIUS("253", "MU", "MU", "MUS", "480"),

    /**
     * Malediven.
     */
    MALEDIVEN("454", "MV", "MV", "MDV", "462"),

    /**
     * Malawi.
     */
    MALAWI("256", "MW", "MW", "MWI", "454"),

    /**
     * Mexiko.
     */
    MEXIKO("353", "MX", "MX", "MEX", "484"),

    /**
     * Malaysia.
     */
    MALAYSIEN("482", "MY", "MY", "MYS", "458"),

    /**
     * Mosambik.
     */
    MOSAMBIK("254", "MZ", "MZ", "MOZ", "508"),

    /**
     * Namibia.
     */
    NAMIBIA("267", "NA", "NA", "NAM", "516"),

    /**
     * Neukaledonien.
     */
    NEUKALEDONIEN("513", "NC", "NC", "NCL", "540"),

    /**
     * Niger.
     */
    NIGER("255", "NE", "NE", "NER", "562"),

    /**
     * Norfolkinsel.
     */
    NORFOLKINSEL("515", "NF", "NF", "NFK", "574"),

    /**
     * Nigeria.
     */
    NIGERIA("232", "NG", "NG", "NGA", "566"),

    /**
     * Nicaragua.
     */
    NICARAGUA("354", "NI", "NI", "NIC", "558"),

    /**
     * Niederlande.
     */
    NIEDERLANDE("148", "NL", "NL", "NLD", "528"),

    /**
     * Norwegen.
     */
    NORWEGEN("149", "NO", "NO", "NOR", "578"),

    /**
     * Nepal.
     */
    NEPAL("458", "NP", "NP", "NPL", "524"),

    /**
     * Nauru.
     */
    NAURU("531", "NR", "NR", "NRU", "520"),

    /**
     * Niue.
     */
    NIUE("533", "NU", "NU", "NIU", "570"),

    /**
     * Neuseeland.
     */
    NEUSEELAND("536", "NZ", "NZ", "NZL", "554"),

    /**
     * Oman.
     */
    OMAN("456", "OM", "OM", "OMN", "512"),

    /**
     * Panama.
     */
    PANAMA("357", "PA", "PA", "PAN", "591"),

    /**
     * Peru.
     */
    PERU("361", "PE", "PE", "PER", "604"),

    /**
     * Französisch-Polynesien.
     */
    FRANZOESISCH_POLYNESIEN("528", "PF", "PF", "PYF", "258"),

    /**
     * Papua-Neuguinea.
     */
    PAPUA_NEUGUINEA("538", "PG", "PG", "PNG", "598"),

    /**
     * Philippinen.
     */
    PHILIPPINEN("462", "PH", "PH", "PHL", "608"),

    /**
     * Pakistan.
     */
    PAKISTAN("461", "PK", "PK", "PAK", "586"),

    /**
     * Polen.
     */
    POLEN("152", "PL", "PL", "POL", "616"),

    /**
     * St. Pierre und Miquelon.
     */
    SAINT_PIERRE_UND_MIQUELON("338", "PM", "PM", "SPM", "666"),

    /**
     * Pitcairninseln.
     */
    PITCAIRNINSELN("516", "PN", "PN", "PCN", "612"),

    /**
     * Puerto Rico.
     */
    PUERTO_RICO("325", "PR", "PR", "PRI", "630"),

    /**
     * Palästinensische Gebiete.
     */
    PALAESTINA("459", "PS", "PS", "PSE", "275"),

    /**
     * Portugal.
     */
    PORTUGAL("153", "PT", "PT", "PRT", "620"),

    /**
     * Palau.
     */
    PALAU("537", "PW", "PW", "PLW", "585"),

    /**
     * Paraguay.
     */
    PARAGUAY("359", "PY", "PY", "PRY", "600"),

    /**
     * Katar.
     */
    KATAR("447", "QA", "QA", "QAT", "634"),

    /**
     * Reunion.
     */
    REUNION("214", "RE", "RE", "REU", "638"),

    /**
     * Rumänien.
     */
    RUMAENIEN("154", "RO", "RO", "ROU", "642"),

    /**
     * Serbien.
     */
    SERBIEN("170", "RS", "RS", "SRB", "688"),

    /**
     * Russische Förderation.
     */
    RUSSLAND("160", "RU", "RU", "RUS", "643"),

    /**
     * Ruanda.
     */
    RWANDA("265", "RW", "RW", "RWA", "646"),

    /**
     * Saudi-Arabien.
     */
    SAUDI_ARABIEN("472", "SA", "SA", "SAU", "682"),

    /**
     * Salomonen.
     */
    SALOMONEN("524", "SB", "SB", "SLB", "090"),

    /**
     * Seychellen.
     */
    SEYCHELLEN("271", "SC", "SC", "SYC", "690"),

    /**
     * Sudan.
     */
    SUDAN("277", "SD", "SD", "SDN", "729"),

    /**
     * Schweden.
     */
    SCHWEDEN("157", "SE", "SE", "SWE", "752"),

    /**
     * Singapur.
     */
    SINGAPUR("474", "SG", "SG", "SGP", "702"),

    /**
     * St. Helena.
     */
    SINT_HELENA_ASCENSION_UND_TRISTAN_DA_CUNHA("215", "SH", "SH", "SHN", "654"),

    /**
     * Slowenien.
     */
    SLOWENIEN("131", "SI", "SI", "SVN", "705"),

    /**
     * Slowakei.
     */
    SLOWAKEI("155", "SK", "SK", "SVK", "703"),

    /**
     * Sierra Leone.
     */
    SIERRA_LEONE("272", "SL", "SL", "SLE", "694"),

    /**
     * San Marino.
     */
    SAN_MARINO("156", "SM", "SM", "SMR", "674"),

    /**
     * Senegal.
     */
    SENEGAL("269", "SN", "SN", "SEN", "686"),

    /**
     * Somalia.
     */
    SOMALIA("273", "SO", "SO", "SOM", "706"),

    /**
     * Suriname.
     */
    SURINAME("364", "SR", "SR", "SUR", "740"),

    /**
     * Südsudan.
     */
    SUEDSUDAN("278", "SS", "SS", "SSD", "728"),

    /**
     * Sao Tome und Principe.
     */
    SAO_TOME_UND_PRINCIPE("268", "ST", "ST", "STP", "678"),

    /**
     * El Salvador.
     */
    EL_SALVADORTSCHAD("337", "SV", "SV", "SLV", "222"),

    /**
     * St. Marten (niederländ. Teil).
     */
    SINT_MAARTTEN("341", "SX", "SX", "SXM", "663"),

    /**
     * Syrien.
     */
    SYRIEN("475", "SY", "SY", "SYR", "760"),

    /**
     * Eswatini Swasiland.
     */
    ESWATANI("281", "SZ", "SZ", "SWZ", "748"),

    /**
     * Turks- und Caicosinseln.
     */
    TURKS_UND_CAICOSINSELN("350", "TC", "TC", "TCA", "796"),

    /**
     * Tschad.
     */
    TSCHAD("284", "TD", "TD", "TCD", "148"),

    /**
     * Togo.
     */
    TOGO("283", "TG", "TG", "TGO", "768"),

    /**
     * Thailand.
     */
    THAILAND("476", "TH", "TH", "THA", "764"),

    /**
     * Tadschikistan.
     */
    TADSCHIKISTAN("470", "TJ", "TJ", "TJK", "762"),

    /**
     * Tokelau.
     */
    TOKELAU("519", "TK", "TK", "TKL", "772"),

    /**
     * Timor-Leste.
     */
    OSTTIMOR("483", "TL", "TL", "TLS", "626"),

    /**
     * Turkmenistan.
     */
    TURKMENISTAN("471", "TM", "TM", "TKM", "795"),

    /**
     * Tunesien.
     */
    TUNESIEN("285", "TN", "TN", "TUN", "788"),

    /**
     * Tonga.
     */
    TONGA("541", "TO", "TO", "TON", "776"),

    /**
     * Türkei.
     */
    TURKEI("163", "TR", "TR", "TUR", "792"),

    /**
     * Trinidad und Tobago.
     */
    TRINIDAD_UND_TOBAGO("371", "TT", "TT", "TTO", "780"),

    /**
     * Tuvalu.
     */
    TUVALU("540", "TV", "TV", "TUV", "798"),

    /**
     * Taiwan.
     */
    TAIWAN("465", "TW", "TW", "TWN", "158"),

    /**
     * Tansania.
     */
    TANSANIA("282", "TZ", "TZ", "TZA", "834"),

    /**
     * Ukraine.
     */
    UKRAINE("166", "UA", "UA", "UKR", "804"),

    /**
     * Uganda.
     */
    UGANDA("286", "UG", "UG", "UGA", "800"),

    /**
     * Vereinigtes Königreich.
     */
    VEREINIGTES_KOENIGREICH("168", "UK", "GB", "GBR", "826"),

    /**
     * USA.
     */
    VEREINIGTE_STAATEN("368", "US", "US", "USA", "840"),

    /**
     * Uruquay.
     */
    URUGUAY("365", "UY", "UY", "URY", "858"),

    /**
     * Usbekistan.
     */
    USBEKISTAN("477", "UZ", "UZ", "UZB", "860"),

    /**
     * Vatikanstadt.
     */
    VATIKANSTADT("167", "VA", "VA", "VAT", "336"),

    /**
     * St. Vincent u. d. Grenadinen.
     */
    SAINT_VINCENT_UND_DIE_GRENADINEN("369", "VC", "VC", "VCT", "670"),

    /**
     * Venezuela.
     */
    VENEZUELA("367", "VE", "VE", "VEN", "862"),

    /**
     * Britische Jungferninseln.
     */
    BRITISCHE_JUNGFERNINSELN("313", "VG", "VG", "VGB", "092"),

    /**
     * Amerikanische Jungferninseln.
     */
    AMERIKANISCHE_JUNGFERNINSELN("316", "VI", "VI", "VIR", "850"),

    /**
     * Vietnam.
     */
    VIETNAM("432", "VN", "VN", "VNM", "704"),

    /**
     * Vanuatu.
     */
    VANUATU("532", "VU", "VU", "VUT", "548"),

    /**
     * Wallis und Futuna.
     */
    WALLIS_UND_FUTUNA("520", "WF", "WF", "WLF", "876"),

    /**
     * Samoa.
     */
    SAMOA("543", "WS", "WS", "WSM", "882"),

    /**
     * Kosovo.
     */
    KOSOVO("150", "XK", "XK", "XKX", "153"),

    /**
     * Jemen.
     */
    JEMEN("421", "YE", "YE", "YEM", "887"),

    /**
     * Mayotte.
     */
    MAYOTTE("211", "YT", "YT", "MYT", "175"),

    /**
     * Südafrika.
     */
    SUEDAFRIKA("263", "ZA", "ZA", "ZAF", "710"),

    /**
     * Sambia.
     */
    SAMBIA("257", "ZM", "ZM", "ZMB", "894"),

    /**
     * Simbabwe.
     */
    SIMBABWE("233", "ZW", "ZW", "ZWE", "716"),

    /**
     * Unbekanntes Ausland. (Mapping von NTSC zu EUROSTAT/ISO31661 unbekannt, daher exakt wie ungeklärt)
     */
    UNBEKANNTES_AUSLAND("996", "XU", "XU", "XUN", "998"),

    /**
     * Staatenlos.
     */
    STAATENLOS("997", "XS", "XS", "XST", "997"),

    /**
     * Ungeklärt.
     */
    UNGEKLAERT("998", "XU", "XU", "XUN", "998"),

    /**
     * Ohne Angabe. (Mapping von NTSC zu EUROSTAT/ISO31661 unbekannt, daher exakt wie ungeklärt)
     */
    OHNE_ANGABE("999", "XU", "XU", "XUN", "998");

    private static final Map<String, LandIsoCodes> NTSC_MAPPING = new HashMap<>();
    private static final Map<String, LandIsoCodes> EURO_STAT_MAPPING = new HashMap<>();
    private static final Map<String, LandIsoCodes> ALPHA_2_MAPPING = new HashMap<>();
    private static final Map<String, LandIsoCodes> ALPHA_3_MAPPING = new HashMap<>();
    private static final Map<String, LandIsoCodes> NUMERISCH_MAPPING = new HashMap<>();

    private final String ntsc;
    private final String eurostat;
    private final String iso31661Alpha2;
    private final String iso31661Alpha3;
    private final String iso31661Numerisch;

    LandIsoCodes(final String ntsc,
        final String eurostat,
        final String iso31661Alpha2,
        final String iso31661Alpha3,
        final String iso31661Numerisch) {
        this.iso31661Alpha2 = iso31661Alpha2;
        this.iso31661Numerisch = iso31661Numerisch;
        this.iso31661Alpha3 = iso31661Alpha3;
        this.ntsc = ntsc;
        this.eurostat = eurostat;
    }

    /**
     * Laendertypen.
     */
    public enum Typ {
        /**
         * NTSC.
         */
        NTSC,
        /**
         * EUROSTAT.
         */
        EUROSTAT,
        /**
         * ISO_3166_1_ALPHA_2.
         */
        ISO_3166_1_ALPHA_2,
        /**
         * ISO_3166_1_ALPHA_3.
         */
        ISO_3166_1_ALPHA_3,
        /**
         * ISO_3166_1_NUMERISCH.
         */
        ISO_3166_1_NUMERISCH
    }

    static {
        for (final LandIsoCodes value : values()) {
            ALPHA_2_MAPPING.put(value.getIso31661Alpha2(), value);
            NUMERISCH_MAPPING.put(value.getIso31661Numerisch(), value);
            ALPHA_3_MAPPING.put(value.getIso31661Alpha3(), value);
            NTSC_MAPPING.put(value.getNtsc(), value);
            EURO_STAT_MAPPING.put(value.getEurostat(), value);
        }
        NTSC_MAPPING.put("", DEUTSCHLAND);
    }

    /**
     * Gibt fuer einen Code aus einem der Formate ISO 3166-1 alpha-2, ISO 3166-1 alpha-3 oder ISO 3166-1 numerisch, NTSC oder EuroStat das
     * Land zurueck.
     *
     * @param code ein String mit einem Code in einem der Formate: ISO 3166-1 alpha-2, ISO 3166-1 alpha-3 oder ISO 3166-1 numerisch
     * @param typ  der Typ des Laendercodes
     * @return ein Optional mit dem Suchergebnis
     */
    public static Optional<LandIsoCodes> findeLandFuerCode(@Nonnull final String code, @Nonnull final Typ typ) {
        return switch (typ) {
            case ISO_3166_1_ALPHA_2 -> Optional.ofNullable(ALPHA_2_MAPPING.get(code));
            case ISO_3166_1_NUMERISCH -> Optional.ofNullable(NUMERISCH_MAPPING.get(code));
            case ISO_3166_1_ALPHA_3 -> Optional.ofNullable(ALPHA_3_MAPPING.get(code));
            case NTSC -> Optional.ofNullable(NTSC_MAPPING.get(code));
            case EUROSTAT -> Optional.ofNullable(EURO_STAT_MAPPING.get(code));
        };
    }
}

