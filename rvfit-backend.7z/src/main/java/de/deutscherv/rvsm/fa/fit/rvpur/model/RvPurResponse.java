package de.deutscherv.rvsm.fa.fit.rvpur.model;

import de.deutscherv.rvsm.fa.fit.rvpur.openapi.model.AtadDto;
import lombok.Builder;
import lombok.Data;

/**
 * RvPurResponse.
 */
@Data
@Builder
public class RvPurResponse {

    private AtadDto atad;
    private String fehlerFeld;
}
