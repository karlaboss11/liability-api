package de.deutscherv.rvsm.fa.fit.util;

import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.faulttolerance.ExecutionContext;
import org.eclipse.microprofile.faulttolerance.FallbackHandler;

/**
 * TimeoutFallbackHandler.
 */
public class TimeoutFallbackHandler implements FallbackHandler<Response> {

    @Override
    public Response handle(final ExecutionContext executionContext) {
        return Response.status(Response.Status.REQUEST_TIMEOUT).build();
    }
}
