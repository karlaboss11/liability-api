package de.deutscherv.rvsm.fa.fit.util;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.regelpruefung.pruefergebnis.util.PruefergebnisUtils;
import de.deutscherv.rvsm.fa.fit.openapi.model.DokumentenklasseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Prüft die Regel für die Angabe eines Freitextes bei einer Antragsablehnung.
 * Die Validierung lautet: Wenn die Vorlage ABLEHNUNG ist und die Metode isValidForAblehnungFreitext true zurückliefert,
 * dann muss der Freitext mindestens 3 Zeichen lang sein
 */
@ApplicationScoped
public class FreitextAblehnungValidator {

    private final AntragRepository antragRepository;

    /**
     * Konstruktor.
     * @param antragRepository Repository Antraege.
     */
    @Inject
    public FreitextAblehnungValidator(final AntragRepository antragRepository) {
        this.antragRepository = antragRepository;
    }

    /**
     * Führt die Validierung des Freitextes durch.
     * Wenn die Vorlage ABLEHNUNG ist und die Methode isValidForAblehnungFreitext true zurückliefert,
     * dann muss der Freitext mindestens 3 Zeichen lang sein
     * @param uuid des betroffenen Antrags
     * @param dto enthaelt den Freitext
     * @return false Wenn die Vorlage ABLEHNUNG ist, die Metode isValidForAblehnungFreitext true zurückliefert und
     * der Freitext kürzer als 3 Zeichen lang ist, ansonsten true
     */
    public boolean isValid(final UUID uuid, final DokumentenklasseDto dto) {

        if (dto.getVorlage() == DokumentenklasseDto.VorlageEnum.ABLEHNUNG) {
            Optional<Antrag> antrag = antragRepository.findByUuid(uuid);

            if (antrag.isPresent()) {
                final boolean pruefergebnisErfordertFreitextEingabe =
                        PruefergebnisUtils.pruefergebnisErfordertFreitextEingabe(antrag.get());
                final String freitext = Objects.toString(dto.getFreitextVersicherter(), "").trim();

                return !pruefergebnisErfordertFreitextEingabe || freitext.length() >= 3;
            }
        }
        return true;
    }
}
