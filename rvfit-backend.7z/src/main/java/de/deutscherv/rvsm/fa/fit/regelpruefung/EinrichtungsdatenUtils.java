package de.deutscherv.rvsm.fa.fit.regelpruefung;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragAngebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.Angebot;
import de.deutscherv.rvsm.fa.fit.einrichtungen.model.RehaEinrichtung;
import de.deutscherv.rvsm.fa.fit.openapi.model.PhaseEnumDto;
import de.deutscherv.rvsm.fa.fit.util.AnschriftUtils;
import de.deutscherv.rvsm.fa.fit.util.DataProcessingUtils;
import jakarta.ws.rs.NotFoundException;
import lombok.experimental.UtilityClass;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

/**
 * Klasse mit statischen Methoden zur EinrichtungsdatenUtils.
 */
@UtilityClass
public class EinrichtungsdatenUtils {

    private static final String NEWLINE_REGEXP = "\\\\r|\\\\n|\\r\\n";
    private static final String WHITESPACES_REGEXP = "\\s+";
    private static final String CONTAIN_PLZ_REGEXP = ".*\\d{5}.*";
    private static final String CONTAIN_ADRESSE_REGEXP = ".*\\d{1,3}.*";
    private static final String AUFFRISCHUNGSPHASE = "Auffrischungsphase";

    /**
     * Bestimmt die Rehaeinrichtung, die in einem Freitext angegeben wurde.
     *
     * @param freitext            der Freitext
     * @param listOfEinrichtungen die Möglichen Einrichtungen
     * @return die gefundene Einrichtung oder {@code null} wenn keine Einrichtung gefunden wurde.
     */
    public static RehaEinrichtung getUniqueEinrichtungFromFreitext(final String freitext,
                                                                   final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(freitext)) {
            return null;
        }

        final String[] lines = preprocessingFreitext(freitext);

        final String inputName = lines[0];
        final String inputStrasse = AnschriftUtils.getStrasse(lines[1]);
        final String inputHausnummer = AnschriftUtils.getHausnummer(lines[1]);
        final String inputPlz = AnschriftUtils.getPlz(lines[2]);

        RehaEinrichtung uniqueEinrichtung =
                getUniqueEinrichtungByNameAndPlz(inputName, inputPlz, listOfEinrichtungen);
        if (uniqueEinrichtung == null) {
            uniqueEinrichtung = getUniqueEinrichtungByStrasseAndHausnummer(inputStrasse,
                    inputHausnummer, listOfEinrichtungen);
        }
        return uniqueEinrichtung;
    }

    /**
     * Gets the einrichtungen from freitext.
     *
     * @param freitext            the freitext
     * @param listOfEinrichtungen the list of einrichtungen
     * @return the einrichtungen from freitext
     */
    public static List<RehaEinrichtung> getEinrichtungenFromFreitext(final String freitext,
            final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(freitext)) {
            return Collections.emptyList();
        }

        final String[] lines = preprocessingFreitext(freitext);

        final String inputName = lines[0];
        final String inputStrasse = AnschriftUtils.getStrasse(lines[1]);
        final String inputHausnummer = AnschriftUtils.getHausnummer(lines[1]);
        final String inputPlz = AnschriftUtils.getPlz(lines[2]);

        List<RehaEinrichtung> einrichtungen =
                getEinrichtungenByNameAndPlz(inputName, inputPlz, listOfEinrichtungen);
        if (!CollectionUtils.isEmpty((einrichtungen))) {
            return einrichtungen;
        } else {
            einrichtungen = getEinrichtungenByStrasseAndHausnummer(inputStrasse, inputHausnummer,
                    listOfEinrichtungen);
            return (!CollectionUtils.isEmpty((einrichtungen))) ? einrichtungen : null;
        }
    }

    /**
     * Findet Einrichtungen anhand der Angebotsfelder im eAntrag.
     *
     * @param angebot       das Angebot aus dem eAntrag
     * @param einrichtungen die Einrichtungen, die durchsucht werden
     * @return die Einrichtungen, die zum übergebenen Angebot passen
     */
    public static List<RehaEinrichtung> getEinrichtungenFromAngebot(final AntragAngebot angebot,
            final List<RehaEinrichtung> einrichtungen) {
        if (!angebot.freitextFelderGesetzt()) {
            return List.of();
        }

        final var nachNameUndPlz =
                getEinrichtungenByNameAndPlz(angebot.name(), angebot.plz(), einrichtungen);
        if (!nachNameUndPlz.isEmpty()) {
            return nachNameUndPlz;
        }

        final String strasse = AnschriftUtils.getStrasse(angebot.strasse());
        final String hausnr = AnschriftUtils.getHausnummer(angebot.strasse());
        return getEinrichtungenByStrasseAndHausnummer(strasse, hausnr, einrichtungen);
    }

    /**
     * Bestimmt ein Angebot aus einem Antrag.
     *
     * @param phase  die Phase des Angebots
     * @param antrag der Antrag
     * @return das Angebot zur übergebenen Phase
     */
    public static AntragAngebot getAngebot(final PhaseEnumDto phase, final Antrag antrag) {
        return switch (phase) {
            case AUFFRISCHUNG -> new AntragAngebot(antrag.getAngebotAufName(),
                    antrag.getAngebotAufOrt(), antrag.getAngebotAufPlz(),
                    antrag.getAngebotAufStrasse());
            case STARTPHASE -> new AntragAngebot(antrag.getAngebotStartName(),
                    antrag.getAngebotStartOrt(), antrag.getAngebotStartPlz(),
                    antrag.getAngebotStartStrasse());
            case TRAININGSPHASE -> new AntragAngebot(antrag.getAngebotTrainingName(),
                    antrag.getAngebotTrainingOrt(), antrag.getAngebotTrainingPlz(),
                    antrag.getAngebotTrainingStrasse());
        };
    }

    /**
     * Bestimmt die Rehaeinrichtung zu einem Namen und einer PLZ.
     *
     * @param name                der Name
     * @param plz                 die PLZ
     * @param listOfEinrichtungen die Möglichen Einrichtungen
     * @return die gefundene Einrichtung oder {@code null} wenn keine Einrichtung gefunden wurde.
     */
    public static RehaEinrichtung getUniqueEinrichtungByNameAndPlz(final String name,
            final String plz, final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(name) || StringUtils.isBlank(plz)
                || listOfEinrichtungen.isEmpty()) {
            return null;
        }

        final List<RehaEinrichtung> listOfIdentifiedEinrichtungen = listOfEinrichtungen.stream()
                .filter(e -> DataProcessingUtils.matchValues(name, e.getName())
                        && e.getAdresse().getPlz().equalsIgnoreCase(plz))
                .toList();

        return listOfIdentifiedEinrichtungen.size() == 1 ? listOfIdentifiedEinrichtungen.getFirst()
                : null;
    }

    /**
     * Gets the einrichtungen by name and plz.
     *
     * @param name                the name
     * @param plz                 the plz
     * @param listOfEinrichtungen the list of einrichtungen
     * @return the einrichtungen by name and plz
     */
    public static List<RehaEinrichtung> getEinrichtungenByNameAndPlz(final String name,
            final String plz, final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(name) || StringUtils.isBlank(plz)
                || listOfEinrichtungen.isEmpty()) {
            return Collections.emptyList();
        }

        return listOfEinrichtungen.stream()
                .filter(e -> DataProcessingUtils.matchValues(name, e.getName())
                        && e.getAdresse().getPlz().equalsIgnoreCase(plz))
                .toList();
    }

    /**
     * Bestimmt die Rehaeinrichtung zu einer Straße und einer Hausnummer.
     *
     * @param strasse             die Straße
     * @param hausnummer          die Hausnummer
     * @param listOfEinrichtungen die Möglichen Einrichtungen
     * @return die gefundene Einrichtung oder {@code null} wenn keine Einrichtung gefunden wurde.
     */
    public static RehaEinrichtung getUniqueEinrichtungByStrasseAndHausnummer(final String strasse,
            final String hausnummer, final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(strasse) || StringUtils.isBlank(hausnummer)
                || listOfEinrichtungen.isEmpty()) {
            return null;
        }

        final List<RehaEinrichtung> listOfIdentifiedEinrichtungen = listOfEinrichtungen.stream()
                .filter(
                        e -> DataProcessingUtils.matchStrasseValues(strasse, e.getAdresse().getStrasse())
                                && e.getAdresse().getHausnummer().replaceAll(WHITESPACES_REGEXP, "")
                                .equals(hausnummer))
                .toList();

        return listOfIdentifiedEinrichtungen.size() == 1 ? listOfIdentifiedEinrichtungen.getFirst()
                : null;
    }

    /**
     * Gets the einrichtungen by strasse and hausnummer.
     *
     * @param strasse             the strasse
     * @param hausnummer          the hausnummer
     * @param listOfEinrichtungen the list of einrichtungen
     * @return the einrichtungen by strasse and hausnummer
     */
    public static List<RehaEinrichtung> getEinrichtungenByStrasseAndHausnummer(final String strasse,
            final String hausnummer, final List<RehaEinrichtung> listOfEinrichtungen) {
        if (StringUtils.isBlank(strasse) || StringUtils.isBlank(hausnummer)
                || listOfEinrichtungen.isEmpty()) {
            return Collections.emptyList();
        }

        return listOfEinrichtungen.stream().filter(
                        e -> DataProcessingUtils.matchStrasseValues(strasse, e.getAdresse().getStrasse()) && e
                                .getAdresse().getHausnummer().replaceAll(WHITESPACES_REGEXP, "").equals(hausnummer))
                .toList();
    }

    /**
     * Bereitet einen Freitext für die Verarbeitung vor.
     *
     * @param freitext der Freitext
     * @return die Addresszeilen
     */
    private static String[] preprocessingFreitext(final String freitext) {
        String text = freitext.replaceAll(NEWLINE_REGEXP, "\n");
        text = text.replace(",", "\n");
        final Stream<String> streamLines = text.lines();

        final String[] lines = streamLines.toArray(String[]::new);
        final String[] daten = new String[3];

        for (int i = 0; i < lines.length; i++) {
            if (lines[i].matches(CONTAIN_PLZ_REGEXP)) {
                daten[2] = lines[i];
            } else {
                notContainPlzRegexp(i, lines, daten);
            }
        }
        return daten;
    }

    /**
     * Not contain plz regexp.
     *
     * @param i     the i
     * @param lines the lines
     * @param daten the daten
     */
    private void notContainPlzRegexp(final int i, final String[] lines, final String[] daten) {
        if (lines[i].matches(CONTAIN_ADRESSE_REGEXP)) {
            daten[1] = lines[i];
        } else {
            if (daten[0] == null) {
                daten[0] = lines[i];
            } else {
                if (daten[1] == null) {
                    daten[1] = lines[i];
                }
            }
        }
    }

    /**
     * Delete angebote ohne freie plaetze from einrichtung.
     *
     * @param phaseEnum   the phase enum
     * @param einrichtung the einrichtung
     */
    public static void deleteAngeboteOhneFreiePlaetzeFromEinrichtung(final PhaseEnumDto phaseEnum,
            final RehaEinrichtung einrichtung) {
        einrichtung.getAngebote().removeIf(angebot -> nonNull(angebot.getPhase())
                && !angebot.getPhase().equals(EinrichtungsdatenUtils.phaseEnumToSmpPhaseName(phaseEnum))
                || nonNull(angebot.getFreiePlaetzeWert())
                && List.of(-2, -1, 0).contains(angebot.getFreiePlaetzeWert()));
    }

    /**
     * Delete nicht eindeutig angebote from einrichtung.
     *
     * @param phaseEnum         the phase enum
     * @param id                the id
     * @param durchfuehrungsart the durchfuehrungsart
     * @param einrichtung       the einrichtung
     */
    public static void deleteNichtEindeutigAngeboteFromEinrichtung(final PhaseEnumDto phaseEnum,
            final Long id, final String durchfuehrungsart, final RehaEinrichtung einrichtung) {
        einrichtung.getAngebote()
                .removeIf(angebot -> !(angebot.getPhase()
                        .equalsIgnoreCase(EinrichtungsdatenUtils.phaseEnumToSmpPhaseName(phaseEnum))
                        && angebot.getSmpAngebotId().equals(id)
                        && angebot.getDurchfuehrungsart().equalsIgnoreCase(durchfuehrungsart)));
    }

    /**
     * Gets the size eindeutig angebote.
     *
     * @param phaseEnum     the phase enum
     * @param einrichtungen the einrichtungen
     * @return the size eindeutig angebote mit "1 - 3 freie Plätze" oder "mehr als 3 freie Plätze"
     */
    public static boolean eindeutigeAngeboteVorhanden(final PhaseEnumDto phaseEnum,
            final List<RehaEinrichtung> einrichtungen) {
        if (isNull(einrichtungen)) {
            return false;
        }
        return einrichtungen.stream()
                .anyMatch(einr -> angeboteMitFreienPlaetzenVorhanden(phaseEnum, einr));
    }

    /**
     * Pruefung ob Angebote mit freien Plaetzen vorhandnen sind.
     *
     * @param phaseEnum   Betroffene Phase
     * @param einrichtung Zu pruefende Eirichtung
     * @return true - Plaetze vorhanden
     */
    private static boolean angeboteMitFreienPlaetzenVorhanden(final PhaseEnumDto phaseEnum,
            final RehaEinrichtung einrichtung) {
        return einrichtung.getAngebote().stream()
                .anyMatch(angebot -> nonNull(angebot.getPhase())
                        && angebot.getPhase().equals(phaseEnumToSmpPhaseName(phaseEnum))
                        && nonNull(angebot.getFreiePlaetzeWert())
                        && List.of(1, 4).contains(angebot.getFreiePlaetzeWert()));
    }

    /**
     * Gets the size eindeutig angebote.
     *
     * @param phaseEnum     the phase enum
     * @param einrichtungen the einrichtungen
     * @return mindenstens eine Einrichtung mit ambulante Angebote, die sind mehr als 50 Kilometer vom Wohnort des Versicherten enfernt
     */
    public static boolean einrichtungMehrAls50KmUndAmbulanteAngebote(final PhaseEnumDto phaseEnum,
            final List<RehaEinrichtung> einrichtungen) {
        if (isNull(einrichtungen)) {
            return false;
        }
        return einrichtungen.stream()
                .anyMatch(e -> isNull(e.getDistanzVersicherter()) || e.getDistanzVersicherter() > 50
                        && angeboteAmbulantUndAmbulantGanztaetig(phaseEnum, e));
    }

    /**
     * Pruefung ob die Angebote ambulante sind.
     *
     * @param phaseEnum   Betroffene Phase
     * @param einrichtung Zu pruefende Eirichtung
     * @return true - die Einrichtung Angebote sind ambulante
     */
    private static boolean angeboteAmbulantUndAmbulantGanztaetig(final PhaseEnumDto phaseEnum,
            final RehaEinrichtung einrichtung) {
        return einrichtung.getAngebote().stream()
                .anyMatch(angebot -> nonNull(angebot.getPhase())
                        && angebot.getPhase().equals(phaseEnumToSmpPhaseName(phaseEnum))
                        && nonNull(angebot.getDurchfuehrungsart())
                        && nonNull(getDurchfuehrungsartId(angebot.getDurchfuehrungsart()))
                        && List.of(4, 5).contains(getDurchfuehrungsartId(angebot.getDurchfuehrungsart())));
    }

    /**
     * Gets the size eindeutig angebote.
     *
     * @param phaseEnum     the phase enum
     * @param einrichtungen the einrichtungen
     * @return the size eindeutig angebote mit "1 - 3 freie Plätze" oder "mehr als 3 freie Plätze"
     */
    public static int anzahlEindeutigeAngebote(final PhaseEnumDto phaseEnum,
            final List<RehaEinrichtung> einrichtungen) {
        if (isNull(einrichtungen)) {
            return 0;
        }
        int eindeutigeAngebotNr = 0;
        for (final RehaEinrichtung einrichtung : einrichtungen) {
            // wenn die Phase gesetzt ist und den PhaseEnum entspricht und Freieplätze ist 1 oder 4
            // ist
            eindeutigeAngebotNr += (int) anzahlAngeboteMitFreienPlaetzen(phaseEnum, einrichtung);
        }
        return eindeutigeAngebotNr;
    }

    /**
     * Liefert die Anzahl der Angebote mit freien Plätzen.
     *
     * @param phaseEnum   Betroffene Phase
     * @param einrichtung zu pruefenede Einrichtung
     * @return Anzahl der freien Plätze
     */
    private long anzahlAngeboteMitFreienPlaetzen(final PhaseEnumDto phaseEnum,
            final RehaEinrichtung einrichtung) {
        return einrichtung.getAngebote().stream()
                .filter(angebot -> nonNull(angebot.getPhase())
                        && angebot.getPhase().equals(phaseEnumToSmpPhaseName(phaseEnum))
                        && nonNull(angebot.getFreiePlaetzeWert())
                        && List.of(1, 4).contains(angebot.getFreiePlaetzeWert()))
                .count();
    }

    /**
     * Gets the size angebote by freie plaetze.
     *
     * @param phaseEnum        the phase enum
     * @param freiePlaetzeWert the freie plaetze wert
     * @param einrichtungen    the einrichtungen
     * @return the size angebote by freie plaetze
     */
    public static boolean angeboteAnhandPlaetzeVorhanden(final PhaseEnumDto phaseEnum,
            final Integer freiePlaetzeWert, final List<RehaEinrichtung> einrichtungen) {
        if (isNull(einrichtungen)) {
            return false;
        }
        return einrichtungen.stream()
                .anyMatch(einr -> angeboteByFreiePlaetzeVorhanden(phaseEnum, freiePlaetzeWert, einr));
    }

    /**
     * Pruefung ob Angebote mit der Anzahl freien Plaetzen vorhandnen sind.
     *
     * @param phaseEnum        Betroffene Phase
     * @param freiePlaetzeWert Anzah der freien Plaetze
     * @param einrichtung      Zu pruefende Eirichtung
     * @return true - Plaetze vorhanden
     */
    private boolean angeboteByFreiePlaetzeVorhanden(final PhaseEnumDto phaseEnum,
            final Integer freiePlaetzeWert, final RehaEinrichtung einrichtung) {
        return einrichtung.getAngebote().parallelStream().anyMatch(
                angebot -> nonNull(angebot.getPhase()) && nonNull(angebot.getFreiePlaetzeWert())
                        && angebot.getPhase().equals(phaseEnumToSmpPhaseName(phaseEnum))
                        && angebot.getFreiePlaetzeWert().equals(freiePlaetzeWert));
    }

    /**
     * Gets the eindeutige einrichtung.
     *
     * @param einrichtungen     the einrichtungen
     * @param phaseEnum         the phase enum
     * @param id                the id
     * @param durchfuehrungsart the durchfuehrungsart
     * @return the eindeutige einrichtung
     */
    public static RehaEinrichtung getEindeutigeEinrichtung(
            final List<RehaEinrichtung> einrichtungen, final PhaseEnumDto phaseEnum, final Long id,
            final String durchfuehrungsart) {
        return einrichtungen.stream()
                .filter(einrichtung -> einrichtung.getAngebote().stream()
                        .anyMatch(angebot -> angebot.getSmpAngebotId().equals(id)
                                && angebot.getPhase().equals(phaseEnumToSmpPhaseName(phaseEnum))
                                && angebot.getDurchfuehrungsart().equalsIgnoreCase(durchfuehrungsart)))
                .findFirst().orElseThrow(NotFoundException::new);
    }

    /**
     * Gets the eindeutige auf angebot.
     *
     * @param einrichtung       the smp start einrichtung
     * @param durchfuehrungsart the durchfuehrungsart
     * @return eindeutiges Angebot
     */
    public static Angebot getEindeutigeAufAngebot(final RehaEinrichtung einrichtung,
                                                  final String durchfuehrungsart) {
        final Angebot aufAngebotDurchfuehrungsart = einrichtung.getAngebote().stream()
                .filter(a -> a.getPhase().equals(AUFFRISCHUNGSPHASE)
                        && a.getDurchfuehrungsart().equalsIgnoreCase(durchfuehrungsart))
                .findFirst().orElse(null);
        if (isNull(aufAngebotDurchfuehrungsart)) {
            final List<Angebot> aufAngebote = einrichtung.getAngebote().stream()
                    .filter(a -> a.getPhase().equals(AUFFRISCHUNGSPHASE)).toList();
            if (aufAngebote.size() != 1) {
                return null;
            }
            return aufAngebote.getFirst();
        }
        return aufAngebotDurchfuehrungsart;
    }

    /**
     * Phase enum to smp phase name.
     *
     * @param phaseEnum the phase enum
     * @return the string
     */
    public static String phaseEnumToSmpPhaseName(final PhaseEnumDto phaseEnum) {
        return switch (phaseEnum) {
            case STARTPHASE -> "Startphase";
            case AUFFRISCHUNG -> AUFFRISCHUNGSPHASE;
            case TRAININGSPHASE -> "Trainingsphase";
            default -> throw new IllegalArgumentException(phaseEnum.name());
        };
    }

    /**
     * Mappt den Namen einer Durchführunsgart auf die Id für die Suche.
     *
     * @param durchfuehrungsart der Name der Durchführunsgart
     * @return die Id der Durchfüherungsart, oder 0, wenn der Name ungültig ist
     */
    public static Integer getDurchfuehrungsartId(final String durchfuehrungsart) {
        if (isNull(durchfuehrungsart)) {
            return null;
        }
        return switch (durchfuehrungsart) {
            case "Ambulant" -> 4;
            case "Ambulant (ganztägig)" -> 5;
            case "online" -> 6;
            case "stationär" -> 7;
            default -> null;
        };
    }

    /**
     * Prüft ob alle Einrichtungen im Antrag gesetzt sind. D.h. für Start-, Trainings- und Auffrischungspahse muss entweder der Freitext
     * oder die SMP AngebotsId gesetzt sein.
     *
     * @param antrag der Antrag
     * @return {@code true}, wenn die Einrichtungen nicht {@code null} sind
     */
    public static boolean alleEinrichtungenVorhanden(final Antrag antrag) {
        if (keinStartAufVorhanden(antrag)) {
            return false;
        }

        final var angebotTraining = getAngebot(PhaseEnumDto.TRAININGSPHASE, antrag);
        return angebotTraining.freitextFelderGesetzt() || antrag.getAngebotTrainingSmpId() != null;
    }

    /**
     * Prüft, ob keine Einrichtungen im antrag gesetzt sind. D.h. für Start-, Trainings- und Auffrischungsphase ist weder der Freitext noch
     * die AngebotsId gesetzt
     *
     * @param antrag der Antrag
     * @return {@code true}, wenn die alle Einrichtungen {@code null} sind
     */
    public static boolean keineEinrichtungenVorhanden(final Antrag antrag) {
        final var angebotStart = getAngebot(PhaseEnumDto.STARTPHASE, antrag);
        final var angebotAuffrischung = getAngebot(PhaseEnumDto.AUFFRISCHUNG, antrag);
        final var angebotTraining = getAngebot(PhaseEnumDto.TRAININGSPHASE, antrag);

        if (angebotStart.freitextFelderGesetzt() || angebotAuffrischung.freitextFelderGesetzt()
                || angebotTraining.freitextFelderGesetzt()) {
            return false;
        }
        return antrag.getAngebotStartSmpId() == null && antrag.getAngebotTrainingSmpId() == null
                && antrag.getAngebotAufSmpId() == null;
    }

    /**
     * Prüft, ob keine Einrichtungen fuer die Start-/Auffrischungsphase gesetzt sind.
     *
     * @param antrag der Antrag
     * @return {@code true}, wenn alle Einrichtungen {@code null} sind
     */
    private static boolean keinStartAufVorhanden(final Antrag antrag) {
        final var angebotStart = getAngebot(PhaseEnumDto.STARTPHASE, antrag);
        final var angebotAuffrischung = getAngebot(PhaseEnumDto.AUFFRISCHUNG, antrag);
        if (angebotStart.freitextFelderGesetzt() || angebotAuffrischung.freitextFelderGesetzt()) {
            return false;
        }

        return antrag.getAngebotAufSmpId() == null && antrag.getAngebotStartSmpId() == null;
    }
}
