package de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.constants.RVFitCamelHeader;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.enricher.PapierantragEinrichtungenEnricher;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.PapierantragZuEntityMapper;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.AntragStatusStatistikAbgeschlossenProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragEntferneEntwurfProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragEntwurfFachprotokollProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragEntwurfSpeichernProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragEntwurfValidierungProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragErledigungAufAndereArtUndWeiseProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragSchliesseAufgabeProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragSpeichernProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragValidierungProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragVerarbeitungRuecknahmeProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.PapierantragWeiterbearbeitungInRvDialogProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.StatistikErfassungsProcessor;
import de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor.erledigungohnebescheid.ErstelleVerarbeitungsStatusErledigungOhneBescheidProcessor;
import de.deutscherv.rvsm.fa.fit.fehler.orchestration.ExceptionHandler;
import de.deutscherv.rvsm.fa.fit.jms.MessagingException;
import de.deutscherv.rvsm.fa.fit.statistik.StatistikException;
import de.deutscherv.rvsm.fa.fit.util.DauerMetricUtil;
import de.deutscherv.rvsm.fa.fit.util.MetricNames;
import de.deutscherv.rvsm.fa.fit.verarbeitung.model.Art;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.RequestContextController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.mapper.PapierantragZuEntityMapper.DIRECT_PAPIERANTRAG_ZU_ENTITY;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_EXTRACT_MANDANT;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_KONTOINFORMATIONEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_FETCH_STAMMDATEN;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_MERGE_EANTRAG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG;
import static de.deutscherv.rvsm.fa.fit.antraege.orchestration.routes.RouteNames.RVFIT_STATUS_BASED_ROUTING;
import static de.deutscherv.rvsm.fa.fit.fehler.orchestration.FehlerRoutes.DIRECT_ERROR;
import static org.apache.camel.support.builder.PredicateBuilder.and;

/**
 * Routen Papierantrag.
 */
@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class PapierantragRoutes extends RouteBuilder {
    /**
     * Routenname fuer Erstelle Papierantrag ohne Antragserfassung und ohne Regelpruefung asyncron Abschluss.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS =
            "direct:createPapierantragOhneAntragserfassungOhneRegelpruefungAsyncAbschluss";
    /**
     * Routenname fuer erstelle Papierantrag.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG = "direct:createPapierantrag";
    /**
     * Routenname fuer erstelle Papierantrag asynchroner Abschluss.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS = "direct:createPapierantragAsyncAbschluss";
    /**
     * Routenname fuer erstelle Papierantrag ohne Regelpruefung asynchron Abschluss.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS =
            "direct:createPapierantragOhneRegelpruefungAsyncAbschluss";
    /**
     * Routenname fuer erstelle Papierantrag ohne Antragserfassung und Weiterbearbeitung in rvDialog.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG =
            "direct:createPapierantragOhneAntragserfassungUndVerarbeiteWeiterbearbeitungInRvDialog";
    /**
     * Routenname fuer erstelle Papierantragentwurf.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_ENTWURF = "direct:createPapierantragEntwurf";
    /**
     * Routenname fuer erstelle Papierantrag und Erledung auf andere Art und Weise.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_UND_ERLEDIGE_AUF_ANDERE_ART_UND_WEISE =
            "direct:createPapierantragUndErledigeOhneBescheid";
    /**
     * Routenname fuer erstelle Papierantrag und verarbeite Ruecknahme.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_RUECKNAHME = "direct:createPapierantragUndVerarbeiteRuecknahme";
    /**
     * Routenname fuer erstelle Papierantrag und Weiterbearbeitung in rvDialog.
     */
    public static final String DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG =
            "direct:createPapierantragUndVerarbeiteWeiterbearbeitungInRvDialog";
    /**
     * Routenname fuer Antragstatus auf Statistik abgeschlossen setzen.
     */
    public static final String DIRECT_SET_ANTRAG_STATUS_STATISTIK_ABGESCHLOSSEN =
            "direct:setAntragStatusStatistikAbgeschlossen";
    /**
     * Routenname fuer Verarbeitungsstatus auf Erledigung ohne Bescheid setzen.
     */
    public static final String DIRECT_ERSTELLE_VERARBEITUNGSSTATUS_ERLEDIGUNG_OHNE_BESCHEID =
            "direct:erstelleVerarbeitungsStatusErledigungOhneBescheid";

    private static final String BODY = "${body}";
    private static final String DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG = "direct:createPapierantragOhneRegelpruefung";
    private static final String DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_ENTWURF_UND_LADE_EINRICHTUNG =
            "direct:validiereUndSpeicherePapierantragEntwurfMitEinrichtung";
    private static final String DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG = "direct:validiereUndSpeicherePapierantrag";
    private static final String DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_UND_LADE_EINRICHTUNG =
            "direct:validiereUndSpeicherePapierantragMitEinrichtung";
    private static final String DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG =
            "direct:createPapierantragOhneAntragserfassungOhneRegelpruefung";

    private final PapierantragValidierungProcessor papierantragValidierungProcessor;
    private final PapierantragEntwurfValidierungProcessor papierantragEntwurfValidierungProcessor;
    private final PapierantragZuEntityMapper papierantragZuEntityMapper;
    private final PapierantragEntferneEntwurfProcessor papierantragEntferneEntwurfProcessor;
    private final PapierantragSpeichernProcessor papierantragSpeichernProcessor;
    private final PapierantragEntwurfSpeichernProcessor papierantragEntwurfSpeichernProcessor;
    private final PapierantragEinrichtungenEnricher papierantragEinrichtungenEnricher;
    private final PapierantragSchliesseAufgabeProcessor papierantragSchliesseAufgabeProcessor;
    private final PapierantragEntwurfFachprotokollProcessor papierantragEntwurfFachprotokollProcessor;
    private final PapierantragErledigungAufAndereArtUndWeiseProcessor papierantragErledigungAufAndereArtUndweiseProcessor;
    private final PapierantragVerarbeitungRuecknahmeProcessor papierantragVerarbeitungRuecknahmeProcessor;
    private final PapierantragWeiterbearbeitungInRvDialogProcessor papierantragWeiterbearbeitungInRvDialogProcessor;
    private final ErstelleVerarbeitungsStatusErledigungOhneBescheidProcessor erstelleVerarbeitungsStatusErledigungOhneBescheidProcessor;
    private final StatistikErfassungsProcessor statistikErfassungsProcessor;
    private final AntragStatusStatistikAbgeschlossenProcessor antragStatusStatistikAbgeschlossenProcessor;
    private final ExceptionHandler exceptionHandler;
    private final RequestContextController requestContextController;
    private final DauerMetricUtil dauerMetricUtil;

    @Override
    public void configure() throws Exception {
        // @formatter:off
        from(DIRECT_CREATE_PAPIERANTRAG)
                .routeId(DIRECT_CREATE_PAPIERANTRAG)

                // Transaktion: Start
                .to(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_UND_LADE_EINRICHTUNG)
                // Transaktion: Ende

                // Transaktion: Start
                .to(PapierantragSchliesseAufgabeProcessor.DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN)
                // Transaktion: Ende
                .wireTap(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS);

        from(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_ASYNC_ABSCHLUSS)
                .process(ex -> requestContextController.activate())
                .to(DIRECT_EXTRACT_MANDANT)
                .doTry()
                    .to(DIRECT_FETCH_STAMMDATEN)
                    .choice()
                    .when(header(RVFitCamelHeader.STAMMDATEN_BESTANDSFEHLER).isNull())
                        .to(DIRECT_FETCH_KONTOINFORMATIONEN)
                    .end()
                    .choice()
                    .when(and(header(RVFitCamelHeader.KONTOINFORMATION_BESTANDSFEHELR).isNull(),
                            header(RVFitCamelHeader.STAMMDATEN_BESTANDSFEHLER).isNull()))
                        .to(StatistikErfassungsProcessor.DIRECT_ERFASSE_STATISTIK_PAPIERANTRAG)
                    .end()
                    .to(RVFIT_STATUS_BASED_ROUTING)
                .endDoTry()
                .doCatch(Exception.class)
                    .log(LoggingLevel.WARN, LOG, "${body.uuid} : ${body}")
                    .to(DIRECT_ERROR)
                .end();

        from(DIRECT_CREATE_PAPIERANTRAG_ENTWURF)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_ENTWURF)
                // Transaktion: Start
                .to(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_ENTWURF_UND_LADE_EINRICHTUNG)
                // Transaktion: Ende
                .to(PapierantragEntwurfFachprotokollProcessor.DIRECT_PAPIERANTRAG_ENTWURF_FACHPROTOKOLL)
                .end();

        from(DIRECT_CREATE_PAPIERANTRAG_UND_ERLEDIGE_AUF_ANDERE_ART_UND_WEISE)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_UND_ERLEDIGE_AUF_ANDERE_ART_UND_WEISE)
                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE)
                .to(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG);

        from(DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_RUECKNAHME)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_RUECKNAHME)
                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE)
                .to(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG);

        from(DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE)
                .to(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG);

        from(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_UND_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE)
                .to(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG);

        from(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_UND_LADE_EINRICHTUNG)
                .routeId(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_UND_LADE_EINRICHTUNG)
                .transacted()
                .to(PapierantragValidierungProcessor.DIRECT_PAPIERANTRAG_VALIDIERUNG)
                .to(DIRECT_PAPIERANTRAG_ZU_ENTITY)

                .to(MetricRouteDefinitions.METRIC_COUNTER_EINGEHENDE_PAPIERANTRAEGE)
                .process(ex -> dauerMetricUtil.startTimerMetric(MetricNames.PAPIERANTRAG_DAUER.getName(), ex))

                .to(PapierantragEntferneEntwurfProcessor.DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF)
                .to(DIRECT_EXTRACT_MANDANT)
                .to(PapierantragSpeichernProcessor.DIRECT_PAPIERANTRAG_SPEICHERN)
                .to(PapierantragEinrichtungenEnricher.DIRECT_PAPIERANTRAG_EINRICHTUNGEN_HINZUFUEGEN)
                .log(BODY);

        from(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG)
                .routeId(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG)
                .transacted()
                .to(PapierantragValidierungProcessor.DIRECT_PAPIERANTRAG_VALIDIERUNG)
                .to(DIRECT_PAPIERANTRAG_ZU_ENTITY)
                .to(PapierantragEntferneEntwurfProcessor.DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF)
                .to(DIRECT_EXTRACT_MANDANT)
                .to(PapierantragSpeichernProcessor.DIRECT_PAPIERANTRAG_SPEICHERN)
                .log(BODY);

        from(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG)
                // Transaktion: Start
                .to(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG)
                // Transaktion: Ende

                // Transaktion: Start
                .to(PapierantragSchliesseAufgabeProcessor.DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN)
                // Transaktion: Ende
                .wireTap(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS);

        from(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS)
                .process(ex -> requestContextController.activate())
                .to(DIRECT_EXTRACT_MANDANT)
                .process(exchange -> {
                    final var antrag = exchange.getMessage().getBody(Antrag.class);
                    antrag.setStatus(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
                    exchange.getMessage().setBody(antrag);
                })
                .to(DIRECT_MERGE_EANTRAG)
                .to(DIRECT_ERSTELLE_VERARBEITUNGSSTATUS_ERLEDIGUNG_OHNE_BESCHEID)
                .to(StatistikErfassungsProcessor.DIRECT_ERFASSE_STATISTIK_PAPIERANTRAG)
                .choice()
                .when(exchange -> exchange.getMessage().getBody(Antrag.class)
                        .getStatus() == AntragStatus.STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN)
                    .to(RVFIT_STATUS_BASED_ROUTING)
                .endChoice()
                .end()
                .choice()
                .when(header(RVFitCamelHeader.ERLEDIGUNG_OHNE_BESCHEID_ART).isEqualTo(Art.ERLEDIGUNG_ANDERE_ART_UND_WEISE))
                    .to(PapierantragErledigungAufAndereArtUndWeiseProcessor
                        .DIRECT_PAPIERANTRAG_VERARBEITE_ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE)
                .when(header(RVFitCamelHeader.ERLEDIGUNG_OHNE_BESCHEID_ART).isEqualTo(Art.RUECKNAHME))
                    .to(PapierantragVerarbeitungRuecknahmeProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_RUECKNAHME)
                .when(header(RVFitCamelHeader.ERLEDIGUNG_OHNE_BESCHEID_ART).isEqualTo(Art.WEITERBEARBEITUNG_IN_RVDIALOG))
                    .to(PapierantragWeiterbearbeitungInRvDialogProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .endChoice()
                .end();

        from(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG)
                // Transaktion: Start
                .to(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG)
                // Transaktion: Ende

                // Transaktion: Start
                .to(PapierantragSchliesseAufgabeProcessor.DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN)
                // Transaktion: Ende
                .wireTap(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS);

        from(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS)
                .routeId(DIRECT_CREATE_PAPIERANTRAG_OHNE_ANTRAGSERFASSUNG_OHNE_REGELPRUEFUNG_ASYNC_ABSCHLUSS)
                .process(ex -> requestContextController.activate())
                .to(DIRECT_EXTRACT_MANDANT)
                .process(exchange -> {
                    final var antrag = exchange.getMessage().getBody(Antrag.class);
                    antrag.setStatus(AntragStatus.KONTOINFORMATION_ABGEFRAGT);
                    exchange.getMessage().setBody(antrag);
                })
                .to(DIRECT_MERGE_EANTRAG)
                .to(DIRECT_ERSTELLE_VERARBEITUNGSSTATUS_ERLEDIGUNG_OHNE_BESCHEID)
                .to(DIRECT_SET_ANTRAG_STATUS_STATISTIK_ABGESCHLOSSEN);


        from(DIRECT_SET_ANTRAG_STATUS_STATISTIK_ABGESCHLOSSEN)
                .routeId(DIRECT_SET_ANTRAG_STATUS_STATISTIK_ABGESCHLOSSEN)
                .process(antragStatusStatistikAbgeschlossenProcessor);


        from(PapierantragValidierungProcessor.DIRECT_PAPIERANTRAG_VALIDIERUNG)
                .routeId(PapierantragValidierungProcessor.DIRECT_PAPIERANTRAG_VALIDIERUNG)
                .transacted()
                .process(papierantragValidierungProcessor);

        from(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_ENTWURF_UND_LADE_EINRICHTUNG)
                .routeId(DIRECT_VALIDIERE_UND_SPEICHERE_PAPIERANTRAG_ENTWURF_UND_LADE_EINRICHTUNG)
                .transacted()
                .to(PapierantragEntwurfValidierungProcessor.DIRECT_PAPIERANTRAG_ENTWURF_VALIDIERUNG)
                .to(DIRECT_PAPIERANTRAG_ZU_ENTITY)
                .to(PapierantragEntferneEntwurfProcessor.DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF)
                .to(DIRECT_EXTRACT_MANDANT)
                .to(PapierantragEntwurfSpeichernProcessor.DIRECT_PAPIERANTRAG_ENTWURF_SPEICHERN)
                .to(PapierantragEinrichtungenEnricher.DIRECT_PAPIERANTRAG_EINRICHTUNGEN_HINZUFUEGEN)
                .log(BODY);

        from(PapierantragEntwurfValidierungProcessor.DIRECT_PAPIERANTRAG_ENTWURF_VALIDIERUNG)
                .routeId(PapierantragEntwurfValidierungProcessor.DIRECT_PAPIERANTRAG_ENTWURF_VALIDIERUNG)
                .transacted()
                .process(papierantragEntwurfValidierungProcessor);

        from(DIRECT_PAPIERANTRAG_ZU_ENTITY)
                .routeId(DIRECT_PAPIERANTRAG_ZU_ENTITY)
                .transacted()
                .process(papierantragZuEntityMapper);

        from(PapierantragEntferneEntwurfProcessor.DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF)
                .routeId(PapierantragEntferneEntwurfProcessor.DIRECT_PAPIERANTRAG_ENTFERNE_ENTWURF)
                .transacted()
                .process(papierantragEntferneEntwurfProcessor);

        from(PapierantragSpeichernProcessor.DIRECT_PAPIERANTRAG_SPEICHERN)
                .routeId(PapierantragSpeichernProcessor.DIRECT_PAPIERANTRAG_SPEICHERN)
                .transacted()
                .process(papierantragSpeichernProcessor);

        from(PapierantragEntwurfSpeichernProcessor.DIRECT_PAPIERANTRAG_ENTWURF_SPEICHERN)
                .routeId(PapierantragEntwurfSpeichernProcessor.DIRECT_PAPIERANTRAG_ENTWURF_SPEICHERN)
                .transacted()
                .process(papierantragEntwurfSpeichernProcessor);

        from(PapierantragEinrichtungenEnricher.DIRECT_PAPIERANTRAG_EINRICHTUNGEN_HINZUFUEGEN)
                .routeId(PapierantragEinrichtungenEnricher.DIRECT_PAPIERANTRAG_EINRICHTUNGEN_HINZUFUEGEN)
                .transacted()
                .process(papierantragEinrichtungenEnricher);

        from(PapierantragSchliesseAufgabeProcessor.DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN)
                .routeId(PapierantragSchliesseAufgabeProcessor.DIRECT_PAPIERANTRAG_AUFGABE_SCHLIESSEN)
                .transacted()
                .doTry()
                .process(papierantragSchliesseAufgabeProcessor)
                .doCatch(MessagingException.class)
                .log("Fehlerbehandlung: ${exception.message}")
                .process(exceptionPreHandlingEnricher())
                .process(exceptionHandler)
                .end();

        from(StatistikErfassungsProcessor.DIRECT_ERFASSE_STATISTIK_PAPIERANTRAG)
                .routeId(StatistikErfassungsProcessor.DIRECT_ERFASSE_STATISTIK_PAPIERANTRAG)
                .transacted()
                .doTry()
                    .process(statistikErfassungsProcessor)
                .doCatch(StatistikException.class)
                    .log("Fehlerbehandlung: ${exception.message}")
                    .process(exceptionPreHandlingEnricher())
                    .process(exceptionHandler)
                .end();

        from(PapierantragEntwurfFachprotokollProcessor.DIRECT_PAPIERANTRAG_ENTWURF_FACHPROTOKOLL)
                .routeId(PapierantragEntwurfFachprotokollProcessor.DIRECT_PAPIERANTRAG_ENTWURF_FACHPROTOKOLL)
                .transacted()
                .process(papierantragEntwurfFachprotokollProcessor);

        from(PapierantragErledigungAufAndereArtUndWeiseProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE)
                .routeId(PapierantragErledigungAufAndereArtUndWeiseProcessor
                    .DIRECT_PAPIERANTRAG_VERARBEITE_ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE)
                .transacted()
                .process(papierantragErledigungAufAndereArtUndweiseProcessor)
                .to(DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID);

        from(PapierantragVerarbeitungRuecknahmeProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_RUECKNAHME)
                .routeId(PapierantragVerarbeitungRuecknahmeProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_RUECKNAHME)
                .transacted()
                .process(papierantragVerarbeitungRuecknahmeProcessor)
                .to(DIRECT_PAPIERANTRAG_ERFASSEN_ERLEDIGUNG_OHNE_BESCHEID);

        from(PapierantragWeiterbearbeitungInRvDialogProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .routeId(PapierantragWeiterbearbeitungInRvDialogProcessor.DIRECT_PAPIERANTRAG_VERARBEITE_WEITERBEARBEITUNG_IN_RV_DIALOG)
                .transacted()
                .process(papierantragWeiterbearbeitungInRvDialogProcessor)
                .to(DIRECT_PAPIERANTRAG_ERFASSEN_WEITERBEARBEITUNG_IN_RV_DIALOG);

        from(DIRECT_ERSTELLE_VERARBEITUNGSSTATUS_ERLEDIGUNG_OHNE_BESCHEID)
                .routeId(DIRECT_ERSTELLE_VERARBEITUNGSSTATUS_ERLEDIGUNG_OHNE_BESCHEID)
                .transacted()
                .process(erstelleVerarbeitungsStatusErledigungOhneBescheidProcessor);
        // @formatter:on
    }

    private Processor exceptionPreHandlingEnricher() {
        return exchange -> {
            Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
            exchange.getMessage().setHeader(RVFitCamelHeader.ERROR_MESSAGE, exception.getMessage());
            exchange.setProperty(Exchange.EXCEPTION_CAUGHT, exception);
        };
    }
}
