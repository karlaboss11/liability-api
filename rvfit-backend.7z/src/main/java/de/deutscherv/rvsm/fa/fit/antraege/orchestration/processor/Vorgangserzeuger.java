package de.deutscherv.rvsm.fa.fit.antraege.orchestration.processor;

import de.deutscherv.rvsm.fa.fit.antraege.model.Antrag;
import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.antraege.repository.AntragRepository;
import de.deutscherv.rvsm.fa.fit.rvpur.RvPurService;
import de.deutscherv.rvsm.fa.fit.util.LoggingUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Vorgangserzeuger.
 */
@ApplicationScoped
@Slf4j
public class Vorgangserzeuger implements Processor {
    private final RvPurService rvPurService;
    private final boolean schedulerEnabled;
    private final AntragRepository antragRepository;

    /**
     * Konstruktor.
     *
     * @param rvPurService     rvPuR-Service
     * @param schedulerEnabled true wenn Scheduler aktive
     * @param antragRepository Antrag-Repository
     */
    @Inject
    Vorgangserzeuger(final RvPurService rvPurService,
        @ConfigProperty(name = "quarkus.scheduler.enabled", defaultValue = "true") final boolean schedulerEnabled,
        final AntragRepository antragRepository) {
        this.rvPurService = rvPurService;
        this.schedulerEnabled = schedulerEnabled;
        this.antragRepository = antragRepository;
    }

    @Override
    public void process(final Exchange exchange) throws Exception {
        var antrag = exchange.getMessage().getBody(Antrag.class);
        LoggingUtils.logProcessorAntrag(exchange.getFromRouteId(), getClass().getSimpleName(), antrag);
        LOG.atInfo()
            .addArgument(antrag.getUuid())
            .addArgument(antrag.getKtan())
            .addArgument(antrag.getVsnr())
            .log("Vorgangserzeuger UUID [{}] KTAN [{}] VSNR [{}]");
        rvPurService.sendeRvPurVorgang(antrag);
        if (!schedulerEnabled) {
            antrag.setStatus(AntragStatus.VORGANG_ERZEUGT);
        } else {
            antrag.setStatus(AntragStatus.VORGANG_WIRD_ERSTELLT);
        }
        antrag = antragRepository.merge(antrag);
        antragRepository.flush();
        exchange.getMessage().setBody(antrag);
    }
}
