package de.deutscherv.rvsm.fa.fit.stammdaten;

import de.deutscherv.rvsm.fa.fit.exceptions.RvfitException;
import java.io.Serial;

/**
 * StammdatenException.
 */
public class StammdatenException extends RvfitException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor.
     *
     * @param message Fehlernachricht
     */
    public StammdatenException(final String message) {
        super(message);
    }
}