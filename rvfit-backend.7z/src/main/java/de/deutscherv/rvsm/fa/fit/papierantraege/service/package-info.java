/**
 * Beinhaltet Klassen, die sich mit Papieranträgen beschäftigen.
 */
package de.deutscherv.rvsm.fa.fit.papierantraege.service;
