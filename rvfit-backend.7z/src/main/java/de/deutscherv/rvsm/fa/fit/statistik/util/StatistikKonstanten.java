package de.deutscherv.rvsm.fa.fit.statistik.util;

/**
 * Konstanten im Statistikumfeld.
 */
public class StatistikKonstanten {

    /**
     * Text Auffrischungsphase.
     */
    public static final String AUFFRISCHUNGSPHASE = "Auffrischungsphase";

    /**
     * Text SERVERFEHLER.
     */
    public static final String SERVERFEHLER = "Statstik - Serverfehler ";
    static final String BEAT_PAPIERANTRAG = "1";
    static final String BEAT_EANTRAG_OHNE_AUSSTEUERUNG = "2";
    static final String BEAT_EANTRAG_MIT_AUSSTEUERUNG = "3";
    static final String KEIN_ZUKUNFTSOFFENER_AUSLANDSTITEL = "169";
    static final String ALTERSRENTE_VON_23_DER_VOLLRENTE = "163";
    static final String LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSBEZUEGEN = "170";
    static final String LEISTUNGSAUSSCHLUSS_WEGEN_VERSORGUNGSANWARTSCHAFT = "171";
    static final String VERSICHERUNGSRECHTLICHE_VORAUSSETZUNGEN_NICHT_ERFUELLT = "160";
    static final String ABLEHNUNG_AUS_SONSTIGEN_GRUENDEN = "50 ";

    static final String ERLEDIGUNG_AUF_ANDERE_ART_UND_WEISE = "72 ";

    static final String RUECKNAHME_DES_ANTRAGS_VOR_ENTSCHEIDUNG = "70 ";

    static final String ZGAT_STATIONAER = "17";
    static final String DF_KEINE_VORHERIGE_LEISTUNG = "0";
    static final String DF_GANZTAEGIG_AMBULANT = "2";
    static final String DF_AMBULANT = "3";
    static final String AT731_TAGE = "1";
    static final String AT731_WOCHE = "2";
    static final String ZKPY_SONSTIGE_GRUENDE = "6";
    static final String ZKBY_FRISTGERECHT_GEPRUEFT = "0";
    static final String MTEP_ERFUELLT = "80";
    static final String MTEP_NICHT_ERFUELLT = "85";
    static final String MTEP_STORNO = "98";
    static final String TRAININGSPHASE = "Trainingsphase";
    static final String STARTPHASE = "Startphase";

    private StatistikKonstanten() {
    }
}
