/**
 * Beinhaltet JPA Entities für KontoInformationen.
 */
package de.deutscherv.rvsm.fa.fit.kontoinformation.model;
