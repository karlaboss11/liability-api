package de.deutscherv.rvsm.fa.fit.log;

import de.deutscherv.rvsm.ba.observe.quarkus.cef.logging.runtime.CEF;
import de.deutscherv.rvsm.ba.observe.quarkus.cef.logging.runtime.CefLogRecordBuilder;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * CEF-Logger.
 */
@ApplicationScoped
public class CEFLogger {

    /**
     * Erstellt eien CefLogRecordBuilder bei Level High.
     *
     * @param eventType    Event-Type
     * @param eventClassId Event-Class-ID
     * @return erstellten CefLogREcordBuilder
     */
    public CefLogRecordBuilder atHigh(final CEFEventType eventType, final int eventClassId) {
        return CEF.atHigh(eventType.getValue(), eventClassId);
    }

    /**
     * Erstellt eien CefLogRecordBuilder bei Level Debug.
     *
     * @param eventType    Event-Type
     * @param eventClassId Event-Class-ID
     * @return erstellten CefLogREcordBuilder
     */
    public CefLogRecordBuilder atDebug(final CEFEventType eventType, final int eventClassId) {
        return CEF.atMedium(eventType.getValue(), eventClassId);
    }

    /**
     * Erstellt eien CefLogRecordBuilder bei Level Medium.
     *
     * @param eventType    Event-Type
     * @param eventClassId Event-Class-ID
     * @return erstellten CefLogREcordBuilder
     */
    public CefLogRecordBuilder atMedium(final CEFEventType eventType, final int eventClassId) {
        return CEF.atMedium(eventType.getValue(), eventClassId);
    }

    /**
     * Erstellt eien CefLogRecordBuilder bei Level Crititcal.
     *
     * @param eventType    Event-Type
     * @param eventClassId Event-Class-ID
     * @return erstellten CefLogREcordBuilder
     */
    public CefLogRecordBuilder atCritical(final CEFEventType eventType, final int eventClassId) {
        return CEF.atCritical(eventType.getValue(), eventClassId);
    }

    /**
     * Erstellt eien CefLogRecordBuilder bei Unauthorized.
     *
     * @param act           Device-Action
     * @param customerKey   Customer-Key
     * @param dhost         Host
     * @param msg           Nachricht
     * @param reason        Grund
     * @param request       Anfrage
     * @param requestMethod Anfragemethode
     * @param spriv         Spriv
     * @param src           Source
     * @param suser         S-User
     * @return erstellten CefLogREcordBuilder
     */
    public CefLogRecordBuilder unauthorized(final String src, final String dhost, final String suser, final String spriv,
            final CEF.DeviceAction act,
            final String reason, final String request, final String requestMethod, final String msg, final Long customerKey) {
        return CEF.unauthorized(src, dhost, suser, spriv, act, reason, request, requestMethod, msg, customerKey);
    }

}
