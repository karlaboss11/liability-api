package de.deutscherv.rvsm.fa.fit.antraege.mapper;

import de.deutscherv.rvsm.fa.fit.antraege.model.AntragStatus;
import de.deutscherv.rvsm.fa.fit.openapi.model.AntragStatusDto.StatusEnum;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.ValueMapping;

/**
 * Mapper fuer AntragStatus.
 */
@Mapper(componentModel = MappingConstants.ComponentModel.JAKARTA,
        unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface AntragStatusMapper {

    /**
     * Mappt den Status des Antrags.
     *
     * @param antragStatus des Antrags
     * @return der Status des Antrags für das Frontend
     */
    @ValueMapping(source = "ENTWURF", target = "ENTWURF")
    @ValueMapping(source = "VORGANG_WIRD_ERSTELLT", target = "VORGANG_WIRD_ERSTELLT")
    @ValueMapping(source = "VORGANG_ERZEUGT", target = "VORGANG_ERZEUGT")
    @ValueMapping(source = "STATISTIK_ERFASST", target = "STATISTIK_ERFASST")
    @ValueMapping(source = "PAPIERANTRAG_GESPEICHERT", target = "PAPIERANTRAG_GESPEICHERT")
    @ValueMapping(source = "AUTOMATISCH", target = "AUTOMATISCH")
    @ValueMapping(source = "PERSONENDATEN_AUFGABE_ERSTELLT", target = "PERSONENDATEN_AUFGABE_ERSTELLT")
    @ValueMapping(source = "RVPUR_AUFGABE_GESCHLOSSEN", target = "RVPUR_AUFGABE_GESCHLOSSEN")
    @ValueMapping(source = "ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT", target = "ANSPRUECHSPRUEFUNG_AUFGABE_ERSTELLT")
    @ValueMapping(source = "BESCHEID_ABGESCHLOSSEN", target = "BESCHEID_ABGESCHLOSSEN")
    @ValueMapping(source = "STATISTIK_ABGESCHLOSSEN", target = "STATISTIK_ABGESCHLOSSEN")
    @ValueMapping(source = "AUFGABE_ABGESCHLOSSEN", target = "AUFGABE_ABGESCHLOSSEN")
    @ValueMapping(source = "BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT", target = "BEMERKUNG_ODER_ANHANG_AUFGABE_ERSTELLT")
    @ValueMapping(source = "AUFGABE_SCHLIESSEN_OHNE_STATISTIK", target = "AUFGABE_SCHLIESSEN_OHNE_STATISTIK")
    @ValueMapping(source = "STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN", target = "STAMMDATEN_FEHLER_AUFGABE_ERSTELLEN")
    @ValueMapping(source = "STAMMDATEN_FEHLER_AUFGABE_ERSTELLT", target = "STAMMDATEN_FEHLER_AUFGABE_ERSTELLT")
    @ValueMapping(source = "STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN", target = "STAMMDATEN_FEHLER_AUFGABE_SCHLIESSEN")
    @ValueMapping(source = "KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN", target = "KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLEN")
    @ValueMapping(source = "KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT", target = "KONTOINFORMATION_FEHLER_AUFGABE_ERSTELLT")
    @ValueMapping(source = "KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN", target = "KONTOINFORMATION_FEHLER_AUFGABE_SCHLIESSEN")
    @ValueMapping(source = "KONTOINFORMATION_ABGEFRAGT", target = "KONTOINFORMATION_ABGEFRAGT")
    @ValueMapping(source = "STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN", target = "STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLEN")
    @ValueMapping(source = "STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT", target = "STATISTIKERFASSUNG_FEHLER_AUFGABE_ERSTELLT")
    @ValueMapping(source = "STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN", target = "STATISTIKERFASSUNG_FEHLER_AUFGABE_SCHLIESSEN")
    @ValueMapping(source = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN", target = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_SCHLIESSEN")
    @ValueMapping(source = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT", target = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLT")
    @ValueMapping(source = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN", target = "STATISTIKABSCHLUSS_FEHLER_AUFGABE_ERSTELLEN")
    @ValueMapping(source = "DOPPELVERGABE_AUFGABE_SCHLIESSEN", target = "DOPPELVERGABE_AUFGABE_SCHLIESSEN")
    StatusEnum toDto(AntragStatus antragStatus);

    /**
     * Mappt den Status des Antrags aus dem Frontend.
     *
     * @param dto Status des Antrags aus dem Frontend
     * @return der Status des Antrags
     */
    @InheritInverseConfiguration
    AntragStatus toEntity(StatusEnum dto);
}
